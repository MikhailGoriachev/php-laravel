﻿

<?php $__env->startSection('title', ($isAdd ? 'Добавление' : 'Изменение') . ' работника'); ?>

<?php $__env->startSection('workersActive', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <div class="min-vh-100">
        <section class="w-50 mx-auto my-4 bg-light shadow-sm border rounded-3 p-3">


            <form action="<?php echo e($isAdd ? '/workers/add' : '/workers/edit'); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <h4 class="text-center mb-4"><?php echo e(($isAdd ? 'Добавление' : 'Изменение') . ' работника'); ?></h4>

                
                <input type="hidden" name="id" value="<?php echo e(($id ?? old('id')) ?? 0); ?>">

                
                <input type="hidden" name="image" value="<?php echo e(($image ?? old('image')) ?? ''); ?>">

                
                <div class="form-floating my-3">
                    <input name="fullName" class="form-control <?php $__errorArgs = ['fullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                           placeholder=" "
                           value="<?php echo e(($fullName ?? old('fullName')) ?? null); ?>">
                    <label class="form-label">Фамилия и инициалы</label>
                </div>

                <?php $__errorArgs = ['fullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                
                <div class="form-floating my-3">
                    <select name="position" class="form-select <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__currentLoopData = $positionList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($pos); ?>" <?php echo e(($pos === (($position ?? old('position')) ?? '') ? 'selected' : '')); ?>><?php echo e($pos); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label class="form-label">Должность</label>
                </div>

                <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                
                <div class="form-floating my-3">
                    <select name="gender" class="form-select <?php $__errorArgs = ['$gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="1" <?php echo e((($gender ?? old('gender') ) ?? true) ? 'selected' : ''); ?>>Мужской</option>
                        <option value="0" <?php echo e(!(($gender ?? old('gender') ) ?? false) ? 'selected' : ''); ?>>Женский</option>
                    </select>
                    <label class="form-label">Пол</label>
                </div>

                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                
                <div class="form-floating my-3">
                    <input name="yearOfEmployment" class="form-control <?php $__errorArgs = ['yearOfEmployment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           type="number" placeholder=" "
                           value="<?php echo e(($yearOfEmployment ?? old('yearOfEmployment')) ?? null); ?>">
                    <label class="form-label">Год трудоустройства</label>
                </div>

                <?php $__errorArgs = ['yearOfEmployment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                
                <div class="form-floating my-3">
                    <input name="salary" class="form-control <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number"
                           placeholder=" "
                           value="<?php echo e(($salary ?? old('salary')) ?? null); ?>">
                    <label class="form-label">Оклад (&#8381;)</label>
                </div>

                <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                
                <div class="form-floating my-3">
                    <input name="photo" type="file" class="form-control p-5 <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder=" "
                           value="<?php echo e(old('photo')); ?>">
                    <label class="form-label">Файл изображения</label>
                </div>

                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                <div class="mt-5">
                    <input class="btn btn-primary w-10rem me-2" type="submit"
                           value="<?php echo e($isAdd ? 'Добавить' : 'Сохранить'); ?>">
                    <a class="btn btn-secondary w-10rem" href="/workers/allData">Назад</a>
                </div>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\17 Занятие ПД011 22.12.2022 PHP\HW\Горячев Михаил\resources\views/workers/workerForm.blade.php ENDPATH**/ ?>