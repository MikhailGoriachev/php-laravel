﻿

<?php $__env->startSection('title', 'О разработчике'); ?>

<?php $__env->startSection('aboutActive', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <div class="min-vh-100">
        <section class="w-50 mx-auto my-4 bg-light shadow-sm border rounded-3 p-3">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="border rounded bg-white shadow-sm">
                            <img class="w-100" src="images/icon.svg" alt="">
                        </div>
                    </div>
                    <div class="col-auto">
                        <ul class="list-group shadow-sm">
                            <li class="list-group-item">
                                Разработчик:
                                <a href="https://github.com/MikhailGoriachev" target="_bank">
                                    <b>Горячев Михаил</b>
                                </a>
                            </li>
                            <li class="list-group-item">
                                Группа: <b>ПД011</b>
                            </li>
                            <li class="list-group-item">
                                Город: <b>Донецк</b>
                            </li>
                            <li class="list-group-item">
                                Год создания: <b>2022</b>
                            </li>
                            <li class="list-group-item">
                                Поддержка:
                                <a href="mailto:goriachevmichael@gmail.com">
                                    <b>goriachevmichael@gmail.com</b>
                                </a>
                            </li>
                        </ul>

                        <div class="text-center mt-5">
                            <a class="btn btn-secondary w-10rem" href="/">На главную</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\14. 15.12.2022 -\2. Home work\home-work\resources\views/home/about.blade.php ENDPATH**/ ?>