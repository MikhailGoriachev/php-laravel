﻿

<?php $__env->startSection('title', 'Текст'); ?>

<?php $__env->startSection('textActive', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">
        <h4 class="text-center">Текст</h4>

        <div class="border shadow-sm rounded bg-white my-4">
            <h5 class="m-4"><?php echo e($str); ?></h5>
        </div>

        <div class="row">

            <div class="col">
                <ul class="list-group">
                    <li class="list-group-item bg-secondary text-white">
                        Слова нач. и зак. на одну букву регистрозависимо: <?php echo e($amountWordsStartEndSensitive); ?>

                    </li>

                    <?php $__currentLoopData = $wordsStartEndSensitive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php echo e($key); ?> (<?php echo e($value); ?>)
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="col">
                <ul class="list-group">
                    <li class="list-group-item bg-secondary text-white">
                        Слова нач. и зак. на одну букву
                        регистронезависимо: <?php echo e($amountWordsStartEndInsensitive); ?>

                    </li>

                    <?php $__currentLoopData = $wordsStartEndInsensitive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php echo e($key); ?> (<?php echo e($value); ?>)
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="col">
                <ul class="list-group">
                    <li class="list-group-item bg-secondary text-white">
                        Количество слов с заданной длиной (<?php echo e($length); ?>): <?php echo e($amountWordsLenLetters); ?>

                    </li>

                    <?php $__currentLoopData = $wordsLenLetters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php echo e($key); ?> (<?php echo e($value); ?>)
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </div>

        <div class="ms-3 my-5">
            <a class="btn btn-primary me-2"
               href="/textForm/<?php echo e($str); ?>/<?php echo e($length); ?>">
                Ввод текста
            </a>
            <a class="btn btn-secondary" href="/">На главную</a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\13. 12.12.2022 -\2. Home work\home-work\resources\views/calculate/text.blade.php ENDPATH**/ ?>