<?php

namespace App\Models;

use Illuminate\Support\Facades\Date;

class Worker
{
    public int $id;            //идентификатор работника
    public string $fullName;   //фамилия и инициалы работника
    public string $post;       //название занимаемой должности
    public bool $gender;       //пол
    public int $year;          //год поступления на работу
    public string $photo;      //имя файла с фотографией работника
    public int $salary;        //величина оклада работника

    //метод вычисления стажа работника для текущей даты
    public function getExperience():int{
        return 2000 +  date('y') - $this->year;
    }

    public function __construct(int $id = 0, string $fullName = " ",  string $post =" ",   bool $gender = true,   int $year = 0,  string $photo = " ",  int $salary = 0){
        $this->id = $id;
        $this->fullName = $fullName;
        $this->post = $post;
        $this->gender = $gender;
        $this->year = $year;
        $this->photo = $photo;
        $this->salary = $salary;
    }

    public function setDataFromArray(array $data):Worker{

        $this->id = +$data['id'];
        $this->fullName = $data['fullName'];
        $this->post = $data['post'];
        $this->gender = +$data['gender'];
        $this->year = +$data['year'];
        $this->photo = $data['photo'];
        $this->salary = +$data['salary'];

        return $this;

    }

}
