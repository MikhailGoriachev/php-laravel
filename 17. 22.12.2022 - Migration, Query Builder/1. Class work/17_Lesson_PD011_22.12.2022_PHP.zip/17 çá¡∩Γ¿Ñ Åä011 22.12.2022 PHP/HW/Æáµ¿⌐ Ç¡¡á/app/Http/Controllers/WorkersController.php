<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Worker;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;

class WorkersController extends Controller
{
    // объект для обработки
    private Collection $workers_;

    // имя файла с данными
    private string $fileName_;

    public function __construct(){

        $disk = Storage::disk('local');
        $this->fileName_ = "workers.json";

        if(!$disk->exists($this->fileName_)){

            $this->workers_ = collect([

                new  Worker(1,"Захарова С. М.",     "диспетчер", false, 2020,"woman_001.jpg",30000),
                new  Worker(2,"Волкова Д. В.",      "менеджер",  false, 2010,"woman_002.jpg",40000),
                new  Worker(3,"Любимов А. К.",      "металлург", true,  2021,"man_001.jpg",  50000),
                new  Worker(4,"Сорокин Р. М.",      "инженер",   true,  2015,"man_002.jpg",  70000),
                new  Worker(5,"Колпакова Т. М.",    "переводчик",false, 2016,"woman_003.jpg",50000),
                new  Worker(6,"Титов В. Л.",        "товаровед", true,  2012,"man_003.jpg",  60000),
                new  Worker(7,"Мельников Г. С.",    "юрист",     true,  2017,"man_004.jpg",  70000),
                new  Worker(8,"Семенова М. А.",     "секретарь", false, 2012,"woman_004.jpg",50000),
                new  Worker(9,"Фокина С. Д.",       "лаборант",  false, 2017,"woman_005.jpg",40000),
                new  Worker(10,"Кожевникова Т. М.", "экспедитор",false, 2019,"woman_006.jpg",50000),
                new  Worker(11,"Соловьев М. Ф.",    "грузчик",   true,  2021,"man_005.jpg",  30000),
                new  Worker(12,"Харитонов Д. С.",   "дизайнер",  true,  2021,"man_006.jpg",  60000),

            ]);

            $this->save();
        }

        else{

            $this->read();
        }

    }

    //сохранение в файл
    private function save(){

        $disk = Storage::disk('local');
        $disk->put("workers.json" , json_encode($this->workers_));
    }

    private function read(){

        $disk = Storage::disk('local');
        $this->workers_ = collect(json_decode($disk->get($this->fileName_), true))->map(fn($a) => (new Worker())->setDataFromArray($a));
    }

    public function show() : View{

        $workers = $this->workers_->sortBy('fullName');
        return view('workers.details-workers', ['workers' =>  $workers->all()]);
    }

    public function showAddForm() : View{
        return view('workers.add-worker', ['isAdd' => true]);
    }

    public function showEditForm($id) :  View{

        $worker = $this->workers_->firstWhere('id', +$id);

        return view('workers.add-worker',['isAdd' => false,
            'id' =>  $worker->id,
            'fullName' => $worker->fullName,
            'post' => $worker->post,
            'gender' => $worker->gender,
            'year' => $worker->year,
            'image' => $worker->photo,
            'salary' => $worker->salary]);
    }

    // добавление записи
    public function addWorker(Request $request) : View{

        $validatedData = $request->validate([

            'fullName' => 'bail|required|min:2',
            'year' => 'bail|required|numeric|min:2000|max:2022',
            'salary' => 'bail|required|numeric|min:16000|max:45000000',
            'photo' => 'required',
            'post' => 'required',
            'gender' => 'required'
        ]);

        $data = $validatedData;

        // сохранение в storage/app/uploaded с автосегенерированным именем,
        // расширеник имени файла определяется по контенту (по MIME-типу)
         $file = $request->file('photo');
         $file->store('public/uploaded');
         $data['photo'] = $file->hashName();

        $this->workers_->prepend((new Worker())->setDataFromArray([...$data,
            'id' => ($this->workers_->isEmpty() ? 1 : $this->workers_->max('id') + 1)]));

        $this->save();

        return $this->show();
    }

    //редактирование рабочего
    public function editWorker(Request $request)  : View{

        $validatedData = $request->validate([

            'id' => 'required',
            'image' => 'required',
            'fullName' => 'bail|required|min:2',
            'year' => 'bail|required|numeric|min:2000|max:2022',
            'salary' => 'bail|required|numeric|min:16000|max:45000000',
            'post' => 'required',
            'gender' => 'required'
        ]);

        $data = $validatedData;

        //если был загружен новый файл
        if ($request->file('photo') !== null){
            $file = $request->file('photo');
            $file->store('public/uploaded');
            $data['photo'] = $file->hashName();
        } else {
            $data['photo'] = $data['image'];
        }

        $this->workers_->firstWhere('id', +$data['id'])->setDataFromArray($data);

        $this->save();

        return $this->show();
    }

    //удаление работника
    public function delete($id): View{

        $this->workers_ = $this->workers_->reject(fn($a) => $a->id === +$id);

        $this->save();

        return $this->show();

    }

    // работники с максимальным окладом
    public function showMaxSalary(): View{

        $workers = $this->workers_->sortBy('post');
        $max = $this->workers_->max('salary')?? 0;

        return view('workers.details-workers', ['workers' => $workers->all(), 'predicate' => fn($w) => $w->salary === $max]);
    }

    // работники с минимальным окладом
    public function showMinSalary(): View{

        $workers = $this->workers_->sortBy('fullName');
        $min = $this->workers_->min('salary')?? 0;

        return view('workers.details-workers', ['workers' => $workers->all(), 'predicate' => fn($w) => $w->salary === $min]);
    }


}
