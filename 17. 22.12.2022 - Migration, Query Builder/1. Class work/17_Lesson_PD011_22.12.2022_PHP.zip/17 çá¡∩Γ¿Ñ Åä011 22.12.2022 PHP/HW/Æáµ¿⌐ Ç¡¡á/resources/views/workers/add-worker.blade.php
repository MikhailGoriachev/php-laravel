@extends('layouts.app')

@section('title', 'Добавление работника')

<!-- секция контент -->
@section('content')

    <form method="post" class="w-50" action="{{$isAdd ? '/workers/add' : "/workers/edit" }}" enctype="multipart/form-data">
        @csrf

        <p class="mt-4 ms-3 mb-4 fs-4" >Введите данные работника:</p>

        <input type="hidden" name="id" value="{{$id ?? 0}}">
        <input type="hidden" name="image" value="{{$image ?? ''}}">

        <div class="mt-3 ms-3">
            <label class="form-label" for="id_fullName">Фамилия и инициалы работника:</label>
            <input class="form-control @error('fullName') is-invalid @enderror " type="text" name="fullName" id = "id_fullName" value="{{$isAdd ? old('fullName')  : $fullName}}" />
        </div>

        <div class="mt-3 ms-3">
            <label  class="form-label" for="id_post">Название занимаемой должности:</label>
            <select class="form-select" name="post" id="id_post" >
                <option value="диспетчер" {{('диспетчер' === ($post ?? '') ? 'selected' : '')}}>диспетчер</option>
                <option value="менеджер" {{('менеджер' === ($post ?? '') ? 'selected' : '')}}>менеджер</option>
                <option value="металлург" {{('металлург' === ($post ?? '') ? 'selected' : '')}}>металлург</option>
                <option value="инженер" {{('инженер' === ($post ?? '') ? 'selected' : '')}}>инженер</option>
                <option value="переводчик" {{('переводчик' === ($post ?? '') ? 'selected' : '')}}>переводчик</option>
                <option value="товаровед" {{('товаровед' === ($post ?? '') ? 'selected' : '')}}>товаровед</option>
                <option value="юрист" {{('юрист' === ($post ?? '') ? 'selected' : '')}}>юрист</option>
                <option value="секретарь" {{('секретарь' === ($post ?? '') ? 'selected' : '')}}>секретарь</option>
                <option value="лаборант" {{('лаборант' === ($post ?? '') ? 'selected' : '')}}>лаборант</option>
                <option value="экспедитор" {{('экспедитор' === ($post ?? '') ? 'selected' : '')}}>экспедитор</option>
                <option value="грузчик" {{('грузчик' === ($post ?? '') ? 'selected' : '')}}>грузчик</option>
                <option value="дизайнер" {{('дизайнер' === ($post ?? '') ? 'selected' : '')}}>дизайнер</option>
            </select>
        </div>

        <div class="mt-3 ms-3">

             <label class="form-label" for="id_radioButton">Пол (мужской или женский):</label>
            <div id = "id_radioButton">
            <div class="form-check">
                <input class="form-check-input" type="radio"
                       name="gender" id="radio1" value="1" {{$isAdd ? 'checked' : ($gender  ? 'checked' : '')}}>
                <label class="form-check-label" for="radio1">
                    Мужской
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="gender" id="radio2" value="0" {{$isAdd ? '' :  ($gender  ? '' : 'checked')}}>
                <label class="form-check-label" for="radio2">
                    Женский
                </label>
            </div>
            </div>

        </div>

        <div class="mt-3 ms-3">
            <label class="form-label" for="id_year">Год поступления на работу:</label>
            <input class="form-control @error('year') is-invalid @enderror" type="number" name="year" id = "id_year"
                   value = "{{$isAdd ? old('year')  : $year}}"/>
        </div>

        <div class="mt-3 ms-3">
            <label class="form-label" for="id_photo">Файл с фотографией работника:</label>
            <input class="form-control  @error('photo') is-invalid @enderror" type="file" name="photo" id = "id_photo" value="{{ old('photo') }}"/>
        </div>


        <div class="mt-3 ms-3">
            <label class="form-label" for="id_salary">Величина оклада работника:</label>
            <input class="form-control @error('salary') is-invalid @enderror" type="number" name="salary" id = "id_salary" value="{{$isAdd ? old('salary')  : $salary}}"/>
        </div>

        <div class="mt-3 ms-3 d-flex justify-content-end">
        <input class="btn btn-primary" type="submit" value="Отправить" />
        </div>

    </form>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

@endsection
