@extends('layouts.app')

@section('workers', 'active')
@section('title', 'Работники')

<!-- секция контент -->
@section('content')

    <div class="d-flex justify-content-end">
    <div class="btn-group w-75 mb-5 mt-3">

        <a class="btn btn-primary" href="/workers">Исходные данные</a>
        <a class="btn btn-primary " href="/workers/show-max-salary">Максимальный оклад</a>
        <a class="btn btn-primary " href="/workers/show-min-salary">Минимальный оклад</a>
        <a class="btn btn-primary " href="/workers/add-worker">Добавить запись</a>
    </div> </div>

    <p class="m-4 fs-5">Список работников:</p>

    <table class="table">
        <thead>
            <tr class="text-center">
                <th>Id</th>
                <th>Фамилия и инициалы </th>
                <th>Должность</th>
                <th>Пол</th>
                <th>Год поступления</th>
                <th>Фото</th>
                <th>Оклад</th>
                <th>Стаж</th>
                <th></th>
            </tr>
        </thead>

        <tbody>
        @foreach($workers as $item)

            <tr class='text-center {{isset($predicate) && $predicate($item) ? 'bg-fill' : ''}}'>
                <td>{{$item->id}}</td>
                <td>{{$item->fullName}}</td>
                <td>{{$item->post}}</td>
                <td>{{($item->gender === true ? "М": "Ж" )}}</td>
                <td>{{$item->year}}</td>
                <td><img style='width: 100px; border-radius: 100px;' src="{{asset("storage/uploaded/$item->photo")}}" alt="image"/></td>
                <td>{{$item->salary}}</td>
                <td>{{$item->getExperience()}}</td>
                <td class='text-center'>
                    <a class='btn btn-danger' title='Удалить' href="/workers/delete/{{$item->id}}"><i class='bi bi-trash-fill'></i></a>
                    <a class="btn btn-success" title="Изменить" href="/workers/edit-form/{{$item->id}}"><i class="bi bi-pencil-fill"></i></a>
                </td>
            </tr>

        @endforeach

        </tbody>

    </table>

@endsection
