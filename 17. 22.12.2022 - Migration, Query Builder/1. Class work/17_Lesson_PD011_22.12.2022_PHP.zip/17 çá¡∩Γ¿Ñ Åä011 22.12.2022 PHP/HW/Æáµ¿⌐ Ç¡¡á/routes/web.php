<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\WorkersController;

// путь к действию index контроллера home
Route::get('/', [ HomeController::class, 'index' ]);

//список работников
Route::get('/workers', [ WorkersController::class, 'show' ]);

//форма добавления работников
Route::get('/workers/add-worker', [ WorkersController::class, 'showAddForm' ]);

//добавление работников
Route::post('/workers/add', [ WorkersController::class, 'addWorker' ]);

// удаление работника
Route::get('/workers/delete/{id}', [WorkersController::class, 'delete']);

// форма изменение работника
Route::get('/workers/edit-form/{id}', [WorkersController::class, 'showEditForm']);

// изменение работника
Route::post('/workers/edit', [WorkersController::class, 'editWorker']);

// работники с максимальным окладом
Route::get('/workers/show-max-salary', [WorkersController::class, 'showMaxSalary']);

// работники с минимальным окладом
Route::get('/workers/show-min-salary', [WorkersController::class, 'showMinSalary']);
