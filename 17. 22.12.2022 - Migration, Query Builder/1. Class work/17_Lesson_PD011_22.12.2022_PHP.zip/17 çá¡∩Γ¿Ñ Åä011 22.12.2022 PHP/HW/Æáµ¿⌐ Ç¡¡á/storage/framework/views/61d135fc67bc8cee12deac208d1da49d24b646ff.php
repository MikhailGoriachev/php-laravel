<?php $__env->startSection('workers', 'active'); ?>
<?php $__env->startSection('title', 'Работники'); ?>

<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <div class="d-flex justify-content-end">
    <div class="btn-group w-75 mb-5 mt-3">

        <a class="btn btn-primary" href="/workers">Исходные данные</a>
        <a class="btn btn-primary " href="/workers/show-max-salary">Максимальный оклад</a>
        <a class="btn btn-primary " href="/workers/show-min-salary">Минимальный оклад</a>
        <a class="btn btn-primary " href="/workers/add-worker">Добавить запись</a>
    </div> </div>

    <p class="m-4 fs-5">Список работников:</p>

    <table class="table">
        <thead>
            <tr class="text-center">
                <th>Id</th>
                <th>Фамилия и инициалы </th>
                <th>Должность</th>
                <th>Пол</th>
                <th>Год поступления</th>
                <th>Фото</th>
                <th>Оклад</th>
                <th>Стаж</th>
                <th></th>
            </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class='text-center <?php echo e(isset($predicate) && $predicate($item) ? 'bg-fill' : ''); ?>'>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->fullName); ?></td>
                <td><?php echo e($item->post); ?></td>
                <td><?php echo e(($item->gender === true ? "М": "Ж" )); ?></td>
                <td><?php echo e($item->year); ?></td>
                <td><img style='width: 100px; border-radius: 100px;' src="<?php echo e(asset("storage/uploaded/$item->photo")); ?>" alt="image"/></td>
                <td><?php echo e($item->salary); ?></td>
                <td><?php echo e($item->getExperience()); ?></td>
                <td class='text-center'>
                    <a class='btn btn-danger' title='Удалить' href="/workers/delete/<?php echo e($item->id); ?>"><i class='bi bi-trash-fill'></i></a>
                    <a class="btn btn-success" title="Изменить" href="/workers/edit-form/<?php echo e($item->id); ?>"><i class="bi bi-pencil-fill"></i></a>
                </td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\17 Занятие ПД011 22.12.2022 PHP\HW\Таций Анна\resources\views/workers/details-workers.blade.php ENDPATH**/ ?>