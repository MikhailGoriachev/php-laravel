<?php $__env->startSection('title', 'Добавление работника'); ?>

<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <form method="post" class="w-50" action="<?php echo e($isAdd ? '/workers/add' : "/workers/edit"); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <p class="mt-4 ms-3 mb-4 fs-4" >Введите данные работника:</p>

        <input type="hidden" name="id" value="<?php echo e($id ?? 0); ?>">
        <input type="hidden" name="image" value="<?php echo e($image ?? ''); ?>">

        <div class="mt-3 ms-3">
            <label class="form-label" for="id_fullName">Фамилия и инициалы работника:</label>
            <input class="form-control <?php $__errorArgs = ['fullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " type="text" name="fullName" id = "id_fullName" value="<?php echo e($isAdd ? old('fullName')  : $fullName); ?>" />
        </div>

        <div class="mt-3 ms-3">
            <label  class="form-label" for="id_post">Название занимаемой должности:</label>
            <select class="form-select" name="post" id="id_post" >
                <option value="диспетчер" <?php echo e(('диспетчер' === ($post ?? '') ? 'selected' : '')); ?>>диспетчер</option>
                <option value="менеджер" <?php echo e(('менеджер' === ($post ?? '') ? 'selected' : '')); ?>>менеджер</option>
                <option value="металлург" <?php echo e(('металлург' === ($post ?? '') ? 'selected' : '')); ?>>металлург</option>
                <option value="инженер" <?php echo e(('инженер' === ($post ?? '') ? 'selected' : '')); ?>>инженер</option>
                <option value="переводчик" <?php echo e(('переводчик' === ($post ?? '') ? 'selected' : '')); ?>>переводчик</option>
                <option value="товаровед" <?php echo e(('товаровед' === ($post ?? '') ? 'selected' : '')); ?>>товаровед</option>
                <option value="юрист" <?php echo e(('юрист' === ($post ?? '') ? 'selected' : '')); ?>>юрист</option>
                <option value="секретарь" <?php echo e(('секретарь' === ($post ?? '') ? 'selected' : '')); ?>>секретарь</option>
                <option value="лаборант" <?php echo e(('лаборант' === ($post ?? '') ? 'selected' : '')); ?>>лаборант</option>
                <option value="экспедитор" <?php echo e(('экспедитор' === ($post ?? '') ? 'selected' : '')); ?>>экспедитор</option>
                <option value="грузчик" <?php echo e(('грузчик' === ($post ?? '') ? 'selected' : '')); ?>>грузчик</option>
                <option value="дизайнер" <?php echo e(('дизайнер' === ($post ?? '') ? 'selected' : '')); ?>>дизайнер</option>
            </select>
        </div>

        <div class="mt-3 ms-3">

             <label class="form-label" for="id_radioButton">Пол (мужской или женский):</label>
            <div id = "id_radioButton">
            <div class="form-check">
                <input class="form-check-input" type="radio" name="gender" id="radio1" value="1" <?php echo e($isAdd ? 'checked' : ($gender  ? 'checked' : '')); ?>>
                <label class="form-check-label" for="radio1">
                    Мужской
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="gender" id="radio2" value="0" <?php echo e($isAdd ? '' :  ($gender  ? '' : 'checked')); ?>>
                <label class="form-check-label" for="radio2">
                    Женский
                </label>
            </div>
            </div>

        </div>

        <div class="mt-3 ms-3">
            <label class="form-label" for="id_year">Год поступления на работу:</label>
            <input class="form-control <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" name="year" id = "id_year"  value = "<?php echo e($isAdd ? old('year')  : $year); ?>"/>
        </div>

        <div class="mt-3 ms-3">
            <label class="form-label" for="id_photo">Файл с фотографией работника:</label>
            <input class="form-control  <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="photo" id = "id_photo" value="<?php echo e(old('photo')); ?>"/>
        </div>


        <div class="mt-3 ms-3">
            <label class="form-label" for="id_salary">Величина оклада работника:</label>
            <input class="form-control <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" name="salary" id = "id_salary" value="<?php echo e($isAdd ? old('salary')  : $salary); ?>"/>
        </div>

        <div class="mt-3 ms-3 d-flex justify-content-end">
        <input class="btn btn-primary" type="submit" value="Отправить" />
        </div>

    </form>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annat\source\repos\PHP\Step_17.12.22(Таций Анна)_PHP\Step171222\resources\views/workers/add-worker.blade.php ENDPATH**/ ?>