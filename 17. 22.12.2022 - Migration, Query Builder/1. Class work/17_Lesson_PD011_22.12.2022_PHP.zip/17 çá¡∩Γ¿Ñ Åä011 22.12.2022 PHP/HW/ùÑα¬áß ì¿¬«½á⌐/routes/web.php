<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\WorkController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// задание
Route::get('/', [IndexController::class, 'home'])->name('home');
// о разработчике
Route::get('/about', [IndexController::class, 'about'])->name('about');
// работники
Route::get('/work', [WorkController::class, 'show_work'])->name('work');
// получение формы редактирование
Route::get('/worker/editForm/{id?}', [WorkController::class, 'editForm']);
// редактирование
Route::post('/worker/editForm/edit/{id}', [WorkController::class, 'edit']);
// удаление
Route::get('worker/delete/{id}', [WorkController::class, 'delete']);
//форма добавление
Route::get('/worker/addForm', [WorkController::class, 'addForm'])->name('addForm');
// добавление
Route::post('/worker/addForm/add', [WorkController::class, 'add']);


