<?php

namespace App\Http\Controllers;

use App\Http\Requests\WorkerRequest;
use Illuminate\Http\Request;
use App\Models\Worker;
use Illuminate\Support\Facades\Storage;

class WorkController extends Controller
{
    private string $fileName_ = 'workers.json';
    private int $id2 = -1;

    private Worker $worker;
    public function __construct(){
        if (Storage::disk('local')->missing($this->fileName_)){
            $this->fillFile();
        }
    }
    // создание файла
    public function fillFile(){
        $workers = [
            new  Worker(1,"Захарова С. М.",     "диспетчер", "женщина", 2020,"woman_01.jpg",30000),
            new  Worker(2,"Волкова Д. В.",      "менеджер",  'женщина', 2010,"woman_02.jpg",40000),
            new  Worker(3,"Любимов А. К.",      "металлург", 'мужчина',  2021,"man_01.jpg",  50000),
            new  Worker(4,"Сорокин Р. М.",      "инженер",   'мужчина',  2015,"man_02.jpg",  70000),
            new  Worker(5,"Колпакова Т. М.",    "переводчик",'женщина', 2016,"woman_03.jpg",50000),
            new  Worker(6,"Титов В. Л.",        "товаровед", 'мужчина',  2012,"man_03.jpg",  60000),
            new  Worker(8,"Семенова М. А.",     "секретарь", 'женщина', 2012,"woman_04.jpg",50000),
            new  Worker(9,"Фокина С. Д.",       "лаборант",  'женщина', 2017,"woman_05.jpg",40000),
            new  Worker(10,"Кожевникова Т. М.", "экспедитор",'женщина', 2019,"woman_06.jpg",50000),
        ];
        $this->write_json($workers);
    }
    // запись json
    public function write_json($list){
        $disk = Storage::disk('local')->put($this->fileName_, json_encode($list));
    }
    // чтение json
    public function read_json(){
        return Storage::disk('local')->get($this->fileName_);
    }
    // вывод таблицы работников
    public function show_work(){
        $workers = $this->read_json();
        return view('show_work', ['workers' => $workers]);
    }
    // форма для редактирование работника
    public function editForm(int $id){
        $this->id2 = $id;
        $worker = collect(json_decode($this->read_json()))
            ->first(function ($value, $key){ return $value->id == $this->id2; });
        return view('editForm', ['worker' => $worker, 'id' => $id]);
    }
    // редактирование
    public function edit(WorkerRequest $req, int $id){
        if ($req->hasFile('images')){
            $image = $req->file('images');
            $path = $image->store('images',
                $image->getClientOriginalName());// . $image->getClientOriginalExtension(), 'public');
        }
        $surname = $req->input('surname');
        $post = $req->input('post');
        $gender = $req->input('gender');
        $year = $req->input('year');
        $photo = $req->input('photo', '');
        $salary = $req->input('salary');
        $this->worker = new Worker($id, $surname, $post, $gender, $year, $photo, $salary);
        $temp = collect(json_decode($this->read_json()));
        // по id находим работника и заменяем
        for($i = 0; $i < $temp->count(); $i++){
            if ($temp[$i]->id == $id){
                $temp[$i] = $this->worker;
            }
        }
        $this->write_json($temp);
        return view('show_work', ['workers' => $temp]);
    }
    // форма добавления
    public function addForm(){
        return view('addForm');
    }
    // добавить
    public function add(WorkerRequest $req){
        $path = '';
        $id = collect(json_decode($this->read_json()))->count() + 1;
        if ($req->hasFile('images')){
            $image = $req->file('images');
            $path = $image->store('images',
                $image->getClientOriginalName());// . $image->getClientOriginalExtension(), 'public');
        }
        $surname = $req->input('surname');
        $post = $req->input('post');
        $gender = $req->input('gender');
        $year = $req->input('year');
        $photo = $path;
        $salary = $req->input('salary');
        $this->worker = new Worker($id, $surname, $post, $gender, $year, $photo, $salary);
        $temp = collect(json_decode($this->read_json()));
        $temp->push($this->worker);
        $this->write_json($temp);
        return view('show_work', ['workers' => $temp]);
    }
    // удаление
    public function delete(int $id){
        $this->id2 = $id;
        $workers = collect(json_decode($this->read_json()))
            ->filter(function ($value, $key){ return $value->id != $this->id2; });
        $this->id2 = 1;
        $workers->each(function ($item){
            $item->id = $this->id2++;
        });
        $this->write_json($workers);
        return view('show_work', ['workers' => $workers]);
    }
}
