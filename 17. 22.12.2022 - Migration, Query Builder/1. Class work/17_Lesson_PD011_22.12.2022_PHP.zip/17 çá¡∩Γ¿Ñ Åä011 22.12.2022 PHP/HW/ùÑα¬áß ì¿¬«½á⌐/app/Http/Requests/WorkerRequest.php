<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class WorkerRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'surname' => 'required',
            'post' => 'required',
            'gender' => 'required',
            'year' => 'required|numeric',
            'photo' => 'sometimes',
            'salary' => 'required|numeric'
        ];
    }

    // вывод сообщений
    public function messages()
    {
        return [
            'surname.required' => 'поле фамилия должно быть заполнено',
            'post.required' => 'поле должность должно быть заполнено',
            'gender.required' => 'поле пол должно быть заполнено',
            'year.required' => 'поле год зачисления должно быть заполнено',
            'year.numeric' => 'поле год должно быть числовым',
            'salary.required' => 'поле оклад должно быть заполнено'
        ];
    }
}
