<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Worker
{
    public int $id;
    public string $surname;
    public string $post;
    public string $gender;
    public int $year;
    public string $photo;
    public int $salary;

    public function __construct($id, $surname, $post, $gender, $year, $photo, $salary)
    {
        $this->id = $id;
        $this->surname = $surname;
        $this->post = $post;
        $this->gender = $gender;
        $this->year = $year;
        $this->photo = $photo;
        $this->salary = $salary;
    }

    static public function timeWork($year){
        return date('Y') - $year;
    }

    public function __toString()
    {
        return "$this->id $this->surname $this->post $this->gender $this->year $this->photo $this->salary";
    }


}
