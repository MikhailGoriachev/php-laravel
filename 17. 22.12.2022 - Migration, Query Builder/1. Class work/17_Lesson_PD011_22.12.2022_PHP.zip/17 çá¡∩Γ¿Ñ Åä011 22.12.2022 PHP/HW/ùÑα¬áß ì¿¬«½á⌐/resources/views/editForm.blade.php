@extends('layouts.app')

@section('title')
    редактирование
@endsection

@section('content')
    <form class="p3 bg-light w-50" action="/worker/editForm/edit/{{$id}}" method="post" enctype="multipart/form-data">
        @csrf

        <div class="mb-3 mt-3">
            <label class="form-label" for="surname">Фамилия</label>
            <input type="text" class="form-control " id="surname" placeholder="Фамилия И.О." name="surname" value="{{$worker->surname}}">
        </div>

        <div class="mb-3">
            <label class="form-label" for="post">Должность</label>
            <input type="text" class="form-control" id="post" placeholder="должность" name="post" value="{{$worker->post}}">
        </div>

        <div class="mb-3">
            <label class="form-label" for="gender">Пол</label>
            <input type="text" class="form-control" id="gender" placeholder="пол" name="gender" value="{{$worker->gender}}">
        </div>

        <div class="mb-3">
            <label class="form-label" for="year">Зачисление в штат</label>
            <input type="number" class="form-control" id="year" placeholder="год зачисления" name="year" value="{{$worker->year}}">
        </div>

        <div class="mb-3">
            <label class="form-label" for="photo">Файл фото</label>
            <input type="file" class="form-control" id="photo" placeholder="файл фото jpg" name="photo">
        </div>

        <div class="mb-3">
            <label class="form-label" for="salary">Оклад</label>
            <input type="number" class="form-control" id="salary" placeholder="оклад" name="salary" value="{{$worker->salary}}">
        </div>

        <div class="mt-3">
            <button type="submit" class="btn btn-success">Готово</button>
            <input class="btn btn-secondary" type="reset" value="Сбросить">
        </div>
    </form>






@endsection
