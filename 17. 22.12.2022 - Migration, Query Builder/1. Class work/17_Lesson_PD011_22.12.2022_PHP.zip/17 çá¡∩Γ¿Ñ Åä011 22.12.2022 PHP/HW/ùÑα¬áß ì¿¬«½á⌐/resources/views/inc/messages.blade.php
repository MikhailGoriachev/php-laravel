@if (session('success'))
    <div class="alert alert-success w-50">
        {{session('success')}}
    </div>
@endif

@if($errors->any())
    <div class='alert alert-danger w-50'>
        @foreach($errors->all() as $error)
            <li>{{$error}}</li>
        @endforeach
    </div>
@endif
