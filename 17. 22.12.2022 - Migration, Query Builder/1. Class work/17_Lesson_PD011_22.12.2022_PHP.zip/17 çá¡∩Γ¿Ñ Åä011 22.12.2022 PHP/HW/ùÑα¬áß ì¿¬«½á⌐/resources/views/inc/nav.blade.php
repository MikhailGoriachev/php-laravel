<nav class=" d-inline-flex mt-2 mt-md-0">
    <a class="me-3 py-2 text-decoration-none" href="{{route('home')}}">Задание</a>
    <a class="me-3 py-2 text-decoration-none" href="{{route('about')}}">Разработчик</a>
    <a class="me-3 py-2 text-decoration-none" href="{{route('work')}}">Работники</a>
</nav>
