@extends('layouts.app')
@section('title')
    сотрудники
@endsection
@section('content')
    <table >
        <thead>
        <th>Фото</th>
        <th></th>
        <th>фамилия</th>
        <th>Должност</th>
        <th>Пол</th>
        <th>Принят</th>
        <th>Оклад</th>
        <th>Стаж</th>
        <th></th>
        </thead>
        <tbody>

    @foreach(json_decode($workers) as $lis)
        <tr class="align-middle fst-italic">
            <td><img src="{{asset("storage/images/$lis->photo")}}" style="height: 80px" alt="image"></td>
            <td class="text-center">{{$lis->id}}</td>
            <td>{{$lis->surname}}</td>
            <td>{{$lis->post}}</td>
            <td>{{$lis->gender}}</td>
            <td>{{$lis->year}}</td>
            <td>{{$lis->salary}}</td>
            <td>{{\App\Models\Worker::timeWork($lis->year)}}</td>
            <td class="text-center">
                <a class="btn btn-success" href="/worker/editForm/{{$lis->id}}" title="Изменить...">
                    <i class="bi bi-pencil"></i>
                </a>
                <a class="btn btn-danger" href="/worker/delete/{{$lis->id}}" title="Удалить">
                    <i class="bi bi-file-x"></i>
                </a>
            </td>
        </tr>
    @endforeach
        </tbody>
    </table>
@endsection

@section('content2')
    <div class="btn-group-vertical gap-3">
        <a class="btn btn-secondary" href="/worker/addForm">Добавить</a>
        <a class="btn btn-secondary"  ></a>
        <a class="btn btn-secondary"  ></a>
    </div>
@endsection
