<?php $__env->startSection('title'); ?>
    сотрудники
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <table >
        <thead>
        <th>Фото</th>
        <th></th>
        <th>фамилия</th>
        <th>Должност</th>
        <th>Пол</th>
        <th>Принят</th>
        <th>Оклад</th>
        <th>Стаж</th>
        <th></th>
        </thead>
        <tbody>

    <?php $__currentLoopData = json_decode($workers); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="align-middle fst-italic">
            <td><img src="<?php echo e(asset("storage/images/$lis->photo")); ?>" style="height: 80px" alt="image"></td>
            <td class="text-center"><?php echo e($lis->id); ?></td>
            <td><?php echo e($lis->surname); ?></td>
            <td><?php echo e($lis->post); ?></td>
            <td><?php echo e($lis->gender); ?></td>
            <td><?php echo e($lis->year); ?></td>
            <td><?php echo e($lis->salary); ?></td>
            <td><?php echo e(\App\Models\Worker::timeWork($lis->year)); ?></td>
            <td class="text-center">
                <a class="btn btn-success" href="/worker/editForm/<?php echo e($lis->id); ?>" title="Изменить...">
                    <i class="bi bi-pencil"></i>
                </a>
                <a class="btn btn-danger" href="/worker/delete/<?php echo e($lis->id); ?>" title="Удалить">
                    <i class="bi bi-file-x"></i>
                </a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
    <div class="btn-group-vertical gap-3">
        <a class="btn btn-secondary" href="/worker/addForm">Добавить</a>
        <a class="btn btn-secondary"  ></a>
        <a class="btn btn-secondary"  ></a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\source\repos\PHP\12hw17122022\resources\views/show_work.blade.php ENDPATH**/ ?>