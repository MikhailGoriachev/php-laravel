<?php $__env->startSection('title'); ?>
    добавить
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="p3 bg-light w-50" action="/worker/addForm/add" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3 mt-3">
            <label class="form-label" for="surname">Фамилия</label>
            <input type="text" class="form-control " id="surname" placeholder="Фамилия И.О." name="surname" value="<?php echo e(old('surname')); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label" for="post">Должность</label>
            <input type="text" class="form-control" id="post" placeholder="должность" name="post" value="<?php echo e(old('post')); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label" for="gender">Пол</label>
            <input type="text" class="form-control" id="gender" placeholder="пол" name="gender" value="<?php echo e(old('gender')); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label" for="year">Зачисление в штат</label>
            <input type="number" class="form-control" id="year" placeholder="год зачисления" name="year" value="<?php echo e(old('year')); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label" for="photo">Файл фото</label>
            <input type="file" class="form-control" id="photo" placeholder="файл фото jpg" name="photo">
        </div>

        <div class="mb-3">
            <label class="form-label" for="salary">Оклад</label>
            <input type="number" class="form-control" id="salary" placeholder="оклад" name="salary" value="<?php echo e(old('salary')); ?>">
        </div>

        <div class="mt-3">
            <button type="submit" class="btn btn-success">Готово</button>
            <input class="btn btn-secondary" type="reset" value="Сбросить">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\source\repos\PHP\12hw17122022\resources\views/addForm.blade.php ENDPATH**/ ?>