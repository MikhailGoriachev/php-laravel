<?php $__env->startSection('title'); ?>
    разработчик
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h2 class="text-center">Черкас Николай г.Донецк 2022 г. группа ПД-011</h2>
    <div class="text-center">
        <img src="<?php echo e(asset('storage/images/work.jpg')); ?>" style="height: 500px">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\source\repos\PHP\12hw17122022\resources\views/about.blade.php ENDPATH**/ ?>