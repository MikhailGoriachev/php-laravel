<nav class=" d-inline-flex mt-2 mt-md-0">
    <a class="me-3 py-2 text-decoration-none" href="<?php echo e(route('home')); ?>">Задание</a>
    <a class="me-3 py-2 text-decoration-none" href="<?php echo e(route('about')); ?>">Разработчик</a>
    <a class="me-3 py-2 text-decoration-none" href="<?php echo e(route('work')); ?>">Работники</a>
</nav>
<?php /**PATH D:\Students\ПД011\15 PHP\17 Занятие ПД011 22.12.2022 PHP\HW\Черкас Николай\resources\views/inc/nav.blade.php ENDPATH**/ ?>