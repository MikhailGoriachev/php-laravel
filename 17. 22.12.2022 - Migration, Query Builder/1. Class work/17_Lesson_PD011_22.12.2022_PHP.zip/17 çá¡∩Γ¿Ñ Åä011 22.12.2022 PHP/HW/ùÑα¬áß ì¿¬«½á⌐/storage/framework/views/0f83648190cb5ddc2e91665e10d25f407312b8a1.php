<nav class=" d-inline-flex mt-2 mt-md-0">
    <a class="me-3 py-2 text-decoration-none" href="<?php echo e(route('home')); ?>">Задание</a>
    <a class="me-3 py-2 text-decoration-none" href="<?php echo e(route('about')); ?>">Разработчик</a>
    <a class="me-3 py-2 text-decoration-none" href="<?php echo e(route('work')); ?>">Работники</a>
</nav>
<?php /**PATH C:\Users\Lenovo\source\repos\PHP\12hw17122022\resources\views/inc/nav.blade.php ENDPATH**/ ?>