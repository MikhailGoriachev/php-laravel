@extends('layouts.app')

@section('experience', 'active')
@section('title', "Выделены работники с стажем выше $exp")

@section('content')
    <table class="table table-hover mt-5 mx-auto">
        <thead class="text-center">
        <th>Фото</th>
        <th>ФИО</th>
        <th>Должность</th>
        <th>Пол</th>
        <th>Год поступления на работу</th>
        <th>Стаж</th>
        <th>Оклад</th>
        </thead>
        <tbody>
        @foreach($workers as $worker)
            {!! html_entity_decode(($worker->toTableRow($worker->calculateExperience() > $exp))) !!}
        @endforeach
        </tbody>
    </table>
@endsection
