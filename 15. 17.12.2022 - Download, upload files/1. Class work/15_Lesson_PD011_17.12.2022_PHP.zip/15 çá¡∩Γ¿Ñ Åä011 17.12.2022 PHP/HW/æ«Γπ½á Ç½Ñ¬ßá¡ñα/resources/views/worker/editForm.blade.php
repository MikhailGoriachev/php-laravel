@extends('layouts.app')

@section('workers', 'active')
@section('title', 'Редактировать данные')

@section('content')
    <form action="/update" method="post" class="w-50 mx-auto mt-5">
        @csrf
        <input type="hidden" id="id" name="id" value="{{$worker->id}}">

        <div class="form-floating ">
            <input type="text" class="form-control" name="fullName" id="fullName" required
                   placeholder="Имя работника" value="{{$worker->fullName}}">
            <label for="fullName">Имя работника</label>
        </div>

        <div class="form-floating mt-5">
            <select class="form-select" name="position" id="position">
                <option {{$worker->position == "Оператор" ? "selected=selected" : ""}} value="Оператор">Оператор</option>
                <option {{$worker->position == "Программист" ? "selected=selected" : ""}} value="Программист">Программист</option>
                <option {{$worker->position == "Инженер" ? "selected=selected" : ""}} value="Инженер">Инженер</option>
            </select>
            <label for="position">Должность</label>
        </div>

        <div class="form-floating mt-5">
            <select class="form-select" name="gender" id="gender">
                <option {{$worker->gender == 1 ? "selected=selected" : ""}} value="true">Мужской</option>
                <option {{$worker->gender == 0 ? "selected=selected" : ""}} value="false">Женский</option>
            </select>
            <label for="gender">Пол</label>
        </div>

        <div class="form-floating mt-5">
            <input type="number" class="form-control" name="admissionYear" id="admissionYear" required
                   placeholder="Год приема на работу" value="{{$worker->admissionYear}}">
            <label for="admissionYear">Год приема на работу</label>
        </div>

        <div class="form-floating mt-5">
            <input type="number" class="form-control" name="salary" id="salary" required
                   placeholder="Оклад" value="{{$worker->salary}}">
            <label for="salary">Оклад</label>
        </div>

        <div class="row mt-5">
            <button type="submit" class="btn btn-outline-success mx-auto col-sm-3">Редактировать</button>
        </div>
    </form>
@endsection

