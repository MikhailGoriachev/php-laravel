@extends('layouts.app')

@section('experience', 'active')
@section('title', 'Введите стаж для выделения')

@section('content')
    <form action="/exp" method="post" class="mt-5">
        @csrf
        <div class="row my-5">
            <div class="col-sm col-sm-4 mx-auto">
                <div class="form-floating">
                    <input type="number" class="form-control" name="exp" id="exp" required
                           placeholder="Минимальное значение стажа">
                    <label for="exp">Минимальное значение стажа</label>
                </div>
            </div>
        </div>

        <div class="row">
            <button type="submit" class="btn btn-outline-success mx-auto col-sm-3">Отметить</button>
        </div>
    </form>
@endsection

