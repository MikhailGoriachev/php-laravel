@extends('layouts.app')

@section('workers', 'active')
@section('title', "$header")

@section('content')
    <table class="table table-hover mt-5 mx-auto">
        <thead class="text-center">
            <th>Фото</th>
            <th>ФИО</th>
            <th>Должность</th>
            <th>Пол</th>
            <th>Год поступления на работу</th>
            <th>Стаж</th>
            <th>Оклад</th>
            <th>Управление</th>
        </thead>
        <tbody>
            @foreach($workers as $worker)
                {!! html_entity_decode(($worker->toTableRow(isEdit: true))) !!}
            @endforeach
        </tbody>
    </table>
@endsection
