<?php $__env->startSection('array', 'active'); ?>
<?php $__env->startSection('title', 'Параметры массива'); ?>

<?php $__env->startSection('content'); ?>

    <div class="w-100 mt-4">
        <a href="#task" class="btn btn-outline-dark w-100 mb-4" data-bs-toggle="collapse">
            <strong>Задание</strong>
        </a>
        <div id="task" class="collapse">
            n – параметр маршрута, случайное целое число в диапазоне [12, 25] – размер массива. В форме вводите диапазон
            генерации случайных целых чисел для заполнения массива. Выполните обработки и вывод результатов для массива,
            не используйте модель. Вывод массива и результатоа – на отдельную страницу.
            <ul>
                <li>вывести исходный массив</li>
                <li>определите количество положительных элементов массива;</li>
                <li>вычислите сумму элементов массива, расположенных после последнего элемента, равного нулю.</li>
                <li>преобразуйте массив таким образом, чтобы сначала располагались все элементы, равные нулю, а потом —
                    все остальные
                </li>
                <li>вывести преобразованный массив</li>
            </ul>
        </div>
    </div>

    <form action="/resultArray" method="post" class="mt-5">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="size" value="<?php echo e($size); ?>">

        <div class="row my-5">
            <div class="col-sm col-sm-4 mx-auto">
                <div class="form-floating">
                    <input type="number" class="form-control" name="min" id="min" placeholder="&alpha;">
                    <label for="min">Минимальное значение диапазона</label>
                </div>
            </div>

            <div class="col-sm col-sm-4 mx-auto">
                <div class="form-floating">
                    <input type="number" class="form-control" name="max" id="max"
                           placeholder="Максимальное значение диапазона">
                    <label for="b">Максимальное значение диапазона</label>
                </div>
            </div>
        </div>

        <div class="row">
            <button class="col-sm-3 btn btn-outline-success mx-auto" type="submit">Вычислить</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\14 Занятие ПД011 15.12.2022 PHP\HW\Сотула Александр\resources\views/calculate/array.blade.php ENDPATH**/ ?>