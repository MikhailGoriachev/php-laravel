<?php $__env->startSection('text', 'active'); ?>
<?php $__env->startSection('title', 'Результат обработки текста'); ?>

<?php $__env->startSection('content'); ?>

    <p class="mt-5">Строка для обработки: <?php echo e($str); ?></p>

    <p class="mt-5">Количество слов начинающихся и заканчивающихся на одну и ту же букву без учета
        регистра: <?php echo e($countByEqualUnRegister); ?></p>

    <p class="mt-5">Уникальные найденные слова с количеством их вхождений</p>
    <table class="table w-25">
        <thead>
        <th>Слово</th>
        <th>Количество</th>
        </thead>
        <?php $__currentLoopData = $arrayUnRegister; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key); ?></td>
                <td><?php echo e($value); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <p class="mt-5">Количество слов начинающихся и заканчивающихся на одну и ту же букву с учетом
        регистра: <?php echo e($countByEqualRegister); ?></p>

    <p class="mt-5">Уникальные найденные слова с количеством их вхождений</p>
    <table class="table w-25">
        <thead>
        <th>Слово</th>
        <th>Количество</th>
        </thead>
        <?php $__currentLoopData = $arrayRegister; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key); ?></td>
                <td><?php echo e($value); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <p class="mt-5">Количество слов состоящих из <b><?php echo e($countLetters); ?></b> букв: <?php echo e($countByLength); ?></p>
    <p class="mt-5">Уникальные найденные слова с количеством их вхождений</p>
    <table class="table w-25">
        <thead>
        <th>Слово</th>
        <th>Количество</th>
        </thead>
        <?php $__currentLoopData = $arrayCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key); ?></td>
                <td><?php echo e($value); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\14 Занятие ПД011 15.12.2022 PHP\HW\Сотула Александр\resources\views/calculate/textSolution.blade.php ENDPATH**/ ?>