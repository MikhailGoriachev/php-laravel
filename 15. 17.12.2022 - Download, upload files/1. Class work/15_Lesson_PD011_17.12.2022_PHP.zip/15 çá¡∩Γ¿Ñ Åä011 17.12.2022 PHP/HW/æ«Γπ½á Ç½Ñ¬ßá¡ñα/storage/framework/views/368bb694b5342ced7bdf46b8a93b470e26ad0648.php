<?php $__env->startSection('equation', 'active'); ?>
<?php $__env->startSection('title', 'Решенные выражения'); ?>

<?php $__env->startSection('content'); ?>

    <h5 class="h5 text-center mt-5">Первое выражение</h5>

    <table class="table table-hover w-50 mx-auto mt-5">
        <thead class="text-center">
            <th>&alpha;</th>
            <th>&beta;</th>
            <th>z<sub>1</sub></th>
            <th>z<sub>2</sub></th>
            <th>Результат</th>
        </thead>
        <tbody>
            <td><?php echo e(sprintf("%.5f", $result['a'])); ?></td>
            <td><?php echo e(sprintf("%.5f", $result['b'])); ?></td>
            <td><?php echo e(sprintf("%.5f", $result['z1FirstEvaluate'])); ?></td>
            <td><?php echo e(sprintf("%.5f", $result['z2FirstEvaluate'])); ?></td>
            <td class="text-white text-center <?php echo e($result['flagFirstEvaluate'] ? "bg-success" : "bg-danger"); ?>"><?php echo e(!$result['flagFirstEvaluate'] ? "не" : ""); ?>совпадает</td>
        </tbody>
    </table>

    <h5 class="h5 text-center mt-5">Второе выражение</h5>

    <table class="table table-hover w-50 mx-auto mt-5">
        <thead class="text-center">
        <th><i>m</i></th>
        <th><i>n</i></th>
        <th>z<sub>1</sub></th>
        <th>z<sub>2</sub></th>
        </thead>
        <tbody>
        <td><?php echo e(sprintf("%.5f", $result['m'])); ?></td>
        <td><?php echo e(sprintf("%.5f",$result['n'])); ?></td>
        <td><?php echo e(sprintf("%.5f",$result['z1SecondEvaluate'])); ?></td>
        <td><?php echo e(sprintf("%.5f",$result['z2SecondEvaluate'])); ?></td>
        <td class="text-white text-center <?php echo e($result['flagSecondEvaluate'] ? "bg-success" : "bg-danger"); ?>"><?php echo e(!$result['flagSecondEvaluate'] ? "не" : ""); ?>совпадает</td>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Академия Шаг\ПД011\15 PHP\13 Занятие ПД011 12.12.2022 PHP\Сотула Александр\resources\views/calculate/evaluateSolution.blade.php ENDPATH**/ ?>