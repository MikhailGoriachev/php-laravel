<?php $__env->startSection('about', 'active'); ?>
<?php $__env->startSection('title', 'О приложении'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-center my-5">
        <p><b>Фамилия:</b> <?php echo e($data['surname']); ?></p>
        <p><b>Имя:</b> <?php echo e($data['name']); ?></p>
        <p><b>Группа:</b> <?php echo e($data['group']); ?></p>
        <img class="rounded mx-auto d-block mt-5" src="../img/<?php echo e($data['img']); ?>">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Академия Шаг\ПД011\15 PHP\13 Занятие ПД011 12.12.2022 PHP\Сотула Александр\resources\views/home/about.blade.php ENDPATH**/ ?>