<?php

namespace App\Models;

// работник
class Worker
{
    public int $id;
    public string $fullName;
    public string $position;
    public bool $gender;
    public int $admissionYear;
    public string $img;
    public float $salary;

    // ctor
    public function __construct(int $id, string $fullName, string $position, bool $gender, int $admissionYear, string $img, float $salary)
    {
        $this->id = $id;
        $this->fullName = $fullName;
        $this->position = $position;
        $this->gender = $gender;
        $this->admissionYear = $admissionYear;
        $this->img = $img;
        $this->salary = $salary;
    }

    // метод вычисления стажа работника для текущей даты
    public function calculateExperience(): int
    {
        return date('Y') - $this->admissionYear;
    } // calculateExperience

    // вывод в строку таблицы
    public function toTableRow(bool $isColored = false, bool $isEdit = false)
    {
        $str = "<tr class='" . ($isColored ? 'bg-info' : '') . "'>
                    <td class='text-center'><img src='/img/photos/$this->img' alt='$this->img'></td>
                    <td>$this->fullName</td>
                    <td>$this->position</td>
                    <td>" . ($this->gender ? 'Мужской' : 'Женский') . "</td>
                    <td class='text-center'>$this->admissionYear</td>
                    <td class='text-center'>" . $this->calculateExperience() . "</td>
                    <td class='text-center'>$this->salary</td>";
        if ($isEdit) {
            $str .= "<td>
                        <div class='row justify-content-center'>

                            <div class='col-sm-6'>
                                <a class='btn btn-outline-primary col-sm-12'  href='/edit/$this->id' title='Редактировать сведения о сотруднике'>
                                <i class='bi bi-pencil-fill'></i></a>
                            </div>

                           <form action='/delete' method='post' class='form-inline col-sm-6'>
                                " . csrf_field() . "
                                <button type='submit' name='id' value='" . $this->id . "' class='btn btn-outline-danger col-sm-12' title='Удалить сведения о работнике'>
                                <i class='bi bi-x-lg'></i>
                                </button>
                           </form>
                        </div>
                    </td>";
        }
        $str .= "</tr>";
        return $str;
    } // toTableRow

} // class Worker
