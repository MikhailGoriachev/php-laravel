<?php

namespace App\Http\Controllers;

use App\Models\Worker;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class WorkerController extends Controller
{

    private array $workers_;
    // название файла данных
    private string $fileName_;

    private $disk_;

    // ctor
    public function __construct(string $fileName = 'workers.json', $driver = 'local')
    {
        $this->fileName_ = $fileName;
        $this->disk_ = Storage::disk($driver);

        if ($this->disk_->missing($this->fileName_) || $this->disk_->size($this->fileName_) === 2) {
            $this->workers_ = [
                new Worker(1, 'Иванов И.И.', 'Инженер', true, 2019, 'man_001.jpg', 35_000),
                new Worker(2, 'Петрова С.А.', 'Оператор', false, 2021, 'woman_001.jpg', 31_000),
                new Worker(3, 'Гончаров А.В.', 'Программист', true, 2020, 'man_002.jpg', 34_000),
                new Worker(4, 'Гоняева О.И.', 'Программист', false, 2021, 'woman_002.jpg', 34_000),
                new Worker(5, 'Колков В.И.', 'Инженер', true, 2018, 'man_003.jpg', 37_000),
                new Worker(6, 'Овчарова Л.В.', 'Оператор', false, 2015, 'woman_003.jpg', 34_000),
                new Worker(7, 'Ковалев А.М.', 'Инженер', true, 2017, 'man_004.jpg', 34_000),
                new Worker(8, 'Михайлова И.В.', 'Инженер', false, 2019, 'woman_004.jpg', 33_000),
                new Worker(9, 'Антипов А.Д.', 'Оператор', true, 2021, 'man_005.jpg', 37_000),
                new Worker(10, 'Величко Д.Д.', 'Инженер', false, 2017, 'woman_005.jpg', 33_000),
            ];

            $this->writeToFile();

        } else
            $this->readFromFile();
    }

    // запись в файл
    private function writeToFile()
    {
        $this->disk_->put($this->fileName_, json_encode($this->workers_));
    } // writeToFile

    // чтение из файла
    private function readFromFile()
    {
        $workers = json_decode($this->disk_->get($this->fileName_), true);

        unset($this->workers_);

        foreach ($workers as $worker)
            $this->workers_[] = new Worker(
                $worker['id'], $worker['fullName'], $worker['position'],
                $worker['gender'], $worker['admissionYear'], $worker['img'],
                $worker['salary']);

    } // readFromFile

    // вывод массива с упорядочиванием фамилий по алфавиту;
    public function showWorkers()
    {
        $this->readFromFile();
        $sorted = $this->workers_;
        usort($sorted, fn($w1, $w2) => strcmp($w1->fullName, $w2->fullName));

        return view('worker/showWorkers', ['workers' => $sorted, 'header' => 'Список работников']);
    } // showWorkers

    // вывод массива с выделением работников с окладами, равными минимальному, упорядочивание по алфавиту;
    public function showWorkersWithMinSalary()
    {
        $this->readFromFile();
        $sorted = $this->workers_;
        $minSalary = min(array_column($this->workers_, 'salary'));
        usort($sorted, fn($w1, $w2) => strcmp($w1->fullName, $w2->fullName));
        return view('worker/showWorkersWithMinSalary', ['workers' => $sorted, 'minSalary' => $minSalary]);
    } // showWorkersWithMinSalary

    // вывод массива с выделением работников с окладами, равными максимальному, упорядочивание по должностям;
    public function showWorkersWithMaxSalary()
    {
        $this->readFromFile();
        $sorted = $this->workers_;
        $maxSalary = max(array_column($this->workers_, 'salary'));
        usort($sorted, fn($w1, $w2) => strcmp($w1->position, $w2->position));
        return view('worker/showWorkersWithMaxSalary', ['workers' => $sorted, 'maxSalary' => $maxSalary]);
    } // showWorkersWithMinSalary

    // форма для ввода стажа
    public function getFormExperienceInput()
    {
        return view('worker/expInput');
    } // getFormExperienceInput

    // вывод массива с выделением работников с превышением заданного стажа работы, упорядочивать массив по окладу.
    public function showByExp(Request $request)
    {
        $this->readFromFile();
        $sorted = $this->workers_;
        usort($sorted, fn($w1, $w2) => $w1->salary - $w2->salary);
        return view('worker/showByExp', ['workers' => $sorted, 'exp' => $request->input('exp')]);
    } // showByExp

    // удаление работника по id
    public function deleteById(Request $request)
    {
        $this->readFromFile();
        $id = $request->input('id');

        $this->workers_ = array_filter($this->workers_, fn($worker) => $worker->id != $id);
        $this->writeToFile();
        $sorted = $this->workers_;
        usort($sorted, fn($w1, $w2) => strcmp($w1->fullName, $w2->fullName));
        return view('worker/showWorkers', ['workers' => $sorted, 'header' => 'Работник успешно удален']);
    } // deleteById

    // форма для редактирования
    public function getEditForm($id)
    {
        $worker = array_values(array_filter($this->workers_, fn($worker) => $worker->id == $id));

        return view('worker/editForm', ['worker' => $worker[0]]);
    } // getEditForm

    // обновление работника
    public function update(Request $request)
    {
        $fields = $request->all();

        foreach ($this->workers_ as $worker) {
            if ($worker->id == $fields['id']) {
                $worker->fullName = $fields['fullName'];
                $worker->position = $fields['position'];
                $worker->gender = $fields['gender'] == 'true';
                $worker->img = ($fields['gender'] == 'true' ? 'man_00' : 'woman_00') . rand(1,9) . '.jpg';
                $worker->admissionYear = $fields['admissionYear'];
                $worker->salary = $fields['salary'];
                break;
            }
        } // foreach

        $this->writeToFile();

        $sorted = $this->workers_;
        usort($sorted, fn($w1, $w2) => strcmp($w1->fullName, $w2->fullName));

        return view('worker/showWorkers', ['workers' => $sorted, 'header' => 'Работник успешно обновлен']);
    } // update

}
