<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// основной контроллер
class HomeController extends Controller
{
    // действие index
    public function index()
    {
        return view('home/index');
    }

    // действие about
    public function about()
    {
        // массив с данными
        $arr['surname'] = "Сотула";
        $arr['name'] = "Александр";
        $arr['group'] = "ПД011";
        $arr['img'] = "laravel.jpg";

        // передача данных в представление
        return view('home/about', ['data' => $arr]);
    }

}
