<?php

// подключение собственных контроллеров
use App\Http\Controllers\HomeController;
use App\Http\Controllers\WorkerController;

use Illuminate\Support\Facades\Route;

// путь к действию index в контроллере HomeController
Route::get('/', [HomeController::class, 'index']);
Route::get('/index', [HomeController::class, 'index']);

// путь к действию about в контроллере HomeController
Route::get('/about', [HomeController::class, 'about']);

// отображение работников
Route::get('/workers', [WorkerController::class, 'showWorkers']);
Route::get('/minSalary', [WorkerController::class, 'showWorkersWithMinSalary']);
Route::get('/maxSalary', [WorkerController::class, 'showWorkersWithMaxSalary']);

// форма ввода стажа
Route::get('/exp-input', [WorkerController::class, 'getFormExperienceInput']);
// обработка post запроса формы ввода стажа
Route::post('/exp', [WorkerController::class, 'showByExp']);

Route::post('/delete', [WorkerController::class, 'deleteById']);
Route::get('/edit/{n}', [WorkerController::class, 'getEditForm']);

Route::post('/update', [WorkerController::class, 'update']);
