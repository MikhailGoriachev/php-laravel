<?php $__env->startSection('title', 'Работники'); ?>

<?php $__env->startSection('workersActive', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">
        <h4 class="text-center"><?php echo e($title ?? 'Работники'); ?></h4>

        <div class="row">
            <div class="col-auto">
                <a class="btn btn-success mt-2" href="/workers/allData">Исходные данные</a>
            </div>
            <div class="col-auto">
                <a class="btn btn-primary mt-2" href="/workers/selectByMaxSalary">Максимальный оклад</a>
            </div>
            <div class="col-auto">
                <a class="btn btn-primary mt-2" href="/workers/selectByMinSalary">Минимальный оклад</a>
            </div>
            <div class="col-auto">
                <form action="/workers/selectByOverExperience" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-auto">
                            <div class="form-floating">
                                <input class="form-control w-22rem" type="number" min="0" name="experience"
                                       value="<?php echo e($experience ?? null); ?>" placeholder=" " required>
                                <label class="form-label">Минимальный стаж работы (лет)</label>
                            </div>
                        </div>

                        <div class="col-auto mt-2">
                            <input class="btn btn-success" type="submit" value="Выделить">
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Фотография</th>
                    <th>Фамилия и инициалы</th>
                    <th>Должность</th>
                    <th>Пол</th>
                    <th>Год трудоустройства</th>
                    <th>Стаж</th>
                    <th>Оклад (&#8381;)</th>
                    <th class="text-center">
                        <a class="btn btn-success" href="/workers/addForm" title="Добавить...">
                            <i class="bi bi-plus-lg"></i> Добавить
                        </a>
                    </th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="align-middle <?php echo e(isset($predicate) && $predicate($item) ? 'bg-light-green' : ''); ?>">
                        <th><?php echo e($item->id); ?></th>
                        <td>
                            <img src="<?php echo e(asset("images/people/$item->image")); ?>" class="h-5rem" alt="image">
                        </td>
                        <td><?php echo e($item->fullName); ?></td>
                        <td><?php echo e($item->position); ?></td>
                        <td><?php echo e($item->gender ? 'мужской' : 'женский'); ?></td>
                        <td><?php echo e($item->yearOfEmployment); ?></td>
                        <td><?php echo e($item->getExperience()); ?></td>
                        <td><?php echo e($item->salary); ?></td>
                        <td class="text-center">
                            <a class="btn btn-warning" href="/workers/editForm/<?php echo e($item->id); ?>" title="Изменить...">
                                <i class="bi bi-pencil-fill"></i>
                            </a>
                            <a class="btn btn-danger" href="/workers/delete/<?php echo e($item->id); ?>" title="Удалить">
                                <i class="bi bi-trash-fill"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\15 Занятие ПД011 17.12.2022 PHP\HW\Михаил Горячев\resources\views/workers/workerList.blade.php ENDPATH**/ ?>