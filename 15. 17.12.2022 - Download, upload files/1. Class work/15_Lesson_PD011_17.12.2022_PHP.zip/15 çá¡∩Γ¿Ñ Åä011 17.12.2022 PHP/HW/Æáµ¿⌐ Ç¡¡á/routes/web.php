<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\WorkersController;

Route::get('/', function () {
    return view('welcome');
});

// путь к действию index контроллера home
Route::get('/', [ HomeController::class, 'index' ]);

Route::get('/workers', [ WorkersController::class, 'show' ]);
