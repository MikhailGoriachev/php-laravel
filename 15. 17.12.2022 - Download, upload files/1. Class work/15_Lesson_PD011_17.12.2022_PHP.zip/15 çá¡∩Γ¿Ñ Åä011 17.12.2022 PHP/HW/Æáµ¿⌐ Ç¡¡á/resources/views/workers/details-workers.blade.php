@extends('layouts.app')

@section('workers', 'active')
@section('title', 'Работники')

<!-- секция контент -->
@section('content')

    <p class="m-4 fs-5">Список работников:</p>

    <table class="table">
        <thead>
            <tr class="text-center">
                <th>Id</th>
                <th>Фамилия и инициалы </th>
                <th>Должность</th>
                <th>Пол</th>
                <th>Год поступления</th>
                <th>Фото</th>
                <th>Оклад</th>
                <th>Стаж</th>
            </tr>
        </thead>

        <tbody>
            @php array_walk_recursive($workers,fn($w)=>$w->toTableRow()); @endphp
        </tbody>

    </table>

@endsection
