<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Worker;
use Illuminate\Support\Facades\Storage;

class WorkersController extends Controller
{
    // объект для обработки
    private $workers_;

    // имя файла с данными
    private string $fileName_;

    public function __construct(){

        $disk = Storage::disk('local');
        $this->fileName_ = "workers.json";
        $this->workers_ = [];

        if(!$disk->exists($this->fileName_)){

            $this->workers_ = [

                new  Worker(1,"Захарова С. М.",     "диспетчер", false, 2020,"woman_001.jpg",30000),
                new  Worker(2,"Волкова Д. В.",      "менеджер",  false, 2010,"woman_002.jpg",40000),
                new  Worker(3,"Любимов А. К.",      "металлург", true,  2021,"man_001.jpg",  50000),
                new  Worker(4,"Сорокин Р. М.",      "инженер",   true,  2015,"man_002.jpg",  70000),
                new  Worker(5,"Колпакова Т. М.",    "переводчик",false, 2016,"woman_003.jpg",50000),
                new  Worker(6,"Титов В. Л.",        "товаровед", true,  2012,"man_003.jpg",  60000),
                new  Worker(7,"Мельников Г. С.",    "юрист",     true,  2017,"man_004.jpg",  70000),
                new  Worker(8,"Семенова М. А.",     "секретарь", false, 2012,"woman_004.jpg",50000),
                new  Worker(9,"Фокина С. Д.",       "лаборант",  false, 2017,"woman_005.jpg",40000),
                new  Worker(10,"Кожевникова Т. М.", "экспедитор",false, 2019,"woman_006.jpg",50000),
                new  Worker(11,"Соловьев М. Ф.",    "грузчик",   true,  2021,"man_005.jpg",  30000),
                new  Worker(12,"Харитонов Д. С.",   "дизайнер",  true,  2021,"man_006.jpg",  60000),

            ];

            $this->save($disk);
        }

        else{

            $this->read($disk);
        }

    }

    //сохранение в файл
    private function save($disk){

        $disk->put("workers.json" , json_encode($this->workers_));
    }


    private function read($disk){

        $this->workers_ = array_map(fn($w) => (new Worker())->setDataFromArray($w),json_decode($disk->get($this->fileName_),true));
    }

    public function show(){
        return view('workers.details-workers', ['workers' => $this->workers_]);
    }
}
