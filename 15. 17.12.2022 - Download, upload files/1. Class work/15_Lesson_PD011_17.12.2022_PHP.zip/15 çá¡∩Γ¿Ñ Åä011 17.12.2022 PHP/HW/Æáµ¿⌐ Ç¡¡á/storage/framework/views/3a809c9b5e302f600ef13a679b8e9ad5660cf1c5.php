<?php $__env->startSection('workers', 'active'); ?>
<?php $__env->startSection('title', 'Работники'); ?>

<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <p class="m-4 fs-5">Список работников:</p>

    <table class="table">
        <thead>
            <tr class="text-center">
                <th>Id</th>
                <th>Фамилия и инициалы </th>
                <th>Должность</th>
                <th>Пол</th>
                <th>Год поступления</th>
                <th>Фото</th>
                <th>Оклад</th>
                <th>Стаж</th>
            </tr>
        </thead>

        <tbody>
            <?php
                array_walk_recursive($workers,fn($w)=>$w->toTableRow())
            ?>
        </tbody>

    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annat\source\repos\PHP\Step_17.12.22(Таций Анна)_PHP\Step171222\resources\views/workers/details-workers.blade.php ENDPATH**/ ?>