<?php

function sphereArea(float $radius): float {
    return 4. * M_PI * $radius**2;
}

function sphereVolume(float $radius): float {
    return 4. * M_PI * $radius**3 / 3;
}

function cylinderArea(float $radius, float $height) : float {
    return 2. * M_PI * $radius * ($height + $radius);
}

function cylinderVolume(float $radius, float $height) : float {
    return M_PI * $radius**2 * $height;
}

function coneArea(float $radius, float $height) : float {
    return M_PI * $radius * ($radius + sqrt($radius**2 + $height**2));
}

function coneVolume(float $radius, float $height) : float {
    return (M_PI * $radius**2 * $height) / 3;
}

function writeToFile($file, $data): void {
    $fd = fopen($file, 'a') or die("<h4>Не удалось открыть файл $file</h4>");
    fwrite($fd, $data);
    fclose($fd);
}
