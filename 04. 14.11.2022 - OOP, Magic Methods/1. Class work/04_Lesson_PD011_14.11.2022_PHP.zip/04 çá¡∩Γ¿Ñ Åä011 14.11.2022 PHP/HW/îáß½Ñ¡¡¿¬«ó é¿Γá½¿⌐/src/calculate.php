<?php
include_once("functions.php");

date_default_timezone_set('Europe/Moscow');

const MATERIALS_DATA = [
    "steel"    => ["name" => "Сталь",       "density" => 7850,  "image" => "steel.png"],
    "aluminum" => ["name" => "Алюминий",    "density" => 2700,  "image" => "aluminum.png"],
    "waterIce" => ["name" => "Водяной лёд", "density" => 916.7, "image" => "water_ice.png"],
    "granite"  => ["name" => "Гранит",      "density" => 2600,  "image" => "granite.png"],
];

const FIGURES_DATA = [
    "sphere"   => ["area" => "sphereArea",   "volume" => "sphereVolume",   "image" => "sphere.png",   "name" => "Сфера"],
    "cylinder" => ["area" => "cylinderArea", "volume" => "cylinderVolume", "image" => "cylinder.png", "name" => "Цилиндр"],
    "cone"     => ["area" => "coneArea",     "volume" => "coneVolume",     "image" => "cone.png",     "name" => "Конус"]
];

const LOG_FILE = "calculations.log";

/*Вычисление параметров геометрического тела*/
function calc(): array
{
    $figureType = $_POST['figureType'];
    $material = $_POST['material'];
    $radius = floatval($_POST['radius']);

    $height = null;
    if ($figureType != "sphere")
        $height = floatval($_POST['height']);

    $area = null;
    if (isset($_POST['area']))
        $area = FIGURES_DATA[$figureType]["area"]($radius, $height);

    $volume = null;
    if (isset($_POST['volume']) || isset($_POST['mass']))
        $volume = FIGURES_DATA[$figureType]["volume"]($radius, $height);

    $mass = null;
    if (isset($_POST['mass']))
        $mass = $volume * MATERIALS_DATA[$material]["density"];

    // строка для записи в журнал
    $history = Date("[d.m.y H:i:s]")
        . " " . FIGURES_DATA[$figureType]["name"]
        . ", материал " . MATERIALS_DATA[$material]["name"]
        . ", r: " . $radius
        . (isset($height) ? ", h: " . $height: "")
        . (isset($area) ? ", площадь поверхности: " . number_format($area,2): "")
        . (isset($volume) ? ", объем тела: " . number_format($volume,2): "")
        . (isset($mass) ? ", масса тела: " . number_format($mass,2): "")
        . "\r\n";

    writeToFile("../" . LOG_FILE, $history);

    return [
        "area"          => $area,
        "volume"        => $volume,
        "mass"          => $mass,
        "figureImage"   => FIGURES_DATA[$figureType]["image"],
        "figureName"    => FIGURES_DATA[$figureType]["name"],
        "materialImage" => MATERIALS_DATA[$material]["image"],
        "materialName"  => MATERIALS_DATA[$material]["name"],
        "density"       => MATERIALS_DATA[$material]["density"]
    ];
}



