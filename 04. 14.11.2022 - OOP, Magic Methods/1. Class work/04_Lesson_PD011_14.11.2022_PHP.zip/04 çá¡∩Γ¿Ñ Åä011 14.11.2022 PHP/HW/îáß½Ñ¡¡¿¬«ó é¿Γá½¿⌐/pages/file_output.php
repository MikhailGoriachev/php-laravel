<?php
include_once("../src/functions.php");
const HEADER = 'Задание 2';
const PAGE = 'task2';
const UPLOAD_ERRORS_MSG = [
    UPLOAD_ERR_FORM_SIZE  => "Ошибка. Превышен допустимый размер файла",
    UPLOAD_ERR_INI_SIZE   => "Ошибка. Превышен допустимый размер файла",
    UPLOAD_ERR_CANT_WRITE => "Ошибка. Не удалось записать файл",
    UPLOAD_ERR_NO_FILE    => "Ошибка. Файл не был загружен",
    UPLOAD_ERR_NO_TMP_DIR => "Ошибка. Отсутствует временная директория",
    UPLOAD_ERR_EXTENSION  => "Ошибка. Загрузка была остановлена",
    UPLOAD_ERR_PARTIAL    => "Ошибка. Файл был загружен не полностью"
];
const MAX_FILE_SIZE = 2097152;
const VALID_MIME = "text/plain";
const UPLOAD_DIR = "../uploaded/";

// сценарий дозаписи в файл
if (isset($_POST['saved_file']) && isset($_POST['text_append'])) {
    $savedFile = $_POST['saved_file'];

    writeToFile(UPLOAD_DIR . $savedFile, "\r\n" . $_POST['text_append']);

    $output = file_get_contents(UPLOAD_DIR . $savedFile);

} // сценарий загрузки файла
else if (isset($_FILES['upload_file'])) {
    try {
        $fileTmp = $_FILES['upload_file']['tmp_name'];

        if ($_FILES && $_FILES['upload_file']['error'] != UPLOAD_ERR_OK)
            throw new RuntimeException(UPLOAD_ERRORS_MSG[$_FILES['upload_file']['error']]);

        if (mime_content_type($fileTmp) != VALID_MIME)
            throw new RuntimeException("Допустимы только текстовые файлы");

        if ($_FILES['upload_file']['size'] > MAX_FILE_SIZE)
            throw new RuntimeException("Максимально допустимый размер файла для загрузки - " . MAX_FILE_SIZE / 1048576 . " Mb");

        if (!file_exists(UPLOAD_DIR))
            mkdir(UPLOAD_DIR);

        $ext = pathinfo($_FILES['upload_file']['name'], PATHINFO_EXTENSION);
        // имя для сохраняемого файла
        $savedFile = sha1_file($fileTmp) . "." . $ext;

        if (!move_uploaded_file($fileTmp, UPLOAD_DIR . $savedFile))
            throw new RuntimeException("Не удалось сохранить файл");

        $output = file_get_contents(UPLOAD_DIR . $savedFile);

    } catch (RuntimeException $e) {
        $error = $e->getMessage();
    }
} else die("Нет данных");

ob_start();
?>

<!--форма дозаписи текста в файл-->
<?php if (isset($savedFile)) { ?>
    <form method="post">
        <input type="hidden" name="saved_file" value=<?= $savedFile ?>>
        <div class="row">
            <div class="col-4">
                <div class="form-floating">
                    <textarea class="form-control h-180-px" id="txtArea" name="text_append" required></textarea>
                    <label for="txtArea">Введите текст:</label>
                </div>
            </div>
            <div class="col-auto mt-3">
                <input class="btn btn-outline-secondary" type='submit' value='Дозапись'/>
            </div>
        </div>
    </form>
<?php } ?>

<!--вывод содержимого файла-->
<div class="mt-4">
    <?php
    if (isset($error))
        echo '<div class="alert alert-danger">' . $error . '</div>';

    if (isset($output)) { ?>
        <h3 class="col-12 mt-4 text-center">Текст файла:</h3>
        <?= nl2br($output); ?>
    <?php } ?>
</div>


<?php
$content = ob_get_clean();
include_once("../pages/partial/layout.php");
?>

