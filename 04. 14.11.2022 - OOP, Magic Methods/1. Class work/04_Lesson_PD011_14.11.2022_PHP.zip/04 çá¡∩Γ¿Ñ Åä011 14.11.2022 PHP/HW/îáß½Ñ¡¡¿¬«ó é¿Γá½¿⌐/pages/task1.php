<?php
include_once("../src/calculate.php");
const HEADER = 'Задача 1';
const PAGE = 'task1';


ob_start();
?>

<div class="row">
    <div class="col-5">

        <h4>Вычисление параметров геометрических тел </h4>

        <form class="mt-3" method="post">
            <div class="row mb-3">
                <div class="col-4">
                    <div class="form-floating">
                        <select class="form-select" id="selectFigure" name="figureType">
                            <option value="cone">Конус</option>
                            <option value="sphere">Сфера</option>
                            <option value="cylinder">Цилиндр</option>
                        </select>
                        <label for="selectFigure">Тип тела:</label>
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-floating">
                        <select class="form-select" id="selectMaterial" name="material">
                            <option value="steel">Сталь</option>
                            <option value="aluminum">Алюминий</option>
                            <option value="waterIce">Водяной лед</option>
                            <option value="granite">Гранит</option>
                        </select>
                        <label for="selectMaterial">Тип материала:</label>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-4">
                    <div class="form-floating mb-3">
                        <input type="number" class="form-control" id="inpRadius" name="radius" min="1e-10" required>
                        <label for="inpRadius">Радиус:</label>
                    </div>
                </div>
                <div class="col-4">
                    <div class="form-floating mb-3">
                        <input type="number" class="form-control" id="inpHeight" name="height" min="1e-10" required>
                        <label for="inpHeight">Высота:</label>
                    </div>
                </div>
            </div>

            <p class="lead fs-5">Параметры для вычисления:</p>

            <div class="row mb-3">
                <div class="col-auto">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="cbxArea" name="area" checked>
                        <label class="form-check-label" for="cbxArea">
                            Площадь поверхности
                        </label>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="cbxVolume" name="volume" checked>
                        <label class="form-check-label" for="cbxVolume">
                            Объем
                        </label>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="cbxMass" name="mass" checked>
                        <label class="form-check-label" for="cbxMass">
                            Масса
                        </label>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-auto">
                    <button class="btn btn-outline-secondary" type="submit">Вычислить</button>
                </div>
                <div class="col-auto">
                    <button class="btn btn-outline-secondary" type="reset">Очистить</button>
                </div>
            </div>
        </form>

        <a class="mt-3" href="history.php">История операций</a>
    </div>

    <!-- результаты вычислений-->
    <?php
    if (isset($_POST["figureType"]) && isset($_POST["material"]) && isset($_POST["radius"])
    && (isset($_POST["mass"]) || isset($_POST["area"]) || isset($_POST["volume"]))) {
    $result = calc();
    ?>
    <div class="col-6">
        <div class="row">
            <div class="col-auto">
                <div class="card">
                    <img src="../images/figures/<?= $result["figureImage"] ?>" class="card-img-top"/>
                    <div class="card-header bg-body">
                        <h5 class="card-title">Фигура: <?= $result["figureName"] ?></h5>
                    </div>
                    <div class="card-body bg-body pt-1">
                        <ul class="list-group list-group-flush">
                            <?php if (isset($_POST["area"])) { ?>
                                <li class="list-group-item">Площадь
                                    поверхности: <?= number_format($result["area"], 2) ?></li>
                            <?php } ?>
                            <?php if (isset($_POST["volume"])) { ?>
                                <li class="list-group-item">Объем тела: <?= number_format($result["volume"], 2) ?></li>
                            <?php } ?>
                            <?php if (isset($_POST["mass"])) { ?>
                                <li class="list-group-item">Масса тела: <?= number_format($result["mass"], 2) ?></li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-auto">
                <div class="card">
                    <img src="../images/materials/<?= $result["materialImage"] ?>" class="card-img-top"/>
                    <div class="card-header bg-body">
                        <h5 class="card-title">Материал: <?= $result["materialName"] ?></h5>
                    </div>
                    <div class="card-body bg-body">
                        <span>Плотность: <?= $result["density"] ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>

<script>
    (() => window.addEventListener("load", () =>
        document.querySelector('select[name="figureType"]').addEventListener("change", (e) => {
            const input = document.querySelector('input[name="height"]');
            e.target.value === "sphere" ? input.setAttribute('disabled', '') : input.removeAttribute('disabled');
        })))();
</script>

<?php
$content = ob_get_clean();
include_once("../pages/partial/layout.php");
?>

