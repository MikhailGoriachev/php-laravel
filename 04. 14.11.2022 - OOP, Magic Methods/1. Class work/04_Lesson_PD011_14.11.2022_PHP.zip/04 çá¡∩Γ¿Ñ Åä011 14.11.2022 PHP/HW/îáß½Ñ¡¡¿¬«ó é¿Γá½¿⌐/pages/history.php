<?php
include_once("../src/calculate.php");
const HEADER = 'Задание 1';
const PAGE = 'task1';

$history = "";

if (isset($_POST['clearHistory'])) {
    unlink("../" . LOG_FILE);
} else {
    if (file_exists("../" . LOG_FILE))
        $history = file_get_contents("../" . LOG_FILE);
}

ob_start();
?>

<div class="row">
    <div class="col-auto">
        <a href="task1.php"><- назад</a>
    </div>
    <div class="col-auto">
        <form method="post" class="ms-1">
            <button class="btn btn-outline-secondary" type="submit" name="clearHistory" id="test">Очистить журнал
            </button>
        </form>
    </div>
</div>
<h3 class="col-12 mt-4 text-center">История операций</h3>

<div class="mt-4">
    <?= nl2br($history) ?>
</div>

<?php
$content = ob_get_clean();
include_once("../pages/partial/layout.php");
?>


