<header class="container-fluid">
    <div class="top-bar row align-items-center ps-4">
        <h1><?=HEADER; ?></h1>
    </div>
</header>