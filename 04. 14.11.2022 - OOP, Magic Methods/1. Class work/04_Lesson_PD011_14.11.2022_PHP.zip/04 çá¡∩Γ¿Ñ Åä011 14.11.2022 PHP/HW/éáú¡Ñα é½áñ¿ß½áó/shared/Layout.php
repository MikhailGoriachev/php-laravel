<?php

function isActivePage($activePage, $linkName):string{
    return $activePage === $linkName? 'active' : '';
}


function createNavBar(string $activePage, string $prefixInner = "", string $prefixInd = ""): void
{
    $isActivePage = 'isActivePage';

    $navBarStr = <<<Task
        <nav class="navbar navbar-expand-sm navbar-dark bg-dark sticky-top shadow">
        <div class="container-fluid justify-content-center">
            <a class="navbar-brand" href="{$prefixInd}index.php">Home work</a>

            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">

                    <!-- Главная -->
                    <li class="nav-item">
                        <a class="nav-link ms-3 {$isActivePage($activePage,"index")}" href="{$prefixInd}index.php">Главная</a>
                    </li>

                    <!-- Задача 1 - -->

                    <li class="nav-item">
                        <a class="nav-link {$isActivePage($activePage,"task1")}" href="{$prefixInner}task1.php">
                        Задача 1
                        </a>
                    </li>

                    <!-- Задача 2 -  -->
                    <li class="nav-item">
                        <a class="nav-link {$isActivePage($activePage,"task2")}" href="{$prefixInner}task2.php">Задача 2</a>
                    </li>
                    


                </ul>
            </div>
        </div>
        </nav>
        Task;

    echo $navBarStr;
}

//Вывод подвала
function footer(): void
{
    echo <<<footer
        <footer class="bg-dark">
            <b>Разработчик:</b> Вагнер Владислав
            <b><br>Группа:</b> ПД011
            <b><br>Город:</b> Донецкая область,Макеевка.
            <b><br>Год разработки:</b> 2022
        </footer>
    footer;

}