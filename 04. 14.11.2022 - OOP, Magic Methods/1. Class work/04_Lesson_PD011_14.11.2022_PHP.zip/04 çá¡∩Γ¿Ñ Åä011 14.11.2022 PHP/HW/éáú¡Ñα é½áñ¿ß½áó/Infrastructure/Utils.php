<?php

// генерация вещественного случайного числа
function getRand_float ($lo, $hi) {
    return ($lo + lcg_value()*(abs($hi - $lo)));
} // random_float

// генерация целочисленного случайного числа
function randomInt ($lo, $hi) {
    return random_int($lo,$hi);
} // random_float

//Плотности взависимости от матераиала
$densities = array(
    'Steel' => 7856,
    'Aluminium' => 2700,
    'Ice' => 918,
    'Granite' => 2600,
);

//Имена файлов картинок фигур
$figuresFilesNames = array(
    'Sphere' => "sphere.png",
    'Cone' => "cone.png",
    'Cylinder' => "cylinder.png"
);
//Имена файлов картинок материалов
$figuresFilesNames = array(
    'Steel' => "steel.jpg",
    'Aluminium' => "aluminium.jpg",
    'Ice' => "ice.jpg",
    'Granite' => "granite.jpg"
);