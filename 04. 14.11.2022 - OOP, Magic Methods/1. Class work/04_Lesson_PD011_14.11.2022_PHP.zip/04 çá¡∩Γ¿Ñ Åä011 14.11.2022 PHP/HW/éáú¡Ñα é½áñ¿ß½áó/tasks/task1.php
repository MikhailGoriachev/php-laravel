<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Задача 1</title>
    <link rel="stylesheet" href="../assets/styles/styles.css">
    <link rel="stylesheet" href="../assets/lib/bootstrap/css/bootstrap.min.css">
    <script src="../assets/lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!--Подключение удалённого шрифта через репозиторий Google Fonts-->
    <link rel="stylesheet" href='https://fonts.googleapis.com/css2?family=Open+Sans:wght@500&display=swap'>
</head>
<body>


<?php

require_once "shared/Layout.php";
require_once "Infrastructure/Utils.php";
require_once "app/task1_functions.php";

$taskRender = task1Main();

createNavBar('task1', prefixInd: "../");

//Вывод текста задания
$task = <<<task
    <!--Вывод задачи-->
    <details class="task-details ms-3 me-3 mt-3">
        <summary class="h5 text-primary">
            Задача 1
        </summary>
        <p>
            Требуется вычислять параметры геометрических тел по выбору пользователя. Параметры тел вводить в элементы интерфейса.
        </p>
        <ul>
           <li>площадь поверхности </li>
           <li>объем</li>
           <li>масса</li>
        </ul>
        
        <p>
            Типы тел по выбору пользователя:
        </p>
        
        <ul>
           <li>конус</li>
           <li>сфера</li>
           <li>цилиндр</li>
        </ul>
        
        <p>
            Варианты материала, из которого изготовлено тело:
        </p>
        
        <ul>
           <li>сталь</li>
           <li>алюминий</li>
           <li>водяной лед</li>
           <li>гранит</li>
        </ul>
        
        <p>
            Тип фигуры и материал выбирать из выпадающих списков. 
            Необходимые числовые параметры вводить при помощи строки ввода с типом number. 
            Параметры вычисления задавать чек-боксами, собственно вычисление выполнять при клике на кнопку "Вычислить" типа submit. 
            В результаты вычислений должны также dвключаться изображения выбранного тела и материала, из которого изготовлено тело.
        </p>
        <p>
            Требуется также вести журнал операций – текстовый файл, в котором записывать дату и время выполнения расчета, исходные данные расчета, 
            результаты расчета. Предусмотрите страницу для просмотра журнала, очистки журнала.
        </p>
    </details>
task;


//Вывод обработок
$main = <<<main
    <main>
    
    <button class="btn btn-outline-primary ms-4 mt-3 p-0">
        <a class="btn" href="history.php">Журнал приложения</a>
    </button>
    
    <!--Форма-->
    <div class="row">
        <form class="col-5 mx-5 mt-4 mb-5 shadow-sm rounded border bg-light"  method="post" >
        
        <div>
            <div class="w-75 my-3" >
                <label>Выбирите тип фигуры</label>
                
                <select class="form-select" id="figure_type_list" name="figureType">
                    <option value="Sphere">Сфера</option>
                    <option value="Cone">Конус</option>
                    <option value="Cylinder">Цилиндр</option>
                </select>
            </div>
            <div class="w-75 my-3">
                <label>Выбирите материал фигуры</label>
                
                <select class="form-select" name="figureMaterial">
                    <option value="Steel">Сталь</option>
                    <option value="Aluminium">Алюминий</option>
                    <option value="Ice">Водяной лед</option>
                    <option value="Granite">Гранит</option>
                </select>
            </div>
            <div>
                <label class="d-block mt-2 me-3">Что вычислять</label>
                
                <div class="form-check">
                <input class="form-check-input" type="checkbox" id="volume_id" name="volume"/>
                <label class="form-check-label" for="volume_id">Объём фигуры</label>
                </div>
                
                <div class="form-check">
                <input class="form-check-input" type="checkbox" id="mass_id" name="mass"/>
                <label class="form-check-label" for="mass_id">Масса фигуры</label>
                </div>
                
                <div class="form-check">
                <input class="form-check-input" type="checkbox" id="square_id" name="square"/>
                <label class="form-check-label" for="square_id">Площадь фигуры</label>
                </div>
                
            </div>
            
            <div class="row">
                <div class="col-auto">
                    <label>Радиус</label>
                    <input class="form-control" type="number" step="any" name="radius">
                </div>
                
                <div class="col-auto visually-hidden" id="cylinder_h" >
                    <label>Высота цилиндра</label>
                    <input class="form-control" type="number" step="any" name="height">
                </div>
                
                <div class="col-auto visually-hidden" id="cone_l">
                    <label>Образующая конуса</label>
                    <input class="form-control" type="number" step="any" name="cone_l">
                </div>
            </div>
        </div>
        <div class="my-4">
            <input class="btn btn-outline-success" type="submit" value="Вычислить"/>
        </div>
    </form>
        $taskRender
    </div>
    </main>
    main;

echo $task . $main;

//Подвал
footer();
?>

<script src="../assets/scripts/task1_dynFields.js"></script>


</body>
</html>