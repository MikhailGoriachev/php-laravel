<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Задача 2</title>
    <link rel="stylesheet" href="../assets/styles/styles.css">
    <link rel="stylesheet" href="../assets/lib/bootstrap/css/bootstrap.min.css">
    <script src="../assets/lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!--Подключение удалённого шрифта через репозиторий Google Fonts-->
    <link rel="stylesheet" href='https://fonts.googleapis.com/css2?family=Open+Sans:wght@500&display=swap'>
</head>
<body>


<?php

require_once "shared/Layout.php";
require_once "Infrastructure/Utils.php";
require_once "app/task2_functions.php";

createNavBar('task2', prefixInd: "../");

//Вывод текста задания
$task = <<<task
    <!--Вывод задачи-->
    <details class="task-details ms-3 me-3 mt-3">
        <summary class="h5 text-primary">
            Задача 2
        </summary>
        <p>
            Загружать текстовый файл в кодировке UTF-8 на сервер, папка uploaded в приложении. Выводить на страницу текст из файла, форму для ввода текста. 
            о клику на кнопку «Дозапись» записать введенный в поле ввода текст в конец файла,  
            вывести измененный файл (AJAX не использовать).
        </p>
    </details>
task;


//Вывод обработок
$main = <<<main
    <main>
    
        <div class="alert alert-danger w-75 mx-auto" role="alert">
          Задание в разработке!
        </div>
    
    </main>
    main;

echo $task.$main;

//Подвал
footer();
?>
</body>
</html>