let typeListElem = document.getElementById("figure_type_list");

console.log(`element: ${typeListElem.innerText}`)

typeListElem.onchange = (e) => {
    let selectedVal = e.target.value;

    console.log(`selectedVal ${selectedVal}`)

    switch (selectedVal) {
        case "Cone":
            document.getElementById("cone_l").className = "col-auto";
            document.getElementById("cylinder_h").className = "col-auto visually-hidden";
            break;

        case "Cylinder":
            document.getElementById("cone_l").className = "col-auto visually-hidden";
            document.getElementById("cylinder_h").className = "col-auto";
            break;

        default:
            document.getElementById("cone_l").className = "col-auto visually-hidden";
            document.getElementById("cylinder_h").className = "col-auto  visually-hidden";
            break;
    }

}