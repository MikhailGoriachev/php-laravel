<?php

const DECIMALS = "%.2f";
const NOCOUNTING = "не вычисляется";

//Работа с log
const DIR_NAME = "App_data";
const FILE_NAME = "log.txt";

require_once "Infrastructure/Utils.php";


function task1Main() {
    if (!isset($_POST['figureType']) || !isset($_POST['figureMaterial']) || !isset($_POST['radius'])) {
        return "";
    }

        //Тип фигуры
        $figureType = $_POST['figureType'];

        //Материал для расчётов
        $figureMaterial = $_POST['figureMaterial'];

        //checkboxes
        $volumeFlag = isset($_POST['volume']);
        $massFlag = isset($_POST['mass']);
        $squareFlag = isset($_POST['square']);


        //Создание переменных для рассчёта
        $volume = $volumeFlag ? 0 : null;
        $square = $squareFlag ? 0 : null;
        $mass = $massFlag ? 0 : null;

        //region Ассоциативные массивы
        //Плотности взависимости от матераиала
        $densities = array(
            'Steel' => 7856,
            'Aluminium' => 2700,
            'Ice' => 918,
            'Granite' => 2600,
        );

        //Имена файлов картинок фигур
        $figuresFilesNames = array(
            'Sphere' => "sphere.png",
            'Cone' => "cone.png",
            'Cylinder' => "cylinder.png"
        );

        //Имена файлов картинок материалов
        $materialsFilesNames = array(
            'Steel' => "steel.jpg",
            'Aluminium' => "aluminium.jpg",
            'Ice' => "ice.jpg",
            'Granite' => "granite.jpg"
        );
        //endregion

        //Список параметров фигуры
        $figureParams = "";

        switch (true) {
            case ($figureType === "Sphere"):
                //Передаём: ссылка на объём, площадь, масса. А так же плотность матераиала
                $figureParams = sphereCounting($volume, $square, $mass, $massFlag ? $densities[$figureMaterial] : 0);
                break;

            case ($figureType === "Cone"):
                //Передаём: ссылка на объём, площадь, масса. А так же плотность матераиала
                $figureParams = coneCounting($volume, $square, $mass, $massFlag ? $densities[$figureMaterial] : 0);
                break;

            case ($figureType === "Cylinder"):
                //Передаём: ссылка на объём, площадь, масса. А так же плотность матераиала
                $figureParams = cylinderCounting($volume, $square, $mass, $massFlag ? $densities[$figureMaterial] : 0);
                break;
        }

        //Записать в файл
        writeToLogFile($figureType,$figureMaterial,$volume,$square,$mass);

        //Вывод разметки
        return task1View($figuresFilesNames[$figureType],$materialsFilesNames[$figureMaterial],$figureParams);

}



function task1View($figureImage, $materialImage,$particularFigureParams){
    return <<<EOF
        <div class="mt-4 col-5 py-4 mb-5 shadow-sm rounded border bg-light ">
        <b><p class="text-center text-Big">Результат вычислений</p></b>
        
        <div class="mx-auto">
            <img src="../assets/images/figures/$figureImage" alt="figure" class="rounded h-25">
            
            <img src="../assets/images/materials/$materialImage" alt="material"  class="rounded h-8-rem">
        </div>
        
        
        <ul class='list-group mx-3'>
        $particularFigureParams
        </ul>
        </div>
    EOF;
}

//Расчёт параметров сферы. Передаём ссылки на переменные
function sphereCounting(float &$volume = null,float &$square = null, &$mass = null,$density = 0): string{

    //Если не задан радиус
    if(!isset($_POST['radius']) /*|| $_POST['radius'] < 0*/)
        return "";

    //Радиус
    $r = $_POST['radius'];

    //Вычисление объёма, если задана такая переменная
    if (!is_null($volume) )
        $volume = 4/3*M_PI*$r**3;

    //Вычисление площади, если задана такая переменная
    if (!is_null($square))
        $square = 4*M_PI*$r**2;

    //Вычисление массы, если задана такая переменная
    if (!is_null($mass))
        //p * v
        $mass = (4/3*M_PI*$r**3) * $density;

    $volumeTemp = !is_null($volume) ? sprintf(DECIMALS, $volume) : NOCOUNTING;
    $squareTemp = !is_null($square) ? sprintf(DECIMALS, $square) : NOCOUNTING;
    $massTemp = !is_null($mass) ? sprintf(DECIMALS, $mass) : NOCOUNTING;


    return <<<EOF
            <ul class="list-group-item p-3 justify-content-between">R: $r</ul>
            <ul class="list-group-item p-3 justify-content-between">Volume: $volumeTemp</ul>
            <ul class="list-group-item p-3 justify-content-between">Square: $squareTemp</ul>
            <ul class="list-group-item p-3 justify-content-between">Mass: $massTemp</ul>
            <ul class="list-group-item p-3 justify-content-between">Плотность: $density</ul>
    EOF;
}

//Расчёт параметров конуса. Передаём ссылки на переменные
function coneCounting(float &$volume = null,float &$square = null, &$mass = null,$density = 0): string{

    //Если не задан радиус или длина образующей
    if(!isset($_POST['radius']) || !isset($_POST['cone_l']))
        return "";

    //Радиус
    $r = floatval($_POST['radius']);
    //Образующая
    $l = floatval($_POST['cone_l']);

    //Сохранить состояние переменной
    $volumeFlag = $volume;

    //Вычисление объёма, если задана такая переменная или если нужно вычислить массу
    if (!is_null($volume) || !is_null($mass)) {

        //Высота
        $h = sqrt($l*$l-$r*$r);

        //Объем V = 1/3 * Pi * r^2 * h
        $volume = 1 / 3 * M_PI * $r*$r * $h;
    }

    //Вычисление площади, если задана такая переменная
    if (!is_null($square))
        //Площадь поверхности
        $square = M_PI * $r * ($r + $l);

    //Вычисление массы, если задана такая переменная
    if (!is_null($mass)) {
        $mass = $volume * $density;

        //Возвращаем сохраненное состояние
        $volume = is_null($volumeFlag) ? null : $volume;
    }

    $volumeTemp = !is_null($volume) ? sprintf(DECIMALS, $volume) : NOCOUNTING;
    $squareTemp = !is_null($square) ? sprintf(DECIMALS, $square) : NOCOUNTING;
    $massTemp = !is_null($mass) ? sprintf(DECIMALS, $mass) : NOCOUNTING;


    return <<<EOF
            <ul class="list-group-item p-3 justify-content-between">R: $r</ul>
            <ul class="list-group-item p-3 justify-content-between">L: $l</ul>
            <ul class="list-group-item p-3 justify-content-between">Volume: $volumeTemp</ul>
            <ul class="list-group-item p-3 justify-content-between">Square: $squareTemp</ul>
            <ul class="list-group-item p-3 justify-content-between">Mass: $massTemp</ul>
            <ul class="list-group-item p-3 justify-content-between">Плотность: $density</ul>
    EOF;
}

//Расчёт параметров конуса. Передаём ссылки на переменные
function cylinderCounting(float &$volume = null,float &$square = null, &$mass = null,$density = 0): string{

    //Если не задан радиус или длина образующей
    if(!isset($_POST['radius']) || !isset($_POST['height']))
        return "";

    //Радиус
    $r = $_POST['radius'];
    //Высота
    $h = $_POST['height'];


    //Вычисление объёма, если задана такая переменная или если нужно вычислить массу
    if (!is_null($volume))
        //Объем V = Pi * r^2 * h
        $volume = M_PI * $r*$r * $h;

    //Вычисление площади, если задана такая переменная
    if (!is_null($square))
        //Площадь поверхности
        $square = 2*M_PI * $r * $h + 2*M_PI * $r*$r;

    //Вычисление массы, если задана такая переменная
    if (!is_null($mass))
        $mass = (M_PI * $r*$r * $h) * $density;

    $volumeTemp = !is_null($volume) ? sprintf(DECIMALS, $volume) : NOCOUNTING;
    $squareTemp = !is_null($square) ? sprintf(DECIMALS, $square) : NOCOUNTING;
    $massTemp = !is_null($mass) ? sprintf(DECIMALS, $mass) : NOCOUNTING;

    return <<<EOF
            <ul class="list-group-item p-3 justify-content-between">R: $r</ul>
            <ul class="list-group-item p-3 justify-content-between">H: $h</ul>
            <ul class="list-group-item p-3 justify-content-between">Volume: $volumeTemp</ul>
            <ul class="list-group-item p-3 justify-content-between">Square: $squareTemp</ul>
            <ul class="list-group-item p-3 justify-content-between">Mass: $massTemp</ul>
            <ul class="list-group-item p-3 justify-content-between">Плотность: $density</ul>
    EOF;
}

//Запись в файл
function writeToLogFile($figureType, $material, $volume, $square, $mass): void{
    if (!file_exists(DIR_NAME))
        mkdir(DIR_NAME);

    //Открыть файловый поток
    $fs = fopen(DIR_NAME . "/" . FILE_NAME,"a");

    date_default_timezone_set("UTC");


    $volume = !is_null($volume) ? sprintf(DECIMALS, $volume) : NOCOUNTING;
    $square = !is_null($square) ? sprintf(DECIMALS, $square) : NOCOUNTING;
    $mass = !is_null($mass) ? sprintf(DECIMALS, $mass) : NOCOUNTING;

    $time = date("d-m-y H:i:s");

    //Форматированная запись в файл
    fprintf($fs, "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n",
            $time,$figureType,$material,$volume,$square,$mass
    );

    fclose($fs);
}