<?php
const FILE_PATH = "App_data/log.txt";

function readLogFile(){
    $fs = @fopen(FILE_PATH,"r");

    $str = "";

    if (!$fs)
        $str = <<<EOF
        <div class="alert alert-danger" role="alert">
          Невозможно прочитать файл!
        </div>
        EOF;

    while (!feof($fs)) {
        $str .= fgetc($fs);
    }

    fclose($fs);
    return  $str;

}

function clearFile(){
    if (!isset($_POST["clear"]))
        return;

    $fs = @fopen(FILE_PATH,"w");


    if (!$fs)
        $str = <<<EOF
        <div class="alert alert-danger" role="alert">
          Невозможно прочитать файл!
        </div>
        EOF;

    fclose($fs);
}