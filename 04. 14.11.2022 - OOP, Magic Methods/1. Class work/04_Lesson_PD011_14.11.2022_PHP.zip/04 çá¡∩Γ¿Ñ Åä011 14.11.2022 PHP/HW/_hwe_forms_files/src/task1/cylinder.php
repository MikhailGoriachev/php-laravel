<?php
/* вычисление площади поверхности и объема для цилиндра */

// площадь поверхности цилиндра
// https://www-formula.ru/2011-09-21-04-33-30
function area($r, $h) {
    return 2 * M_PI * $r * ($r + $h);
} // area


// объем цилиндра
// https://www-formula.ru/2011-09-21-10-54-43
function volume($r, $h) {
    return M_PI * $r * $r * $h;
} // volume
