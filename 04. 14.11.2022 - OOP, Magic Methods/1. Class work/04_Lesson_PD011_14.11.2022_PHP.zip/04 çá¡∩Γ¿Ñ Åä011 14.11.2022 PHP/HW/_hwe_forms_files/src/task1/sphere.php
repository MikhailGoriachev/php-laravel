<?php
/* вычисление площади поверхности и объема для шара */

// площадь поверхности шара
// https://www-formula.ru/2011-09-21-04-30-33
function area($r) {
    return 4 * M_PI * $r * $r;
} // area


// объем шара
// https://www-formula.ru/2011-09-21-10-52-47
function volume($r) {
    return 4 * M_PI * $r**3 / 3;
} // volume
