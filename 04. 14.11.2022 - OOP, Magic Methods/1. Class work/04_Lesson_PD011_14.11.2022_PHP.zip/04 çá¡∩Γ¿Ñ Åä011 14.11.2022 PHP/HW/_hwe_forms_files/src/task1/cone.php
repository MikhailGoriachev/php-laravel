<?php
/* вычисление площади поверхности и объема для конуса */

// площадь поверхности конуса
// https://www-formula.ru/2011-09-21-04-34-19
function area($r, $h) {
    return M_PI * $r * ($r + sqrt($r*$r + $h*$h));
} // area


// объем конуса
// https://www-formula.ru/2011-09-21-10-55-09
function volume($r, $h) {
    return M_PI * $r*$r*$h/3;
} // volume
