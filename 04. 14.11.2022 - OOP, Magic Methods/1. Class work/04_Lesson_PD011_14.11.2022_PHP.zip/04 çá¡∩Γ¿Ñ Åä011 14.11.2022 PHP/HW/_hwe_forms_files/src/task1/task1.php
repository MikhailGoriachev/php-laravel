<?php

// ----------------------------------------------------------------------------

// имя файла журнала операций
const TASK1_LOG_NAME = "../app_data/task1.log";

// формат вывода значений в разметку, журнал операций
const FMT = "%.3f";

// обработка формы по задаче 1 - выводит разметку результатов вычислений
function task1Action()
{
    if (!isset($_POST['body']) || !isset($_POST['material']) || !isset($_POST['r'])) {
        warning();
        return;
    } // if

    // для упрощения кода
    $body = $_POST['body'];
    $material = $_POST['material'];

    // получить значения радиуса и высоты
    $r = +$_POST['r'];
    $h = isset($_POST['h']) ? $_POST['h'] : 0;
    if ($body !== 'sphere' && $h === 0) {
        warning();
        return;
    } // if

    // флаги для заданных чекбоксами вычислений
    $needVolume = isset($_POST['volume']);
    $needArea = isset($_POST['area']);
    $needMass = isset($_POST['mass']);

    // ассоциативный массив с плотностями материалов
    $materialInfo = [
        "steel"     => [7850.0, 'сталь',       'steel.png'],
        "aluminium" => [2698.9, 'алюминий',    'aluminium.png'],
        "water-ice" => [916.7,  'водяной лед', 'water_ice.png'],
        "granite"   => [2600.0, 'гранит',      'granite.png'],
    ];

    // инициализация переменных для вычисления объема, площади, массы соответственно
    $volume = $area = $mass = 0;

    // вычисления в зависимости от типа тела
    switch ($body):
        case 'cone':
            require_once 'cone.php';
            $volume = $needVolume ? volume($r, $h) : 0;
            $area = $needArea ? area($r, $h) : 0;

            // объем вычисляем явно, т.к. возможен случай, при котором
            // не требуется вычислять объем, но требуется вычислять массу
            $mass = $needMass ? volume($r, $h) * $materialInfo[$material][0] : 0;
            break;

        case 'cylinder':
            require_once 'cylinder.php';
            $volume = $needVolume ? volume($r, $h) : 0;
            $area = $needArea ? area($r, $h) : 0;

            // объем вычисляем явно, т.к. возможен случай, при котором
            // не требуется вычислять объем, но требуется вычислять массу
            $mass = $needMass ? volume($r, $h) * $materialInfo[$material][0] : 0;
            break;

        case 'sphere':
            require_once 'sphere.php';
            $volume = $needVolume ? volume($r) : 0;
            $area = $needArea ? area($r) : 0;

            // объем вычисляем явно, т.к. возможен случай, при котором
            // не требуется вычислять объем, но требуется вычислять массу
            $mass = $needMass ? volume($r) * $materialInfo[$material][0] : 0;
            break;
    endswitch;

    // запись данных в журнал
    task1LogWrite(TASK1_LOG_NAME, $body, $materialInfo[$material], $r, $h, $volume, $area, $mass);

    // формирование представления результатов
    task1View($body, $materialInfo[$material], $r, $h, $volume, $area, $mass);
} // task1Action

// вывод предупреждения о некорректных параметрах вычислений
function warning(){
    echo "
    <div class='alert alert-warning'>
        <strong>Предупреждение</strong><br>
        Не все данные введены, расчет невозможен
    </div>";
} // warning

// формирование разметки для вывода результата
function task1View($body, $material, $r, $h, $volume, $area, $mass){
    // предобработка для вывода значений
    $r = sprintf(FMT, $r);
    if ($h === 0):
        $disabled = "disabled";
    else:
        $disabled = "";
        $h = sprintf(FMT, $h);
    endif;

    $volume = $volume === 0 ? "расчет не требуется" : sprintf(FMT, $volume);
    $area = $area === 0 ? "расчет не требуется" : sprintf(FMT, $area);
    $mass = $mass === 0 ? "расчет не требуется" : sprintf(FMT, $mass);

    // формирование имен файлов для вывода изображений
    $imgBody = "../images/task1/bodies/$body.png";
    $imgMaterial = "../images/task1/materials/$material[2]";

    echo "
        <div class='d-flex m-3 justify-content-center'>
            <img src='$imgBody' class='w-25' alt='Изображения для фигуры $body'/>
            <img src='$imgMaterial' class='w-25' alt='Изображения для материала $material[1]'/>
        </div>
        <ul class='list-group w-75 mx-auto'>
          <li class='list-group-item d-flex justify-content-between p-3'><span>Тип тела:</span> <b>$body</b></li>
          <li class='list-group-item d-flex justify-content-between p-3'><span>Материал:</span> <b>$material[1]</b></li>
          <li class='list-group-item d-flex justify-content-between p-3'><span>Плотность, кг/м<sup>3</sup>:</span> <b>$material[0]</b></li>
          <li class='list-group-item d-flex justify-content-between p-3'><span>Радиус, м:</span> <b>$r</b></li>
          <li class='list-group-item d-flex justify-content-between p-3 $disabled'><span>Высота, м:</span> <b>$h</b></li>
          <li class='list-group-item d-flex justify-content-between p-3'><span>Площадь поверхности, м<sup>2</sup>:</span> <b>$area</b></li>
          <li class='list-group-item d-flex justify-content-between p-3'><span>Объем, м<sup>3</sup>:</span> <b>$volume</b></li>
          <li class='list-group-item d-flex justify-content-between p-3'><span>Масса, кг:</span> <b>$mass</b></li>
        </ul>
    ";
} // task1View

// запись данных в журнал
function task1LogWrite($logName, $body, $material, $r, $h, $volume, $area, $mass) {
    $f = @fopen($logName, "a");
    if (!$f) {
        echo "
        <div class='alert alert-danger'>
            <strong>Ошибка</strong><br>
            Не могу открыть файл журнала <u>$logName</u> для записи
        </div>";
        return;
    } // if

    $h = $h === 0 ? "" : sprintf(FMT, $h);
    $volume = $volume === 0 ? "расчет не требуется" : sprintf(FMT, $volume);
    $area = $area === 0 ? "расчет не требуется" : sprintf(FMT, $area);
    $mass = $mass === 0 ? "расчет не требуется" : sprintf(FMT, $mass);

    // установить правильный часовой пояс
    // https://phpclub.ru/talk/threads/Корректировка-результата-функции-date-относительно-часового-пояса.51609/
    date_default_timezone_set('Europe/Moscow');

    // дата и время в PHP: https://daruse.ru/tekushhaya-data-i-vremya-php
    @fprintf(
        $f,
        "<tr><td>%s</td><td>%s</td><td>%s</td><td>%.3f</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n",
        date("d-m-y")." ".date("H:i:s"), $body, $material[1], $r, $h, $volume, $area, $mass
    );

    fclose($f);
} // task1LogWrite


// чтение данных из журнала
function task1LogView($logName) {
    $f = @fopen($logName, "r");
    if (!$f) {
        echo "
        <div class='alert alert-danger'>
            <strong>Ошибка</strong><br>
            Не могу открыть файл журнала <u>$logName</u> для чтения
        </div>";
        return;
    } // if

    while(!feof($f)):
        echo fgets($f);
    endwhile;

    fclose($f);
} // task1LogWrite

// очистка файла журнала
function task1LogClear($logName) {
    // Открытие файла в режиме "w" уничтожает все записи файла
    $f = @fopen($logName, "w");
    if (!$f) {
        echo "
        <div class='alert alert-danger'>
            <strong>Ошибка</strong><br>
            Не могу открыть файл журнала <u>$logName</u> для очистки
        </div>";
        return;
    } // if

    fclose($f);
} // task1LogClear