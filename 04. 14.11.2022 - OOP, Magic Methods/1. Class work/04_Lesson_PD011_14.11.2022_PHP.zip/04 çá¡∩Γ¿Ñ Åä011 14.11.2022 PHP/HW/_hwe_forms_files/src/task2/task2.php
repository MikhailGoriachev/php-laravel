<?php

const TASK2_PATH_UPLOADED = "../app_data/uploaded";
const TASK2_LAST_UPLOADED = "../app_data/last_uploaded.txt";

// загрузка файла, имя которого введено в форме
// возвращает имя загруженного файла или false, если
// оказалось невозможным загрузить файл
function task2UploadFile() {
    // если вызов функции не из формы загрузки файла - выходим
    if (!isset($_POST['upload'])) return false;

    if (!file_exists(TASK2_PATH_UPLOADED)) {
        mkdir(TASK2_PATH_UPLOADED);
    } // if

    // переместить загруженный файл из папки временных файлов в папку назначения
    // app_data/uploaded
    $fileName = TASK2_PATH_UPLOADED.'/'.$_FILES['fileName']['name'];
    move_uploaded_file($_FILES['fileName']['tmp_name'], $fileName);

    // сохранить имя последнего загруженного файла в служебном файле
    // app_data/last_uploaded.txt
    file_put_contents(TASK2_LAST_UPLOADED, $fileName);

    return $fileName;
} // task2UploadFile


// вывод загруженного файла по его имени
function task2ViewFile($fileName) {
    // открыть файл для чтения
    $fd = @fopen($fileName, 'r');
    if (!$fd) {
        echo "
            <div class='alert alert-danger'>
                <strong>Ошибка</strong><br>
                На могу открыть файл <u>$fileName</u> для чтения
            </div>";
        return;
    } // if

    echo "<h5 class='text-center'>Файл <u>$fileName</u></h5>";
    while(!feof($fd)):
        // htmlentities() - перекодировка html-разметки для вывода в браузер
        $str = htmlentities(fgets($fd));
        echo "$str<br/>";
    endwhile;
    fclose($fd);
} // task2ViewFile

// дозапись а файл заданного текста
function task2AppendFile($fileName, $text) {
    $f = @fopen($fileName, "a");
    if (!$f) return false;

    fputs($f, $text."\n");

    fclose($f);
    return true;
} // task2AppendFile