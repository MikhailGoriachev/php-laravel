<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>Задание на 14.11.2022</title>
    <!-- подключение файла-иконки -->
    <link rel="shortcut icon" href="../images/blimp.png" type="image/x-icon">

    <!-- подключение bootstrap -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- подключение собственных стилей -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php
// загрузка панели навигации

// активность страниц
$activeTask01Log = "active";
$activateTask01Form = $activeTask02 = "";

// собственно загрузка панели навигации
include_once "../pages/shared/_header.php";
?>

<!-- размещение контента страницы -->
<main class="container mt-5">
    <div class="row">
        <details>
            <summary><b>Задача 1.</b> Работа с формами и текстовым файлом</summary>
            <p>
                Требуется вычислять параметры геометрических тел по выбору пользователя.
                Параметры тел вводить в элементы интерфейса.
            </p>
            <ul class="ms-5">
                <li>площадь поверхности</li>
                <li>объем</li>
                <li>масса</li>
            </ul>
            <p>Типы тел по выбору пользователя:</p>
            <ul class="ms-5">
                <li>конус</li>
                <li>сфера</li>
                <li>цилиндр</li>
            </ul>
            <p>Варианты материала, из которого изготовлено тело:</p>
            <ul class="ms-5">
                <li>сталь</li>
                <li>алюминий</li>
                <li>водяной лед</li>
                <li>гранит</li>
            </ul>
            <p>
                Тип фигуры и материал выбирать из выпадающих списков. Необходимые числовые параметры вводить при помощи
                строки ввода с типом <b>number</b>. Параметры вычисления задавать чек-боксами, собственно вычисление выполнять при
                клике на кнопку "Вычислить" типа <b>submit</b>. В результаты вычислений должны также включаться изображения
                выбранного тела и материала, из которого изготовлено тело.
            </p>
            <p>
                Требуется также вести журнал операций – текстовый файл, в котором записывать дату и время выполнения расчета,
                исходные данные расчета, результаты расчета. Предусмотрите страницу для просмотра журнала, очистки
                журнала.
            </p>
        </details>

        <div class="row">
            <h5 class="mt-3 col-6">Решение задачи 1 - работа с формами, текстовым файлом</h5>
            <form class="col-1" method="post">
                <input class="btn btn-danger" type="submit" name="clear" value="Очистка журнала"/>
            </form>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>Дата и время</th>
                    <th>Тип тела</th>
                    <th>Материал тела</th>
                    <th>Радиус, м</th>
                    <th>Высота, м</th>
                    <th>Объем, м<sup>3</sup></th>
                    <th>Площадь поверхности, м<sup>2</sup></th>
                    <th>Масса, кг</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    require_once("../src/utils.php");
                    require_once("../src/task1/task1.php");

                    // очистка журнала по клику на кнопку формы
                    if (isset($_POST['clear'])) task1LogClear(TASK1_LOG_NAME);

                    // вывести представление файла журнала
                    task1LogView(TASK1_LOG_NAME);
                ?>
            </tbody>
        </table>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../pages/shared/_footer.php" ?>
</body>
</html>

