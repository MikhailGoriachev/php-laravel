<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>Задание на 14.11.2022</title>
    <!-- подключение файла-иконки -->
    <link rel="shortcut icon" href="../images/blimp.png" type="image/x-icon">

    <!-- подключение bootstrap -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- подключение собственных стилей -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php
    // загрузка панели навигации

    // активность страниц
    $activeTask01Form = "active";
    $activeTask01Log = $activeTask02 = "";

    // собственно загрузка панели навигации
    include_once "../pages/shared/_header.php";
?>

<!-- размещение контента страницы -->
<main class="container mt-5">
    <div class="row">
        <details>
            <summary><b>Задача 1.</b> Работа с формами и текстовым файлом</summary>
            <p>
                Требуется вычислять параметры геометрических тел по выбору пользователя.
                Параметры тел вводить в элементы интерфейса.
            </p>
            <ul class="ms-5">
                <li>площадь поверхности</li>
                <li>объем</li>
                <li>масса</li>
            </ul>
            <p>Типы тел по выбору пользователя:</p>
            <ul class="ms-5">
                <li>конус</li>
                <li>сфера</li>
                <li>цилиндр</li>
            </ul>
            <p>Варианты материала, из которого изготовлено тело:</p>
            <ul class="ms-5">
                <li>сталь</li>
                <li>алюминий</li>
                <li>водяной лед</li>
                <li>гранит</li>
            </ul>
            <p>
                Тип фигуры и материал выбирать из выпадающих списков. Необходимые числовые параметры вводить при помощи
                строки ввода с типом <b>number</b>. Параметры вычисления задавать чек-боксами, собственно вычисление выполнять при
                клике на кнопку "Вычислить" типа <b>submit</b>. В результаты вычислений должны также включаться изображения
                выбранного тела и материала, из которого изготовлено тело.
            </p>
            <p>
                Требуется также вести журнал операций – текстовый файл, в котором записывать дату и время выполнения расчета,
                исходные данные расчета, результаты расчета. Предусмотрите страницу для просмотра журнала, очистки
                журнала.
            </p>
        </details>

        <h5 class="my-3">Решение задачи 1 - работа с формами, текстовым файлом</h5>

        <div class="row my-3">
            <!-- форма ввода параметров вычислений в левой половине страинцы -->
            <form class="col-5" method="post">
                <div class="row my-3">
                    <div class="col-6">
                        <label class="form-label">Объемное тело:</label>
                        <select class="form-select" name="body" id="body">
                            <option value="cone">Конус</option>
                            <option value="cylinder">Цилиндр</option>
                            <option value="sphere">Сфера</option>
                        </select>
                    </div>

                    <div class="col-6">
                        <label class="form-label">Материал:</label>
                        <select class="form-select" name="material" id="material">
                            <option value="aluminium">Алюминий</option>
                            <option value="water-ice">Водяной лед</option>
                            <option value="granite">Гранит</option>
                            <option value="steel">Сталь</option>
                        </select>
                    </div>
                </div>

                <div class="my-3">
                    <label class="form-label">Радиус:</label>
                    <input class="form-control" type="number" name="r" id="r" step="any" min="1e-6"/>
                </div>

                <div class="my-3">
                    <label class="form-label">Высота (для сферы не учитывается):</label>
                    <input class="form-control" type="number" name="h" id="h" step="any" min="1e-6"/>
                </div>

                <div class="my-3">
                    <label class="form-label me-3">Что вычислять:</label>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="volume" id="volume" value="volume">
                        <label class="form-check-label" for="volume">объем</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="area" id="area" value="area">
                        <label class="form-check-label" for="area">площадь</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="mass" id="mass" value="mass">
                        <label class="form-check-label" for="mass">массу</label>
                    </div>
                </div>

                <div class="my-3">
                    <input class="btn btn-success" type="submit" value="Вычислить">
                    <input class="btn btn-secondary" type="reset" value="Сброс">
                </div>
            </form>

            <!-- область вывода результатов вычислений -->
            <div class="col-5 ms-5" id="result">
                <h5 class="text-center">Результаты вычислений:</h5>
                <!-- Изображение тела -->
                <!-- Изображение материала -->
                <!-- параметры тела -->
                <!-- результаты расчетов параметров тела -->
                <?php
                    require_once("../src/utils.php");
                    require_once("../src/task1/task1.php");
                    task1Action();
                ?>
            </div>
        </div>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../pages/shared/_footer.php" ?>
</body>
</html>

