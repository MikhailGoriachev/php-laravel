<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>Задание на 14.11.2022</title>
    <!-- подключение файла-иконки -->
    <link rel="shortcut icon" href="/images/blimp.png" type="image/x-icon">

    <!-- подключение bootstrap -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- подключение собственных стилей -->
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>

<?php
// активность страниц
$activeTask02 = "active";
$activeTask01Form = $activeTask01Log = "";

// загрузка панели навигации
include_once "../pages/shared/_header.php";
?>

<!-- размещение контента страницы -->
<main class="container mt-5">
    <div class="row">
        <details>
            <summary><b>Задача 2.</b> Загрузка и обработка текстового файла</summary>
            <p>
                <b>Задача 2.</b> Загружать текстовый файл в коди
                на сервер, папка uploaded в приложении. Выводить
                текст из файла, форму для ввода текста. По клику
                на кнопку «Дозапись» записать введенный в поле
                ввода текст вывести измененный файл (AJAX не
                использовать).
            </p>
        </details>

        <h5 class="my-3">Решение задачи 2 - загрузка и обработка текстового файла</h5>
        <div class="row">
            <div class="col-5">
                <!-- форма выбора файла для загрузки и обработки -->
                <!-- атрибут enctype='multipart/form-data' делает возможным загрузку файлов -->
                <form enctype='multipart/form-data' method="post">
                    <div class="form-file">
                        <label class="form-label">Выберите файл для загрузки:</label>
                        <label class="form-file-label" for="fileName">
                            <input type='file' name='fileName' size='10' class="form-file-text"/>
                        </label>
                    </div>
                    <div class="my-3">
                        <input type="submit" name="upload" value="Загрузить" class="btn btn-success"/>
                    </div>
                </form>
                <!-- место вывода загруженного файла -->
                <div class="m-3 p-3">
                    <?php
                    require_once "../src/utils.php";
                    require_once "../src/task2/task2.php";

                    // при обработке POST-запроса от формы загрузки файла
                    // загрузка файла и, если загрузка прошла успешно, вывод
                    // файла на страницу, сохранить имя загруженного файла в служебном
                    // файле
                    if (isset($_POST['upload'])):
                        $fileName = task2UploadFile();
                        if ($fileName !== false):
                            task2ViewFile($fileName);
                        endif;
                    // при обработке POST-запроса от формы дозаписи
                    // просто покажем последний загруженный файл
                    // (по заданию обрабатыается именно он)
                    elseif (isset($_POST['append'])):
                        $fileName = @file_get_contents(TASK2_LAST_UPLOADED);
                        if ($fileName === false):
                            echo "
                                <div class='alert alert-danger'>
                                    <strong>Ошибка</strong><br>
                                    Нет загруженных файлов или ошибки при работе со служебным файлом 
                                </div>";
                        else:
                            task2ViewFile($fileName);
                        endif;
                    endif;
                    ?>
                </div>
            </div>

            <!-- форма ввода дописываемой строки, блок вывода измененного файла -->
            <div class="col-5">
                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Текст для дозаписи в последний загруженный файл:</label>
                        <input class="form-control" name="text" type="text"/>
                    </div>

                    <div class="my-3">
                        <input type="submit" name="append" value="Дозапись" class="btn btn-success"/>
                    </div>
                </form>
                <!-- место вывода обработанного файла -->
                <div class="m-3 p-3">
                    <?php
                    // если был клик по кнопке "Дозапись" - дозаписать текст в файл, вывести
                    // файл после изменения
                    if (isset($_POST['append']) and isset($_POST['text'])):
                        // из служебного файла получить имя последнего загруженного в uploaded файла
                        $fileName = @file_get_contents(TASK2_LAST_UPLOADED);
                        if ($fileName === false):
                            echo "
                                <div class='alert alert-danger'>
                                    <strong>Ошибка</strong><br>
                                    Нет загруженных файлов или ошибки при работе со служебным файлом 
                                </div>";
                        else:
                            // дозапись текста из формы в файл, вывод текста в разметку на странице
                            $result = task2AppendFile($fileName, $_POST['text']);
                            if ($result):
                                task2ViewFile($fileName);
                            else:
                                echo "
                                <div class='alert alert-danger'>
                                    <strong>Ошибка</strong><br>
                                    Не удалось дополнить файл <u>$fileName</u>, ошибки при работе с файлом
                                </div>";
                            endif;
                        endif;
                    endif;
                    ?>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../pages/shared/_footer.php" ?>
</body>
</html>
