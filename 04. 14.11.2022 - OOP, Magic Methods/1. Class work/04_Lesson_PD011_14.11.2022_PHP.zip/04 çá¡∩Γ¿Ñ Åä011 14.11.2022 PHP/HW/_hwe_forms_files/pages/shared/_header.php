<!-- навигация по приложению, переходы по заданию -->
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand active" href="/index.php">ПД011</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#appNavbar-1">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="appNavbar-1">
            <ul class="navbar-nav">
                <!-- Переход на страницу решения задачи 1 -->
                <li class="nav-item">
                    <a class="nav-link <?= $activeTask01Form ?>" href="/pages/task01_form.php"
                       title="Переход на страницу решения задачи 1 - операции с объемными телами">Объемные тела</a>
                </li>

                <!-- Переход на страницу решения задачи Proc11 -->
                <li class="nav-item">
                    <a class="nav-link <?= $activeTask01Log?>" href="/pages/task01_log.php"
                       title="Переход на страницу решения задачи 1 - журнал операций">Журнал операций</a>
                </li>

                <!-- Переход на страницу решения Proc12 -->
                <li class="nav-item">
                    <a class="nav-link <?= $activeTask02 ?>" href="/pages/task02.php"
                       title="Переход на страницу решения задачи 2 - обработка текстового файла">Текстовый файл</a>
                </li>


            </ul>
        </div>
    </div>
</nav>
