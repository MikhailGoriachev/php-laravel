<footer class="mt-5 p-1 bg-dark text-white text-center">
    <h5>КА Шаг, ПД011, Донецк, 2022</h5>
</footer>
