<?php
    // получить данные от клиента
    $name1=$_POST['name1'];
    $age1=$_POST['age1'];
    $countries1=$_POST['countries1'];
    
    echo "<h3>Получено: </h3><ul><li>$name1</li><li>$age1</li><li>$countries1</li></ul>";
    
  
    

