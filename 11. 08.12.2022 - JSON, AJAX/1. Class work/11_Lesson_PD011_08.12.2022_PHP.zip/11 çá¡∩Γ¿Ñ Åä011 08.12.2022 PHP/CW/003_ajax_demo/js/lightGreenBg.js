// изменение только свойства css для выбранного элемента
$('body').css('background-color', 'lightgreen');
$('#out').html("<p>Скрипт отработал</p>");
console.log("Цвет фона изменен");

