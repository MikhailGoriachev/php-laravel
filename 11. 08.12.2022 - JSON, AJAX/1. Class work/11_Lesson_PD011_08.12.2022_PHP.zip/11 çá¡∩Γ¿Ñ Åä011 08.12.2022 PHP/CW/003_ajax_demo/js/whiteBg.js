// изменение только свойства css для выбранного элемента
$('body').css('background-color', 'white');