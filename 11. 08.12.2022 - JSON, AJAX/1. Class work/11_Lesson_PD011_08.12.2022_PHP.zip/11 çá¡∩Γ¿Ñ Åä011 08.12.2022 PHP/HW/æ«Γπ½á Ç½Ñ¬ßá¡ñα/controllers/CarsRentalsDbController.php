<?php


require_once "../Models/CarsRentalsDb/Car.php";
require_once "../Models/CarsRentalsDb/ClientWithRentData.php";
require_once "../Models/CarsRentalsDb/ClientByDate.php";
require_once "../Models/CarsRentalsDb/CarWithInsuranceFee.php";
require_once "../Models/CarsRentalsDb/CarWithMinInsuranceCost.php";
require_once "../Models/CarsRentalsDb/Brand.php";
require_once "../Models/CarsRentalsDb/Client.php";
require_once "../Models/CarsRentalsDb/Color.php";
require_once "../Models/CarsRentalsDb/Model.php";
require_once "../Models/CarsRentalsDb/Rental.php";
require_once "../Models/CarsRentalsDb/CarWithColor.php";

class CarsRentalsDbController
{

    // объект БД
    private PDO $pdo;

    // конструктор
    public function __construct(string $dsn, string $user, string $password, $options)
    {
        $this->pdo = new PDO($dsn, $user, $password, $options);
    }

    // цвета
    public function getColors() {
        $stmt = $this->pdo->prepare("call colors_table()");
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "Color");

        return $stmt->fetchAll();
    } // getBrands

    // марки
    public function getBrands() {
        $stmt = $this->pdo->prepare("call brands_table()");
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "Brand");

        return $stmt->fetchAll();
    } // getBrands

    // модели
    public function getModels() {
        $stmt = $this->pdo->prepare("call models_table()");
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "Model");

        return $stmt->fetchAll();
    } // getBrands

    // автомобили
    public function getCars() {
        $stmt = $this->pdo->prepare("call cars_table()");
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "Car");

        return $stmt->fetchAll();
    } // getCars

    // автомобили c цветом для выбора
    public function getCarsWithColor() {
        $stmt = $this->pdo->prepare("call cars_table()");
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "CarWithColor");

        return $stmt->fetchAll();
    } // getCars

    // прокаты
    public function getRentals() {
        $stmt = $this->pdo->prepare("call rentals_table()");
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "Rental");

        return $stmt->fetchAll();
    } // getRentals

    // клиенты
    public function getClients() {
        $stmt = $this->pdo->prepare("call clients_table()");
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "Client");

        return $stmt->fetchAll();
    } // getClients

    // Выбирает информацию об автомобилях,
    // стоимость одного дня проката которых меньше заданной
    public function getCarsByCostOneDayLess(float $cost)
    {
        $stmt = $this->pdo->prepare("call query01(:cost)");
        $stmt->bindParam(":cost", $cost, PDO::PARAM_STR);
        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_CLASS, "Car");


        return $stmt->fetchAll();
    } // getCarsByCostOneDayLess

    // Выбирает информацию об автомобилях,
    // страховая стоимость которых находится в заданном диапазоне значений
    public function getCarsByInsuranceCostInRange(float $minCost, float $maxCost)
    {
        $stmt = $this->pdo->prepare("call query02(:minCost, :maxCost)");
        $stmt->bindParam(":minCost", $minCost, PDO::PARAM_STR);
        $stmt->bindParam(":maxCost", $maxCost, PDO::PARAM_STR);
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "Car");

        return $stmt->fetchAll();
    } // getCarsByInsuranceCostInRange

    // Выбирает информацию о клиентах, серия-номер паспорта которых начинается с заданной параметром цифры.
    // Включает поля Код клиента, Паспорт, Дата начала проката, Количество дней проката, Модель автомобиля
    public function getClientsByStartNumPassport(int $number)
    {
        $stmt = $this->pdo->prepare("call query03(:number)");
        $stmt->bindParam(":number", $number, PDO::PARAM_INT);
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "ClientWithRentData");

        return $stmt->fetchAll();
    } // getClientsByStartNumPassport

    // Выбирает информацию о клиентах,
    // бравших автомобиль напрокат в некоторый определенный день.
    public function getClientsByDate(string $date)
    {
        $stmt = $this->pdo->prepare("call query04(:date)");
        $stmt->bindParam(":date", $date, PDO::PARAM_STR);
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "ClientByDate");

        return $stmt->fetchAll();
    } // getClientsByDate

    // Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса.
    // Включает поля Гос.номер автомобиля, Модель автомобиля, Год выпуска автомобиля,
    // Страховая стоимость автомобиля, Страховой взнос. Сортировка по полю Год выпуска автомобиля
    public function getInsuranceFeeEachCar() {
        $stmt = $this->pdo->prepare("call query06()");
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "CarWithInsuranceFee");

        return $stmt->fetchAll();
    } // getInsuranceFeeEachCar

    // Выполняет группировку по полю Модель автомобиля.
    // Для каждой модели вычисляет минимальную страховую стоимость автомобиля.
    public function getMinInsuranceByGroupModel() {
        $stmt = $this->pdo->prepare("call query07()");
        $stmt->execute();

        $stmt->setFetchMode(PDO::FETCH_CLASS, "CarWithMinInsuranceCost");

        return $stmt->fetchAll();
    } // getMinInsuranceByGroupModel

    // добавить прокат
    public function addRental(int $idClient, int $idCar, string $date, int $duration) {
        $query = "
        insert into rentals
            (id_client, id_car, date_start, duration)  
        values
            (:idClient, :idCar, :date, :duration)";

        $stmt = $this->pdo->prepare($query);

        $stmt->bindParam(':idClient', $idClient, PDO::PARAM_INT);
        $stmt->bindParam(':idCar', $idCar, PDO::PARAM_INT);
        $stmt->bindParam(':date', $date, PDO::PARAM_STR);
        $stmt->bindParam(':duration', $duration, PDO::PARAM_INT);

        $stmt->execute();
    } // addRental

    public function updateCost(int $idCar, float $cost) {
        $query = "
        update cars
        set insurance_cost=:cost
        where 
            cars.id = :idCar";

        $stmt = $this->pdo->prepare($query);

        $stmt->bindParam(':idCar', $idCar, PDO::PARAM_INT);
        $stmt->bindParam(':cost', $cost, PDO::PARAM_STR);

        $stmt->execute();
    }
}