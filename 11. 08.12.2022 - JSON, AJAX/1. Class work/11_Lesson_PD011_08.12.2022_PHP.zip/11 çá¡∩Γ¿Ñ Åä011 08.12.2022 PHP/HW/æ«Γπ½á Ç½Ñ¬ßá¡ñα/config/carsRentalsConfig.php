<?php
$db = "cars_rentals_sotula";

$dsn_config = "mysql:host=localhost;port=3306;dbname=$db;charset=utf8";

$user_config = "root";

$password_config = "___sP123456890...";

$options_config = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
];
