<!DOCTYPE html>
<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Задача 1</title>

    <link rel="icon" href="../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">

    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Задача 1</h1>
</header>

<?php


require_once '../controllers/CarsRentalsDbController.php';

// активность страниц
$activeTask01 = "active";
$activeTask02 = $activeMain = "";

require_once '../src/utils.php';
require_once '../src/header.php';

?>

<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1">

    </div>

    <!--    основной блок контента-->
    <div class="col-sm-10">

        <?php
        // нажатая кнопка
        $btn = $_POST['button'] ?? false;

        if ($btn) {
            switch ($btn) {
                // таблица марок
                case 'brands':
                    require_once '../src/carsRentalsDb/tables/brands.php';
                    showBrandsTable();
                    break;

                // таблица автомобилей
                case 'cars':
                    require_once '../src/carsRentalsDb/tables/cars.php';
                    showCarsTable();
                    break;

                // таблица клиентов
                case 'clients':
                    require_once '../src/carsRentalsDb/tables/clients.php';
                    showClientsTable();
                    break;

                // таблица цветов
                case 'colors':
                    require_once '../src/carsRentalsDb/tables/colors.php';
                    showColorsTable();
                    break;

                // таблица моделей
                case 'models':
                    require_once '../src/carsRentalsDb/tables/models.php';
                    showModelsTable();
                    break;

                // таблица прокатов
                case 'rentals':
                    require_once '../src/carsRentalsDb/tables/rentals.php';
                    showRentalsTable();
                    break;


                //
                case 'query01':
                    require_once '../src/carsRentalsDb/queries/query01.php';
                    query01();
                    break;

                case 'query02':
                    require_once '../src/carsRentalsDb/queries/query02.php';
                    query02();
                    break;

                case 'query03':
                    require_once '../src/carsRentalsDb/queries/query03.php';
                    query03();
                    break;

                // Выбирает информацию о клиентах,
                // бравших автомобиль напрокат в некоторый определенный день.
                case 'query04':
                    require_once '../src/carsRentalsDb/queries/query04.php';
                    query04();
                    break;

                // Выбирает информацию об автомобилях, для которых значение
                // в поле Страховая стоимость автомобиля попадает в некоторый заданный интервал.
                case 'query05':
                    require_once '../src/carsRentalsDb/queries/query05.php';
                    query05();
                    break;

                // Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса.
                // Включает поля Госномер автомобиля, Модель автомобиля, Год выпуска автомобиля,
                // Страховая стоимость автомобиля, Страховой взнос. Сортировка по полю Год выпуска автомобиля
                case 'query06':
                    require_once '../src/carsRentalsDb/queries/query06.php';
                    query06();
                    break;

                // Выполняет группировку по полю Модель автомобиля.
                // Для каждой модели вычисляет минимальную страховую стоимость автомобиля.
                case 'query07':
                    require_once '../src/carsRentalsDb/queries/query07.php';
                    query07();
                    break;
            }

            // обработка данных от форм с параметрами запросов
        } else if ($_POST) {

            if (isset($_POST['add']) || isset($_POST['client'])) {
                require_once "../src/carsRentalsDb/addRental.php";
                addRental();
            } elseif (isset($_POST['update']) || isset($_POST['cost'])) {
                require_once "../src/carsRentalsDb/update.php";
                update();
            }


        } // рендер выбора запроса
        else { ?>
            <div class="row mt-5">
                <h4 class="h4 text-center mb-5">Таблицы</h4>

                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="colors">Цвета
                    </button>
                </form>

                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="brands">Марки
                    </button>
                </form>

                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="models">Модели
                    </button>
                </form>

                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="cars">Автомобили
                    </button>
                </form>

                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="clients">Клиенты
                    </button>
                </form>

                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="rentals">Прокаты
                    </button>
                </form>


            </div>

            <div class="row mt-5">
                <h4 class="h4 text-center mb-5">Запросы</h4>


                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="query01">
                        Автомобили, стоимость дня проката меньше заданной
                    </button>
                </form>

                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="query02">
                        Автомобилях, страховая стоимость в диапазоне
                    </button>
                </form>

                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="query03">
                        Клиенты с указанным началом паспорта
                    </button>
                </form>

                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="query04">
                        Клиенты бравшие авто в определенный день
                    </button>
                </form>

                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="query05">
                        Автомобили по интервалу страховой стоимости
                    </button>
                </form>

            </div>

            <div class="row mt-5">
                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="query06">
                        Страховой взнос для каждого авто
                    </button>
                </form>

                <form class="form-inline col-sm-2 mx-auto" method="post">
                    <button type="submit" class="btn btn-outline-dark col-sm-12" name="button" value="query07">
                        Мин-ая страховая стоимость каждой модели
                    </button>
                </form>
            </div>
            <?php
        } ?>

    </div>

    <!--    правый сайд бар-->
    <div class="col-sm-1"></div>
</div>
<!--футер-->
<?php
require_once '../src/footer.php';
?>
</body>
</html>
