<!DOCTYPE html>
<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Задача 2</title>

    <link rel="icon" href="../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">

    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Задача 2</h1>
</header>

<?php

// активность страниц
$activeTask02 = "active";
$activeTask01 = $activeMain = "";

require_once '../src/utils.php';
require_once '../src/header.php';

?>

<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1">

    </div>

    <!--    основной блок контента-->
    <div class="col-sm-10">

        <h4 class="text-center h4 mt-5">Задание в разработке...</h4>

    </div>

    <!--    правый сайд бар-->
    <div class="col-sm-1"></div>
</div>
<!--футер-->
<?php
require_once '../src/footer.php';
?>
</body>
</html>
