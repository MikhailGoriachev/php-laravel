<?php

class Color
{
    private int $id;
    private string $name;

    public function toTableRow(): string
    {
        return "<tr>
                    <td class='text-center'>$this->id</td>
                    <td>$this->name</td>
               </tr>";
    }
}