<?php

class CarWithInsuranceFee {
    private string $plate;
    private string $model;
    private int $year_manufacture;
    private float $insurance_cost;
    private float $insurance_fee;

    public function toTableRow(): string{
        return "<tr>
                    <td>$this->plate</td>
                    <td>$this->model</td>
                    <td class='text-center'>$this->year_manufacture</td>
                    <td class='text-center'>" . number_format($this->insurance_cost, 2, ".", " ") . "</td>
                    <td class='text-center'>" . number_format($this->insurance_fee, 2, ".", " ") . "</td>
               </tr>";
    }
}