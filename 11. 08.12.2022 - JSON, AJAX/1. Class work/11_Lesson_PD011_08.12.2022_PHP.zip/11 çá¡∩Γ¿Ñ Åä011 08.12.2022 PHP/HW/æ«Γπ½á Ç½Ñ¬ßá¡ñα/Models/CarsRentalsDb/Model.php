<?php

class Model
{
    private int $id;
    private string $brand;
    private string $model;

    public function toTableRow(): string
    {
        return "<tr>
                    <td class='text-center'>$this->id</td>
                    <td>$this->brand</td>
                    <td>$this->model</td>
               </tr>";
    }
}