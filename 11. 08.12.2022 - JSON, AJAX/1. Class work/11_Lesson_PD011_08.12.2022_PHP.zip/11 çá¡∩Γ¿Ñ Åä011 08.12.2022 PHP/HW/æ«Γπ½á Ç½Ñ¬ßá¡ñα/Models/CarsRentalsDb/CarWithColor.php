<?php

class CarWithColor
{
    private int $id;
    private string $brand;
    private string $model;
    private string $color;
    private float $cost_one_day;

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }

    public function getBrand(): string
    {
        return $this->brand;
    }

    public function setBrand(string $brand): void
    {
        $this->brand = $brand;
    }

    public function getModel(): string
    {
        return $this->model;
    }

    public function setModel(string $model): void
    {
        $this->model = $model;
    }

    public function getColor(): string
    {
        return $this->color;
    }

    public function setColor(string $color): void
    {
        $this->color = $color;
    }

    public function getCostOneDay(): float
    {
        return $this->cost_one_day;
    }

    public function setCostOneDay(float $cost_one_day): void
    {
        $this->cost_one_day = $cost_one_day;
    }

}