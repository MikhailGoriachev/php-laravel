<?php

// представление для клиента, для запроса 3
class ClientWithRentData
{
    private int $id_client;
    private string $passport;
    private string $full_name_client;
    private string $date_start;
    private int $duration;
    private string $model;

    public function toTableRow(): string {
        return "<tr>
                    <td class='text-center'>$this->id_client</td>
                    <td>$this->passport</td>
                    <td>$this->full_name_client</td>
                    <td class='text-center'>$this->date_start</td>
                    <td class='text-center'>$this->duration</td>
                    <td>$this->model</td>
               </tr>";
    }


}