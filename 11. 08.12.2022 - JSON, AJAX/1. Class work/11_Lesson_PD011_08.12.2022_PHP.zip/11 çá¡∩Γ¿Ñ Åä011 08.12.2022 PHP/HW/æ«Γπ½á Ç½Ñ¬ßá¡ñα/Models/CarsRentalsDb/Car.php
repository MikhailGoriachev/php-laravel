<?php

class Car
{
    private int $id;
    private string $brand;
    private string $model;
    private string $color;
    private string $plate;
    private int $year_manufacture;
    private float $insurance_cost;
    private float $cost_one_day;


    public function toTableRow(): string
    {
        return "<tr>
                    <td>$this->brand</td>
                    <td>$this->model</td>
                    <td>$this->plate</td>
                    <td class='text-center'>$this->year_manufacture</td>
                    <td class='text-center'>" . number_format($this->insurance_cost, 2, ".", " ") . "</td>
                    <td class='text-center'>" . number_format($this->cost_one_day, 2, ".", " ") . "</td>
               </tr>";
    }

    public function toTableRowWithId(): string
    {
        return "<tr>
                    <td>$this->id</td>
                    <td>$this->brand</td>
                    <td>$this->model</td>
                    <td>$this->color</td>
                    <td>$this->plate</td>
                    <td class='text-center'>$this->year_manufacture</td>
                    <td class='text-center'>" . number_format($this->insurance_cost, 2, ".", " ") . "</td>
                    <td class='text-center'>" . number_format($this->cost_one_day, 2, ".", " ") . "</td>
                    
                    <td>
                        <div class='row justify-content-center'>               
                            <form method='post' class='form-inline col-sm-12'>
                                <button type='submit' name='update' value='$this->id' class='btn btn-outline-primary col-sm-12' title='Редактировать страховую стоимость'>
                                <i class='bi bi-pencil-fill'></i>
                                </button>
                            </form>
                        </div>        
                    </td>                   

               </tr>";
    }
}