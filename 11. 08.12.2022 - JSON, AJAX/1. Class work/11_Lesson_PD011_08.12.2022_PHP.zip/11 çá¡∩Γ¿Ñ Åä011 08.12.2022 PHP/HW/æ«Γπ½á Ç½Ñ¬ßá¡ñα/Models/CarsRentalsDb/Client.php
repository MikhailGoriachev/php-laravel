<?php

class Client {
    private int $id;
    private string $surname;
    private string $name;
    private string $patronymic;
    private string $passport;

    public function toTableRow(): string
    {
        return "<tr>
                    <td class='text-center'>$this->id</td>
                    <td>$this->surname</td>
                    <td>$this->name</td>
                    <td>$this->patronymic</td>
                    <td>$this->passport</td>
               </tr>";
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }

    public function getSurname(): string
    {
        return $this->surname;
    }

    public function setSurname(string $surname): void
    {
        $this->surname = $surname;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function setName(string $name): void
    {
        $this->name = $name;
    }

    public function getPatronymic(): string
    {
        return $this->patronymic;
    }

    public function setPatronymic(string $patronymic): void
    {
        $this->patronymic = $patronymic;
    }

    public function getPassport(): string
    {
        return $this->passport;
    }

    public function setPassport(string $passport): void
    {
        $this->passport = $passport;
    }
}