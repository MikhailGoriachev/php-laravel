<?php

class CarWithMinInsuranceCost {
    private string $brand;
    private string $model;
    private float $minimal_insurance_cost;

    public function toTableRow(): string {
        return "<tr>
                    <td>$this->brand</td>
                    <td>$this->model</td>
                    <td class='text-center'>" . number_format($this->minimal_insurance_cost, 2, ".", " ") . "</td>
               </tr>";
    }

}