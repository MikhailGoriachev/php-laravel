<?php

class ClientByDate {
    private string $full_name_client;
    private string $passport;
    private string $date;


    public function toTableRow(): string{
        return "<tr>
                    <td>$this->full_name_client</td>
                    <td>$this->passport</td>
                    <td class='text-center'>$this->date_start</td>
               </tr>";
    }
}