<?php

class Rental
{
    private int $id_rental;
    private string $date_start;
    private string $full_name_client;
    private string $passport;
    private string $brand;
    private string $model;
    private string $plate;
    private int $year_manufacture;
    private float $insurance_cost;
    private float $cost_one_day;
    private int $duration;
    private float $price;

    public function toTableRow(): string
    {
        return "<tr>
                    <td class='text-center'>$this->id_rental</td>
                    <td>$this->date_start</td>
                    <td>$this->full_name_client</td>
                    <td>$this->passport</td>
                    <td>$this->brand</td>
                    <td>$this->model</td>
                    <td>$this->plate</td>
                    <td>$this->year_manufacture</td>
                    <td class='text-center'>" . number_format($this->insurance_cost, 2, ".", " ") . "</td>
                    <td class='text-center'>" . number_format($this->cost_one_day, 2, ".", " ") . "</td>
                    <td>$this->duration</td>
                    <td class='text-center'>" . number_format($this->price, 2, ".", " ") . "</td>
               </tr>";
    }
}
