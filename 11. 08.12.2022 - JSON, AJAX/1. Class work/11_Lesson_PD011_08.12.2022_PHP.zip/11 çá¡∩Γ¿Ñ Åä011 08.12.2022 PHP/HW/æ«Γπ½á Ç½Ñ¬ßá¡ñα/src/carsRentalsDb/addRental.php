<?php

function addRental(): void
{
    require_once '../config/carsRentalsConfig.php';

    $controller = new CarsRentalsDbController($dsn_config, $user_config, $password_config, $options_config);

    if (isset($_POST['client'])) {
        $controller->addRental((int)$_POST['client'], (int)$_POST['car'], $_POST['date'], (int)$_POST['duration']);
        echo "<h4 class='h4 text-center mt-5'>Прокат успешно добавлен</h4>";
    } else {

        ?>

        <h4 class="h4 text-center mt-5">Добавить прокат</h4>
        <form method='post' class='w-50 mt-5 mx-auto'>

            <div class='form-floating mb-2'>
                <select class='form-select' name='client' required>
                    <?php
                    $clients = $controller->getClients();

                    usort($clients, function ($c1, $c2) {
                        return strcmp($c1->getSurname(), $c2->getSurname());
                    });

                    foreach ($clients as $client)
                        echo "<option " .
                            "value=" . $client->getId() . ">" .
                            $client->getSurname() . " " .
                            mb_substr($client->getName(), 0, 1) . ". " .
                            mb_substr($client->getPatronymic(), 0, 1) . "." . "
                        </option>";

                    ?>
                </select>
                <label class="form-label">Клиент</label>
            </div>

            <div class='form-floating mb-2'>
                <select class='form-select' name='car' required>
                    <?php
                    $cars = $controller->getCarsWithColor();

                    usort($cars, function ($c1, $c2) {
                        return $c1->getBrand() <=> $c2->getBrand() ?:
                            $c1->getModel() <=> $c2->getModel() ?:
                                $c1->getColor() <=> $c2->getColor() ?:
                                    $c1->getCostOneDay() <=> $c2->getCostOneDay();
                    });

                    foreach ($cars as $car)
                        echo "<option " .
                            "value=" . $car->getId() . ">" .
                            $car->getBrand() . " " .
                            $car->getModel() . " (" .
                            $car->getColor() . ") (" .
                            number_format($car->getCostOneDay(), 2, ".", " ") . " руб/день)" .
                            "</option>";

                    ?>
                </select>
                <label class="form-label">Автомобиль</label>
            </div>

            <div class="form-floating mb-2 mx-auto">
                <input type="date"
                       name="date"
                       class="form-control"
                       placeholder="Дата" required/>
                <label class="form-label">Дата</label>
            </div>

            <div class="form-floating mb-2 mx-auto">
                <input type="number"
                       min="1"
                       name="duration"
                       class="form-control"
                       placeholder="Длительность проката" required/>
                <label class="form-label">Длительность проката</label>
            </div>

            <div class="row">
                <button type="submit"
                        class="btn btn-outline-success mx-auto col-sm-3 mt-5">
                    Добавить
                </button>
            </div>
        </form>

        <?php
    }
}