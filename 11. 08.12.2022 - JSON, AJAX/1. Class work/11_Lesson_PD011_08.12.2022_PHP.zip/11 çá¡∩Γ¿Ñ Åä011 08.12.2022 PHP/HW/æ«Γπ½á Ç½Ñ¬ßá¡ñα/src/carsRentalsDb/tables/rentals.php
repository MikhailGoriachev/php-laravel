<?php

function showRentalsTable(string $title = "Прокаты"):void {
    require_once '../config/carsRentalsConfig.php';

    $controller = new CarsRentalsDbController($dsn_config, $user_config, $password_config, $options_config);
    $rows = $controller->getRentals();
    if (sizeof($rows) > 0) {
        ?>
        <h4 class="h4 text-center mt-5"><?= $title ?></h4>

        <div class="row justify-content-end my-5">
            <form class="form-inline col-sm-3" method="post">
                <button type="submit" name="add" value="0" class="btn btn-success col-sm-12">Добавить прокат</button>
            </form>
        </div>

        <table class="table table-hover w-100 mx-auto mt-5">
            <thead>
            <tr class="text-center">
                <th>Id</th>
                <th>Начало проката</th>
                <th>Клиент</th>
                <th>Гос. номер</th>
                <th>Марка</th>
                <th>Модель</th>
                <th>Гос.номер</th>
                <th>Год выпуска</th>
                <th>Страх. стоимость</th>
                <th>Стоимость 1-го дня</th>
                <th>Длительность</th>
                <th>Стоимость</th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($rows as $row)
                echo $row->toTableRow();
            ?>
            </tbody>
        </table>
        <?php
    } else { ?>
        <h4 class="text-center mt-5 h4">Данные отсутствуют</h4>
        <?php
    }
}