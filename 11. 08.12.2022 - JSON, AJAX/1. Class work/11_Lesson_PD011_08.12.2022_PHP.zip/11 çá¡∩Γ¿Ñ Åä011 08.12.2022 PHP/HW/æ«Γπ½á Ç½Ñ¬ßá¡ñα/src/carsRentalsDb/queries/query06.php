<?php

function query06(): void
{
    require_once '../config/carsRentalsConfig.php';

    $controller = new CarsRentalsDbController($dsn_config, $user_config, $password_config, $options_config);

    $rows = $controller->getInsuranceFeeEachCar();

    if (sizeof($rows) > 0) {
        ?>
        <h4 class="h4 text-center mt-5">Страховой взнос для каждого автомобиля</h4>

        <table class="table table-hover w-75 mx-auto mt-5">
            <thead>
            <tr class="text-center">
                <th>Гос. номер</th>
                <th>Модель</th>
                <th>Год выпуска</th>
                <th>Страховая стоимость</th>
                <th>Страховой взнос</th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($rows as $row)
                echo $row->toTableRow();
            ?>
            </tbody>
        </table>
        <?php
    } else { ?>
        <h4 class="h4 text-center mt-5">Данные отсутствуют</h4>
        <?php
    }
}
