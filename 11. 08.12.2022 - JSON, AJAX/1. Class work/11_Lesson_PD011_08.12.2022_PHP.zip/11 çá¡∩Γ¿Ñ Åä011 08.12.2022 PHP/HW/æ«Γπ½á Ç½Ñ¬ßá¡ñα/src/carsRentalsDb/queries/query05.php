<?php

function query05(): void
{
    require_once '../config/carsRentalsConfig.php';

    do {
        $minCost = rand(20, 40) * 100000;
        $maxCost = rand(20, 40) * 100000;
    } while ($minCost >= $maxCost);

    $controller = new CarsRentalsDbController($dsn_config, $user_config, $password_config, $options_config);
    $rows = $controller->getCarsByInsuranceCostInRange($minCost, $maxCost);
    if (sizeof($rows) > 0) {
        ?>
        <h4 class="h4 text-center mt-5">Информация об автомобилях, страховая стоимость которых попадает в
            интервал от
            <b><?= $minCost ?></b> до <b><?= $maxCost ?></b></h4>

        <table class="table table-hover w-75 mx-auto mt-5">
            <thead>
            <tr class="text-center">
                <th>Марка</th>
                <th>Модель</th>
                <th>Гос. номер</th>
                <th>Год выпуска</th>
                <th>Страховая стоимость</th>
                <th>Стоимость одного дня</th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($rows as $row)
                echo $row->toTableRow();
            ?>
            </tbody>
        </table>
        <?php
    } else { ?>
        <h4 class="h4 text-center mt-5">Данные отсутствуют для интервала от
            <b><?= $minCost ?></b> до <b><?= $maxCost ?></b></h4>
        <?php
    }
}
