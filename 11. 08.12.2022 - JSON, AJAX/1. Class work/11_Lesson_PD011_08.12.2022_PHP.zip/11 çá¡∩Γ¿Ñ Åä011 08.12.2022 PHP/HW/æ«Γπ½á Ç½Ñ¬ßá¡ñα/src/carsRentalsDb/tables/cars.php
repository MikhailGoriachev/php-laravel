<?php

function showCarsTable():void {
    require_once '../config/carsRentalsConfig.php';

    $controller = new CarsRentalsDbController($dsn_config, $user_config, $password_config, $options_config);
    $rows = $controller->getCars();
    if (sizeof($rows) > 0) {
        ?>
        <h4 class="h4 text-center mt-5">Автомобили</h4>

        <table class="table table-hover w-75 mx-auto mt-5">
            <thead>
            <tr class="text-center">
                <th>Id</th>
                <th>Марка</th>
                <th>Модель</th>
                <th>Цвет</th>
                <th>Гос. номер</th>
                <th>Год выпуска</th>
                <th>Страховая стоимость</th>
                <th>Стоимость дня проката</th>
                <th>Управление</th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($rows as $row)
                echo $row->toTableRowWithId();
            ?>
            </tbody>
        </table>
        <?php
    } else { ?>
        <h4 class="text-center mt-5 h4">Данные отсутствуют</h4>
        <?php
    }
}