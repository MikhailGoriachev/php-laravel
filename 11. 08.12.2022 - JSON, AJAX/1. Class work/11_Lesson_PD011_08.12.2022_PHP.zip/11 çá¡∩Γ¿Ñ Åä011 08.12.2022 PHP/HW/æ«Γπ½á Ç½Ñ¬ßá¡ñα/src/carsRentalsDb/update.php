<?php

function update() {
    require_once '../config/carsRentalsConfig.php';

    $controller = new CarsRentalsDbController($dsn_config, $user_config, $password_config, $options_config);

    if (isset($_POST['cost'])) {
        $controller->updateCost((int)$_POST['id'], (float)$_POST['cost']);
        echo "<h4 class='h4 text-center mt-5'>Страховая стоимость успешно обновлена</h4>";
    } else {

        ?>

        <h4 class="h4 text-center mt-5">Изменить страховую стоимость</h4>
        <form method='post' class='w-50 mt-5 mx-auto'>

            <input type="hidden" name="id" value="<?= $_POST['update'] ?>">

            <div class="form-floating mb-2 mx-auto">
                <input type="number"
                       min="1"
                       name="cost"
                       class="form-control"
                       placeholder="Страховая стоимость" required/>
                <label class="form-label">Страховая стоимость</label>
            </div>

            <div class="row">
                <button type="submit"
                        class="btn btn-outline-success mx-auto col-sm-3 mt-5">
                    Изменить
                </button>
            </div>
        </form>

        <?php
    }
}