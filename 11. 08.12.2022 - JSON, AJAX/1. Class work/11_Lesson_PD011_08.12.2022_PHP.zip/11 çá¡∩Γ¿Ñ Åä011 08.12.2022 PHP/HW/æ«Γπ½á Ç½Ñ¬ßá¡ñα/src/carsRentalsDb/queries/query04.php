<?php

function query04(): void
{
    require_once '../config/carsRentalsConfig.php';

    $minDate = strtotime("2022-09-01");
    $maxDate = strtotime("2022-12-02");
    $date = date("Y-m-d",rand($minDate, $maxDate));


    $controller = new CarsRentalsDbController($dsn_config, $user_config, $password_config, $options_config);

    $rows = $controller->getClientsByDate($date);

    if (sizeof($rows) > 0) {
        ?>
        <h4 class="h4 text-center mt-5">Информация о клиентах бравших автомобиль
            <b><?= $date ?></b></h4>

        <table class="table table-hover w-75 mx-auto mt-5">
            <thead>
            <tr class="text-center">
                <th>Клиент</th>
                <th>Паспорт</th>
                <th>Дата проката</th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($rows as $row)
                echo $row->toTableRow();
            ?>
            </tbody>
        </table>
        <?php
    } else { ?>
        <h4 class="h4 text-center mt-5">Данные отсутствуют для даты
            <b><?= $date ?></b></h4>
        <?php
    }
}
