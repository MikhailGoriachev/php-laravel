<?php

function query01(): void {
    require_once '../config/carsRentalsConfig.php';

    $cost = rand(2,7) * 1000;

    $controller = new CarsRentalsDbController($dsn_config, $user_config, $password_config, $options_config);
    $rows = $controller->getCarsByCostOneDayLess($cost);
    if (sizeof($rows) > 0) {
        ?>
        <h4 class="h4 text-center mt-5">Информация об автомобилях, стоимость одного дня проката которых меньше
            <b><?= $cost ?></b></h4>

        <table class="table table-hover w-75 mx-auto mt-5">
            <thead>
            <tr class="text-center">
                <th>Марка</th>
                <th>Модель</th>
                <th>Гос. номер</th>
                <th>Год выпуска</th>
                <th>Страховая стоимость</th>
                <th>Стоимость одного дня</th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($rows as $row)
                echo $row->toTableRow();
            ?>
            </tbody>
        </table>
        <?php
    } else { ?>
        <h4 class="text-center mt-5 h4">Данные отсутствуют</h4>
        <?php
    }
}
