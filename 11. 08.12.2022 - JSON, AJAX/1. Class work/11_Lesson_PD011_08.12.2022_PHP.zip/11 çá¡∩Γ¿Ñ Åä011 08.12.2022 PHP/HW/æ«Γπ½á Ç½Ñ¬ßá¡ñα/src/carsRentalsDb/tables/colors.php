<?php

function showColorsTable():void {
    require_once '../config/carsRentalsConfig.php';

    $controller = new CarsRentalsDbController($dsn_config, $user_config, $password_config, $options_config);
    $rows = $controller->getColors();
    if (sizeof($rows) > 0) {
        ?>
        <h4 class="h4 text-center mt-5">Цвета</h4>

        <table class="table table-hover w-25 mx-auto mt-5">
            <thead>
            <tr class="text-center">
                <th>Id</th>
                <th>Название цвета</th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($rows as $row)
                echo $row->toTableRow();
            ?>
            </tbody>
        </table>
        <?php
    } else { ?>
        <h4 class="text-center mt-5 h4">Данные отсутствуют</h4>
        <?php
    }
}