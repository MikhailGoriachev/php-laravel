<?php

function query03(): void
{
    require_once '../config/carsRentalsConfig.php';

    $startNum = rand(0,2);

    $controller = new CarsRentalsDbController($dsn_config, $user_config, $password_config, $options_config);

    $rows = $controller->getClientsByStartNumPassport($startNum);

    if (sizeof($rows) > 0) {
        ?>
        <h4 class="h4 text-center mt-5">Информация о клиентах с паспортом начинающимся на
            <b><?= $startNum ?></b></h4>

        <table class="table table-hover w-75 mx-auto mt-5">
            <thead>
            <tr class="text-center">
                <th>Id</th>
                <th>Паспорт</th>
                <th>Клиент</th>
                <th>Дата начала</th>
                <th>Длительность</th>
                <th>Автомобиль</th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($rows as $row)
                echo $row->toTableRow();
            ?>
            </tbody>
        </table>
        <?php
    } else { ?>
        <h4 class="h4 text-center mt-5">Данные отсутствуют для стартовой цифры
            <b><?= $startNum ?></b></h4>
        <?php
    }
}
