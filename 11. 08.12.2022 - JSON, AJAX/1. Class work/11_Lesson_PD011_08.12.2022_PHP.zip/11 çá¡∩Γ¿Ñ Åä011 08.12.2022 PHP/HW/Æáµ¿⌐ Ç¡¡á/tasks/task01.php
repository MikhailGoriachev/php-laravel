<?php

// подключение конфигурационного файла
require_once 'db_config.php';

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,      // при ошибках выбрасывать исключение
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC  // запрос возвращает ассоциативный массив
];

// создание PDO объекта
$pdo = new PDO($dsn, $user, $password, $options);

// используем класс Car из пространства имен Models
spl_autoload_register();

// ------------------------------------------------------------------------
//
// Хранимая процедура 1
// Выбирает информацию об автомобилях, стоимость одного дня проката которых меньше заданной
// создать запрос и передать ему именованный параметр
$stmt = $pdo->prepare("call proc01(:price)");
$price = rand(2000,4000);
$stmt->bindParam(':price', $price, PDO::PARAM_INT);
$stmt->execute();

// показать результаты
$title = "<p class='fs-5 mt-5'>Информация об автомобилях, где стоимость одного дня проката меньше $price:</p>";
viewCars($title, $stmt,1);

// ------------------------------------------------------------------------
//
// Хранимая процедура 2
// Выбирает информацию об автомобилях, страховая стоимость которых находится в заданном диапазоне значений
// создать запрос и передать ему именованный параметр
$stmt = $pdo->prepare("call proc02(:lo,:hi)");
$lo = rand(200000,600000);
$hi = rand(700000,800000);
$stmt->bindParam(':lo', $lo, PDO::PARAM_INT);
$stmt->bindParam(':hi', $hi, PDO::PARAM_INT);
$stmt->execute();

// показать результаты
$title = "<p class='fs-5 mt-5'>Информация об автомобилях, страховая стоимость которых находится в диапазоне от $lo до $hi: </p>";
viewCars($title, $stmt,1);

// ------------------------------------------------------------------------
//
// Хранимая процедура 6
// Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса.
// создать запрос и передать ему именованный параметр
$stmt = $pdo->prepare("call proc06()");
$stmt->execute();

// показать результаты
$title = "<p class='fs-5 mt-5'>Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса: </p>";
viewCars($title, $stmt,2);

// ------------------------------------------------------------------------
//
// Хранимая процедура 7
// Для каждой модели вычисляет минимальную страховую стоимость автомобиля..
// создать запрос и передать ему именованный параметр
$stmt = $pdo->prepare("call proc07()");
$stmt->execute();

// показать результаты
$title = "<p class='fs-5 mt-5'>Для каждой модели вычисляет минимальную страховую стоимость автомобиля: </p>";
viewQuery07($title, $stmt);

// ------------------------------------------------------------------------
//
// Хранимая процедура 3
// Выбирает информацию о клиентах, серия-номер паспорта которых начинается с заданной параметром цифры.
// создать запрос и передать ему именованный параметр
$stmt = $pdo->prepare("call proc03(:n)");
$n = rand(0,9);
$stmt->bindParam(':n', $n, PDO::PARAM_STR);
$stmt->execute();

// показать результаты
$title = "<p class='fs-5 mt-5'>Выбирает информацию о клиентах, серия-номер паспорта которых начинается с цифры: $n</p>";
viewRent($title, $stmt,1);

// ------------------------------------------------------------------------
//
// Хранимая процедура 4
// Выбирает информацию о клиентах, бравших автомобиль напрокат в некоторый определенный день.
// создать запрос и передать ему именованный параметр
$stmt = $pdo->prepare("call proc04(:date)");
$date = '2022-12-5';
$stmt->bindParam(':date', $date, PDO::PARAM_STR);
$stmt->execute();

// показать результаты
$title = "<p class='fs-5 mt-5'>Выбирает информацию о клиентах, бравших автомобиль напрокат $date:</p>";
viewRent($title, $stmt,2);

// ------------------------------------------------------------------------
//
// Запрос с параметрами 8
// Добавить запись в таблицу ПРОКАТ.
// создать запрос и передать ему именованный параметр
$stmt = $pdo->prepare("INSERT INTO `rent_a_car_tatsiy_anna`.`rents`
(
`id_customer`,
`id_car`,
`date`,
`amount`)
VALUES (
:id_customer,
:id_car,
:date,
:amount);");

$id_customer = rand(1,10);
$id_car = rand(1,10);
$date = '2022-12-8';
$amount = rand(1,7);

$stmt->bindParam(':id_customer', $id_customer, PDO::PARAM_INT);
$stmt->bindParam(':id_car', $id_car, PDO::PARAM_INT);
$stmt->bindParam(':date', $date, PDO::PARAM_STR);
$stmt->bindParam(':amount', $amount, PDO::PARAM_INT);
$stmt->execute();

// показать результаты
$title = "<p class='fs-5 mt-5'>Добавлена запись в таблицу ПРОКАТ:</p>";
$result = $pdo->query("select 
	id,
	id_customer,
    id_car,
    `date`,
    amount 
from rents 
where id = (select 	max(id) from rents);");

viewRent($title, $result,3);

// ------------------------------------------------------------------------
//
// Запрос с параметрами 9
// Изменить страховую стоимость заданного параметром автомобиля
// создать запрос и передать ему именованный параметр
$stmt = $pdo->prepare(" UPDATE `rent_a_car_tatsiy_anna`.`cars`
set insurance_cost = :cost
WHERE id = :id ");

$id = rand(1,10);
$insurance_cost = rand(200000,800000);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->bindParam(':cost', $insurance_cost, PDO::PARAM_INT);
$stmt->execute();

// показать результаты
$title = "<p class='fs-5 mt-5'>Изменина страховая стоимость автомобиля с id = $id:</p>";
$stmt = $pdo->prepare("select id,
    id_model,
    id_color,
    `year`,
    state_number,
    cost_one_day,
    insurance_cost from cars where id = :id");
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();
viewCars($title, $stmt,3);

// ------------------------------------------------------------------------
//
// выводим cars (выборку запроса)
function viewCars($title, $stmt, $v): void {
    // настроить режим вывода результата
    $stmt->setFetchMode(PDO::FETCH_CLASS, 'Models\task01\Car');

    echo $title;

    switch ($v){

        case 1: echo "<table class='table table-bordered'><tr><th>Модель</th><th>Цвет</th><th>Год</th><th>Госномер</th><th>Стоимость одного дня</th><th>Страховая стоимость</th></tr>";
            break;

        case 2: echo "<table class='table table-bordered'><tr><th>Модель</th><th>Год</th><th>Госномер</th><th>Страховая стоимость</th><th>Страховой взнос</th></tr>";
            break;

        case 3: echo "<table class='table table-bordered'><tr><th>Id авто</th><th>Id модели</th><th>Id цвета</th><th>Год</th><th>Госномер</th><th>Стоимость одного дня</th><th>Страховая стоимость</th></tr>";
            break;

    }

    while ($row = $stmt->fetch()) {

        switch ($v){

            case 1: echo $row->toTableRow01();
                break;

            case 2: echo $row->toTableRow02();
                break;

            case 3: echo $row->toTableRow03();
                break;

        }
    }
    echo "</table>";

    // необходимо для повторного использования запроса
    $stmt->closeCursor();
} // view

// ------------------------------------------------------------------------
//
// выводим Query07 (выборку запроса)
function viewQuery07($title, $stmt): void {
    // настроить режим вывода результата
    $stmt->setFetchMode(PDO::FETCH_CLASS, 'Models\task01\Query07');

    echo $title;
    echo "<table class='table table-bordered'><tr><th>Id модели</th><th>Модель</th><th>Мин страховая стоимость</th></tr>";
    while ($row = $stmt->fetch()) {

        echo $row->toTableRow();
    }
    echo "</table>";

    // необходимо для повторного использования запроса
    $stmt->closeCursor();
} // view

// ------------------------------------------------------------------------
//
// выводим rent (выборку запроса)
function viewRent($title, $stmt, $v): void {
    // настроить режим вывода результата
    $stmt->setFetchMode(PDO::FETCH_CLASS, 'Models\task01\Rent');

    echo $title;
    switch ($v){
            case 1: echo "<table class='table table-bordered'><tr><th>Id клиента</th><th>Паспорт</th><th>Дата</th><th>Количество дней проката</th><th>Модель авто</th></tr>";
        break;
            case 2: echo "<table class='table table-bordered'><tr><th>Id клиента</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Паспорт</th><th>Дата</th></tr>";
        break;
        case 3: echo "<table class='table table-bordered'><tr><th>Id</th><th>Id клиента</th><th>Id авто</th><th>Дата</th><th>Количество дней проката</th></tr>";
        break;
    }

    while ($row = $stmt->fetch()) {

        switch ($v){
            case 1:  echo $row->toTableRow01();
                break;
            case 2:  echo $row->toTableRow02();
                break;
            case 3:  echo $row->toTableRow03();
                break;
        }
    }
    echo "</table>";

    // необходимо для повторного использования запроса
    $stmt->closeCursor();
} // view










