<?php

// вывод сообщения
function info($title, $text){
    echo "
    <div class='alert alert-success'>
        <strong>$title</strong><br>$text
    </div>";
} // alert