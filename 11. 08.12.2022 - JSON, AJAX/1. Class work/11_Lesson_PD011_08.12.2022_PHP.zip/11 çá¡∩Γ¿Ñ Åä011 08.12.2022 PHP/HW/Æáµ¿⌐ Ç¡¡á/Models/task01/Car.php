<?php

namespace Models\task01;
class Car{

    // класс для представления сущности БД - таблицы cars
    // сущность для cars - имя полей совпадают с именами столбцов

    private int $id = 0;
    private int $id_model = 0;
    private int $id_color = 0;
    private string $model_title = ""; //Модель автомобиля
    private string $color_title = ""; //Цвет автомобиля
    private int $year = 0; //Год выпуска автомобиля
    private string $state_number = ""; //Госномер автомобиля
    private int $cost_one_day = 0; //Стоимость одного дня проката
    private int $insurance_cost = 0; //Страховая стоимость автомобиля
    private float $insurance_premium = 0; //Страховая стоимость автомобиля

    function toTableRow01() :string {

        return "<tr>
            
            <td>$this->model_title</td>
            <td>$this->color_title</td>
            <td>$this->year</td>
            <td>$this->state_number</td>
            <td>$this->cost_one_day</td>
            <td>$this->insurance_cost</td>
</tr>";

    }

    function toTableRow02() :string {

        return "<tr>
            
            <td>$this->model_title</td>
            <td>$this->year</td>
            <td>$this->state_number</td>
            <td>$this->insurance_cost</td>
            <td>$this->insurance_premium</td>
</tr>";

    }

    function toTableRow03() :string {

        return "<tr>
            
            <td>$this->id</td>
            <td>$this->id_model</td>
            <td>$this->id_color</td>
            <td>$this->year</td>
            <td>$this->state_number</td>
            <td>$this->cost_one_day</td>
            <td>$this->insurance_cost</td>
</tr>";

    }


}

?>