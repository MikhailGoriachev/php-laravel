<?php

namespace Models\task01;

class Query07{

    private int $id_model;
    private string $model_title;
    private int $min_insurance_cost;

    function toTableRow() :string {
        return "<tr>
            
            <td>$this->id_model</td>
            <td>$this->model_title</td>
            <td>$this->min_insurance_cost</td>
</tr>";

    }
}