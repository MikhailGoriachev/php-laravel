<?php

namespace Models\task01;

class Rent{

    private int $id = 0;
    private int $id_customer;
    private int $id_car = 0;
    private string $surname = "";
    private string $name = "";
    private string $patronymic = "";
    private string $passport = "";
    private  $date;
    private int $amount = 0;
    private string $title = "";

    function toTableRow01() :string {

        return "<tr>
            <td>$this->id_customer</td>
            <td>$this->passport</td>
            <td>$this->date</td>
            <td>$this->amount</td>
            <td>$this->title</td>
</tr>";

    }

    function toTableRow02() :string {

        return "<tr>
            
            <td>$this->id_customer</td>
            <td>$this->surname</td>
            <td>$this->name</td>
            <td>$this->patronymic</td>
            <td>$this->passport</td>
            <td>$this->date</td>
</tr>";

    }

    function toTableRow03() :string {

        return "<tr>
            <td>$this->id</td>
            <td>$this->id_customer</td>
            <td>$this->id_car</td>
            <td>$this->date</td>
            <td>$this->amount</td>
    </tr>";

    }

}