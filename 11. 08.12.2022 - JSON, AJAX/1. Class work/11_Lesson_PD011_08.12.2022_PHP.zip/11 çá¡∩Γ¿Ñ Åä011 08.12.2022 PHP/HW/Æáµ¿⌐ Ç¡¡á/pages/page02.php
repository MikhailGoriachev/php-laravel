
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_28.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../lib/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<?php
// активность страниц
$activePage02 = "active";
$activeIndex = "";

// загрузка панели навигации
include_once "shared/_header.php";
?>

<main class="container-fluid">

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-4 bg-white m-3 border-warning-top border-warning-bottom">



        </div>

    </div>

</main>

<!-- загрузка подвала страницы -->
<?php include "shared/_footer.php" ?>

</body>
</html>
