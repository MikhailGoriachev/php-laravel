<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
            $this->call(ShoesSeeder::class);
        $this->command->info('Таблица с информацией о обуви успешно заполнена данными!');
    }
}
