<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CustomersController;
use App\Http\Controllers\CarsController;
use App\Http\Controllers\RentsController;

// путь к действию index контроллера home
Route::get('/', [ HomeController::class, 'index' ]);

Route::get('/customers', [CustomersController::class, 'index']);

Route::get('/cars', [CarsController::class, 'index']);

Route::get('/rents', [RentsController::class, 'index']);

