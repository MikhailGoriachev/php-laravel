<?php $__env->startSection('customers', 'active'); ?>
<?php $__env->startSection('title', 'Клиенты'); ?>

<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <p class="fs-5 ms-2 mt-5">Все записи:</p>

    <table class="table table-bordered ms-2">
        <thead>
        <tr>
            <th>ИД</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Паспорт</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($customer->id); ?></td>
                <td><?php echo e($customer->surname); ?></td>
                <td><?php echo e($customer->name); ?></td>
                <td><?php echo e($customer->patronymic); ?></td>
                <td><?php echo e($customer->passport); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php
        echo $s01;
        echo $s02;
    ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annat\source\repos\PHP\Step_24.12.22_PHP\resources\views/customers/index.blade.php ENDPATH**/ ?>