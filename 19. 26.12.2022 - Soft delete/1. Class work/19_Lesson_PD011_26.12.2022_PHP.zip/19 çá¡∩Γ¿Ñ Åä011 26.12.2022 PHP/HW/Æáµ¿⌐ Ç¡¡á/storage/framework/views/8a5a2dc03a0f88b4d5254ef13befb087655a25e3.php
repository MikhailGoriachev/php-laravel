<?php $__env->startSection('rents', 'active'); ?>
<?php $__env->startSection('title', 'Прокаты'); ?>

<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <?php
        echo $s01;
        echo $s03;
        echo $s02;
    ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annat\source\repos\PHP\Step_24.12.22_PHP\resources\views/rents/index.blade.php ENDPATH**/ ?>