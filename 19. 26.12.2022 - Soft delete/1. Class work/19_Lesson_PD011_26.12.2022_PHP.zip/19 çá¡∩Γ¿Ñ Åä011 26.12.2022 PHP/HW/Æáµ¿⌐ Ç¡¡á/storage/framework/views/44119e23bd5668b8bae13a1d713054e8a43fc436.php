<?php $__env->startSection('rents', 'active'); ?>
<?php $__env->startSection('title', 'Прокаты'); ?>

<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <?php
        echo $s01;
        echo $s03;
        echo $s02;
    ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\19 Занятие ПД011 26.12.2022 PHP\HW\Таций Анна\resources\views/rents/index.blade.php ENDPATH**/ ?>