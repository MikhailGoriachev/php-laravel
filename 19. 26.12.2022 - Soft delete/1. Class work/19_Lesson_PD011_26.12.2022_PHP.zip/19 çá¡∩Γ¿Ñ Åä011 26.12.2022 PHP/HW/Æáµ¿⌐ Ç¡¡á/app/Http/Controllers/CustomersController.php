<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Rent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class CustomersController extends Controller
{
    public function index(): View{

        // получить все записи (и все поля) из таблицы
        $customers =  Customer::all();


        //Выбирает информацию о клиентах, серия-номер паспорта которых начинается с заданной цифры.
        $customers01 = Rent::with(['car','customer'])
            ->where('passport', 'like', "0%")
            ->get();

        $s01 = $this->toTable($customers01,"Выбирает информацию о клиентах, серия-номер паспорта которых начинается с цифры 0:");

        //Выбирает из информацию о клиентах, бравших автомобиль напрокат в некоторый определенный день.
        $day = '2022-12-08';

        $customers02 = Rent::with(['car','customer'])
            ->where('date', '=', $day)
            ->get();

        $s02 = $this->toTable($customers02,"Выбирает из информацию о клиентах, бравших автомобиль напрокат $day:");


        $s01 = "";

        return view('customers.index', ['customers' => $customers, 's01' => $s01, 's02' => $s02]);

    }

    //Вывод запроса в табличном формате
    private function toTable($customers,$caption):string{

        $s =  "  <p class='fs-5 ms-2 mt-5'>$caption</p>

    <table class='table table-bordered ms-2'>
        <thead>
        <tr>
            <th>Код клиента</th>
            <th>Паспорт</th>
            <th>Дата начала проката</th>
            <th>Количество дней проката</th>
            <th>Модель автомобиля</th>
        </tr>
        </thead>
        <tbody>";

        foreach($customers as $customer) {
            $s = $s. "<tr>
                <td>".$customer->customer->surname." ".$customer->customer->name." ".$customer->customer->patronymic."</td>
                <td>".$customer->customer->passport."</td>
                <td>$customer->date</td>
                <td>$customer->amount</td>
                <td>".$customer->car->brand->title."</td>
              </tr>";
        }

        $s = $s. "
        </tbody>
    </table>

        ";

        return $s;
    }
}
