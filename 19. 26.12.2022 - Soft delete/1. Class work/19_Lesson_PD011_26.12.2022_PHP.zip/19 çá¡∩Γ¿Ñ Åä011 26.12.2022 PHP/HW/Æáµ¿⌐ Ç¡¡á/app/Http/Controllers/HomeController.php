<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\View\View;

class HomeController extends Controller
{
    // действие контроллера index
    public function index() {
        // обращение к странице отображения действия index в каталоге home
        return view('home/index');
    } // index
}
