<?php

namespace App\Http\Controllers;

use App\Models\Car;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class CarsController extends Controller
{
    public function index(): View
    {

        //Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса. Включает поля Госномер автомобиля,
        // Модель автомобиля, Год выпуска автомобиля, Страховая стоимость автомобиля, Страховой взнос. Сортировка по полю
        // Год выпуска автомобиля
      $cars01 = Car::with(['brand','color'])
          //  ->selectRaw('insurance_cost*0.1 as insurance_premium')
            ->orderBy('year')
            ->get();

        //Выбирает из таблицы информацию об автомобилях, страховая стоимость которых находится в заданном диапазоне
        $insurance_cost_lo = 480956;
        $insurance_cost_hi = 600000;

        $cars02 = Car::with(['brand','color'])
            ->whereBetween('insurance_cost', [$insurance_cost_lo, $insurance_cost_hi])
            ->get();

        //Запрос на выборку
        //Выбирает из информацию об автомобилях, стоимость одного дня проката которых меньше заданной
        $cost_one_day_min = 4000;

        $cars03 = Car::with(['brand','color'])
            ->where('cost_one_day', '<' , $cost_one_day_min)
            ->get();

        $s01 = $this->toTable($cars02,"Выбирает информацию обо всех автомобилях, для которых значение в поле
        Страховая стоимость автомобиля попадает в интервал [ $insurance_cost_lo , $insurance_cost_hi ]:",false);


        $s02 = $this->toTable($cars03,"Выбирает из информацию об автомобилях, стоимость одного дня проката которых меньше $cost_one_day_min:",false);

        $s03 = $this->toTable($cars01,"Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса:",true);

        return view('cars.index', [

            's01' => $s01,
            's02' => $s02,
            's03' => $s03
        ]);

    }

    //Вывод запроса в табличном формате
    private function toTable($cars,$caption,$flag):string{

        $s =  "  <p class='fs-5 ms-2 mt-5'>$caption</p>

    <table class='table table-bordered ms-2'>
        <thead>
        <tr>
            <th>ИД</th>
            <th>Цвет</th>
            <th>Модель</th>
            <th>Год выпуска</th>
            <th>Гос номер</th>
            <th>Стоимость одного дня</th>
            <th>Страховая стоимость</th>";

        $s = ($flag) ? $s. " <th>Страховая взнос</th>" : $s;

   $s = $s. " </tr>
        </thead>
        <tbody>";

        foreach($cars as $car) {
            $s = $s. "<tr>
                <td>$car->id</td>
                <td>".$car->color->title."</td>
                <td>".$car->brand->title."</td>
                <td>$car->year</td>
                <td>$car->state_number</td>
                <td>$car->cost_one_day</td>
                <td>$car->insurance_cost</td>";

            $s = ($flag) ? $s. "  <td>$car->insurance_premium</td>" : $s;

       $s = $s.   "  </tr>";
        }

        $s = $s. "
        </tbody>
    </table>

        ";

        return $s;
    }
}
