<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Car extends Model
{
    use HasFactory;

    // поля таблицы для отображения на свойства модели
    protected $fillable = [
        'brand_id',
        'color_id',
        'year',
        'state_number',
        'cost_one_day',
        'insurance_cost'
    ];

    // сторона "много" отношение "1:М", отношение "принадлежит"
    public function color() {
        return $this->belongsTo(Color::class);
    }

    public function brand() {
        return $this->belongsTo(Brand::class);
    }

}
