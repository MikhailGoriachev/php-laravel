<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;

    // поля таблицы для отображения на свойства модели
    protected $fillable = [
        'surname',
        'name',
        'patronymic',
        'passport'
    ];

    // сторона "один" отношения "1:М" - отношение "имеет"
    public function Rent(){
        return $this->hasMany(Rent::class);
    }
}
