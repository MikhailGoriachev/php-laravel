@extends('layouts.app')

@section('rents', 'active')
@section('title', 'Прокаты')

<!-- секция контент -->
@section('content')

    @php
        echo $s01;
        echo $s03;
        echo $s02;
    @endphp

@endsection
