@extends('layouts.app')

@section('cars', 'active')
@section('title', 'Авто')

<!-- секция контент -->
@section('content')

    @php
        echo $s01;
        echo $s02;
        echo $s03;
    @endphp

@endsection
