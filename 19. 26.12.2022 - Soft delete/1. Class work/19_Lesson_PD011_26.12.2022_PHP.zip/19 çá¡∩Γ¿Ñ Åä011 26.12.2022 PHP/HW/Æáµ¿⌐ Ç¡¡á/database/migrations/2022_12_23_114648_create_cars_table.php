<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{

    public function up()
    {
        Schema::create('cars', function (Blueprint $table) {
            $table->increments('id');  // первичный ключ, моджно явно указать имя

            $table->unsignedInteger('brand_id');
            $table->unsignedInteger('color_id');

            $table->foreign('brand_id')->references('id')->on('brands');
            $table->foreign('color_id')->references('id')->on('colors');

            //$table->foreignId('model_id')->constrained();
            //$table->foreignId('color_id')->constrained();

            $table->integer('year');
            $table->string('state_number',9);

            $table->integer('cost_one_day');
            $table->integer('insurance_cost');

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('cars');
    }
};
