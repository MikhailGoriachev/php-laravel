<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    public function run()
    {

        DB::table('colors')->insert([

            ['title'=>'белый'],
            ['title'=>'зелёный'],
            ['title'=>'синий'],
            ['title'=>'красный'],
            ['title'=>'бежевый'],
            ['title'=>'серый'],
            ['title'=>'чёрный'],
            ['title'=>'бирюзовый'],
            ['title'=>'фиолетовый'],
            ['title'=>'оранжевый']
        ]);

        DB::table('customers')->insert([

            ['surname'=>'Федоров', 'name'=>'Дмитрий', 'patronymic'=>'Александрович', 'passport'=>'4028491230'],
            ['surname'=>'Меркулова', 'name'=>'Виктория', 'patronymic'=>'Мироновна', 'passport'=>'8640324959'],
            ['surname'=>'Емельянов', 'name'=>'Максим', 'patronymic'=>'Романович', 'passport'=>'0583438562'],
            ['surname'=>'Климова', 'name'=>'Кира', 'patronymic'=>'Николаевна', 'passport'=>'5834092962'],
            ['surname'=>'Котова', 'name'=>'Вероника', 'patronymic'=>'Романовна', 'passport'=>'5940932056'],
            ['surname'=>'Крюков', 'name'=>'Лев', 'patronymic'=>'Леонович', 'passport'=>'8593205563'],
            ['surname'=>'Соколова', 'name'=>'Екатерина', 'patronymic'=>'Львовна', 'passport'=>'1275076352'],
            ['surname'=>'Орлов', 'name'=>'Алексей', 'patronymic'=>'Витальевич', 'passport'=>'0056422876'],
            ['surname'=>'Иванова', 'name'=>'Кристина', 'patronymic'=>'Алексеевна', 'passport'=>'0756745424'],
            ['surname'=>'Федорова', 'name'=>'София', 'patronymic'=>'Павловна', 'passport'=>'9458939235']
        ]);

        DB::table('brands')->insert([

            ['title'=>'Lada 2107'],
            ['title'=>'Lada 2106'],
            ['title'=>'Kia Rio'],
            ['title'=>'Lada 4×4 «Нива»'],
            ['title'=>'Hyundai Solaris'],
            ['title'=>'Lada 2110'],
            ['title'=>'Renault Logan'],
            ['title'=>'Lada 2114'],
            ['title'=>'Ford Focus'],
            ['title'=>'Lada 2109']
        ]);

        DB::table('cars')->insert([

            ['brand_id'=>1, 'color_id'=>1, 'year'=>2001, 'state_number'=>'А845КА349', 'cost_one_day'=>2000, 'insurance_cost'=>450895],
            ['brand_id'=>2, 'color_id'=>2, 'year'=>2005, 'state_number'=>'В958ЕУ943', 'cost_one_day'=>3000, 'insurance_cost'=>662022],
            ['brand_id'=>3, 'color_id'=>3, 'year'=>2010, 'state_number'=>'Р459НО403', 'cost_one_day'=>4000, 'insurance_cost'=>543565],
            ['brand_id'=>4, 'color_id'=>4, 'year'=>2012, 'state_number'=>'Н953ША49', 'cost_one_day'=>5000, 'insurance_cost'=>620784],
            ['brand_id'=>5, 'color_id'=>5, 'year'=>2015, 'state_number'=>'Г932ОТ32', 'cost_one_day'=>2000, 'insurance_cost'=>685077],
            ['brand_id'=>6, 'color_id'=>6, 'year'=>2018, 'state_number'=>'Н934ВТ83', 'cost_one_day'=>3500, 'insurance_cost'=>480956],
            ['brand_id'=>7, 'color_id'=>7, 'year'=>2020, 'state_number'=>'П943ВЛ39', 'cost_one_day'=>4000, 'insurance_cost'=>601516],
            ['brand_id'=>8, 'color_id'=>8, 'year'=>2020, 'state_number'=>'Н472КУ39', 'cost_one_day'=>3500, 'insurance_cost'=>729928],
            ['brand_id'=>9, 'color_id'=>9, 'year'=>2017, 'state_number'=>'Г564АЛ42', 'cost_one_day'=>4000, 'insurance_cost'=>307839],
            ['brand_id'=>9, 'color_id'=>9, 'year'=>2020, 'state_number'=>'В843СМ84', 'cost_one_day'=>4000, 'insurance_cost'=>600000]

        ]);

        DB::table('rents')->insert([

            ['customer_id'=>1, 'car_id'=>1, 'date'=>'2022-12-04', 'amount'=>3],
            ['customer_id'=>2, 'car_id'=>2, 'date'=>'2022-12-04', 'amount'=>4],
            ['customer_id'=>3, 'car_id'=>3, 'date'=>'2022-12-04', 'amount'=>5],
            ['customer_id'=>4, 'car_id'=>4, 'date'=>'2022-12-05', 'amount'=>6],
            ['customer_id'=>5, 'car_id'=>5, 'date'=>'2022-12-06', 'amount'=>7],
            ['customer_id'=>6, 'car_id'=>6, 'date'=>'2022-12-06', 'amount'=>3],
            ['customer_id'=>7, 'car_id'=>7, 'date'=>'2022-12-06', 'amount'=>4],
            ['customer_id'=>8, 'car_id'=>8, 'date'=>'2022-12-06', 'amount'=>6],
            ['customer_id'=>9, 'car_id'=>9, 'date'=>'2022-12-08', 'amount'=>7],
            ['customer_id'=>9, 'car_id'=>9, 'date'=>'2022-12-08', 'amount'=>8]

        ]);
    }
}
