﻿

<?php $__env->startSection('title', 'Запрос 3'); ?>

<?php $__env->startSection('queriesActive', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">

        <h4 class="text-center">Запрос 3</h4>

        <form method="post" action="/queries/query03">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-auto">
                    <div class="form-floating">
                        <input type="text" class="form-control <?php $__errorArgs = ['passport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="passport" placeholder=" "
                               value="<?php echo e($passport ?? old('passport')); ?>">
                        <label class="form-label">Паспорт</label>
                    </div>

                    <?php $__errorArgs = ['passport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col my-auto">
                    <button class="btn btn-success my-auto" type="submit">Выбрать</button>
                    <a class="btn btn-warning my-auto"
                       href="queries/query03">Сброс</a>
                </div>
            </div>
        </form>

        <div class="row">
            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Клиент</th>
                    <th>Паспорт</th>
                    <th>Модель</th>
                    <th>Цвет</th>
                    <th>Номер</th>
                    <th>Страх. стоимость</th>
                    <th>Аренда</th>
                    <th>Дата</th>
                    <th>Длительность</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $data->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="align-middle">
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->client->last_name . ' ' . mb_substr($item->client->first_name, 0, 1) . '.' .
                            mb_substr($item->client->patronymic, 0, 1) . '.'); ?>

                        </td>
                        <td><?php echo e($item->client->passport); ?></td>
                        <td><?php echo e($item->car->brand->name); ?></td>
                        <td><?php echo e($item->car->color->name); ?></td>
                        <td><?php echo e($item->car->plate); ?></td>
                        <td><?php echo e($item->car->inshurance_pay); ?></td>
                        <td><?php echo e($item->car->rental); ?></td>
                        <td><?php echo e($item->date_start); ?></td>
                        <td><?php echo e($item->duration); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\18. 25.12.2022 -\2. Home work\home-work\resources\views/carRentals/queries/query03.blade.php ENDPATH**/ ?>