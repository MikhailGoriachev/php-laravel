﻿

<?php $__env->startSection('title', $title ?? 'Ошибка'); ?>

<?php $__env->startSection($activeTab ?? '', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">
        <div class="row">
            <div class="m-3 alert alert-danger col-auto" role="alert">
                <?php echo e($message); ?>. <b><a href="/">Перейти на главную</a></b>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\13. 12.12.2022 -\2. Home work\home-work\resources\views/shared/error.blade.php ENDPATH**/ ?>