﻿

<?php $__env->startSection('title', 'Запрос 1'); ?>

<?php $__env->startSection('queriesActive', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">

        <h4 class="text-center">Запрос 1</h4>

        <form method="post" action="/queries/query01">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-auto">
                    <div class="form-floating">
                        <input type="number" class="form-control <?php $__errorArgs = ['min_rental'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="min_rental" placeholder=" " value="<?php echo e($min_rental ?? old('min_rental')); ?>">
                        <label class="form-label">Мин. стоимость проката</label>
                    </div>

                    <?php $__errorArgs = ['min_rental'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert alert-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="col my-auto">
                    <button class="btn btn-success my-auto" type="submit">Выбрать</button>
                    <a class="btn btn-warning my-auto"
                       href="queries/query01">Сброс</a>
                </div>
            </div>
        </form>

        <div class="row">
            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Модель</th>
                    <th>Цвет</th>
                    <th>Госномер</th>
                    <th>Год выпуска</th>
                    <th>Страховая плата</th>
                    <th>Цена проката (сутки)</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $data->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="align-middle">
                        <th><?php echo e($item->id); ?></th>
                        <td><?php echo e($item->brand->name); ?></td>
                        <td><?php echo e($item->color->name); ?></td>
                        <td><?php echo e($item->plate); ?></td>
                        <td><?php echo e($item->year_manufacture); ?></td>
                        <td><?php echo e($item->inshurance_pay); ?></td>
                        <td><?php echo e($item->rental); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\19 Занятие ПД011 26.12.2022 PHP\HW\Горячев Михаил\resources\views/carRentals/queries/query01.blade.php ENDPATH**/ ?>