@extends('layouts.layout')

<!-- секция контент -->
@section('main_part')
    <h4 class="text-center my-5">Страница home/index</h4>

@endsection
