<!-- секция контент -->
<?php $__env->startSection('main_part'); ?>
    <h4 class="text-center my-5">Страница home/index</h4>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\19 Занятие ПД011 26.12.2022 PHP\CW\app-shoes\resources\views/home/index.blade.php ENDPATH**/ ?>