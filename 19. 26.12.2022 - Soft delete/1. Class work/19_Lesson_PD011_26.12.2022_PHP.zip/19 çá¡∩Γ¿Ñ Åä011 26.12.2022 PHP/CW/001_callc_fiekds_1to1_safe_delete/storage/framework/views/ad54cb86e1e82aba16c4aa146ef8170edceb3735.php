<?php $__env->startSection('active_read', 'active'); ?>

<!-- секция контент -->
<?php $__env->startSection('main_part'); ?>
    <h4 class="text-center my-5">Страница categories/view-all</h4>

    <div class="row">
        <div class="col-4">
            <h4 class="text-center">Категории товаров</h4>
            <table class="table table-bordered w-100 my-3">
                <thead>
                <tr>
                    <th>ИД</th>
                    <th>Категория</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->category); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="col-4 mx-3">
            <h4 class="text-center">Выборка из категории товаров</h4>
            <table class="table table-bordered my-3">
                <thead>
                <tr>
                    <th>ИД</th>
                    <th>Категория</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->category); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="col-4 mx-3">
            <h4 class="text-center">Выборка первой записи из категории товаров</h4>
            <table class="table table-bordered my-5">
                <thead>
                <tr>
                    <th>ИД</th>
                    <th>Категория</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?php echo e($categories2->id); ?></td>
                    <td><?php echo e($categories2->category); ?></td>
                </tr>
                </tbody>
            </table>
        </div>

        <div class="col-4">
            <h4 class="text-center">Выборка записи по id категории товаров</h4>
            <table class="table table-bordered my-5">
                <thead>
                <tr>
                    <th>ИД</th>
                    <th>Категория</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?php echo e($categories3->id); ?></td>
                    <td><?php echo e($categories3->category); ?></td>
                </tr>
                </tbody>
            </table>
        </div>

        <div class="col-4 mx-3">
            <h4 class="text-center">Выборка группы записей по id из категории товаров</h4>
            <table class="table table-bordered my-5">
                <thead>
                <tr>
                    <th>ИД</th>
                    <th>Категория</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->category); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\18 Занятие ПД011 25.12.2022 PHP\CW\db-eloquent-intro\resources\views/categories/view-all.blade.php ENDPATH**/ ?>