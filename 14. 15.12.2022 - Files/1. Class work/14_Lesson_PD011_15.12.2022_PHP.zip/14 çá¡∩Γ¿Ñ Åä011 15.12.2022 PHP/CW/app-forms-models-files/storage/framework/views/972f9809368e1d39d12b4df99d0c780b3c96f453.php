<?php $__env->startSection('active_write', 'active'); ?>

<!-- секция контента -->
<?php $__env->startSection('main_part'); ?>
    <h3>Демонстрация <u>записи</u> в файл</h3>
    <p>Файл записан, в нем должно быть число <b><?php echo e($n); ?></b></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\14 Занятие ПД011 15.12.2022 PHP\CW\app-forms-models-files\resources\views/file-operation/write.blade.php ENDPATH**/ ?>