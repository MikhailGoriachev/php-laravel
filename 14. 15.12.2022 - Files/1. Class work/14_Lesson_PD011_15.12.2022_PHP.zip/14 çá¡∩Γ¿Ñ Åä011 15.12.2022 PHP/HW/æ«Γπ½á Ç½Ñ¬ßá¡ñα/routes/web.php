<?php

// подключение собственных контроллеров
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CalculateController;

use Illuminate\Support\Facades\Route;

// путь к действию index в контроллере HomeController
Route::get('/', [HomeController::class, 'index']);
Route::get('/index', [HomeController::class, 'index']);

// путь к действию about в контроллере HomeController
Route::get('/about', [HomeController::class, 'about']);

// выражение
Route::get('/evaluate', [CalculateController::class, 'getEvaluateForm']);
Route::post('/processEvaluate', [CalculateController::class, 'processEvaluate']);

// массив
Route::get('/array/{n?}', [CalculateController::class, 'getArrayForm']);
Route::post('/resultArray', [CalculateController::class, 'processArray']);

// текст
Route::get('/text', [CalculateController::class, 'getTextForm']);
Route::post('/resultText', [CalculateController::class, 'processText']);
