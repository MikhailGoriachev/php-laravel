<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;

class CalculateController extends Controller
{

    // GET
    // форма ввода данных
    public function getEvaluateForm() {
       return view('calculate/evaluate');
    }

    // POST
    // расчет выраженений
    public function processEvaluate(Request $request) {
        // параметры из формы
        // храним в отдельных переменных только для упрощения чтения кода
        $a = $request->input('a');
        $b = $request->input('b');
        $m = $request->input('m');
        $n = $request->input('n');

        // массив для хранения данных
        $result = [];

        // сохраняем исходные данные
        $result['a'] = $a;
        $result['b'] = $b;
        $result['m'] = $m;
        $result['n'] = $n;

        // результаты вычислений выражений
        $z1FirstEvaluate = $this->calcZ1FirstEvaluate($a, $b);
        $z2FirstEvaluate = $this->calcZ2FirstEvaluate($b);

        // сохранить вычисления первого выражения
        $result['z1FirstEvaluate'] = $z1FirstEvaluate;
        $result['z2FirstEvaluate'] = $z2FirstEvaluate;
        // признак совпадения значений
        $result['flagFirstEvaluate'] = abs($z2FirstEvaluate - $z1FirstEvaluate) < 1e-6;

        // результаты вычислений выражений
        $z1SecondEvaluate = $this->calcZ1SecondEvaluate($m, $n);
        $z2SecondEvaluate = $this->calcZ2SecondEvaluate($m, $n);

        // признак совпадения значений
        $result['z1SecondEvaluate'] = $z1SecondEvaluate;
        $result['z2SecondEvaluate'] = $z2SecondEvaluate;
        $result['flagSecondEvaluate'] = abs($z2SecondEvaluate - $z1SecondEvaluate) < 1e-6;

        // возврат представление и передача в него данных
        return view('calculate/evaluateSolution', ['result' => $result]);
    }

    // GET
    // форма ввода данных
    public function getArrayForm($n = null) {
        try {
            $min = 12;
            $max = 25;

            if(is_null($n))
                $n = rand($min, $max);

            if($n < $min || $n > $max)
                throw new Exception("Недопустимое значение параметра маршрута");

            return view('calculate/array', ['size' => $n]);
        } catch (Exception $ex) {
            return view('calculate/exception', ['errorMessage' => $ex->getMessage()]);
        }
    }

    // POST
    // обработка массива
    public function processArray(Request $request) {
        $size = $request->input('size');
        $min = $request->input('min');
        $max = $request->input('max');

        $result = [];

        $array = array_map(fn() => rand($min, $max), array_pad([], $size, 0));
        $result['main'] = $array;

        // количество положительных элементов массива
        $countPositive = count(array_filter($array, fn($value) => $value >= 0));
        $result['count'] = $countPositive;

        // сумма элементов массива, расположенных после последнего элемента, равного нулю
        $pos = array_search(0, $array);
        $sum = $pos ? array_sum(array_slice($array, $pos + 1)) : "Нет нулевых элементов";
        $result['sum'] = $sum;

        // сначала все элементы, равные нулю, а потом — все остальные
        usort($array, fn($x, $y) => $x !== 0 && $y === 0);
        $result['sorted'] = $array;

        return view('calculate/arraySolution', ['result' => $result]);
    } // processArray

    // GET
    // вывод формы ввода
    public function getTextForm() {
        return view('calculate/text');
    }

    // POST
    // обработка строки
    public function processText(Request $request) {

        /* TODO: - переделать на регулярные выражения
                 - вынести обработки в приватные методы */

        $str = $request->input('text');
        $countLetters = (int)$request->input('countLetters');

        $strArr = explode(' ' , $str);

        // Количество слов начинающихся и заканчивающихся на одну и ту же букву без учета регистра
        $countByEqualUnRegister = 0;
        foreach ($strArr as $s) {
            $word = mb_strtolower($s);
            if (mb_substr($word, 0, 1) === mb_substr($word, mb_strlen($word) - 1, 1))
                $countByEqualUnRegister++;
        }

        $arrayUnRegister = [];
        foreach ($strArr as $s) {
            $word = mb_strtolower($s);
            if (mb_substr($word, 0, 1) === mb_substr($word, mb_strlen($word) - 1, 1))
                $arrayUnRegister[$s] = mb_substr_count($str, $s);
        }

        // Количество слов начинающихся и заканчивающихся на одну и ту же букву с учетом регистра
        $countByEqualRegister = 0;
        foreach ($strArr as $s) {
            if (mb_substr($s, 0, 1) === mb_substr($s, mb_strlen($s) - 1, 1))
                $countByEqualRegister++;
        }

        $arrayRegister = [];
        foreach ($strArr as $s) {
            if (mb_substr($s, 0, 1) === mb_substr($s, mb_strlen($s) - 1, 1))
                $arrayRegister[$s] = mb_substr_count($str, $s);
        }

        // подсчет количества слов, длина которых $countLetters символов
        $countByLength = preg_match_all('/\b[a-zA-Z|\x{0400}-\x{04FF}]{'. $countLetters .'}\b/ui', $str);

        $arrayCount = [];
        foreach ($strArr as $s) {
            if (mb_strlen($s) === $countLetters)
                $arrayCount[$s] = mb_substr_count($str, $s);
        }

        return view('calculate/textSolution', [
            'str' => $str,
            'countLetters' => $countLetters,

            'countByEqualRegister' => $countByEqualRegister,
            'arrayRegister' => $arrayRegister,

            'countByEqualUnRegister' => $countByEqualUnRegister,
            'arrayUnRegister' => $arrayUnRegister,

            'countByLength' => $countByLength,
            'arrayCount' => $arrayCount
        ]);
    } // processText

    // вычислить z1 для первого выражения
    private function calcZ1FirstEvaluate($a, $b)
    {
        return (sin($a) + cos(2 * $b - $a)) / (cos($a) - sin(2 * $b - $a));
    }

    // вычислить z2 для первого выражения
    private function calcZ2FirstEvaluate($b)
    {
        return (1 + sin(2 * $b)) / cos(2 * $b);
    }

    // вычислить z1 для второго выражения
    private function calcZ1SecondEvaluate($m, $n) {
        return
            (($m - 1) * sqrt($m) - ($n - 1) * sqrt($n))
            /
            (sqrt(pow($m, 3) * $n) + $n * $m + $m * $m - $m);
    }

    // вычислить z1 для второго выражения
    private function calcZ2SecondEvaluate($m, $n) {
        return (sqrt($m) - sqrt($n)) / $m;
    }
}
