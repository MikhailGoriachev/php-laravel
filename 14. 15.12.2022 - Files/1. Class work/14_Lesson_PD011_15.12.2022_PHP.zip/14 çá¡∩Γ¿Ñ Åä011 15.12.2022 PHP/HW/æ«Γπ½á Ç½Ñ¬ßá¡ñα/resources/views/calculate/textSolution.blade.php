@extends('layouts.app')

@section('text', 'active')
@section('title', 'Результат обработки текста')

@section('content')

    <p class="mt-5">Строка для обработки: {{$str}}</p>

    <p class="mt-5">Количество слов начинающихся и заканчивающихся на одну и ту же букву без учета
        регистра: {{$countByEqualUnRegister}}</p>

    <p class="mt-5">Уникальные найденные слова с количеством их вхождений</p>
    <table class="table w-25">
        <thead>
        <th>Слово</th>
        <th>Количество</th>
        </thead>
        @foreach($arrayUnRegister as $key => $value)
            <tr>
                <td>{{ $key }}</td>
                <td>{{ $value }}</td>
            </tr>
        @endforeach
    </table>

    <p class="mt-5">Количество слов начинающихся и заканчивающихся на одну и ту же букву с учетом
        регистра: {{$countByEqualRegister}}</p>

    <p class="mt-5">Уникальные найденные слова с количеством их вхождений</p>
    <table class="table w-25">
        <thead>
        <th>Слово</th>
        <th>Количество</th>
        </thead>
        @foreach($arrayRegister as $key => $value)
            <tr>
                <td>{{ $key }}</td>
                <td>{{ $value }}</td>
            </tr>
        @endforeach
    </table>

    <p class="mt-5">Количество слов состоящих из <b>{{$countLetters}}</b> букв: {{$countByLength}}</p>
    <p class="mt-5">Уникальные найденные слова с количеством их вхождений</p>
    <table class="table w-25">
        <thead>
        <th>Слово</th>
        <th>Количество</th>
        </thead>
        @foreach($arrayCount as $key => $value)
            <tr>
                <td>{{ $key }}</td>
                <td>{{ $value }}</td>
            </tr>
        @endforeach
    </table>

@endsection
