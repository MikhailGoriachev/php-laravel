<!DOCTYPE html>

<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>@yield('title')</title>

    <link rel="icon" href="{{ asset("img/laravel_logo.png")}}" type="image/x-icon">

    <link rel="stylesheet" href="{{ asset("bootstrap/css/bootstrap.min.css")}}"/>
    <script src="{{ asset("bootstrap/js/bootstrap.bundle.min.js")}}"></script>

</head>

<body class="d-flex flex-column h-100">

@section('header')
<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">@yield('title')</h1>
</header>


<!--панель навигации-->
<nav class="navbar navbar-expand-sm bg-black navbar-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img height="48" width="48" src="{{ asset("/img/laravel_logo.png")}}" alt="logo">
        </a>
        <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbar-hide">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar-hide">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link @yield('index')" href="/">Главная страница</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link @yield('equation')" href="/evaluate">Уравнение</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link @yield('array')" href="/array">Массив</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link @yield('text')" href="/text">Текст</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link @yield('about')" href="/about">О приложении</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
@show

<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1">

    </div>

    <!--    основной блок контента-->
    <div class="col-sm-10">
        @yield('content')
    </div>


    <!--    правый сайд бар-->
    <div class="col-sm-1"></div>

</div>

@section('footer')
<!--футер-->
<footer class="container-fluid text-center text-white bg-black p-3 mt-auto">
    <p class="m-0">Сотула Александр. ПД011. Донецк-2022.</p>
    <a href="mailto:alexander.sotula@gmail.com">Эл. почта для связи</a>
</footer>
@show

</body>
</html>
