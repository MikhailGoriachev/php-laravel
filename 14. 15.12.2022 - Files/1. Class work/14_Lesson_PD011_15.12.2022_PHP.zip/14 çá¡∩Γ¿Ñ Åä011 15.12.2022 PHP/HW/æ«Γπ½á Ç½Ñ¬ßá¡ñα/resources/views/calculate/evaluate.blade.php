@extends('layouts.app')

@section('equation', 'active')
@section('title', 'Введите исходные данные')

@section('content')

    <div class="w-100 mt-4">
        <a href="#task" class="btn btn-outline-dark w-100 mb-4" data-bs-toggle="collapse">
            <strong>Задание</strong>
        </a>
        <div id="task" class="collapse">
            Выполните ввод исходных данных в форму, вычисления и вывод результатов для заданных выражений, не
            используйте модель. Вывод исходных данных и результатов – на отдельную страницу.

            <img class="rounded mx-auto d-block mt-5" src="{{asset('/img/task1.jpg')}}" alt="task1">
            <img class="rounded mx-auto d-block mt-5" src="{{asset('/img/task2.jpg')}}" alt="task2">
        </div>
    </div>



    <form action="/processEvaluate" method="post" class="mt-5">
        @csrf
        <div class="form-floating mb-3 col-sm-4 mx-auto">
            <input type="number" class="form-control" name="a" id="a" placeholder="&alpha;">
            <label for="a">&alpha;</label>
        </div>

        <div class="form-floating mb-3 col-sm-4 mx-auto">
            <input type="number" class="form-control" name="b" id="b" placeholder="&beta;">
            <label for="b">&beta;</label>
        </div>

        <div class="form-floating mb-3 col-sm-4 mx-auto">
            <input type="number" class="form-control" name="m" id="m" placeholder="<i>m</i>">
            <label for="m"><i>m</i></label>
        </div>

        <div class="form-floating mb-3 col-sm-4 mx-auto">
            <input type="number" class="form-control" name="n" id="n" placeholder="<i>n</i>">
            <label for="n"><i>n</i></label>
        </div>

        <div class="row">
            <button class="col-sm-3 btn btn-outline-success mx-auto" type="submit">Вычислить</button>
        </div>
    </form>

@endsection
