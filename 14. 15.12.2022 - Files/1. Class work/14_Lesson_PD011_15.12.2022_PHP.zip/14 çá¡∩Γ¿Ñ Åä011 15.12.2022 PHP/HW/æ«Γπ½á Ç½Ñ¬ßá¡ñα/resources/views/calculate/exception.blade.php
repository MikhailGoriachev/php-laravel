@extends('layouts.app')

@section('array', 'active')
@section('title', 'Ошибка')

@section('content')
    <h5 class="h5 text-center text-danger mt-5">{{ $errorMessage }}</h5>
@endsection
