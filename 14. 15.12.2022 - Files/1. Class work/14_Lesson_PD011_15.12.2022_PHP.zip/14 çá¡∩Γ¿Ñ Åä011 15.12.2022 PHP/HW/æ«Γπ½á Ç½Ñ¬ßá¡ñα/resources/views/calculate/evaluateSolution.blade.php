@extends('layouts.app')

@section('equation', 'active')
@section('title', 'Решенные выражения')

@section('content')

    <h5 class="h5 text-center mt-5">Первое выражение</h5>

    <table class="table table-hover w-50 mx-auto mt-5">
        <thead class="text-center">
            <th>&alpha;</th>
            <th>&beta;</th>
            <th>z<sub>1</sub></th>
            <th>z<sub>2</sub></th>
            <th>Результат</th>
        </thead>
        <tbody>
            <td>{{ sprintf("%.5f", $result['a']) }}</td>
            <td>{{ sprintf("%.5f", $result['b']) }}</td>
            <td>{{ sprintf("%.5f", $result['z1FirstEvaluate']) }}</td>
            <td>{{ sprintf("%.5f", $result['z2FirstEvaluate']) }}</td>
            <td class="text-white text-center {{ $result['flagFirstEvaluate'] ? "bg-success" : "bg-danger" }}">{{ !$result['flagFirstEvaluate'] ? "не" : ""}}совпадает</td>
        </tbody>
    </table>

    <h5 class="h5 text-center mt-5">Второе выражение</h5>

    <table class="table table-hover w-50 mx-auto mt-5">
        <thead class="text-center">
        <th><i>m</i></th>
        <th><i>n</i></th>
        <th>z<sub>1</sub></th>
        <th>z<sub>2</sub></th>
        </thead>
        <tbody>
        <td>{{ sprintf("%.5f", $result['m']) }}</td>
        <td>{{ sprintf("%.5f",$result['n']) }}</td>
        <td>{{ sprintf("%.5f",$result['z1SecondEvaluate']) }}</td>
        <td>{{ sprintf("%.5f",$result['z2SecondEvaluate']) }}</td>
        <td class="text-white text-center {{ $result['flagSecondEvaluate'] ? "bg-success" : "bg-danger" }}">{{ !$result['flagSecondEvaluate'] ? "не" : ""}}совпадает</td>
        </tbody>
    </table>

@endsection
