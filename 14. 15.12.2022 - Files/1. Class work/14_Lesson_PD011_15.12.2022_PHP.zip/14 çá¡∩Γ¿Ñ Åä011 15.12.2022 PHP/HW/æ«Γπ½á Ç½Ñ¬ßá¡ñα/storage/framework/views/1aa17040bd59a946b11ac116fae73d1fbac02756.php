<?php $__env->startSection('text', 'active'); ?>
<?php $__env->startSection('title', 'Обработка текста'); ?>

<?php $__env->startSection('content'); ?>

    <div class="w-100 mt-4">
        <a href="#task" class="btn btn-outline-dark w-100 mb-4" data-bs-toggle="collapse">
            <strong>Задание</strong>
        </a>
        <div id="task" class="collapse">
            Для строки, вводимой в форме определить (все обработки – по кнопке <b>submit</b> единственной формы на странице,
            вывод – на отдельную страницу результатов):

            <ul>
                <li>Количество слов, начинающихся и заканчивающихся на одну и ту же букву с учетом и без учета регистра
                    букв, выводить строку и уникальные найденные слова с количеством их вхождений
                </li>
                <li>Количество слов, состоящих ровно из <i><b>k</b></i> букв, количество букв вводить в поле ввода формы, выводить
                    строку и уникальные найденные слова с количеством их вхождений
                </li>
            </ul>

        </div>
    </div>

    <form action="/resultText" method="post" class="mt-5">
        <?php echo csrf_field(); ?>
        <div class="form-floating mb-3 col-sm-4 mx-auto">
            <input type="text" class="form-control" name="text" id="text" placeholder="Текст для обработки">
            <label for="text">Текст для обработки</label>
        </div>

        <div class="form-floating mb-3 col-sm-4 mx-auto">
            <input type="number" class="form-control" name="countLetters" id="countLetters"
                   placeholder="Количество букв">
            <label for="countLetters">Количество букв</label>
        </div>

        <div class="row">
            <button class="col-sm-3 btn btn-outline-success mx-auto" type="submit">Обработать</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Академия Шаг\ПД011\15 PHP\13 Занятие ПД011 12.12.2022 PHP\Сотула Александр\resources\views/calculate/text.blade.php ENDPATH**/ ?>