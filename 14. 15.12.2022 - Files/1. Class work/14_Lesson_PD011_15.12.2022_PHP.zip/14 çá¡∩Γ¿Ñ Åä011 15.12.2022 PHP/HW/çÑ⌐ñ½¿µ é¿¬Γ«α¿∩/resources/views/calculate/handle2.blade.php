@extends('layouts.layout')

@section('main_content')

    <h4>Размер массива: {{ $n }} элементов</h4>

    <p class="mt-5"><b>Исходный массив</b></p>
    <table class='w-50 table table-bordered mt-1'>
        <tr>
            @foreach($result['arr'] as $item)
                <td>{{$item}}</td>
            @endforeach
        </tr>
    </table>

    <p class="mt-5"><b>Количество положительных элементов: </b>{{$result['count']}}</p>

    <p class="mt-5"><b>Сумма элементов после последнего элемента равного нулю:</b> {{$result['sum']}}</p>

    <p class="mt-5"><b>Преобразованный массив, по правилу сначала все элементы, равные нулю, а потом — все остальные</b>
    </p>
    <table class='w-50 table table-bordered mt-1'>
        <tr>
            @foreach($result['sorted'] as $item)
                <td>{{$item}}</td>
            @endforeach
        </tr>
    </table>




@endsection
