@extends('layouts.layout')

@section('main_content')
    <h3 class="text-center mb-5">Результаты вычислений</h3>
    <img src="/img/evaluate1.png" alt="evaluate1">
    <table class="table w-50">
        <tbody>
        <tr>
            <th class="text-left">Параметр α:</th>
            <td>{{ $data['a'] }}</td>
        </tr>
        <tr>
            <th class="text-left">Параметр β:</th>
            <td>{{ $data['b'] }}</td>
        </tr>
        <tr>
            <th class="text-left">z1:</th>
            <td>{{ $ev1z1 }}</td>
        </tr>
        <tr>
            <th class="text-left">z2:</th>
            <td>{{ $ev1z2 }}</td>
        </tr>
        </tbody>
    </table>
    <img src="/img/evaluate2.png" alt="evaluate1">
    <table class="table w-50">
        <tbody>
        <tr>
            <th class="text-left">Параметр m:</th>
            <td>{{ $data['m'] }}</td>
        </tr>
        <tr>
            <th class="text-left">Параметр n:</th>
            <td>{{ $data['n'] }}</td>
        </tr>
        <tr>
            <th class="text-left">z1:</th>
            <td>{{ $ev2z1 }}</td>
        </tr>
        <tr>
            <th class="text-left">z2:</th>
            <td>{{ $ev2z2 }}</td>
        </tr>
        </tbody>
    </table>
@endsection

