@extends('layouts.layout')

@section('main_content')
    <div class="my-5 text-center">

    <div class="alert alert-warning alert-dismissible fade show w-50 text-dark" role="alert">
        <b>Страница /text в разработке...</b>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    </div>
@endsection
