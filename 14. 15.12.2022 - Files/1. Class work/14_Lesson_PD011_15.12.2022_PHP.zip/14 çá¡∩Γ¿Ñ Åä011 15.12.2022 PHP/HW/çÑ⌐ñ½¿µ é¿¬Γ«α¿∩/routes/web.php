<?php

use App\Http\Controllers\CalculateController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// главная
Route::get('/', [ HomeController::class, 'index']);

// о разработчике
Route::get('/home/about', [ HomeController::class, 'about']);

// выражения
Route::get('/evaluate', [CalculateController::class, 'evaluate']);
Route::get('/handle1', [CalculateController::class, 'handle1']);

// массивы
Route::get('/array_n', [CalculateController::class, 'array_n']);
Route::post('/handle2/{n?}', [CalculateController::class, 'handle2']);

// текст
Route::get('/text', [CalculateController::class, 'text']);
Route::post('/handle3', [CalculateController::class, 'handle3']);
