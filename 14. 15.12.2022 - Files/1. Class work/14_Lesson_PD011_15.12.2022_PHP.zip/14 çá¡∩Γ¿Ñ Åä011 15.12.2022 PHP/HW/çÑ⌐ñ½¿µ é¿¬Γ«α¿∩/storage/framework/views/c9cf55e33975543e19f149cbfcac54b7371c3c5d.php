<?php $__env->startSection('main_content'); ?>
    
    <h3 class="text-center mb-5">Форма ввода диапазона генерации случайных целых чисел для заполнения массива</h3>
    <div class="offset-2 col-5">
        <form action="/handle2/{n?}" method="post">
            <?php echo csrf_field(); ?>
            <div class="row my-3">
                <label class="visually-hidden" for="from">from:</label>
                <div class="input-group">
                    <div class="input-group-text">от:</div>
                    <input class="form-control" type="number" name="from" id="from" value="12"/>
                </div>
            </div>

            <div class="row mb-3">
                <label class="visually-hidden" for="to">to:</label>
                <div class="input-group">
                    <div class="input-group-text">до:</div>
                    <input class="form-control" type="number" name="to" id="to" value="25"/>
                </div>
            </div>


            <div class="my-3 row">
                <div class="offset-3 col-9">
                    <input class="btn btn-success" type="submit" value="Отправить">
                </div>
            </div>
        </form>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\User\source\repos\HW13PHP\resources\views/calculate/array_n.blade.php ENDPATH**/ ?>