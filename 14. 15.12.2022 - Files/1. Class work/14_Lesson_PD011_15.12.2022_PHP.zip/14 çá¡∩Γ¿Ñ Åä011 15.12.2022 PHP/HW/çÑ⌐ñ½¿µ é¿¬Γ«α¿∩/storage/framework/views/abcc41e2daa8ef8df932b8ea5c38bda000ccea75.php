<?php $__env->startSection('main_content'); ?>
    <h3 class="text-center mb-5">Результаты вычислений</h3>
    <img src="/img/evaluate1.png" alt="evaluate1">
    <table class="table w-50">
        <tbody>
        <tr>
            <th class="text-left">Параметр α:</th>
            <td><?php echo e($data['a']); ?></td>
        </tr>
        <tr>
            <th class="text-left">Параметр β:</th>
            <td><?php echo e($data['b']); ?></td>
        </tr>
        <tr>
            <th class="text-left">z1:</th>
            <td><?php echo e($ev1z1); ?></td>
        </tr>
        <tr>
            <th class="text-left">z2:</th>
            <td><?php echo e($ev1z2); ?></td>
        </tr>
        </tbody>
    </table>
    <img src="/img/evaluate2.png" alt="evaluate1">
    <table class="table w-50">
        <tbody>
        <tr>
            <th class="text-left">Параметр m:</th>
            <td><?php echo e($data['m']); ?></td>
        </tr>
        <tr>
            <th class="text-left">Параметр n:</th>
            <td><?php echo e($data['n']); ?></td>
        </tr>
        <tr>
            <th class="text-left">z1:</th>
            <td><?php echo e($ev2z1); ?></td>
        </tr>
        <tr>
            <th class="text-left">z2:</th>
            <td><?php echo e($ev2z2); ?></td>
        </tr>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\14 Занятие ПД011 15.12.2022 PHP\HW\Зейдлиц Виктория\resources\views/calculate/handle1.blade.php ENDPATH**/ ?>