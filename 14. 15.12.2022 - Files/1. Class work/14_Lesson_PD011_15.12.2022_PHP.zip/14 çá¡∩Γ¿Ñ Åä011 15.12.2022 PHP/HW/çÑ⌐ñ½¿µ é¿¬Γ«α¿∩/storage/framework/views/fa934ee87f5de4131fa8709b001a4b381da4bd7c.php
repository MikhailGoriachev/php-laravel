<?php $__env->startSection('main_content'); ?>
    <div class="my-5 text-center">

    <div class="alert alert-warning alert-dismissible fade show w-50 text-dark" role="alert">
        <b>Страница /text в разработке...</b>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\User\source\repos\HW13PHP\resources\views/calculate/text.blade.php ENDPATH**/ ?>