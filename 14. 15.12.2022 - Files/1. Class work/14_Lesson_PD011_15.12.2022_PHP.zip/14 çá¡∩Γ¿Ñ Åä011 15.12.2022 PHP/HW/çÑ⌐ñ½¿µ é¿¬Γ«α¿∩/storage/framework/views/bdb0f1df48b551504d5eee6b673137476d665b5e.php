<?php $__env->startSection('main_content'); ?>
    <div class="card w-50 text-center bg-light">
        <img src="public/img/program-64.png" class="card-img-top bg-gradient" alt="...">
        <hr/>
        <div class="card-body">
            <h5 class="card-title">Данные о разработчике</h5>
            <p class="card-text"><b>Студент:</b> Зейдлиц Виктория</p>
            <p class="card-text"><b>Группа: </b> ПД011 г.Донецк 2022</p>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\User\source\repos\HW12PHP\resources\views/about.blade.php ENDPATH**/ ?>