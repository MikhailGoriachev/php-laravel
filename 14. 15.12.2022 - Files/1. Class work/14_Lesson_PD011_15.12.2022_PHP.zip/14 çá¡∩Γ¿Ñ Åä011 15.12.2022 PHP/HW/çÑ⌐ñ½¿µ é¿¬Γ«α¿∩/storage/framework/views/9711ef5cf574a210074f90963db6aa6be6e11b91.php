<?php $__env->startSection('main_content'); ?>
    <h3 class="text-center mb-5">Ввод данных для выражений</h3>
    
<div class="row">
    <form action="/handle1" class="align-items-center">
        <div class="col-md-8">

            <img src="/img/evaluate1.png" alt="evaluate1">
                <div class="col-6">
                    <label class="visually-hidden" for="a">Параметр α:</label>
                    <div class="input-group">
                        <div class="input-group-text">Параметр α:</div>
                        <input class="form-control" type="number" name="a" id="a" step="any"/>
                    </div>
                </div>
                <div class="col-6 mt-1">
                    <label class="visually-hidden" for="b">Параметр β:</label>
                    <div class="input-group">
                        <div class="input-group-text">Параметр β:</div>
                        <input class="form-control" type="number" name="b" id="b" step="any"/>
                    </div>
                </div>
        </div>
        <div class="col-md-8 mt-3">
                <img src="/img/evaluate2.png" alt="evaluate1">
                <div class="col-6">
                    <label class="visually-hidden" for="m">Параметр m:</label>
                    <div class="input-group">
                        <div class="input-group-text">Параметр m:</div>
                        <input class="form-control" type="number" name="m" id="m" step="any"/>
                    </div>
                </div>
                <div class="col-6 mt-1">
                    <label class="visually-hidden" for="b">Параметр n:</label>
                    <div class="input-group">
                        <div class="input-group-text">Параметр n:</div>
                        <input class="form-control" type="number" name="n" id="n" step="any"/>
                    </div>
                </div>
        </div>

        <div class="col-6 mt-2 ps-10rem">
            <input class="btn btn-success " type="submit" value="Вычислить">
        </div>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\14 Занятие ПД011 15.12.2022 PHP\HW\Зейдлиц Виктория\resources\views/calculate/evaluate.blade.php ENDPATH**/ ?>