<?php $__env->startSection('main_content'); ?>

    <h4>Размер массива: <?php echo e($n); ?> элементов</h4>

    <p class="mt-5"><b>Исходный массив</b></p>
    <table class='w-50 table table-bordered mt-1'>
        <tr>
            <?php $__currentLoopData = $result['arr']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($item); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>

    <p class="mt-5"><b>Количество положительных элементов: </b><?php echo e($result['count']); ?></p>

    <p class="mt-5"><b>Сумма элементов после последнего элемента равного нулю:</b> <?php echo e($result['sum']); ?></p>

    <p class="mt-5"><b>Преобразованный массив, по правилу сначала все элементы, равные нулю, а потом — все остальные</b>
    </p>
    <table class='w-50 table table-bordered mt-1'>
        <tr>
            <?php $__currentLoopData = $result['sorted']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($item); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\User\source\repos\HW13PHP\resources\views/calculate/handle2.blade.php ENDPATH**/ ?>