<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CalculateController extends Controller
{

    // отображение формы для выражения
    public function evaluate() {
        return view('calculate.evaluate');
    }


    // обработка формы для выражения
    public function handle1(Request $request) {
        $data = $request->all();

        $a = $data['a'];
        $b = $data['b'];
        $m = $data['m'];
        $n = $data['n'];

        $ev1z1 = (sin($a) + cos(2 * $b - $a)) / (cos($a) - sin(2 * $b - $a));
        $ev1z2 = (1 + sin(2 * $b)) / cos(2 * $b);

        $ev2z1 = (($m - 1) * sqrt($m) - ($n - 1) * sqrt($n)) / (sqrt($m**3 * $n) + $n * $m + $m**2 - $m);
        $ev2z2 = (sqrt($m) - sqrt($n)) / $m;

        return view('calculate.handle1', ['data'=>$data, 'ev1z1'=>$ev1z1, 'ev1z2' => $ev1z2, 'ev2z1'=>$ev2z1, 'ev2z2' => $ev2z2]);

    } // handle


    // отображение формы для массива
    public function array_n() {
        return view('calculate.array_n');
    }


    // обработка формы для массива
    public function handle2(Request $request, $n=7) {
        $from = $request->input('from');
        $to = $request->input('to');

        $result = [];

        // $n = rand($from, $to);
        $array = array_map(fn() => rand(-5, 5), array_pad([], $n, 0));
        $result['arr'] = $array;

        // количество положительных элементов массива
        $cntPositive = count(array_filter($array, fn($value) => $value >= 0));
        $result['count'] = $cntPositive;

        // сумма элементов массива, расположенных после последнего элемента, равного нулю
        $positive = array_search(0, $array);
        $sum = $positive ? array_sum(array_slice($array, $positive + 1)) : "Нет нулевых элементов";
        $result['sum'] = $sum;

        // сначала все элементы, равные нулю, а потом — все остальные
        usort($array,fn($a) => $a == 0 ? -1: 1);

        $result['sorted'] = $array;

        return view('calculate.handle2',['result' => $result, 'from' => $from, 'to' => $to, 'n'=>$n]);

    } // handle2


    // отображение формы для текста
    public function text() {
        return view('calculate.text');
    }

    public function handle3() {
        return "В разработке...";
    }
} // class CalculateController
