@extends('layouts.layout')

{{-- задать параметр шаблона - имя активной страницы--}}
@section('active_text', 'active')


<!-- секция контент -->
@section('main_part')
    <div class="offset-2 col-5">
        <h4>Форма ввода строки для оработки</h4>
        <form action="/text-handle" method="post" >
            {{-- защита от CSRF (Cross Site ReFerence ) атак --}}
            @csrf
            <div class="row my-3">
                <label class="form-label col-3" for="id_text">Строка:</label>
                <div class="col-9">
                    <input class="form-control" type="text" name="text" id="id_text">
                </div>
            </div>

            <div class="my-3 row">
                <div class="offset-3 col-3 me-3">
                    <input class="btn btn-success" type="submit" value="Обработать">
                </div>
                <div class="col-3">
                    <input class="btn btn-secondary" type="reset" value="Сбросить">
                </div>
            </div>
        </form>
@endsection
