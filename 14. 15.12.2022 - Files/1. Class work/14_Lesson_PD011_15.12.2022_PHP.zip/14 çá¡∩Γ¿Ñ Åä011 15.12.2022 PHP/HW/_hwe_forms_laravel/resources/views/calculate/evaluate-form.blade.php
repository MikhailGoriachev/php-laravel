{{-- форма ввода параметров вычислений  --}}
@extends('layouts.layout')

{{-- задать параметр шаблона - имя активной страницы--}}
@section('active_evaluate', 'active')

<!-- секция контент -->
@section('main_part')
    <div class="offset-2 col-5">
        <h4>Форма ввода данных для вычислений</h4>
        <form action="/evaluate-handle" method="post" >
            {{-- защита от CSRF (Cross Site ReFerence ) атак --}}
            @csrf
            <div class="row my-3">
                <label class="form-label col-3" for="id_a">Значение &alpha;:</label>
                <div class="col-9">
                    <input class="form-control" type="number" name="a" id="id_a">
                </div>
            </div>
            <div class="row my-3">
                <label class="form-label col-3" for="id_b">Значение &beta;:</label>
                <div class="col-9">
                    <input class="form-control" type="number" name="b" id="id_b">
                </div>
            </div>

            <div class="row my-3">
                <label class="form-label col-3" for="id_m">Значение m:</label>
                <div class="col-9">
                    <input class="form-control" type="number" name="m" id="id_m">
                </div>
            </div>
            <div class="row my-3">
                <label class="form-label col-3" for="id_n">Значение n:</label>
                <div class="col-9">
                    <input class="form-control" type="number" name="n" id="id_n">
                </div>
            </div>

            <div class="my-3 row">
                <div class="offset-3 col-3 me-3">
                    <input class="btn btn-success" type="submit" value="Вычислить">
                </div>
                <div class="col-3">
                    <input class="btn btn-secondary" type="reset" value="Сбросить">
                </div>
            </div>
        </form>
    </div>

@endsection
