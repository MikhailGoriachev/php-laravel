@extends('layouts.layout')

{{-- задать параметр шаблона - имя активной страницы--}}
@section('active_array', 'active')

<!-- секция контент -->
@section('main_part')
    <div class="offset-2 col-5">
        <h4>Форма ввода диапазона значений для заполнения массива</h4>
        <form action="/array-handle/{{ $n }}" method="post" >
            {{-- защита от CSRF (Cross Site ReFerence ) атак --}}
            @csrf
            <div class="row my-3">
                <label class="form-label col-3" for="id_lo">Нижняя граница:</label>
                <div class="col-9">
                    <input class="form-control" type="number" name="lo" id="id_lo">
                </div>
            </div>
            <div class="row my-3">
                <label class="form-label col-3" for="id_hi">Верхняя граница:</label>
                <div class="col-9">
                    <input class="form-control" type="number" name="hi" id="id_hi">
                </div>
            </div>

            <div class="my-3 row">
                <div class="offset-3 col-3 me-3">
                    <input class="btn btn-success" type="submit" value="Обработать">
                </div>
                <div class="col-3">
                    <input class="btn btn-secondary" type="reset" value="Сбросить">
                </div>
            </div>
        </form>
	</div>
@endsection
