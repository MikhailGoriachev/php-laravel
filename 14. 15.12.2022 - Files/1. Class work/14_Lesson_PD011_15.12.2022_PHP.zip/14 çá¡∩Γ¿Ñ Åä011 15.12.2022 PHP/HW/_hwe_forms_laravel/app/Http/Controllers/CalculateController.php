<?php

namespace App\Http\Controllers;

use App\Models\Person;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

// контроллео по заданию, реализаця простых обработок по заданию
class CalculateController extends Controller
{
    // запрос отображения формы ввода параметров
    // GET /evaluate
    public function evaluate()
    {
        return view("calculate.evaluate-form");
    } // evaluate

    // обработка формы ввода параметров, вычисления по заданию
    // POST /evaluate-handle
    public function evaluateHandle(Request $request)
    {
        // параметры выражения и результаты
        $results = [];

        // вычислеяем выражения и помещаем в массив
        $a = $request->input('a');
        $b = $request->input('b');

        $z1 = (sin($a) + cos(2 * $b - $a)) / (cos($a) - sin(2 * $b - $a));
        $z2 = (1 + sin(2 * $b)) / cos(2 * $b);

        // запись параметров и результатов в массив
        $results[0]['a'] = $a;
        $results[0]['b'] = $b;
        $results[0]['z1ab'] = $z1;
        $results[0]['z2ab'] = $z2;

        $m = $request->input('m');
        $n = $request->input('n');

        $z1 = (($m - 1) * sqrt($m) - ($n - 1) * sqrt($n)) / (sqrt($m ** 3 * $n) + $n * $m + $m ** 2 - $m);
        $z2 = (sqrt($m) - sqrt($n)) / $m;

        // запись параметров и результатов в массив
        $results[1]['m'] = $m;
        $results[1]['n'] = $n;
        $results[1]['z1mn'] = $z1;
        $results[1]['z2mn'] = $z2;

        // передача результатаов расчетов представлению
        return view("calculate.evaluate-handle", ['results' => $results]);
    } // evaluateHandle

    // запрос формы ввода параметров генерации массива
    // GET /array
    public function array($n = 10)
    {
        return view("calculate.array-form", ['n'=>$n]);
    } // array

    // запрос обработки массива, вывод массива, результатов обработки
    // POST /array-handle/{n}
    public function arrayHandle(Request $request, $n)
    {
        $lo = $request->input('lo');
        $hi = $request->input('hi');

        // TODO: реализовать обработку по заданию

        return view("calculate.array-handle", ['n'=>$n, 'lo'=>$lo, 'hi'=>$hi]);
    } // arrayHandle

    // запрос формы ввода текстов
    // GET /text
    public function text()
    {
        return view("calculate.text-form");
    } // text

    // POST /text-handle
    public function textHandle(Request $request)
    {
        $text = $request->input('text');

        // TODO: реализовать обработку по заданию

        return view("calculate.text-handle", ['text'=>$text]);
    } // textHandle
} // class CalculateController
