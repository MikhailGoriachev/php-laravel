<?php

use App\Http\Controllers\CalculateController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// маршруты по заданию для HomeController

// путь к действию index контроллера home
Route::get('/', [ HomeController::class, 'index' ]);
Route::get('/index', [ HomeController::class, 'index' ]);

// путь к действию about контроллера home
Route::get('/about', [ HomeController::class, 'about' ]);


// маршруты по заданию для CalculateController
// маршрут для вывода формы, представление evaluate-form
Route::get('/evaluate', [ CalculateController::class, 'evaluate' ]);

// маршрут для обработки данных формы, представление evaluate-handle
Route::post('/evaluate-handle', [ CalculateController::class, 'evaluateHandle' ]);

Route::get('/array/{n?}', [ CalculateController::class, 'array' ]);
Route::post('/array-handle/{n}', [ CalculateController::class, 'arrayHandle' ]);

Route::get('/text', [ CalculateController::class, 'text' ]);
Route::post('/text-handle', [ CalculateController::class, 'textHandle' ]);
