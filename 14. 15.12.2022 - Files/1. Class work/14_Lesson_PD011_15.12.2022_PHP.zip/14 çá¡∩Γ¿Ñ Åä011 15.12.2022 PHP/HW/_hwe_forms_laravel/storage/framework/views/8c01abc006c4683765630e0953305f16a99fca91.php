<?php $__env->startSection('active_evaluate', 'active'); ?>

<!-- секция контент -->
<?php $__env->startSection('main_part'); ?>
    <h4 class="text-center my-5">Вычисления выражений по заданию</h4>

    <div class="mb-3 text-center">
        <h5>Выражения для вычисления, вариант 13</h5>
        <img class="w-25" src="<?php echo e(asset("/images/variant13.png")); ?>">
    </div>

    <h4 class="text-center">Результаты вычислений</h4>
    <table class="table table-bordered table-striped w-75 mx-auto mb-5">
        <thead>
        <tr class="text-center">
            <th>Номер</th>
            <th>Параметр &alpha;</th>
            <th>Параметр &beta;</th>
            <th>Результат z<sub>1</sub></th>
            <th>Результат z<sub>2</sub></th>
            <th>Корректность</th>
        </tr>
        </thead>
        <tbody>
        <tr class="text-center">
            <td>1</td>
            <td><?php echo e(sprintf("%.5f", $results[0]['a'])); ?> </td>
            <td><?php echo e(sprintf("%.5f", $results[0]['b'])); ?> </td>
            <td><?php echo e(sprintf("%.5f", $results[0]['z1ab'])); ?> </td>
            <td><?php echo e(sprintf("%.5f", $results[0]['z2ab'])); ?> </td>
            <td><?php echo e(abs($results[0]['z2ab'] - $results[0]['z1ab']) < 1e-6?"":"не"); ?>корректно</td>
        </tr>
        </tbody>
    </table>

    <div class="mt-5 mb-3 text-center">
        <h5>Выражения для вычисления, вариант 20</h5>
        <img class="w-25" src="<?php echo e(asset("images/variant20.png")); ?>">
    </div>

    <h4 class="text-center">Результаты вычислений</h4>
    <table class="table table-bordered table-striped w-75 mx-auto mb-5">
        <thead>
        <tr class="text-center">
            <th>Номер</th>
            <th>Параметр m</th>
            <th>Параметр n</th>
            <th>Результат z<sub>1</sub></th>
            <th>Результат z<sub>2</sub></th>
            <th>Корректность</th>
        </tr>
        </thead>
        <tbody>
        <tr class="text-center">
            <td> 1</td>
            <td><?php echo e(sprintf("%.5f", $results[1]['m'])); ?> </td>
            <td><?php echo e(sprintf("%.5f", $results[1]['n'])); ?> </td>
            <td><?php echo e(sprintf("%.5f", $results[1]['z1mn'])); ?> </td>
            <td><?php echo e(sprintf("%.5f", $results[1]['z2mn'])); ?> </td>
            <td><?php echo e(abs($results[1]['z2mn'] - $results[1]['z1mn']) < 1e-6?"":"не"); ?>корректно</td>
        </tr>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\14 Занятие ПД011 15.12.2022 PHP\HW\_hwe_forms_laravel\resources\views/calculate/evaluate-handle.blade.php ENDPATH**/ ?>