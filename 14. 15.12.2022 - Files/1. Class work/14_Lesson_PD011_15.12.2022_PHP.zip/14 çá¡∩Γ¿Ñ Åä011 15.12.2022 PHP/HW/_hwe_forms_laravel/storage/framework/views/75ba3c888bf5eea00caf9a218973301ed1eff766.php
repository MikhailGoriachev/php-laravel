<?php $__env->startSection('active_variant13', 'active'); ?>

<!-- секция контент -->
<?php $__env->startSection('main_part'); ?>
    <h4 class="text-center my-5">Вычисления выражений по заданию "Вариант 13"</h4>

    <div class="mb-5 text-center">
        <h5>Выражения для вычисления</h5>
        <img class="w-25" src="/images/variant13.png" >
    </div>

    <h4 class="text-center">Результаты вычислений</h4>
    <table class="table table-bordered table-striped w-75 mx-auto mb-5">
        <thead>
            <tr class="text-center">
                <th>Номер</th>
                <th>Параметр &alpha;</th>
                <th>Параметр &beta;</th>
                <th>Результат z<sub>1</sub></th>
                <th>Результат z<sub>2</sub></th>
                <th>Корректность</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td><?php echo e($loop->iteration); ?> </td>
                    <td><?php echo e(sprintf("%.5f", $result['a'])); ?> </td>
                    <td><?php echo e(sprintf("%.5f", $result['b'])); ?> </td>
                    <td><?php echo e(sprintf("%.5f", $result['z1'])); ?> </td>
                    <td><?php echo e(sprintf("%.5f", $result['z2'])); ?> </td>
                    <td><?php echo e(abs($result['z2'] - $result['z1']) < 1e-6?"":"не"); ?>корректно </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\14 Занятие ПД011 15.12.2022 PHP\HW\_hwe_forms_laravel\resources\views/calculate/evaluate-handle.blade.php ENDPATH**/ ?>
