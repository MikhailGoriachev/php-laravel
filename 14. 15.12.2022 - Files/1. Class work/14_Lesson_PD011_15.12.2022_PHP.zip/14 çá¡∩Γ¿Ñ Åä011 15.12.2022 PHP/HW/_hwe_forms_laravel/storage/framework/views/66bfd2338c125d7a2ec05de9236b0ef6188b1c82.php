<?php $__env->startSection('active_array', 'active'); ?>

<!-- секция контент -->
<?php $__env->startSection('main_part'); ?>
    <div class="offset-2 col-5">
        <h4>Форма ввода диапазона значений для заполнения массива</h4>
        <form action="/array-handle/<?php echo e($n); ?>" method="post" >
            
            <?php echo csrf_field(); ?>
            <div class="row my-3">
                <label class="form-label col-3" for="id_lo">Нижняя граница:</label>
                <div class="col-9">
                    <input class="form-control" type="number" name="lo" id="id_lo">
                </div>
            </div>
            <div class="row my-3">
                <label class="form-label col-3" for="id_hi">Верхняя граница:</label>
                <div class="col-9">
                    <input class="form-control" type="number" name="hi" id="id_hi">
                </div>
            </div>

            <div class="my-3 row">
                <div class="offset-3 col-3 me-3">
                    <input class="btn btn-success" type="submit" value="Обработать">
                </div>
                <div class="col-3">
                    <input class="btn btn-secondary" type="reset" value="Сбросить">
                </div>
            </div>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\14 Занятие ПД011 15.12.2022 PHP\HW\_hwe_forms_laravel\resources\views/calculate/array-form.blade.php ENDPATH**/ ?>