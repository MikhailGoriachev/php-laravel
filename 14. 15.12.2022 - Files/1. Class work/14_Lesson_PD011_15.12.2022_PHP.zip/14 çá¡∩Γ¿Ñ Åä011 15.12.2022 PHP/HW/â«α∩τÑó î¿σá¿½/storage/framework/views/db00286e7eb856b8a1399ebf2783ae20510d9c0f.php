﻿<div class='m-3 p-3 border bg-white shadow rounded'>
    <h5><?php echo e($title); ?></h5>

    <?php if(count($array) > 0): ?>
        <div class='row mt-3'>
            <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class='border m-2 p-2 shadow-sm w-8rem text-center rounded <?php echo e(isset($isActive) ? $isActive($item) : ''); ?>'>
                    <?php echo e(number_format($item, 3)); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="alert alert-danger" role="alert">
            Нет данных
        </div>
    <?php endif; ?>
</div>
<?php /**PATH D:\Students\ПД011\15 PHP\14 Занятие ПД011 15.12.2022 PHP\HW\Горячев Михаил\resources\views/calculate/showArray.blade.php ENDPATH**/ ?>