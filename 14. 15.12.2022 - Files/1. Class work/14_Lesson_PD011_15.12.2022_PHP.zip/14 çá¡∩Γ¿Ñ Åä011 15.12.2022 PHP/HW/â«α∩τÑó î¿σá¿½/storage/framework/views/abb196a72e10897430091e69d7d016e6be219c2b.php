﻿

<?php $__env->startSection('title', 'Массивы'); ?>

<?php $__env->startSection('arrayActive', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">
        <h4 class="text-center">Массивы</h4>

        <?php echo e(view('calculate.showArray', ['title' => 'Исходный массив', 'array' => $sourceArray])); ?>


        <?php echo e(view('calculate.showArray', ['title' => "Количество положительных элементов: $countPositiveItems",
            'array' => $sourceArray, 'isActive' => fn($n) => $n > 0 ? 'bg-primary text-white' : ''])); ?>


        <?php echo e(view('calculate.showArray', ['title' => sprintf('Сумма элементов после последнего нулевого: %.3f', $sumItemsAfterLastZeroElem),
            'array' => $sourceArray, 'isActive' => fn($n) => $n === 0 ? 'bg-success text-white' : ''])); ?>


        <?php echo e(view('calculate.showArray', ['title' => 'Сортировка по правилу: нули в начале',
            'array' => $sortArray, 'isActive' => fn($n) => $n === 0 ? 'bg-success text-white' : ''])); ?>


        <div class="ms-3 my-5">
            <a class="btn btn-primary me-2"
               href="/arrayForm/<?php echo e($min); ?>/<?php echo e($max); ?>">
                Ввод данных
            </a>
            <a class="btn btn-secondary" href="/">На главную</a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\14 Занятие ПД011 15.12.2022 PHP\HW\Горячев Михаил\resources\views/calculate/array.blade.php ENDPATH**/ ?>