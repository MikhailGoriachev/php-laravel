﻿

<?php $__env->startSection('title', 'Ввод текста'); ?>

<?php $__env->startSection('textActive', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <div class="min-vh-100">
        <section class="w-50 mx-auto my-4 bg-light shadow-sm border rounded-3 p-3">

            <form action="/text" method="post">
                <?php echo csrf_field(); ?>

                <h4 class="text-center mb-4">Ввода текста</h4>

                
                <div class="form-floating my-3">
                    <input name="text" class="form-control" type="text" placeholder=" "
                           value="<?php echo e($text); ?>" required>
                    <label class="form-label">Текст</label>
                </div>

                
                <div class="form-floating my-3">
                    <input name="length" class="form-control" type="number" min="1" placeholder=" "
                           value="<?php echo e($length); ?>" required>
                    <label class="form-label">Длина слова (для обработки)</label>
                </div>

                <div class="mt-5">
                    <input class="btn btn-primary w-10rem me-2" type="submit" value="Обработка">
                    <a class="btn btn-success w-10rem me-2" href="/textForm" title="Генерация нового текста">Сгенерировать</a>
                    <a class="btn btn-secondary w-10rem" href="/">На главную</a>
                </div>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\14. 15.12.2022 -\2. Home work\home-work\resources\views/calculate/textForm.blade.php ENDPATH**/ ?>