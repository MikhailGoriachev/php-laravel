﻿

<?php $__env->startSection('title', ($isAdd ? 'Добавление' : 'Изменение') . ' обуви'); ?>

<?php $__env->startSection('tablesActive', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <div class="min-vh-100">
        <section class="w-50 mx-auto my-4 bg-light shadow-sm border rounded-3 p-3">


            <form action="<?php echo e($isAdd ? '/shoes/create' : '/shoes/edit'); ?>" method="post">
                <?php echo csrf_field(); ?>

                <h4 class="text-center mb-4"><?php echo e(($isAdd ? 'Добавление' : 'Изменение') . ' обуви'); ?></h4>

                
                <input type="hidden" name="id" value="<?php echo e((isset($item) ? $item->id : old('id'))); ?>">

                
                <div class="form-floating my-3">
                    <select name="manufacture_id" class="form-select <?php $__errorArgs = ['manufacture_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__currentLoopData = $manufactureList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($m['key']); ?>" <?php echo e(($m['key'] === (isset($item)
                                        ? $item->manufacture_id
                                        : old('manufacture_id')) ? 'selected' : '')); ?>>
                                <?php echo e($m['value']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label class="form-label">Производитель</label>
                </div>

                <?php $__errorArgs = ['manufacture_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                
                <div class="form-floating my-3">
                    <select name="shoes_type_id" class="form-select <?php $__errorArgs = ['shoes_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__currentLoopData = $shoesTypeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($m['key']); ?>" <?php echo e(($m['key'] === (isset($item)
                                                    ? $item->shoes_type_id
                                                    : old('shoes_type_id')) ? 'selected' : '')); ?>>
                                <?php echo e($m['value']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label class="form-label">Тип обуви</label>
                </div>

                <?php $__errorArgs = ['shoes_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                
                <div class="form-floating my-3">
                    <input name="code" class="form-control <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           type="number" placeholder=" "
                           value="<?php echo e(isset($item) ? $item->code : old('code')); ?>">
                    <label class="form-label">Код товара</label>
                </div>

                
                <div class="form-floating my-3">
                    <input name="price" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           type="number" placeholder=" "
                           value="<?php echo e(isset($item) ? $item?->price : old('price')); ?>">
                    <label class="form-label">Стоимость (&#8381;)</label>
                </div>

                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="mt-5">
                    <input class="btn btn-primary w-10rem me-2" type="submit"
                           value="<?php echo e($isAdd ? 'Добавить' : 'Сохранить'); ?>">
                    <a class="btn btn-secondary w-10rem" href="/shoes/index">Назад</a>
                </div>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\19. 26.12.2022 -\2. Home work\home-work\resources\views/shoes/forms/shoesForm.blade.php ENDPATH**/ ?>