﻿

<?php $__env->startSection('title', 'Обувь'); ?>

<?php $__env->startSection('tablesActive', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">
        <h4 class="text-center">Обувь</h4>

        <form action="/shoes/show" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">

                
                <div class="col-auto">
                    <div class="form-floating my-3">
                        <select name="shoes_type_id" class="form-select <?php $__errorArgs = ['shoes_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__currentLoopData = $shoesTypeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($s['key']); ?>" <?php echo e(($s['key'] === ($shoes_type_id ?? old('shoes_type_id')) ? 'selected' : '')); ?>>
                                    <?php echo e($s['value']); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label class="form-label">Тип обуви</label>
                    </div>
                </div>

                <div class="col-auto mt-4">
                    <input class="btn btn-success w-8rem" type="submit" value="Выбрать">
                </div>
                <div class="col-auto mt-4">
                    <a class="btn btn-warning w-8rem" href="/shoes/index">Сброс</a>
                </div>
            </div>
        </form>

        <table class="table table-hover">
            <thead>
            <tr>
                <th>ID</th>
                <th>Код товара</th>
                <th>Производитель</th>
                <th>Тип обуви</th>
                <th>Цена</th>
                <th class="text-center">
                    <a class="btn btn-success" href="shoes/create"><i class="bi bi-plus-lg"></i>Добавить...</a>
                </th>
            </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $data->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="align-middle">
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->code); ?></td>
                    <td><?php echo e($item->manufacture->name); ?></td>
                    <td><?php echo e($item->shoes_type->name); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td class='text-center'>
                        <a class="btn btn-warning" href='shoes/edit/<?php echo e($item->code); ?>'><i
                                class='bi bi-pencil-fill'></i></a>
                        <a class="btn btn-danger" href="shoes/delete/<?php echo e($item->code); ?>" title="Удалить">
                            <i class="bi bi-trash-fill"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\20 Занятие ПД011 29.12.2022 PHP\HW\Горячев Михаил\resources\views/shoes/tables/shoes.blade.php ENDPATH**/ ?>