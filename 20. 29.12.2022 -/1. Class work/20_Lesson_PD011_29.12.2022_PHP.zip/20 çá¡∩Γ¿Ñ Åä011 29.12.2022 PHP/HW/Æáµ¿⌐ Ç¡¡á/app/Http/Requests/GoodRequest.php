<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class GoodRequest extends FormRequest{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [

            'price' => 'bail|required|numeric|min:1000|max:1000000'
        ];
    }

    // вывод сообщений
    public function messages()
    {
        return [
            'price.required' => 'Поле стоимость должно быть заполнено',
            'price.numeric' => 'Поле стоимость должно быть числовым',
            'price.min' => 'Стоимость товара должна быть больше 999',
            'price.max' => 'Стоимость товара должна быть меньше 1000001'
        ];
    }

}
