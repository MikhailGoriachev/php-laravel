<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Good;
use App\Models\Maker;
use App\Http\Requests\GoodRequest;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Faker\Generator;

class ShoesController extends Controller
{
    // shoes/index: вывод всех записей таблицы
    public function index(): \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View{

        $shoes = Good::with(['category','maker'])->get();

        return view('shoes.index', ['shoes' => $shoes]);
    }


    // shoes/create-form: форма с валидацией для добавление пары обуви
    public function createForm(): \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
    {

        $categories = Category::all();
        $makers = Maker::all();

        return view('shoes.create-form', ['categories' => $categories, 'makers' => $makers, 'isAdd' => true]);

    } // createForm

    // обработчик формы добавления пары обуви (с валидацией)
    public function add(GoodRequest $request): View
    {
        $faker = app(Generator::class);

        $good = new Good();
        $good->category_id = $request->input('category');
        $good->maker_id = $request->input('maker');
        $good->code = $faker->bothify('##****##*');
        $good->price = $request->input('price');

        $good->save();

        return $this->index();
    }

    //"мягкое" удаление пары обуви с заданным  кодом товара
    public function delete($code): View {

        $good = Good::all()
        ->where('code','like',$code)
        ->first();

        $good->delete();

        return $this->index();
    }

    // shoes/edit/{code}: форма для редактирования пары обуви,
    //                    по коду товара
    public function editForm($code): View {

        $categories = Category::all();
        $makers = Maker::all();

        $good = Good::all()
            ->where('code','like',$code)
            ->first();

        return view('shoes.create-form', [
            'categories' => $categories,
            'makers' => $makers,
            'isAdd' => false,
            'category_id' => $good->category_id,
            'maker_id' => $good->maker_id,
            'code' => $code,
            'price' => $good->price
        ]);
    }


    // обработчик формы для редактирования пары обуви,
    //                    по коду товара
    public function edit(GoodRequest $request): View {

        $good = Good::all()
            ->where('code','like',$request->input('code'))
            ->first();

        $good->category_id = $request->input('category');
        $good->maker_id = $request->input('maker');
        $good->price = $request->input('price');

        $good->save();

        return $this->index();
    }

    //  shoes/show: выводит пары обуви заданного наименования
    public function showForm(): View {

        $categories = Category::all();
        $shoes = Good::with(['category','maker'])->get();

        return view('shoes.show', ['categories' => $categories, 'shoes' => $shoes]);
    }

    //  shoes/show-handler: выводит пары обуви заданного наименования
    public function show(Request $request): View {

        $categories = Category::all();

        $shoes = Good::with(['category','maker'])
            ->where('category_id','=', $request->input('category'))
            ->get();

        return view('shoes.show', ['categories' => $categories, 'shoes' => $shoes]);
    }

}// class ShoesController
