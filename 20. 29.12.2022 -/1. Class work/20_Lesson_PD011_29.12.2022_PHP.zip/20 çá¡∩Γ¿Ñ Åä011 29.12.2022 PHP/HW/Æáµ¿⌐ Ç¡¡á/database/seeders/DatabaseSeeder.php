<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\Good;
use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\Maker;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         Category::factory(10)->create();
         Maker::factory(10)->create();
         Good::factory(20)->create();
    }
}
