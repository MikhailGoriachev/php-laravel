<?php

namespace Database\Factories;

use Faker\Generator;
use Illuminate\Database\Eloquent\Factories\Factory;
class GoodFactory extends Factory
{
    protected $faker;

    public function definition()
    {
        $faker = app(Generator::class);

        return [

            'category_id' => $faker->numberBetween(1, 10),
            'maker_id' => $faker->numberBetween(1, 10),
            'code' => $faker->bothify('##****##*'),
            'price' => $faker->numberBetween(100, 100000)
        ];
    }
}
