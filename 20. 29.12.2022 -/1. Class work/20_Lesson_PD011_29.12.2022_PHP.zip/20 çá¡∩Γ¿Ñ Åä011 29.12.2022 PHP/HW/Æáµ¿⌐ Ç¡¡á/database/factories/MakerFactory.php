<?php

namespace Database\Factories;

use Faker\Generator;
use Illuminate\Database\Eloquent\Factories\Factory;

class MakerFactory extends Factory
{
    protected $faker;

    public function definition()
    {
        $faker = app(Generator::class);

        return [
            'title' => $faker->company
        ];
    }
}
