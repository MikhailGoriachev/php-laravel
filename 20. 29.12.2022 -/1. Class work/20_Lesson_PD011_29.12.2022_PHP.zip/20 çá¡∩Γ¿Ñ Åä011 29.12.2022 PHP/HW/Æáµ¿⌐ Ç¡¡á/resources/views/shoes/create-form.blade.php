@extends('layouts.app')

@section('title', 'Добавление товара')

@section('content')

    <form method="post" class="w-50" action="{{$isAdd ? '/shoes/add' : "/shoes/edit" }}">

        @csrf

        <input type="hidden" name="code" value="{{$isAdd ? 0  : $code}}">

        <p class="mt-4 ms-3 mb-4 fs-4" >Введите данные товара:</p>

        <div class="mt-3 ms-3">
            <label  class="form-label" for="id_category">Категория:</label>
            <select class="form-select" name="category" id="id_category" >
                @foreach($categories as $category)
                    <option value="{{$category->id}}" {{($category->id === (($category_id ?? old('category')) ?? '') ? 'selected' : '')}}>
                        {{$category->title}}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mt-3 ms-3">
            <label  class="form-label" for="id_maker">Производитель:</label>
            <select class="form-select" name="maker" id="id_maker" >
                @foreach($makers as $maker)
                    <option value="{{$maker->id}}" {{($maker->id === (($maker_id ?? old('maker')) ?? '') ? 'selected' : '')}}>{{$maker->title}}</option>
                @endforeach
            </select>
        </div>

        <div class="mt-3 ms-3">
            <label class="form-label" for="id_price">Стоимость обуви:</label>
            <input class="form-control  @error('price') is-invalid @enderror " type="number" name="price" id = "id_price"
                   value = "{{$isAdd ? old('price')  : $price}}"/>
        </div>

        <div class="mt-3 ms-3 d-flex justify-content-end">
            <input class="btn btn-primary" type="submit" value="Отправить" />
        </div>

        @if ($errors->any())
            <div class="mt-5 ms-3 alert alert-danger">
                @foreach ($errors->all() as $error)
                    {{ $error }}
                @endforeach
            </div>
        @endif

    </form>


@endsection
