@extends('layouts.app')

@section('shoes', 'active')
@section('title', 'Страница с товаром')

<!-- секция контент -->
@section('content')

    <div class="d-flex justify-content-end">
        <div class="btn-group w-25 mb-5 mt-3">

            <a class="btn btn-primary" href="/shoes/create">Добавить запись</a>
        </div> </div>

    <p class="fs-5">Список пар обуви:</p>

    <table class="table mt-4">
        <thead>
            <tr>
                <th>Тип обуви</th>
                <th>Производитель</th>
                <th>Код</th>
                <th>Стоимость</th>
            </tr>
        </thead>

        <tbody>
            @foreach($shoes as $shoe)
                <tr>
                    <td>{{$shoe->category->title}}</td>
                    <td>{{$shoe->maker->title}}</td>
                    <td>{{$shoe->code}}</td>
                    <td>{{$shoe->price}}</td>
                    <td class='text-center'>
                        <a class='btn btn-danger' title='Удалить' href="/shoes/delete/{{$shoe->code}}"><i class='bi bi-trash-fill'></i></a>
                        <a class="btn btn-success" title="Изменить" href="/shoes/edit-form/{{$shoe->code}}"><i class="bi bi-pencil-fill"></i></a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

@endsection
