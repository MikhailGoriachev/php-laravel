@extends('layouts.app')

@section('show', 'active')
@section('title', 'Выводит пары обуви заданного наименования')

<!-- секция контент -->
@section('content')

    <form method="post" class="w-50" action="/shoes/show-handler">
        @csrf

        <div class="row mb-5 mt-3">

            <div class="col mt-2">
                <label class="form-label" for="id_category">Категория:</label>
                <select class="form-select" name="category" id="id_category">
                    @foreach($categories as $category)
                        <option value="{{$category->id}}">{{$category->title}}</option>
                    @endforeach
                </select>
            </div>

            <div class="col" style="margin-top: 45px">
                <input class="btn btn-primary" type="submit" value="Отправить"/>
            </div>
        </div>

    </form>


    @if(count($shoes) == 0)
        <div class="mt-5 w-50  alert alert-danger">
           По вашему запросу ничего не найдено
        </div>
    @else
        <p class="fs-5">Список пар обуви:</p>

        <table class="table mt-4">
            <thead>
            <tr>
                <th>Тип обуви</th>
                <th>Производитель</th>
                <th>Код</th>
                <th>Стоимость</th>
            </tr>
            </thead>

            <tbody>
            @foreach($shoes as $shoe)
                <tr>
                    <td>{{$shoe->category->title}}</td>
                    <td>{{$shoe->maker->title}}</td>
                    <td>{{$shoe->code}}</td>
                    <td>{{$shoe->price}}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    @endif

@endsection
