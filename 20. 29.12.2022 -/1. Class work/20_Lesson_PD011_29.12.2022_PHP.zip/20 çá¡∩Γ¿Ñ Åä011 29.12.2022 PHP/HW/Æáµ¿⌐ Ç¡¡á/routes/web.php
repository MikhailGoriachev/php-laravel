<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ShoesController;

// путь к действию index контроллера home
Route::get('/', [ HomeController::class, 'index' ]);
Route::get('/about', [ HomeController::class, 'about' ]);

// вывод всех записей таблицы обуви
Route::get('/shoes/index', [ ShoesController::class, 'index' ]);

// добавляет пару обуви в таблицу, используйте форму с валидацией
Route::get('/shoes/create', [ ShoesController::class, 'createForm' ]);

Route::post('/shoes/add', [ ShoesController::class, 'add' ]);

//редактирует пару обуви, выбор пары по коду товара
Route::get('/shoes/edit-form/{code}', [ ShoesController::class, 'editForm' ]);

Route::post('/shoes/edit', [ ShoesController::class, 'edit' ]);

//"мягкое" удаление пары обуви с заданным  кодом товара
Route::get('/shoes/delete/{code}', [ ShoesController::class, 'delete' ]);

//shoes/show: выводит пары обуви заданного наименования
Route::get('/shoes/show', [ ShoesController::class, 'showForm' ]);

//shoes/show-handler: выводит пары обуви заданного наименования
Route::post('/shoes/show-handler', [ ShoesController::class, 'show' ]);
