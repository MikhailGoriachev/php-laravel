<?php $__env->startSection('title', 'Добавление товара'); ?>

<?php $__env->startSection('content'); ?>

    <form method="post" class="w-50" action="<?php echo e($isAdd ? '/shoes/add' : "/shoes/edit"); ?>">

        <?php echo csrf_field(); ?>

        <input type="hidden" name="code" value="<?php echo e($isAdd ? 0  : $code); ?>">

        <p class="mt-4 ms-3 mb-4 fs-4" >Введите данные товара:</p>

        <div class="mt-3 ms-3">
            <label  class="form-label" for="id_category">Категория:</label>
            <select class="form-select" name="category" id="id_category" >
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(($category->id === (($category_id ?? old('category')) ?? '') ? 'selected' : '')); ?>>
                        <?php echo e($category->title); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mt-3 ms-3">
            <label  class="form-label" for="id_maker">Производитель:</label>
            <select class="form-select" name="maker" id="id_maker" >
                <?php $__currentLoopData = $makers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($maker->id); ?>" <?php echo e(($maker->id === (($maker_id ?? old('maker')) ?? '') ? 'selected' : '')); ?>><?php echo e($maker->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mt-3 ms-3">
            <label class="form-label" for="id_price">Стоимость обуви:</label>
            <input class="form-control  <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " type="number" name="price" id = "id_price"
                   value = "<?php echo e($isAdd ? old('price')  : $price); ?>"/>
        </div>

        <div class="mt-3 ms-3 d-flex justify-content-end">
            <input class="btn btn-primary" type="submit" value="Отправить" />
        </div>

        <?php if($errors->any()): ?>
            <div class="mt-5 ms-3 alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\20 Занятие ПД011 29.12.2022 PHP\HW\Таций Анна\resources\views/shoes/create-form.blade.php ENDPATH**/ ?>