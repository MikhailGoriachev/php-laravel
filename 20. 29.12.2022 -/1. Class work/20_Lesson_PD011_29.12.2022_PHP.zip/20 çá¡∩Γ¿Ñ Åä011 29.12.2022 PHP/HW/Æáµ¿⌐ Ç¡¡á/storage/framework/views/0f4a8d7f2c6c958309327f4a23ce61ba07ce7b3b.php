<?php $__env->startSection('show', 'active'); ?>
<?php $__env->startSection('title', 'Выводит пары обуви заданного наименования'); ?>

<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <form method="post" class="w-50" action="/shoes/show-handler">
        <?php echo csrf_field(); ?>

        <div class="row mb-5 mt-3">

            <div class="col mt-2">
                <label class="form-label" for="id_category">Категория:</label>
                <select class="form-select" name="category" id="id_category">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col" style="margin-top: 45px">
                <input class="btn btn-primary" type="submit" value="Отправить"/>
            </div>
        </div>

    </form>


    <?php if(count($shoes) == 0): ?>
        <div class="mt-5 w-50  alert alert-danger">
           По вашему запросу ничего не найдено
        </div>
    <?php else: ?>
        <p class="fs-5">Список пар обуви:</p>

        <table class="table mt-4">
            <thead>
            <tr>
                <th>Тип обуви</th>
                <th>Производитель</th>
                <th>Код</th>
                <th>Стоимость</th>
            </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $shoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shoe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($shoe->category->title); ?></td>
                    <td><?php echo e($shoe->maker->title); ?></td>
                    <td><?php echo e($shoe->code); ?></td>
                    <td><?php echo e($shoe->price); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annat\source\repos\PHP\Step_29.12.22_PHP\resources\views/shoes/show.blade.php ENDPATH**/ ?>