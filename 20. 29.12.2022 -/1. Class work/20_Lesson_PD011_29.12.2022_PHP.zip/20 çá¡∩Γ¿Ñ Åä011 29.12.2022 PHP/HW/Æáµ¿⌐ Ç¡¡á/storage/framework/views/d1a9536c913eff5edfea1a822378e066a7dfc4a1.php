<?php $__env->startSection('shoes', 'active'); ?>
<?php $__env->startSection('title', 'Страница с товаром'); ?>

<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <div class="d-flex justify-content-end">
        <div class="btn-group w-25 mb-5 mt-3">

            <a class="btn btn-primary" href="/shoes/create">Добавить запись</a>
        </div> </div>

    <p class="fs-5">Список пар обуви:</p>

    <table class="table mt-4">
        <thead>
            <tr>
                <th>Тип обуви</th>
                <th>Производитель</th>
                <th>Код</th>
                <th>Стоимость</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $shoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shoe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($shoe->category->title); ?></td>
                    <td><?php echo e($shoe->maker->title); ?></td>
                    <td><?php echo e($shoe->code); ?></td>
                    <td><?php echo e($shoe->price); ?></td>
                    <td class='text-center'>
                        <a class='btn btn-danger' title='Удалить' href="/shoes/delete/<?php echo e($shoe->code); ?>"><i class='bi bi-trash-fill'></i></a>
                        <a class="btn btn-success" title="Изменить" href="/shoes/edit-form/<?php echo e($shoe->code); ?>"><i class="bi bi-pencil-fill"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annat\source\repos\PHP\Step_29.12.22_PHP\resources\views/shoes/index.blade.php ENDPATH**/ ?>