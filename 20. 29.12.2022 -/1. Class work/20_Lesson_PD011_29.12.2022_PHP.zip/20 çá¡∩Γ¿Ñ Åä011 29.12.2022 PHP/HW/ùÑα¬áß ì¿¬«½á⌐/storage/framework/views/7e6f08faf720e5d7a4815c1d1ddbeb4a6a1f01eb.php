<?php $__env->startSection('title'); ?>
    задание
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
     <h2>Задача 1.</h2>
    <p>С использованием фреймворка Laravel создайте приложение для работы
        с однотабличной базой данных (да, дикое упрощение) для хранения данных
        по обуви.</p>
     <p>Таблица хранит данные: наименование (ботинки, кроссовки и т.д.),
         уникальный код товара (это не поле первичного ключа id), производителя,
         цену.</p>
    <p>Создайте базу данных, миграции, выполните начальное заполнение данными
        (не менее 10 записей). Разработайте модель, контроллеры.
        Применяйте навигацию, мастер-страницы. Предусмотрите следующие действия
        в приложении:</p>
    <ul>
        <li>HomeController</li>
        <ul>
            <li>home/index: вывод всех записей таблицы обуви</li>
            <li>home/about: вывод этого задания</li>
        </ul>
        <li>ShoesController</li>
        <ul>
            <li>shoes/create: добавляет пару обуви в таблицу, используйте
                форму с валидацией</li>
            <li>shoes/edit/{code}: редактирует пару обуви, выбор пары по
                коду товара</li>
            <li>shoes/show: выводит пары обуви заданного наименования</li>
        </ul>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Documents\ШАГ\задания\PHP\shoe_storage\resources\views/about.blade.php ENDPATH**/ ?>