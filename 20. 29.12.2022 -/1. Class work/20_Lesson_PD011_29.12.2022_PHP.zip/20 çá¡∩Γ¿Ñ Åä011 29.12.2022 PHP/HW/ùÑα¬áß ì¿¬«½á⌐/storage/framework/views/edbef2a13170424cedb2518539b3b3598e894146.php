<footer class="container-fluid bg-light p-3 mt-1">
    <p>Черкас Николай г.Донецк 2022 г. группа ПД-011</p>
</footer>
<?php /**PATH C:\Users\Lenovo\Documents\ШАГ\задания\PHP\shoe_storage\resources\views/inc/footer.blade.php ENDPATH**/ ?>