<footer class="container-fluid bg-light p-3 mt-1">
    <p>Черкас Николай г.Донецк 2022 г. группа ПД-011</p>
</footer>
<?php /**PATH D:\Students\ПД011\15 PHP\20 Занятие ПД011 29.12.2022 PHP\HW\Черкас Николай\resources\views/inc/footer.blade.php ENDPATH**/ ?>