<nav class=" d-inline-flex mt-2 mt-md-0">
    <a class="me-3 py-2 text-decoration-none" href="/">Задание</a>
    <a class="me-3 py-2 text-decoration-none" href="/home/about">Разработчик</a>
    <a class="me-3 py-2 text-decoration-none" href="/shoes/index">Обувь</a>
    <a class="me-3 py-2 text-decoration-none" >Разработчик</a>
</nav>
<?php /**PATH D:\Students\ПД011\15 PHP\20 Занятие ПД011 29.12.2022 PHP\HW\Черкас Николай\resources\views/inc/nav.blade.php ENDPATH**/ ?>