<?php $__env->startSection('title'); ?>
    задание
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h2 class="text-center">Черкас Николай г.Донецк 2022 г. группа ПД-011</h2>
    <div class="text-center">
        <img src="<?php echo e(asset('storage/images/work.jpg')); ?>" style="height: 500px" alt="фото">
    </div
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Documents\ШАГ\задания\PHP\shoe_storage\resources\views/home/about.blade.php ENDPATH**/ ?>