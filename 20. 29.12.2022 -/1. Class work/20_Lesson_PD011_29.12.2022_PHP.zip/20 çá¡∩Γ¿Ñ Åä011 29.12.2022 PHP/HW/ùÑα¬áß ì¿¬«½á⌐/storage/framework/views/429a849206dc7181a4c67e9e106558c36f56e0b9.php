<div class="btn-group-vertical gap-1 w-75">
    <a class="btn btn-success" href="<?php echo e(route('form_create')); ?>" >Добавить</a>

</div>
<?php /**PATH C:\Users\Lenovo\Documents\ШАГ\задания\PHP\shoe_storage\resources\views/inc/nav_task.blade.php ENDPATH**/ ?>