<?php $__env->startSection('title'); ?>
    редактировать

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <h4>добавляет пару обуви</h4>
    <form class="p3 bg-light w-50 text-center" action="/shoes/edit" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label" for="title">Наименование</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo e($prod->title); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label" for="color">Цвет</label>
            <input type="text" class="form-control" id="color" name="color" value="<?php echo e($prod->color->color); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label" for="price">Цена</label>
            <input type="number" class="form-control" id="price" name="price" value="<?php echo e($prod->price); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label" for="article">код товара</label>
            <input type="number" class="form-control" id="article" name="article" value="<?php echo e($prod->article); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label" for="manufacture">Производитель</label>
            <input type="text" class="form-control" id="manufacture" name="manufacture" value="<?php echo e($prod->manufacture->manufacture); ?>">
        </div>
        <div class="mt-3">
            <button type="submit" class="btn btn-success">Готово</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Documents\ШАГ\задания\PHP\shoe_storage\resources\views/shoes/edit.blade.php ENDPATH**/ ?>