<?php if(session('success')): ?>
    <div class="alert alert-success w-50">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>



<?php if($errors->any()): ?>
    <div class='alert alert-danger w-50'>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Lenovo\Documents\ШАГ\задания\PHP\shoe_storage\resources\views/inc/messages.blade.php ENDPATH**/ ?>