<div class="btn-group-vertical gap-1 w-75">
    <a class="btn btn-success" href="<?php echo e(route('form_create')); ?>" >Добавить</a>

</div>
<?php /**PATH D:\Students\ПД011\15 PHP\20 Занятие ПД011 29.12.2022 PHP\HW\Черкас Николай\resources\views/inc/nav_task.blade.php ENDPATH**/ ?>