@extends('layouts.app')
@section('title')
    обувь
@endsection
@section('content')

<table class="table">
    <thead>
    <tr>
        <th>id</th>
        <th>Наименование</th>
        <th>Цвет</th>
        <th>Код товара</th>
        <th>Производитель</th>
        <th>Цена</th>
        <th></th>
    </tr>
    </thead>
    <tbody>
    @foreach ($shoes as $sh)
        <tr>
            <td>{{$sh->id}}</td>
            <td>{{$sh->title}}</td>
            <td>{{$sh->color->color}}</td>
            <td>{{$sh->article}}</td>
            <td>{{$sh->manufacture->manufacture}}</td>
            <td>{{$sh->price}}</td>
            <td class="text-center">
                <a class="btn btn-success" href="/shoes/edit/{{$sh->id}}" title="Изменить...">
                    <i class="bi bi-pencil"></i>
                </a>
                <a class="btn btn-danger" href="/shoes/delete/{{$sh->id}}" title="Удалить">
                    <i class="bi bi-file-x"></i>
                </a>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>
@endsection

@section('content2')
    @include('inc.nav_task')
@endsection
