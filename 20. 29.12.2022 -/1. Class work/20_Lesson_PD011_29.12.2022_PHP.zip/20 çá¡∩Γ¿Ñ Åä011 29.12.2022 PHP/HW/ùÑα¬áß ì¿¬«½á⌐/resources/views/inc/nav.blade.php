<nav class=" d-inline-flex mt-2 mt-md-0">
    <a class="me-3 py-2 text-decoration-none" href="/">Задание</a>
    <a class="me-3 py-2 text-decoration-none" href="/home/about">Разработчик</a>
    <a class="me-3 py-2 text-decoration-none" href="/shoes/index">Обувь</a>
    <a class="me-3 py-2 text-decoration-none" >Разработчик</a>
</nav>
