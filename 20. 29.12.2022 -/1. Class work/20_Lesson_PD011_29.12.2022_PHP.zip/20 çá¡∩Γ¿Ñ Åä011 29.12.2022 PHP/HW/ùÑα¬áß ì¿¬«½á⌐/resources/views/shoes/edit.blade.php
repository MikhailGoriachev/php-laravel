@extends('layouts.app')
@section('title')
    редактировать

@endsection
@section('content')

    <h4>добавляет пару обуви</h4>
    <form class="p3 bg-light w-50 text-center" action="/shoes/edit" method="post">
        @csrf
        <div class="mb-3">
            <label class="form-label" for="title">Наименование</label>
            <input type="text" class="form-control" id="title" name="title" value="{{$prod->title}}">
        </div>

        <div class="mb-3">
            <label class="form-label" for="color">Цвет</label>
            <input type="text" class="form-control" id="color" name="color" value="{{$prod->color->color}}">
        </div>
        <div class="mb-3">
            <label class="form-label" for="price">Цена</label>
            <input type="number" class="form-control" id="price" name="price" value="{{$prod->price}}">
        </div>
        <div class="mb-3">
            <label class="form-label" for="article">код товара</label>
            <input type="number" class="form-control" id="article" name="article" value="{{$prod->article}}">
        </div>
        <div class="mb-3">
            <label class="form-label" for="manufacture">Производитель</label>
            <input type="text" class="form-control" id="manufacture" name="manufacture" value="{{$prod->manufacture->manufacture}}">
        </div>
        <div class="mt-3">
            <button type="submit" class="btn btn-success">Готово</button>
        </div>
    </form>
@endsection
