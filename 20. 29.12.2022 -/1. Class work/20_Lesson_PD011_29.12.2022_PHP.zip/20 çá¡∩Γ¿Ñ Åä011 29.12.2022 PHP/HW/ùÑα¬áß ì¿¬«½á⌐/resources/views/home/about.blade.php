@extends('layouts.app')
@section('title')
    задание
@endsection
@section('content')
    <h2 class="text-center">Черкас Николай г.Донецк 2022 г. группа ПД-011</h2>
    <div class="text-center">
        <img src="{{asset('storage/images/work.jpg')}}" style="height: 500px" alt="фото">
    </div
@endsection
