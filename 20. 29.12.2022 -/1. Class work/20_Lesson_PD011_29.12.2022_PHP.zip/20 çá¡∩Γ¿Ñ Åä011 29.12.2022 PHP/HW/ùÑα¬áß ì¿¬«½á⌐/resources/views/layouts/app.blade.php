<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width" />
    <title>@yield('title')</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="{{asset('css/style.css')}}">
    <link rel="stylesheet" href="{{asset('lib/bootstrap/css/bootstrap.min.css')}}">


</head>
<body>
<nav class="navbar fixed-top navbar-light bg-light">
    <div class="container-fluid">
        @include('inc.nav')
    </div>
</nav>
<main class="col-sm p-3 mt-5">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-sm-10">
                @include('inc.messages')
                @yield('content')
            </div>
            <div class="col p-1">

                @yield('content2')
            </div>
        </div>
    </div>
</main>
@include('inc.footer')
</body>
</html>
