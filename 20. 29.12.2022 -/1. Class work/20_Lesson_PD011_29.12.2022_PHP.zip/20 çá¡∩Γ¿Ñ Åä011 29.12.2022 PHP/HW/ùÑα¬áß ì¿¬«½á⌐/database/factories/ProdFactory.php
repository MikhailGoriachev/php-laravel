<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Faker\Generator as Faker;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Prod>
 */
class ProdFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        $shoes = [
            'Балетки', 'Берцы', 'Мокасины', 'Кроссовки',
            'Ботфорты', 'Лабутены', 'Угги', 'Слипоны',
            'Туфли', 'Босоножки', 'Кеды', 'Чешки'
        ];
        return [
            'title' => fake()->randomElement($shoes),
            'price' => fake()->numberBetween(1000, 9999),
            'article' => fake()->unique()->biasedNumberBetween(1000, 9999),
            'color_id' => fake()->numberBetween(1, 5),
            'manufacture_id' => fake()->numberBetween(1, 10)
        ];
    }
}
