<?php

use App\Http\Controllers\ShoesController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class, 'index']);
Route::get('/home/index', [HomeController::class, 'index']);
Route::get('/home/about', [HomeController::class, 'about']);
// вывод вей коллекци
Route::get('/shoes/index', [ShoesController::class, 'index']);
// добавление
Route::get('/shoes/create', [ShoesController::class, 'form_create'])
    ->name('form_create');
Route::post('/shoes/create', [ShoesController::class, 'create'])
    ->name('create');
// удаление
Route::get('/shoes/delete/{id}', [ShoesController::class, 'removeShoe']);
// редактирование
Route::get('/shoes/edit/{id}', [ShoesController::class, 'edit_form']);
Route::post('/shoes/edit', [ShoesController::class, 'edit']);
