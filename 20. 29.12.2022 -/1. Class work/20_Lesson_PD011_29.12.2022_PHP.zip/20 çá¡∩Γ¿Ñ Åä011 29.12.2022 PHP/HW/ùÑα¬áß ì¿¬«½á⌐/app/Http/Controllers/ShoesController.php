<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProdRequest;
use App\Models\Color;
use App\Models\Manufacture;
use App\Models\Prod;
use Illuminate\Http\Request;

class ShoesController extends Controller
{
    // выводит всю коллекцию обуви
    public function index(){
        return view('shoes.index', ['shoes' => Prod::with('color', 'manufacture')->get()]);
    }
    // добавление
    public function form_create(){

        return view('shoes.create');
    }
    public function create(ProdRequest $req){
        $prod = new Prod();
        $prod->title = $req->input('title');
        $prod->article = $req->input('article');
        $prod->price = $req->input('price');
        $prod->color_id = $this->colorId($req);
        $prod->manufacture_id = $this->manufactureId($req);
        $prod->save();
        return $this->index();
    }
    // возвращает id цвета
    public function colorId(ProdRequest $req){
        $c = Color::all()->firstWhere('color', '=', $req->input("color"));
        // если такого цвета нет добавляем
        if ($c == null){
            $color_input = $req->input('color');
            $color = new Color();
            $color->color = $color_input;
            $color->save();
            $c = Color::all()->firstWhere('color', '=', $req->input("color"));
        }
        return $c->id;
    }
    // возвращает id производителя
    public function manufactureId(ProdRequest $req){
        $c = Manufacture::all()->firstWhere('manufacture', '=', $req->input("manufacture"));
        // если такого производителя нет добавляем
        if ($c == null){
            $m_input = $req->input('manufacture');
            $manufacture = new Manufacture();
            $manufacture->manufacture = $m_input;
            $manufacture->save();
            $c = Manufacture::all()->firstWhere('manufacture', '=', $req->input("manufacture"));
        }
        return $c->id;
    }
    // удаление
    public function removeShoe(int $id){
        Prod::destroy($id);
        return $this->index();
    }
    // редактирование
    public function edit_form(int $id){
        $prod = Prod::with('color', 'manufacture')->find($id);
        return view('shoes.edit', ['prod' => $prod]);
    }
    public function edit(ProdRequest $req){
        $prod = new Prod();
        $prod->title = $req->input('title');
        $prod->article = $req->input('article');
        $prod->price = $req->input('price');
        $prod->color_id = $this->colorId($req);
        $prod->manufacture_id = $this->manufactureId($req);
        $prod->save();
        return $this->index();
    }

}
