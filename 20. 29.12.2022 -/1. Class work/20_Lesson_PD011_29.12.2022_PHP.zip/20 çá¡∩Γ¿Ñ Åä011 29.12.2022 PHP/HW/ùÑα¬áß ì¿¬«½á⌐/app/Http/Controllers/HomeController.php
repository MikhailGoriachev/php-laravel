<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index() {
        return view('home.index');
        //$shoes_list = [];
        //return view('index', ['shoes_list' => $shoes_list]);
    }

    public function about() {
        return view('home.about');
    }
}
