<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProdRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'title' => 'required',
            'article' => 'required|min:4',
            'color' => 'required',
            'manufacture' => 'required'
        ];
    }

    public function messages()
    {
        return [
            'title.required' => 'поле наименование должно быть заполнено',
            'article.required' => "поле производитель должно быть заполнено",
            'article.min' => 'значение код товара болжно быть 4 знака',
            'manufacture' => 'поле производитель должно быть заполнено',
            'price' => 'поле цена должно быть заполнено',
            'color' => 'поле цвет должно быть заполнено'
        ];
    }
}
