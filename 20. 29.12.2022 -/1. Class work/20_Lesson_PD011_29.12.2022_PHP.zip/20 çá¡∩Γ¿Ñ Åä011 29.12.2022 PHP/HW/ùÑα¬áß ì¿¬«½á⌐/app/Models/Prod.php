<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Prod extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        'title',
        'price',
        'article',
        'color_id',
        'manufacture_id'
    ];
    // связи
    public function color(){
        return $this->belongsTo(Color::class);
    }
    public function manufacture(){
        return $this->belongsTo(Manufacture::class);
    }
}
