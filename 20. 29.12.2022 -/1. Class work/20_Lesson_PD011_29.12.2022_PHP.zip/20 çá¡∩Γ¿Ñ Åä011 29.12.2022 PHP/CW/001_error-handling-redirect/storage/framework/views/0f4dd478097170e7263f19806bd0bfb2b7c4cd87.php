<?php $__env->startSection('active_redirections', 'active'); ?>

<!-- секция контент -->
<?php $__env->startSection('main_part'); ?>
    <h4 class="text-center my-5">Страница redirect-demo/index</h4>
    <h5 class="text-center my-3">Демонстрация переадресаций</h5>
    <div class="btn-group">
        <a class="btn btn-secondary mx-3" href="/redirect-demo/redirect1">
            Переадресация на маршрут
        </a>
        <a class="btn btn-secondary mx-3" href="/redirect-demo/redirect2">
            Переадресация на метод действия
        </a>
        <a class="btn btn-secondary mx-3" href="/redirect-demo/handler/<?php echo e(random_int(1000, 9999)); ?>">
            Переход на маршрут (без редиректа)
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\20 Занятие ПД011 29.12.2022 PHP\CW\error-handling\resources\views/redirect-demo/index.blade.php ENDPATH**/ ?>