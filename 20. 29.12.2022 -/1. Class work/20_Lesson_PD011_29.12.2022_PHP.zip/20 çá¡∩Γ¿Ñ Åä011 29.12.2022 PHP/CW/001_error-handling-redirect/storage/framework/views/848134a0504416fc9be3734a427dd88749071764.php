<!-- секция контент -->
<?php $__env->startSection('main_part'); ?>
    <h4 class="text-center my-5">Страница home/index</h4>

    <ul class="list-group w-50 mx-auto my-5">
        <li class="list-group-item">
           Вычисляемые поля в запросах ORM  Eloquent
        </li>
        <li class="list-group-item">
            Связь 1:1 в моделях Eloquent
        </li>
        <li class="list-group-item">
            Жадная загрузка по умолчанию в моделях ORM Eloquent 
        </li>
        <li class="list-group-item">
            "Мягкое" удаление в ORM Eloquent
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\20 Занятие ПД011 29.12.2022 PHP\CW\error-handling\resources\views/home/index.blade.php ENDPATH**/ ?>