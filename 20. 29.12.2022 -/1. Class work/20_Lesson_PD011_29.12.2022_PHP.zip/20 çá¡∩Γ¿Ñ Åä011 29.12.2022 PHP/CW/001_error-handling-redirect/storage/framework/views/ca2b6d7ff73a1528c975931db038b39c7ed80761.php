<?php $__env->startSection('active_about', 'active'); ?>

<!-- секция контента: вывод фамилии, имени, группы студента, произвольной картинки -->
<?php $__env->startSection('main_part'); ?>
    <h4 class="text-center">Сведения о разработчике</h4>
    <ul class="list-group my-5 mx-auto w-25">
        <li class="list-group-item d-flex justify-content-between px-5"><span>Имя:</span> <b>Студент</b></li>
        <li class="list-group-item d-flex justify-content-between px-5"><span>Фамилия:</span> <b>Программер</b></li>
        <li class="list-group-item d-flex justify-content-between px-5"><span>Группа:</span> <b>ПД011</b></li>
    </ul>
    <div class="text-center">
        <h5>Рабочее место Тейлора Отвелла, главного разработчика Laravel</h5>
        <img class="w-50" src="<?php echo e(asset("/images/tailor_at_works.jpg")); ?>" >
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\20 Занятие ПД011 29.12.2022 PHP\CW\error-handling\resources\views/home/about.blade.php ENDPATH**/ ?>