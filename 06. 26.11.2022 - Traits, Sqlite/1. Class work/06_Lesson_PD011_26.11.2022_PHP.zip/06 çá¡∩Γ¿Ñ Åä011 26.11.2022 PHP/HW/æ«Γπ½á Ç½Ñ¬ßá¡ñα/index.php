<!DOCTYPE html>

<html lang="ru" class="h-100" xmlns:style="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Главная страница</title>

    <link rel="icon" href="img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css"/>
    <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Главная страница</h1>
</header>


<!--панель навигации-->
<nav class="navbar navbar-expand-sm bg-black navbar-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="img/php.png" alt="logo">
        </a>
        <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbar-hide">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar-hide">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="#">Главная страница</a>
                </li>

                <?php
                require_once 'Models/utils.php';

                if (isset($_POST['login']) && $_POST['login'] === 'true' || isset($_COOKIE[SESSION_NAME])) {
                    // создание сессии
                    session_name(SESSION_NAME);
                    session_start();

                    // данные от формы входа
                    if (isset($_POST['login']) && $_POST['login'] === 'true') {

                        // запись в журнал
                        sessionWriteLog(FOLDER_NAME_APP_DATA . '/' . FILE_NAME_SESSION_LOG, true);

                        // установка признака доступа к функционалу
                        $_SESSION['access'] = true;
                    } elseif (isset($_POST['login']) && $_POST['login'] === 'false') { // были получены данные от формы выхода
                        deleteSession();
                    }
                } // if

                // установлен доступ к функционалу
                if (isset($_SESSION['access'])) {
                // есть доступ
                // вывод разметки перехода на страницы выполнения задач
                // и формы с кнопкой завер
                if ($_SESSION['access']) {
                ?>
                <li class='nav-item'>
                    <a class='nav-link' href='Pages/page01.php'>Задача 1</a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='Pages/page02.php'>Задача 2</a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='Pages/page03.php'>Задача 3</a>
                </li>
            </ul>
            <li>
                <a class='btn btn-outline-primary me-2' href='Pages/logPage.php'>Журнал</a>
            </li>
            <div class='text-end'>
                <form method='post'>
                    <input type='hidden' name='login' value=false>
                    <input type='submit' class='btn btn-danger' value='Выход'/>
                </form>
            </div>
            <?php
            }
            } else {
                ?>
                </ul>

                <li>
                    <div class='text-end'>
                        <form method='post'>
                            <input type='hidden' name='login' value=true>
                            <input type='submit' class='btn btn-success' value='Вход'/>
                        </form>
                    </div>
                </li>
                </ul>
                <?php
            } ?>
        </div>
    </div>
</nav>


<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1"></div>

    <!--    основной блок контента-->
    <div class="col-sm-10">
        <h3 class="text-info h3 mt-3">Теоретическая часть</h3>

        <ul>
            <li>Наследование в PHP, абстрактные классы, методы</li>
            <li>Интерфейсы и наследование в PHP</li>
            <li>ООП в PHP: пространства имен <b>namespace</b>, <b>use</b></li>
            <li>ООП в PHP: автозагрузка классов, функции <b>__autoload(имяКласса)</b>, <b>spl_autoload_register(имяФункции)</b>,
                <b>spl_autoload()</b></li>
            <li>Сериализация скалярных переменных, массивов, объектов в строковое представление</li>
            <li>Десериализация скалярных переменных, массивов, объектов из строкового представления</li>
            <li>Магические методы <b>__sleep()</b>, <b>__wakeup()</b> для сериализациии, десериализации объектов</li>
        </ul>

        <h3 class="text-info h3">Практическая часть</h3>

        <p>Разработайте приложение PHP. На главной странице разместите это задание, на других страницах – решение задач.
            Доступ к функционалу приложения открывается только после создания сессии (клик по кнопке «Войти»). По клику
            на кнопку «Выйти№ удаляется сессия, запрещается доступ к функционалу.</p>

        <p>В файле формата CSV хранить данные о моменте начала и завершения сессии (начало сессии – момент нажатия
            кнопки «Вход», окончание сессии – момент нажатия кнопки «Выход»). Логин и пароль не использовать.
            Предусмотрите страницу для просмотра файла-журнала сессий. </p>

        <p>В сеттерах классов выбрасывать исключения при некорректны параметрах. Обработка исключений – на страницах с
            таблицей товаров, таблицей транспортных средств.</p>

        <p>Формы обрабатывать в тех же файлах, где они определены, при некорректных значениях выбрасывать
            исключения.</p>

        <p><b>Задача 1.</b>Создать класс <b>Goods</b> (товар). В классе должны быть представлены поля: наименование
            товара,
            дата оформления (прихода), цена единицы товара, количество единиц товара, номер накладной, по которой товар
            поступил на склад.</p>

        <p>Реализовать методы изменения цены единицы товара, изменения количества товара (увеличения и уменьшения),
            вычисления стоимости товара. Разработать форму добавления/редактирования товара. Использовать
            __toString().</p>

        <p>Реализовать массив товаров, добавление в массив, удаление из массива. Данные по товарам сохранять в файле в
            формате <b>CSV</b>. Также требуется выводить таблицу товаров, итоговую сумму хранимых товаров.</p>

        <p><b>Задача 2.</b> Разработайте иерархию: Интерфейс ТранспортноеСредство --> абстрактный класс
            ОбщественныйТранспорт --> класс Трамвай.</p>

        <p>Данные по трамваю вводить в форме, трамвай добавляем в массив, массив трамваев сохранять на сервере, в
            CSV-файле. Отображение массива трамваев – в таблице. Предусмотрите возможность добавления, удаления,
            изменения данных о конкретном трамвае.</p>

        <p>Некоторые рекомендуемые свойства трамвая: маршрут, пассажировместимость, фактическое количество пассажиров,
            текущая скорость. Некоторые рекомендуемые методы: начало движения, завершение движения, посадка пассажиров,
            высадка пассажиров.</p>

        <p>Очевидно, что посадка и высадка пассажиров не выполняются в процессе движения трамвая.</p>

        <p>Примените magic-методы __get(), __set(), __toString() в классе Трамвай. По отдельным командам
            продемонстрируйте сериализацию и десериализацию трамвая, массива трамваев.</p>

        <p><b>Задача 3.</b> Обработка файла объектов в формате CSV. Объект – класс Планета (Солнечной системы) с
            закрытыми
            свойствами название, радиус, масса, количество спутников, <i>тип планеты (каменная, газовый гигант, ледяной
                гигант)</i>, расстояние до Солнца в а.е., фотография. По кликам на кнопки типа «submit»реализуйте
            обработки:</p>

        <ul>
            <li>Вывод данных из файла на страницу с упорядочиванием по расстоянию</li>
            <li>Вывод данных из файла на страницу с упорядочиванием по алфавиту</li>
            <li>Вывод данных из файла на страницу с упорядочиванием по массе</li>
            <li>Выборка планет по массе</li>
            <li>Выборка планет по типу</li>
            <li>Удаление сведений о планете</li>
        </ul>

        <h3 class="text-info h3">Дополнительно</h3>

        <p>Материалы занятия – в этом же архиве. Запись занятия можно скачать <a
                    href="https://cloud.mail.ru/public/vhnY/K741ziKmS"><b>по этой
                    ссылке</b></a></p>
    </div>


    <!--    правый сайд бар-->
    <div class="col-sm-1"></div>

</div>

<!--футер-->
<?php
require_once 'Models/shared/footer.php' ?>

</body>
</html>