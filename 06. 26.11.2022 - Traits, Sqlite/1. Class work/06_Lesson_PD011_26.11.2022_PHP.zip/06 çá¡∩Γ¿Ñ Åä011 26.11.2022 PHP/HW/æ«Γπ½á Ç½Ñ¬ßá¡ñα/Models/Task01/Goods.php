<?php

//класс Goods (товар). В классе должны быть представлены поля: наименование товара,
// дата оформления (прихода), цена единицы товара, количество единиц товара,
// номер накладной, по которой товар поступил на склад.
//Реализовать методы изменения цены единицы товара, изменения количества товара (увеличения и уменьшения),
// вычисления стоимости товара.


class Goods
{
    private int $id;
    private string $title;     // наименование товара
    private DateTime $date;    // дата оформления
    private float $cost;       // цена ед. товара
    private int $count;        // кол-во единиц товара
    private string $docNumber; // номер накладной

    // конструктор
    public function __construct(int    $id = 0, string $title = "", DateTime $date = new DateTime('now'),
                                float  $cost = 0, int $count = 0,
                                string $docNumber = "")
    {
        $this->id = $id;
        $this->title = $title;
        $this->date = $date;
        $this->cost = $cost;
        $this->count = $count;
        $this->docNumber = $docNumber;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function setId($value): void{
        $this->id = $value;
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function getDate(): DateTime
    {
        return $this->date;
    }

    public function getCost(): float
    {
        return $this->cost;
    }

    public function getCount(): int
    {
        return $this->count;
    }

    public function getDocNumber(): string
    {
        return $this->docNumber;
    }

    // изменение цены товара
    public function setCost(float $newCost): void
    {
        if ($newCost < 0)
            throw new Exception("Стоимость товара не может быть отрицательной");
        $this->cost = $newCost;
    }

    // увеличение количества
    public function increaseCountOn(int $count): void
    {
        if ($count < 0)
            throw new Exception("Количество товара не может быть увеличено на отрицательное число");
        $this->count += $count;
    }

    // уменьшение количества
    public function decreaseCountOn(int $count): void
    {
        if ($count < 0)
            throw new Exception("Количество товара не может быть уменьшено на отрицательное число");
        $this->count -= $count;
    }

    // вычисление стоимости товара
    public function getFullCost(): float
    {
        return $this->cost * $this->count;
    }


    // переопределение toString()
    public function __toString()
    {
        return "<tr>
                    <td>$this->title</td>
                    <td>{$this->date->format("d/m/Y")}</td>
                    <td>$this->cost</td>
                    <td>$this->count</td>
                    <td>$this->docNumber</td>
                    <td>{$this->getFullCost()}</td>
                    <td>
                    <div class='row'>
                        <form method='post' action='../../Pages/goodsForm.php' class='col-sm-5'>
                            <input type='hidden' name='action' value='edit'>
                            <input type='hidden' name='id' value='{$this->id}'>
                            <button type='submit' class='btn btn-outline-primary'>Редактировать</button>
                        </form>
                        
                        <form method='post' class='col-sm-6 mx-auto' class='col-sm-5'>
                            <input type='hidden' name='action' value='delete'>
                            <input type='hidden' name='id' value='{$this->id}'>
                            <button type='submit' class='btn btn-outline-danger'>Удалить</button>
                        </form>
                    </div>
                    </td>
                </tr>";
    }


}