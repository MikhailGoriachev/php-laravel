<?php

namespace Models\Task01;

use DateTime;
use Exception;
use Goods;

class GoodsController
{
    private string $fileName;   // имя файла
    private array $goodsArray;  // массив товаров

    // конструктор
    public function __construct(
        string $fileName = "goods.csv"
    )
    {
        $this->fileName = '../app_data/' . $fileName;

        // файл не существует
        if (!file_exists($this->fileName)) {
            // инициализируем массив и записываем в файл
            $this->initialize();
            $this->writeToFile();
        }

        // чтение данных из файла
        $this->readFromFile();

    } // __construct

    // получить товар по id
    public function getById($id) : Goods|null {
        // фильтр записи по id и переиндексация массива
        $arr = array_values(array_filter($this->goodsArray, fn($goods) => $goods->getId() == $id));

        if(count($arr) !== 1)
            return null;

        return $arr[0];
    }

    // таблица товаров
    public function showGoodsTable(): void
    {
        echo "<table class='table table-hover'>
                    <thead>
                        <tr>
                            <th>Наименование</th>
                            <th>Дата оформления</th>
                            <th>Стоимость/ед</th>
                            <th>Количество</th>
                            <th>Номер накладной</th>
                            <th>Сумма</th>
                        </tr>
                    </thead>
                    <tbody>";

        foreach ($this->goodsArray as $goods)
            echo $goods;

        echo "  </tbody>
                </table>";

        echo "
        <div class='row'>
            <p class='text-end'><b> Итого: ";

        $sum = array_sum(array_map(fn($goods) => $goods->getFullCost(), $this->goodsArray));

        echo $sum;

        echo " руб.</b></p>
        </div> 
        ";
    }

    // добавить товар
    public function addGoods($goods): void {
        $max = max(array_column($this->goodsArray, null,0))->getId();
        $goods->setId(++$max);
        $this->goodsArray[] = $goods;
        $this->writeToFile();
    }

    // редактировать товар
    public function editGoods($goods): void {
        for ($i = 0; $i < count($this->goodsArray); $i++){
            if($this->goodsArray[$i]->getId() === $goods->getId())
                $this->goodsArray[$i] = $goods;
        }

        $this->writeToFile();
    }

    // удалить товар
    public function removeGoods($id): void{
        $this->goodsArray = array_filter($this->goodsArray, fn($goods) => $goods->getId() != $id);
        $this->writeToFile();
    }

    // запись данных из файла
    private function writeToFile(): void
    {
        // открыть файл для записи
        $f = @fopen($this->fileName, 'w');

        // запись данных в файл
        foreach ($this->goodsArray as $goods) {
            $arr = [$goods->getId(), $goods->getTitle(), $goods->getDate()->format('d/m/Y'), $goods->getCost(), $goods->getCount(), $goods->getDocNumber()];
            fputcsv($f, $arr, eol: "\r\n");
        }

        // закрыть файл
        fclose($f);
    } // writeToFile

    // чтение данных из файла
    private function readFromFile(): void
    {
        // открыть файл для чтения
        $f = @fopen($this->fileName, 'r');

        // массив для хранения
        $this->goodsArray = [];

        // чтение записи из файла
        // и добавление в массив
        while (true) {
            $arrData = fgetcsv($f);
            if (feof($f)) break;
            $this->goodsArray[] = new Goods($arrData[0], $arrData[1],
                DateTime::createFromFormat("d/m/Y", $arrData[2]), $arrData[3], $arrData[4], $arrData[5]);
        } // readFromFile

        // закрытие файла
        fclose($f);
    }

    // инициализация массива товаров
    private function initialize(): void
    {
        // диапазон значений для генерации
        $min = 1;
        $max = 5;

        // коэффициенты
        $priceRatio = 1000;
        $countRatio = 3;

        // массив товаров
        $this->goodsArray = [
            new Goods(1,"Магнитофон", new DateTime("2022-11-20"), rand($min, $max) * $priceRatio, rand($min, $max) * $countRatio, "241122-01"),
            new Goods(2,"Куртка замшевая", new DateTime("2022-11-21"), rand($min, $max) * $priceRatio, rand($min, $max) * $countRatio, "N523"),
            new Goods(3,"Портсигар отечественный", new DateTime("2022-11-22"), rand($min, $max) * $priceRatio, rand($min, $max) * $countRatio, "2211/42"),
            new Goods(4,"Кинокамера заграничная", new DateTime("2022-11-22"), rand($min, $max) * $priceRatio, rand($min, $max) * $countRatio, "2211/42"),
            new Goods(5,"Часы наручные", new DateTime("2022-11-21"), rand($min, $max) * $priceRatio, rand($min, $max) * $countRatio, "N523"),
            new Goods(6,"Видеомагнитофон", new DateTime("2022-11-20"), rand($min, $max) * $priceRatio, rand($min, $max) * $countRatio, "241122-01"),
            new Goods(7,"Телевизор", new DateTime("2022-11-20"), rand($min, $max) * $priceRatio, rand($min, $max) * $countRatio, "241122-01"),
            new Goods(8,"Утюг", new DateTime("2022-11-24"), rand($min, $max) * $priceRatio, rand($min, $max) * 3, "241122-04"),
            new Goods(9,"Соковыжималка", new DateTime("2022-11-23"), rand($min, $max) * $priceRatio, rand($min, $max) * $countRatio, "1122_31"),
            new Goods(10,"Кофеварка", new DateTime("2022-11-22"), rand($min, $max) * $priceRatio, rand($min, $max) * $countRatio, "2211/42"),
        ];
    }
}