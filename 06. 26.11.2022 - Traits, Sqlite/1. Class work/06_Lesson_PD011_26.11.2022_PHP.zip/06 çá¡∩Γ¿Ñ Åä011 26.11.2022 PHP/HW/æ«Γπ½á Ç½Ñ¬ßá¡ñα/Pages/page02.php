<!DOCTYPE html>

<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Задача 2</title>

    <link rel="icon" href="../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>

    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Задача 2</h1>
</header>

<?php
// активность страниц
$activeTask02 = "active";
$activeTask01 = $activeTask03 = "";

require_once '../Models/utils.php';
require_once '../Models/shared/header.php';
session_name(SESSION_NAME);
session_start();

?>

<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1">

    </div>

    <!--    основной блок контента-->
    <div class="col-sm-10">
        <?php

        if (isset($_POST['login']) && $_POST['login'] !== 'true') {
            sessionWriteLog('../' . FOLDER_NAME_APP_DATA . '/' . FILE_NAME_SESSION_LOG, false);
            deleteSession();
            echo errorAccessTask();
        } else {
            ?>
            <div class="w-100 mt-4">
                <a href='#task1' class='btn btn-outline-dark w-100 mb-4' data-bs-toggle='collapse'>
                    <strong>Задание</strong>
                </a>
                <div id='task1' class='collapse'>
                    <p class='mt-3'><b>Задача 2.</b> Разработайте иерархию: Интерфейс ТранспортноеСредство --> абстрактный класс
                        ОбщественныйТранспорт --> класс Трамвай.</p>

                    <p>Данные по трамваю вводить в форме, трамвай добавляем в массив, массив трамваев сохранять на сервере, в
                        CSV-файле. Отображение массива трамваев – в таблице. Предусмотрите возможность добавления, удаления,
                        изменения данных о конкретном трамвае.</p>

                    <p>Некоторые рекомендуемые свойства трамвая: маршрут, пассажировместимость, фактическое количество пассажиров,
                        текущая скорость. Некоторые рекомендуемые методы: начало движения, завершение движения, посадка пассажиров,
                        высадка пассажиров.</p>

                    <p>Очевидно, что посадка и высадка пассажиров не выполняются в процессе движения трамвая.</p>

                    <p>Примените magic-методы __get(), __set(), __toString() в классе Трамвай. По отдельным командам
                        продемонстрируйте сериализацию и десериализацию трамвая, массива трамваев.</p>

                </div>
            </div>

            <h3 class="h3 mt-5 text-center">Задание в разработке...</h3>
            <?php
        }
        ?>
        <!--    правый сайд бар-->
        <div class="col-sm-1"></div>
    </div>
</div>
<!--футер-->
<?php
require_once '../Models/shared/footer.php' ?>

</body>
</html>