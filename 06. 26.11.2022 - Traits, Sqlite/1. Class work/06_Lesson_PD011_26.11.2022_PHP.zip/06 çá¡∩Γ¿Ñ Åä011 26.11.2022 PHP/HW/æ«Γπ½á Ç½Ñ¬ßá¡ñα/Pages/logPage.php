<!DOCTYPE html>

<html lang="ru" class="h-100" xmlns:style="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Журнал</title>

    <link rel="icon" href="../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Журнал</h1>
</header>

<?php
// активность страниц

require_once '../Models/utils.php';
require_once '../Models/shared/header.php';
session_name(SESSION_NAME);
session_start();
?>


<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1"></div>

    <!--    основной блок контента-->
    <div class="col-sm-10">
        <?php
        if (isset($_POST['login']) && $_POST['login'] === 'false') {
            sessionWriteLog('../' . FOLDER_NAME_APP_DATA . '/' . FILE_NAME_SESSION_LOG, false);
            deleteSession();
            echo errorAccessTask();
        } else {
            ?>
            <h3 class="h3 text-center my-5">Журнал сессий</h3>

            <div class="row my-4">
                <a class='btn btn-outline-danger col-sm-3 mx-auto' href='../index.php'>Вернуться на главную</a>
            </div>

            <table class="table table-hover w-50 mx-auto">
                <thead>
                <tr>
                    <th>Действие</th>
                    <th>Дата</th>
                    <th>Время</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $f = @fopen('../' . FOLDER_NAME_APP_DATA . '/' . FILE_NAME_SESSION_LOG, "r");

                while (true) {
                    $str = @fgetcsv($f);
                    if (@feof($f)) break;
                    echo "<tr>
                        <td>$str[0]</td>
                        <td>$str[1]</td>
                        <td>$str[2]</td>
                      </tr>";
                }
                @fclose($f);
                ?>
                </tbody>
            </table>
        <?php
        } ?>
    </div>


    <!--    правый сайд бар-->
    <div class="col-sm-1"></div>

</div>

<!--футер-->
<?php
require_once '../Models/shared/footer.php' ?>

</body>
</html>