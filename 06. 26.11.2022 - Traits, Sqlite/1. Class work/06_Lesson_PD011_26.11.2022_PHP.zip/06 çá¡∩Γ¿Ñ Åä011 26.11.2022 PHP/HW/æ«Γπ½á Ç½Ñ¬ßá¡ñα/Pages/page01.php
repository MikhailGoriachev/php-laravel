<!DOCTYPE html>

<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Задача 1</title>

    <link rel="icon" href="../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>

    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Задача 1</h1>
</header>

<?php


use Models\Task01\GoodsController;

spl_autoload_register();

// активность страниц
$activeTask01 = "active";
$activeTask02 = $activeTask03 = "";

require_once '../Models/utils.php';
require_once '../Models/shared/header.php';
require_once "../Models/Task01/GoodsController.php";

session_name(SESSION_NAME);
session_start();

?>

<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1">

    </div>

    <!--    основной блок контента-->
    <div class="col-sm-10">
        <?php
        try {

            if (isset($_POST['login']) && $_POST['login'] !== 'true') {
                sessionWriteLog('../' . FOLDER_NAME_APP_DATA . '/' . FILE_NAME_SESSION_LOG, false);
                deleteSession();
                echo errorAccessTask();
            } else {
                ?>
                <div class="w-100 mt-4">
                    <a href='#task1' class='btn btn-outline-dark w-100 mb-4' data-bs-toggle='collapse'>
                        <strong>Задание</strong>
                    </a>
                    <div id='task1' class='collapse'>
                        <p class='mt-3'><b>Задача 1.</b> Создать класс <b>Goods</b> (товар). В классе должны быть
                            представлены
                            поля:
                            наименование товара, дата оформления (прихода), цена единицы товара, количество единиц
                            товара,
                            номер
                            накладной, по которой товар поступил на склад.
                        </p>

                        <p>Реализовать методы изменения цены единицы товара, изменения количества товара (увеличения и
                            уменьшения),
                            вычисления стоимости товара. Разработать форму добавления/редактирования товара.
                            Использовать
                            __toString().</p>

                        <p>Реализовать массив товаров, добавление в массив, удаление из массива. Данные по товарам
                            охранять
                            в файле
                            в формате CSV. Также требуется выводить таблицу товаров, итоговую сумму хранимых
                            товаров.</p>

                    </div>
                </div>
                <?php

                // объект контроллера
                $controller = new GoodsController();

                if (isset($_POST['action']) && $_POST['action'] === 'delete')
                    $controller->removeGoods($_POST['id']);

                ?>
                <div class="row d-flex justify-content-end me-2">
                    <a href="goodsForm.php" class="btn btn-outline-success col-sm-3">Добавить</a>
                </div>

                <?php
                // вывод таблицы
                $controller->showGoodsTable();
            }
        } catch (Exception $ex) {
            echo "<p class='text-danger'>{$ex->getMessage()}</p>";
        }

        ?>

        <!--    правый сайд бар-->
        <div class="col-sm-1"></div>
    </div>
</div>
<!--футер-->
<?php

require_once '../Models/shared/footer.php' ?>

</body>
</html>