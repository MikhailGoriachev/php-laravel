<!DOCTYPE html>

<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Задача 1</title>

    <link rel="icon" href="../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>

    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Задача 1</h1>
</header>

<?php


use Models\Task01\GoodsController;

spl_autoload_register();

// активность страниц
$activeTask01 = "active";
$activeTask02 = $activeTask03 = "";

require_once '../Models/utils.php';
require_once '../Models/shared/header.php';
require_once "../Models/Task01/GoodsController.php";

session_name(SESSION_NAME);
session_start();


?>

<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1"></div>

    <!--    основной блок контента-->
    <div class="col-sm-10">
        <?php
        if (isset($_POST['login']) && $_POST['login'] !== 'true') {
            sessionWriteLog('../' . FOLDER_NAME_APP_DATA . '/' . FILE_NAME_SESSION_LOG, false);
            deleteSession();
            echo errorAccessTask();
        } else {

            // контроллер
            $controller = new GoodsController();

            if (isset($_POST['id']) && !isset($_POST['action'])) {
                $goods = new Goods($_POST['id'], $_POST['title'], new DateTime($_POST['date']), $_POST['cost'], $_POST['count'], $_POST['docNumber']);
                if ($_POST['id'] == 0)
                    $controller->addGoods($goods);
                else
                    $controller->editGoods($goods);
            }
            // форма для добавления или редактирования
            $isAdd = !isset($_POST['action']);

            // для редактирования
            if (!$isAdd)
                // получить объект для редактирования
                $goods = $controller->getById($_POST['id']);

            ?>
            <h3 class="h3 text-center mt-5"><?= $isAdd ? "Добавить" : "Редактировать" ?> товар</h3>

            <form class="col-sm-6 m-5 mx-auto" method="post">
                <input type="hidden" name="id" value="<?= $isAdd ? '0' : $goods->getId() ?>">

                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="title" name="title"
                           value="<?= $isAdd ? '' : $goods->getTitle() ?>" required placeholder="Наименование товара">
                    <label for="title">Наименование товара</label>
                </div>

                <div class="form-floating mb-3">
                    <input type="date" class="form-control" id="date" name="date"
                           value="<?= $isAdd ? null : $goods->getDate()->format("Y-m-d") ?>" required
                           placeholder="Дата прихода">
                    <label for="date">Дата прихода</label>
                </div>

                <div class="form-floating mb-3">
                    <input type="number" step="0.01" class="form-control" id="cost" name="cost"
                           value="<?= $isAdd ? null : $goods->getCost() ?>" required placeholder="Стоимость товара">
                    <label for="cost">Стоимость товара</label>
                </div>

                <div class="form-floating mb-3">
                    <input type="number" step="1" class="form-control" id="count" name="count"
                           value="<?= $isAdd ? null : $goods->getCount() ?>" required placeholder="Количество товара">
                    <label for="count">Количество товара</label>
                </div>

                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="docNumber" name="docNumber"
                           value="<?= $isAdd ? '' : $goods->getDocNumber() ?>" required placeholder="Номер прихода">
                    <label for="docNumber">Номер прихода</label>
                </div>

                <div class="row">
                    <input class="btn btn-outline-success col-sm-5 mx-auto" type="submit"
                           value="<?= $isAdd ? 'Добавить' : "Редактировать" ?>">
                    <a class='btn btn-outline-danger col-sm-5 mx-auto' href='page01.php'>Отмена</a>
                </div>
            </form>
            <?php
        }
        ?>

    </div>
    <!--    правый сайд бар-->
    <div class="col-sm-1"></div>

</div>
<!--футер-->
<?php

require_once '../Models/shared/footer.php' ?>

</body>
</html>