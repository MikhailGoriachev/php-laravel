<?php

// имя каталога
const FOLDERNAME  = "../app_data";

// проверка существования папки file_exists("folder")
if (!file_exists(FOLDERNAME))
    mkdir(FOLDERNAME);  // создание каталога

// установить правильный часовой пояс
date_default_timezone_set('Europe/Moscow');

function isLogged($sessionName) {
    if (isset($_COOKIE[$sessionName])) {
        // присоединяемся к существующей сессии
        session_name($sessionName);
        session_start();

        // есть сессия
        return true;
    }
    else
        // нет сессии
        return false;
}

// вывод предупреждения
function alert($title, $text){
    echo "
    <div class='alert alert-warning'>
        <strong>$title</strong><br>$text
    </div>";
} // alert


// вывод сообщения
function info($title, $text){
    echo "
    <div class='alert alert-success'>
        <strong>$title</strong><br>$text
    </div>";
} // alert

// Запись в файл журнал приложения
function writeToLog($sessionId, $sessionName, $message) {

    $date = date("d-m-y");
    $time = date("H:i:s");

    $path = "../app_data/app.log";
    $fh = fopen($path, 'a');
    if ($fh === false) {
        throw new Exception("Не могу открыть файл журнала $path для добавления записи");
    } // if

    fputcsv($fh, [$date, $time, $sessionName, $sessionId, $message], ';');
    fclose($fh);
}
