<?php

//подключили функции
require_once("../tasks/utils.php");

class Planet{

    private string $title;    //название
    private int $r;           //радиус
    private $w;               //масса
    private int $count;       //количество спутников
    private string $type;     //тип планеты
    private float $distance;  //расстояние до Солнца
    private string $image;    //фотография

    // конструктор класса
    function __construct($title,$r,$w,$count,$type,$distance,$image)
    {
        $this->title = $title;
        $this->r = $r;
        $this->w = $w;
        $this->count = $count;
        $this->type = $type;
        $this->distance = $distance;
        $this->image = $image;
    }

    //геттеры и сеттеры с выбросом исключений
    function getTitle(): string {return $this->title;}
    function setTitle($value): void
    {
        if(mb_strlen($value) == 0) throw new InvalidArgumentException("Title: Строка пуста");

        $this->title = $value;
    }

    function getR(): int {return $this->r;}
    function setR($value): void
    {
        if($value <= 0) throw new InvalidArgumentException("R <= 0");

        $this->r = $value;
    }

    function getW() {return $this->w;}
    function setW($value): void
    {
        if($value <= 0) throw new InvalidArgumentException("W <= 0");

        $this->w = $value;
    }

    function getCount(): int {return $this->count;}
    function setCount($value): void
    {
        if($value <= 0) throw new InvalidArgumentException("count <= 0");

        $this->count = $value;
    }

    function getType(): string {return $this->type;}
    function setType($value): void
    {
        if(mb_strlen($value) == 0) throw new InvalidArgumentException("Type: Строка пуста");

        $this->type = $value;
    }

    function getDistance(): float {return $this->distance;}
    function setDistance($value): void
    {
        if($value <= 0) throw new InvalidArgumentException("distance <= 0");

        $this->distance = $value;
    }

    function getImage(): string {return $this->image;}
    function setImage($value): void
    {
        if(mb_strlen($value) == 0) throw new InvalidArgumentException("Image: Строка пуста");

        $this->image = $value;
    }

    //генератор планет
    static function getPlanet(){

        $planets = array(
            new Planet("Меркурий",2439,3.3022e23, 0,"каменная",0.39, "mercury.png"),
            new Planet("Земля",6378, 5.9722e24, 1,"каменная",1,"earth.png"),
            new Planet("Юпитер",71492,1.9e27,63,"газовый гигант",5.2,"jupiter.png"),
            new Planet("Сатурн",60300, 5.68e26,56,"газовый гигант",9.5,"saturn.png"),
            new Planet("Марс",3397,6.42e23,2,"каменная",1.5,"mars.png"),
            new Planet("Венера",12103,4.87e24,0,"каменная",0.4,"venus.png"),
            new Planet("Нептун", 24764, 1.02e26,13,"ледяной гигант",30,"neptune.png"),
            new Planet("Уран",25360,8.68e25,27,"ледяной гигант",19.6,"uranium.png")
        );

        return $planets[random_int(0, 7)];
    }

    // получить массив значений
    public function getArrayValues(): array
    {
        return [
            $this->title,
            $this->r,
            $this->w,
            $this->count,
            $this->type,
            $this->distance,
            $this->image,
        ];
    }

    public function toTableRow($id): void
    {
      echo "<tr>
            <td>$this->title</td>
            <td>$this->r</td>
            <td>$this->w</td>
            <td>$this->count</td>
            <td>$this->type</td>
            <td>$this->distance</td>
            <td><img style='width: 100px' src='../images/$this->image'></td>
            <td><form method='post'><button class='btn btn-danger' type='submit' name='id' value='$id'>Удалить</button></form></td>
            
        </tr>";
    }
}

//класс для работы с коллекцией
class BodiesPlanet{

    const PATH  = FOLDERNAME . '/' .'bodiesPlanet.csv';

    private array $planets = array();

    function __constructor(): void {}

    public function init():void{

        if(!$this->load()){

            //заполняем массив
            for ($i = 0; $i < 12; $i++) {
                $this->planets[$i] = Planet::getPlanet();
            }

            $this->save();
        }

    }

    // запись данных в файл в формте CSV
    function save(): void{

        $file = fopen(self::PATH, 'w');

        array_walk($this->planets, fn($a) => fputcsv($file, $a->getArrayValues()));
        fclose($file);
    }

    // установить значения из массива
    function setDataFromArray(array $arr): void
    {
        $this->planets =  array_map(fn($item) => new Planet(...$item), $arr);
    }

    // загрузить данные из файла в формте CSV
    function load(): bool{

        //проверка был ли записан файл
        if (!file_exists(self::PATH))
            return false;

        $file = fopen(self::PATH, 'r');

        $result = [];

        while (!feof($file)) {
            $buf = fgetcsv($file);

            if (is_array($buf))
                $result[] = $buf;
        }

        fclose($file);

        $this->setDataFromArray($result);

        return true;
    }

    //упорядочиванием по расстоянию
    function sortDistance() :void {
        usort($this->planets,fn($a,$b) => $a->getDistance() <=> $b->getDistance());
    }

    //упорядочиванием по алфавиту
    function sortTitle() :void {
        usort($this->planets,fn($a,$b) => strcmp($a->getTitle(),$b->getTitle()));
    }

    //упорядочиванием по массе
    function sortMass() :void {
        usort($this->planets,fn($a,$b) => $a->getW() <=> $b->getW());
    }

    public function show(): void
    {
        $index = 0;

        foreach ($this->planets as $planet){
            $planet->toTableRow($index);
            $index++;
        }

        //array_walk_recursive($this->planets,fn($p)=>$p->toTableRow());
    }

    public function delete($index) : void{
        unset($this->planets[$index]);
        $this->planets = array_values($this->planets);
    }
}

$bodies = new BodiesPlanet();
$bodies->init();

isset($_POST['order-by-destination']) ? $bodies->sortDistance(): "";
isset($_POST['order-by-title']) ? $bodies->sortTitle(): "";
isset($_POST['order-by-mass']) ? $bodies->sortMass(): "";

//Удалить элемент
if (isset($_POST['id'])) {

    $bodies->delete($_POST['id']);
    $bodies->save();
}

echo $bodies->show();
