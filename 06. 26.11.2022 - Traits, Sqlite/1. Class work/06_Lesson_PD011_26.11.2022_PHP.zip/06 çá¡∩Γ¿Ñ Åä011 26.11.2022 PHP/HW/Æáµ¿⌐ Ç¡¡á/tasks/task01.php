<?php

//подключили функции
require_once("../tasks/utils.php");
require_once("../models/goods.php");
require_once("../models/bodiesGoods.php");
require_once("../tasks/taskGoodAdd.php");

class Task01
{

    private BodiesGoods $bodies;

    public function __construct()
    {
        $this->bodies = new BodiesGoods();
    }

    function task01(): void
    {

        //Удалить элемент
        if (isset($_POST['id'])) {

            $this->bodies->delete($_POST['id']);
            $this->bodies->save();
        }

        $this->bodies->show();
    }

    function add(): void
    {

        if (isset($_POST['add'])) {

            $good = new Goods("", date("d.m.y"), 0, 0, "");

            try {

                $date = $_POST['date'];

                $good->setTitle($_POST['title']);
                $good->setDate($date);
                $good->setPrice(+$_POST['price']);
                $good->setCount(+$_POST['count']);
                $good->setInvoiceNumber($_POST['invoiceNumber']);

                $this->bodies->add($good);
                $this->bodies->save();

            } catch (InvalidArgumentException $ex) {

                $msg = $ex->getMessage();
                echo "<span style='color:red;'>$msg</span><br>";
            }
        }
    }

}

$task01 = new Task01();

