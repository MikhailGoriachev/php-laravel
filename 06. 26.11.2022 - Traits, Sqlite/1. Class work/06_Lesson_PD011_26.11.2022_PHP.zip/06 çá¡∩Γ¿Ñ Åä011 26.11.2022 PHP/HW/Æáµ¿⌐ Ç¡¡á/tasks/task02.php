<?php

//класс Трамвай.
class Tram extends PublicTransport {

    function __construct($route, $amount, $factAmount, $speed)
    {
        parent::__construct($route, $amount, $factAmount, $speed);
    }

    // получить массив значений
    public function getArrayValues(): array
    {
        return [
            $this->route,
            $this->amount,
            $this->factAmount,
            $this->speed
        ];
    }

    function toTableRow($id) :void
    {
        echo "<tr>
            <td>$this->route</td>
            <td>$this->amount</td>
            <td>$this->factAmount</td>
            <td>$this->speed</td>
            <td><form method='post'><button class='btn btn-danger' type='submit' name='id' value='$id'>Удалить</button></form></td>
        </tr>";
    }
}

//абстрактный класс ОбщественныйТранспорт
abstract class PublicTransport{

    protected string $route; //маршрут
    protected int $amount; //пассажировместимость
    protected int $factAmount; //фактическое количество пассажиров
    protected float $speed; //текущая скорость.

    function __construct($route,$amount,$factAmount,$speed){

        $this->route = $route;
        $this->amount = $amount;
        $this->factAmount = $factAmount;
        $this->speed = $speed;
    }

    // абстрактный метод
    abstract public function toTableRow($id):void;

}

//Интерфейс ТранспортноеСредство
interface TransportVehicle{
    //начало движения
    function start();

    //завершение движения
    function end();

    //посадка пассажиров
    function boarding();

    //высадка пассажиров
    function disembarkation();
}

class BodiesTrams{

    const PATH  = FOLDERNAME . '/' .'bodiesTrams.csv';

    //коллекция
    private array $tramsArr = array();

    function __constructor(): void {}

    function init():void{

        if(!$this->load()){

            $tramsArr = [
                new Tram("Волноваха - Горловка",30,23,60),
                new Tram("Горловка - Донецк",25,15,60),
                new Tram("Горловка - Дебальцево",20,3,75),
                new Tram("Зугрэс - Донецк",25,16,70),
                new Tram("Иловайск - Донецк",25,19,60),
                new Tram("Зугрэс - Горловка",30,21,60),
                new Tram("Макеевка - Донецк",20,20,70),
                new Tram("Новоазовск - Донецк",25,23,70),
                new Tram("Донецк - Горловка",30,14,60),
                new Tram("Снежное - Донецк",30,11,65),
                new Tram("Зугрэс - Снежное",25,19,65),
                new Tram("Харцызск - Донецк",25,24,65),
            ];

            $this->save();
        }

    }

    // вывод в таблицу
    function show():void{

        $index = 0;

        foreach ($this->tramsArr as $tram){
            $tram->toTableRow($index);
            $index++;
        }

        //array_walk_recursive($this->tramsArr,fn($p)=>$p->toTableRow());

    }

    // запись данных в файл в формте CSV
    function save(): void{

        $file = fopen(self::PATH, 'w');

        array_walk($this->tramsArr, fn($a) => fputcsv($file, $a->getArrayValues()));
        fclose($file);
    }

    // установить значения из массива
    function setDataFromArray(array $arr): void
    {
        $this->tramsArr =  array_map(fn($item) => new Tram(...$item), $arr);
    }

    // загрузить данные из файла в формте CSV
    function load(): bool{

        //проверка был ли записан файл
        if (!file_exists(self::PATH))
            return false;

        $file = fopen(self::PATH, 'r');

        $result = [];

        while (!feof($file)) {
            $buf = fgetcsv($file);

            if (is_array($buf))
                $result[] = $buf;
        }

        fclose($file);

        $this->setDataFromArray($result);

        return true;
    }

    public function delete($index) : void{
        unset($this->tramsArr[$index]);
        $this->tramsArr = array_values($this->tramsArr);
    }
}

$bodies = new BodiesTrams();

$bodies->init();

//Удалить элемент
if (isset($_POST['id'])) {

    $bodies->delete($_POST['id']);
    $bodies->save();
}

$bodies->show();