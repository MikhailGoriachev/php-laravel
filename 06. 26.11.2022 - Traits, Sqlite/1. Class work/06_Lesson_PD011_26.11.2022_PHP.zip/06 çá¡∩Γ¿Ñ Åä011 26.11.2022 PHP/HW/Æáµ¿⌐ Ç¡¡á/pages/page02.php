
<?php
require_once "../tasks/utils.php";

// проверим наличие сессии с назначенным именем
$sessionName = "Step261122";
if (isset($_COOKIE[$sessionName])):
    session_name($sessionName);
    session_start();
    $sessionId = session_id();

    // есть сессия
    $loggedIn = true;
else:
    // нет сессии
    $loggedIn = false;
endif;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_26.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../lib/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<?php
// активность страниц
$activePage02 = "active";
$activeIndex = $activePage01 = $activePage03 = "";

// загрузка панели навигации
include_once "../pages/shared/_header.php";
?>

<main class="container-fluid" >

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-3 bg-white m-3 border-warning-top border-warning-bottom">

            <div class="<?= !$loggedIn?"":"visually-hidden" ?>">
                <?php alert("Предупреждение", "Вход не выполнен"); ?>
            </div>

            <div class="<?= $loggedIn?"":"visually-hidden" ?>">
                <div class="me-1 justify-content-end d-flex">

                    <div class="row">

                        <div class="col-3 mt-3">

                            <div class="btn-group me-5">

                                <a class="btn btn-primary" style="width: 200px;" >Добавить трамвай</a>

                            </div>
                        </div>
                    </div>

                </div>

                <p class="mb-2 ms-4 fs-4 mt-3">Решение задания 2</p>

                <div class="d-flex justify-content-center">

                    <form method="post">
                        <table class="table mt-5">
                            <thead>
                            <tr>
                                <th>Mаршрут</th>
                                <th>Пассажировместимость</th>
                                <th>Количество пассажиров</th>
                                <th>Скорость</th>
                                <th></th>
                            </tr>
                            </thead>

                            <tbody class="align-middle">

                            <?php
                            //подключили функции
                            require_once("../tasks/task02.php");

                            ?>

                            </tbody></table></form>

                </div>

            </div>

        </div>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../pages/shared/_footer.php" ?>

</body>
</html>
