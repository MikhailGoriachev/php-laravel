
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_26.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../lib/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<?php

$activeIndex = $activePage03 =  $activePage02 = $activePage01 = "";

// загрузка панели навигации
include_once "../pages/shared/_header.php";
?>

<main class="container-fluid" >

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-3 bg-white m-3 border-warning-top border-warning-bottom">

            <p class="mb-2 ms-4 fs-4 mt-3">Добавить товар:</p>

            <form class="w-50 m-4" method="post">

                <div class="mt-3">
                    <label class="form-label" for="title">Наименование товара</label>
                    <input class="form-control" type="text" name="title" required/>
                </div>

                <div class="mt-3">
                    <label class="form-label" for="date">Дата оформления</label>
                    <input class="form-control" type="date" name="date" required/>
                </div>

                <div class="mt-3">
                    <label class="form-label" for="price">Цена единицы товара</label>
                    <input class="form-control" type="number" name="price" required min="1"/>
                </div>

                <div class="mt-3">
                    <label class="form-label" for="count">Количество единиц товара</label>
                    <input class="form-control" type="number" name="count" required min="1"/>
                </div>

                <div class="mt-3">
                    <label class="form-label" for="invoiceNumber">Номер накладной</label>
                    <input class="form-control" type="text" name="invoiceNumber" required/>
                </div>

                <div class="mt-3 d-flex justify-content-end">
                    <input class="btn btn-primary" type='submit' name="add" value='Добавить' />
                </div>

            </form>

            <?php
            //подключили функции
            require_once("../tasks/task01.php");

            $task01->add();
            ?>

        </div>

    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../pages/shared/_footer.php" ?>

</body>
</html>

