<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
    <div class="container-fluid">
        <div style="width: 70%; margin: auto;">
            <div class="navbar-collapse" id="appNavbar-1">
                <ul class="navbar-nav fs-4">
                    <li class="nav-item pt-1">
                        <a class="nav-link <?= $activeIndex ?>" href="/index.php">Страница с заданием</a>
                    </li>
                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link <?= $activePage01 ?>" href="/pages/page01.php">Задача 1</a>
                    </li>
                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link <?= $activePage02 ?>" href="/pages/page02.php">Задача 2</a>
                    </li>
                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link <?= $activePage03 ?>" href="/pages/page03.php">Задача 3</a>
                    </li>

                    <li class="nav-item ms-5 me-3">
                        <a class="btn btn-sm btn-success" href="/pages/login.php">Вход</a>
                    </li>

                    <li class="nav-item">
                        <a class="btn btn-sm btn-warning" href="/pages/logout.php">Выход</a>
                    </li>

                </ul>
            </div>
        </div>
    </div>
</nav>