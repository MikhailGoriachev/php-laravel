
<?php
require_once "../tasks/utils.php";

// проверим наличие сессии с назначенным именем
$sessionName = "Step261122";
if (isset($_COOKIE[$sessionName])):
    session_name($sessionName);
    session_start();
    $sessionId = session_id();

    // есть сессия
    $loggedIn = true;
else:
    // нет сессии
    $loggedIn = false;
endif;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_26.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../lib/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<?php
// активность страниц
$activePage03 = "active";
$activeIndex = $activePage02 = $activePage01 = "";

// загрузка панели навигации
include_once "../pages/shared/_header.php";
?>


<main class="container-fluid" >

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-3 bg-white m-3 border-warning-top border-warning-bottom">

            <div class="<?= !$loggedIn?"":"visually-hidden" ?>">
                <?php alert("Предупреждение", "Вход не выполнен"); ?>
            </div>

            <div class="<?= $loggedIn?"":"visually-hidden" ?>">
            <div class="me-1 justify-content-end d-flex">

                <div class="row">

                    <div class="col-3 mt-3">

                        <div class="btn-group me-5">

                            <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">
                                Сортировки по заданию
                            </button>
                            <ul class="dropdown-menu">

                                <li>
                                    <form method="post" action="#">

                                        <input type='hidden' name='order-by-destination'/>

                                        <input class="dropdown-item" type="submit" value="По расстоянию"/>

                                    </form>
                                </li>


                                <li>
                                    <form method="post" action="#">

                                        <input type='hidden' name='order-by-title'/>

                                        <input class="dropdown-item" type="submit"  value="По алфавиту"/>

                                    </form>
                                </li>

                                <li>
                                    <form method="post" action="#">

                                    <input type='hidden' name='order-by-mass'/>

                                    <input class="dropdown-item" type="submit" value="По массе"/>

                                    </form>
                                </li>

                            </ul>

                        </div>
                    </div>
                </div>

            </div>

            <p class="mb-2 ms-4 fs-4 mt-3">Решение задания 3</p>

            <form method="post">
                <table class="table mt-5">
                    <thead>
                    <tr>
                        <th>Название</th>
                        <th>Радиус</th>
                        <th>Масса</th>
                        <th>Количество спутников</th>
                        <th>Тип</th>
                        <th>Расстояние</th>
                        <th></th>
                        <th></th>
                    </tr>
                    </thead>

                    <tbody class="align-middle">

            <?php
            //подключили функции
            require_once("../tasks/task03.php");

            ?>

            </tbody></table></form>

        </div>

        </div>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../pages/shared/_footer.php" ?>

</body>
</html>

