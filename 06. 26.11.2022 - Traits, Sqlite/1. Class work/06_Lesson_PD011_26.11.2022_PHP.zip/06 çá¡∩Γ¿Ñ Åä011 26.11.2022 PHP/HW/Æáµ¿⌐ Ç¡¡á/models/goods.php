<?php

require_once("../tasks/utils.php");

//Создать класс Goods (товар)
class Goods {

    private string $title; //наименование товара
    private $date; //дата оформления
    private int $price; //цена единицы товара
    private int $count; //количество единиц товара
    private string  $invoiceNumber; //номер накладной

    public function __construct($title,$date,$price,$count,$invoiceNumber){

        $this->title = $title;
        $this->date = $date;
        $this->price = $price;
        $this->count = $count;
        $this->invoiceNumber = $invoiceNumber;
    }

    //геттеры и сеттеры с выбросом исключений

    function getTitle(): string {return $this->title;}
    function setTitle($value): void
    {
        if(mb_strlen($value) == 0) throw new InvalidArgumentException("Title: Строка пуста");

        $this->title = $value;
    }

    function getDate() {return $this->date;}
    function setDate($value): void{

        //if($value < DateTime()) throw new InvalidArgumentException("Date: накладная не может быть выписана задним числом");

        $this->date = $value;
    }

    function getPrice() :int {return $this->price;}
    function setPrice($value): void
    {
        if($value <= 0) throw new InvalidArgumentException("Стоиммость <= 0");

        $this->price = $value;
    }

    function getCount() :int {return $this->count;}
    function setCount($value): void
    {
        if($value <= 0) throw new InvalidArgumentException("Кол-во товара <= 0");

        $this->count = $value;
    }

    function getInvoiceNumber(): string {return $this->invoiceNumber;}
    function setInvoiceNumber($value): void
    {
        if(mb_strlen($value) == 0) throw new InvalidArgumentException("Номер накладной пуст");

        $this->invoiceNumber = $value;
    }

    //вычисления стоимости товара.
    function getFullPrice():int{
        return  $this->count*$this->price;
    }

    // получить массив значений
    public function getArrayValues(): array
    {
        return [
            $this->title,
            $this->date,
            $this->price,
            $this->count,
            $this->invoiceNumber,
        ];
    }

    public function toTableRow($id):void{
        echo "<tr>
            <td>$this->title</td>
            <td>$this->date</td>
            <td>$this->price</td>
            <td>$this->count</td>
            <td>$this->invoiceNumber</td>  
            <td><form method='post'><button class='btn btn-danger' type='submit' name='id' value='$id'>Удалить</button></form></td>
        </tr>";
    }
}
