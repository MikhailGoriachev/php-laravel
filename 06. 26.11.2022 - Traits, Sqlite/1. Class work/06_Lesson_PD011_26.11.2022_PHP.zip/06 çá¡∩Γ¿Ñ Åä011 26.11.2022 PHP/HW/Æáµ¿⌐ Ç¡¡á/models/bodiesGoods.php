<?php

require_once("../tasks/utils.php");

//класс для работы с коллекцией
class BodiesGoods{

    const PATH  = FOLDERNAME . '/' .'bodiesGoods.csv';

    //коллекция
    private array $goodsArr = array();

    function __construct() {

        if(!$this->load()){

            $goodsArr = [
                new Goods("Суп Крестьянский",date("d.m.y"),74,4,"4503-59FSF"),
                new Goods("Гороховый суп",date("d.m.y"),129,4,"0090435KF"),
                new Goods("Цыпленок с рисом",date("d.m.y"),208,4,"349-5934KF"),
                new Goods("Смесь Бельгийская",date("d.m.y"),223,8,"40-593-FS"),
                new Goods("Смесь Мексиканская",date("d.m.y"),105,4,"059-3045VV"),
                new Goods("Фасоль стручковая",date("d.m.y"),166,23,"430-59-395-3F"),
                new Goods("Кукуруза",date("d.m.y"),199,12,"90259-23945-0F"),
                new Goods("Корнишоны",date("d.m.y"),202,4,"9023-4592EE"),
                new Goods("Лечо",date("d.m.y"),124,5,"345693-405-WERF"),
                new Goods("Свекла",date("d.m.y"),94,4,"5390-593-SFA"),
                new Goods("Гречневая крупа",date("d.m.y"),100,30,"2352-094FS"),
                new Goods("Оливки",date("d.m.y"),86,2,"23904820FKJG"),
            ];

            $this->save();
        }

    }

    // вывод в таблицу
    function show():void{

        $index = 0;

        foreach ($this->goodsArr as $good){
            $good->toTableRow($index);
            $index++;
        }

        //array_walk_recursive($this->goodsArr,fn($p)=>$p->toTableRow());

    }

    public function delete($index) : void{
        unset($this->goodsArr[$index]);
        $this->goodsArr = array_values($this->goodsArr);
    }

    public function add($good) : void{
        array_unshift($this->goodsArr,$good);
    }

    // запись данных в файл в формте CSV
    function save(): void{

        $file = fopen(self::PATH, 'w');

        array_walk($this->goodsArr, fn($a) => fputcsv($file, $a->getArrayValues()));
        fclose($file);
    }

    // установить значения из массива
    function setDataFromArray(array $arr): void
    {
        $this->goodsArr =  array_map(fn($item) => new Goods(...$item), $arr);
    }

    // загрузить данные из файла в формте CSV
    function load(): bool{

        //проверка был ли записан файл
        if (!file_exists(self::PATH))
            return false;

        $file = fopen(self::PATH, 'r');

        $result = [];

        while (!feof($file)) {
            $buf = fgetcsv($file);

            if (is_array($buf))
                $result[] = $buf;
        }

        fclose($file);

        $this->setDataFromArray($result);

        return true;
    }
}