<!-- секция контент -->
<?php $__env->startSection('main_part'); ?>
    <h4 class="text-center my-5">Страница home/index</h4>

    <ul class="list-group w-50 mx-auto my-5">
        <li class="list-group-item">
           Конфигурирование доступа к базе данных
        </li>
        <li class="list-group-item">
            Миграции для работы с базой данных
        </li>
        <li class="list-group-item">
            <b>QB</b> - <b>Q</b>uery <b>B</b>uilder, Построитель Запросов
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\17 Занятие ПД011 22.12.2022 PHP\CW\db-intro\resources\views/home/index.blade.php ENDPATH**/ ?>