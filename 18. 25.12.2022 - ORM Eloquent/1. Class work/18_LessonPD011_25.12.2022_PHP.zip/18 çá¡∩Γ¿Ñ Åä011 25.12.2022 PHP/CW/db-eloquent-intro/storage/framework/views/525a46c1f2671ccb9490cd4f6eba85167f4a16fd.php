<!-- секция контент -->
<?php $__env->startSection('main_part'); ?>
    <h4 class="text-center my-5">Страница home/index</h4>

    <ul class="list-group w-50 mx-auto my-5">
        <li class="list-group-item">
           Создание и настройка модели для Eloquent
        </li>
        <li class="list-group-item">
            Выполнение запросов выборки данных
        </li>
        <li class="list-group-item">
            Связи между моделями
        </li>
        <li class="list-group-item">
            Выполнение <b>CRUD</b>-операций
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\18 Занятие ПД011 25.12.2022 PHP\CW\db-eloquent-intro\resources\views/home/index.blade.php ENDPATH**/ ?>