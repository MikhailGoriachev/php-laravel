## Введение в работу с базами данных ORM <u>Eloquent</u>
### Создание модели
php artisan make:model ИмяМодели
php artisan make:model Product

