@extends('layouts.app')

@section('customers', 'active')
@section('title', 'Клиенты')

<!-- секция контент -->
@section('content')

    <p class="fs-5 ms-2 mt-5">Все записи:</p>

    <table class="table table-bordered ms-2">
        <thead>
        <tr>
            <th>ИД</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Паспорт</th>
        </tr>
        </thead>
        <tbody>
        @foreach($customers as $customer)
            <tr>
                <td>{{ $customer->id }}</td>
                <td>{{ $customer->surname }}</td>
                <td>{{ $customer->name }}</td>
                <td>{{ $customer->patronymic }}</td>
                <td>{{ $customer->passport }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>

    @php
        echo $s01;
        echo $s02;
    @endphp

@endsection
