<?php $__env->startSection('cars', 'active'); ?>
<?php $__env->startSection('title', 'Авто'); ?>

<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <?php
        echo $s01;
        echo $s02;
        echo $s03;
    ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annat\source\repos\PHP\Step_24.12.22_PHP\resources\views/cars/index.blade.php ENDPATH**/ ?>