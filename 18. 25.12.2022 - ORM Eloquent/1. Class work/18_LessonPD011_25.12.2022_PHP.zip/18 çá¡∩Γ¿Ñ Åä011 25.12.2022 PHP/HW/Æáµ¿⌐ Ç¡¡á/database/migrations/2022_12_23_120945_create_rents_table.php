<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{

    public function up()
    {
        Schema::create('rents', function (Blueprint $table) {
            $table->increments('id');  // первичный ключ, моджно явно указать имя

            $table->unsignedInteger('customer_id');
            $table->unsignedInteger('car_id');

            $table->foreign('customer_id')->references('id')->on('customers');
            $table->foreign('car_id')->references('id')->on('cars');

            //$table->foreignId('customers_id')->constrained();
            //$table->foreignId('cars_id')->constrained();

            $table->date('date');
            $table->integer('amount');

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('rents');
    }
};
