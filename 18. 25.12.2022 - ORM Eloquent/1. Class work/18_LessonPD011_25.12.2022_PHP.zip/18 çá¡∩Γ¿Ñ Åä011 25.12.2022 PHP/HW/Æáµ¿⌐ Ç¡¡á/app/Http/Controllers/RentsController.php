<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class RentsController extends Controller
{
    public function index(): View{

        // добавление записи
        $id = DB::table('rents')->insertGetId([
            'customer_id' => random_int(1, 10),
            'car_id' => random_int(1, 10),
            'date' => '2022-12-24',
            'amount' => random_int(1, 20)
        ]);

        $rents01 = DB::table('rents')->get();

        $s01 = $this->toTable($rents01,"Добавили запись c id = $id:");

        //Измените длительность выбранного факта проката автомобиля
        $num = DB::table('rents')->where('id', $id)->update([
            'amount' => random_int(1, 20)
        ]);

        $rents03 = DB::table('rents')->get();

        $s03 = $this->toTable($rents03,"Изменена длительность факта проката автомобиля c id = $id:");

        //Удалите выбранный факт проката автомобиля
        $num = DB::table('rents')->where('id', $id)->delete();

        $rents02 = DB::table('rents')->get();

        $s02 = $this->toTable($rents02,"Удалена запись c id = $id:");

        return view('rents.index', [

            's01' => $s01,
            's03' => $s03,
            's02' => $s02
        ]);
    }

    //Вывод запроса в табличном формате
    private function toTable($rents,$caption):string{

        $s =  "  <p class='fs-5 ms-2 mt-5'>$caption</p>

    <table class='table table-bordered ms-2'>
        <thead>
        <tr>
            <th>ИД проката</th>
            <th>ИД клиента</th>
            <th>ИД авто</th>
            <th>Дата начала проката</th>
            <th>Количество дней проката</th>
        </tr>
        </thead>
        <tbody>";

        foreach($rents as $rent) {
            $s = $s. "<tr>
                <td>$rent->id</td>
                <td>$rent->customer_id</td>
                <td>$rent->car_id</td>
                <td>$rent->date</td>
                <td>$rent->amount</td>
              </tr>";
        }

        $s = $s. "
        </tbody>
    </table>

        ";

        return $s;
    }
}
