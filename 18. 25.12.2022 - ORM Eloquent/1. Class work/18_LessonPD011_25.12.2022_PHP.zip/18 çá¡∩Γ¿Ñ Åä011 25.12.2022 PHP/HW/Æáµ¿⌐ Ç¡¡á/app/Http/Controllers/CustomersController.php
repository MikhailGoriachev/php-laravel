<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class CustomersController extends Controller
{
    public function index(): View{

        // получить все записи (и все поля) из таблицы
        $customers =  DB::table('customers')->get();

        //Выбирает информацию о клиентах, серия-номер паспорта которых начинается с заданной цифры.
        $customers01 = DB::table('rents')->join('customers', 'rents.customer_id', '=', 'customers.id')
            ->join('cars', 'rents.car_id', '=', 'cars.id')
            ->join('models', 'cars.model_id', '=', 'models.id')
            ->where('customers.passport', 'like', "0%")
            ->select('rents.customer_id', 'customers.passport as passport', 'date', 'amount', 'models.model as model')
            ->get();


        $s01 = $this->toTable($customers01,"Выбирает информацию о клиентах, серия-номер паспорта которых начинается с цифры 0:");

        //Выбирает из информацию о клиентах, бравших автомобиль напрокат в некоторый определенный день.
        $day = '2022-12-08';

        $customers02 = DB::table('rents')->join('customers', 'rents.customer_id', '=', 'customers.id')
            ->join('cars', 'rents.car_id', '=', 'cars.id')
            ->join('models', 'cars.model_id', '=', 'models.id')
            ->where('date', '=', $day)
            ->select('rents.customer_id', 'customers.passport as passport', 'date', 'amount', 'models.model as model')
            ->get();

        $s02 = $this->toTable($customers02,"Выбирает из информацию о клиентах, бравших автомобиль напрокат $day:");

        return view('customers.index', ['customers' => $customers, 's01' => $s01, 's02' => $s02]);


    }

    //Вывод запроса в табличном формате
    private function toTable($customers,$caption):string{

        $s =  "  <p class='fs-5 ms-2 mt-5'>$caption</p>

    <table class='table table-bordered ms-2'>
        <thead>
        <tr>
            <th>Код клиента</th>
            <th>Паспорт</th>
            <th>Дата начала проката</th>
            <th>Количество дней проката</th>
            <th>Модель автомобиля</th>
        </tr>
        </thead>
        <tbody>";

        foreach($customers as $customer) {
            $s = $s. "<tr>
                <td>$customer->customer_id</td>
                <td>$customer->passport</td>
                <td>$customer->date</td>
                <td>$customer->amount</td>
                <td>$customer->model</td>
              </tr>";
        }

        $s = $s. "
        </tbody>
    </table>

        ";

        return $s;
    }
}
