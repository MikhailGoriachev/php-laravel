<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Стили -->
    <link rel="stylesheet" href="/lib/bootstrap/css/bootstrap.min.css">
    <!-- внешнее подключение стилевого файла-->
    <link rel="stylesheet" href="/style/index.css">

    <!-- Скрипты -->
    <script src="/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="/lib/bootstrap-icons/bootstrap-icons.css">

    <title>HomeWork</title>

    <!-- логотип -->
    <link rel="shortcut icon" type="image/x-icon" href="/img/program-64.png">
</head>
<body class="body">
<main>
    <header>
        <div class="d-flex flex-column flex-md-row align-items-center bg-primary pb-3 mb-4 border-bottom fw-bold fs-5">
            <a href="/" class="d-flex align-items-center text-dark text-decoration-none mx-4">
                Главная
            </a>
            <ul class="navbar-nav mb-2 mb-lg-0">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-dark" href="#" data-bs-toggle="dropdown" aria-expanded="false">Таблицы</a>
                <ul class="dropdown-menu" aria-labelledby="dropdown01">
                    <li><a class="dropdown-item" href="/view-colors">Цвет</a></li>
                    <li><a class="dropdown-item" href="/view-models">Модель</a></li>
                    <li><a class="dropdown-item" href="/view-clients">Клиенты</a></li>
                    <li><a class="dropdown-item" href="/view-cars">Автомобили</a></li>
                    <li><a class="dropdown-item" href="/view-rentals">Прокат</a></li>
                </ul>
            </li>
            </ul>

            <ul class="navbar-nav mb-2 mb-lg-0 mx-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-dark " href="#" data-bs-toggle="dropdown" aria-expanded="false">Запросы</a>
                    <ul class="dropdown-menu" aria-labelledby="dropdown01">
                        <li><a class="dropdown-item" href="/query01">Запрос 1</a></li>
                        <li><a class="dropdown-item" href="/query02">Запрос 2</a></li>
                        <li><a class="dropdown-item" href="/query03">Запрос 3</a></li>
                        <li><a class="dropdown-item" href="/query04">Запрос 4</a></li>
                        <li><a class="dropdown-item" href="/query05">Запрос 5</a></li>
                        <li><a class="dropdown-item" href="/query06">Запрос 6</a></li>
                    </ul>
                </li>
            </ul>
            <a class="me-3 py-2 text-dark text-decoration-none" href="/view-rentals">Добавление</a>
            <a class="me-3 py-2 text-dark text-decoration-none" href="/view-rentals">Удаление</a>
            <nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
                <a class="me-3 py-2 text-dark text-decoration-none" href="/about">О разработчике</a>
            </nav>
        </div>
    </header>

    <section class="col-12 col-md-12 px-5 mt-3">
        
        <?php echo $__env->yieldContent('main_content'); ?>
    </section>


</main>
<div class="d-flex flex-column flex-md-row align-items-center bg-primary pb-4 border-bottom ">

</div>
</body>
</html>








<?php /**PATH D:\Students\ПД011\15 PHP\18 Занятие ПД011 25.12.2022 PHP\HW\Зейдлиц Виктория\resources\views/layouts/layout.blade.php ENDPATH**/ ?>