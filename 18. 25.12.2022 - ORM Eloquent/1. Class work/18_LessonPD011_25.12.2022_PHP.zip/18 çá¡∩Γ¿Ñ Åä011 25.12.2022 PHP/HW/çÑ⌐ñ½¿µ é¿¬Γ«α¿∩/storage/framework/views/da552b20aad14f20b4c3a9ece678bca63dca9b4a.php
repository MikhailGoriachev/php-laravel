<?php $__env->startSection('main_content'); ?>

    <h4 class="text-center">Выбирает из информацию об автомобилях, стоимость одного дня проката которых меньше заданной</h4>
    <table class="table table-bordered w-75 mx-auto my-5">
        <thead>
        <tr>
            <th>ИД</th>
            <th>Модель</th>
            <th>Цвет</th>
            <th>Госномер</th>
            <th>Год выпуска</th>
            <th>Страховая стоимость</th>
            <th>Стоимость 1дн.проката</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->model); ?></td>
                <td><?php echo e($item->color); ?></td>
                <td><?php echo e($item->car_number); ?></td>
                <td><?php echo e($item->year); ?></td>
                <td><?php echo e($item->insurance_pay); ?></td>
                <td><?php echo e($item->pay_rental_day); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\User\source\repos\HW17PHP\resources\views/query/query01.blade.php ENDPATH**/ ?>