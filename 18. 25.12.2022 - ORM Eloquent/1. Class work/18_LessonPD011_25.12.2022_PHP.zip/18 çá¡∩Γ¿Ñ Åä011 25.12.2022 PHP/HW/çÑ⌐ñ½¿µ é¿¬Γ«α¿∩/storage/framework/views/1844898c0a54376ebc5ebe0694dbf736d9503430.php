<?php $__env->startSection('main_content'); ?>

    <h4 class="text-center">Выбирает из информацию о клиентах, бравших автомобиль напрокат в некоторый определенный день. </h4>
    <table class="table table-bordered lg:max-w-[90rem] mx-auto my-5">
        <thead>
        <tr>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Паспортные данные</th>
            <th>Дата проката</th>
            <th>Кол-во дней</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->surname); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->patronymic); ?></td>
                <td class="text-center"><?php echo e($item->passport); ?></td>
                <td><?php echo e($item->rental_start_date); ?></td>
                <td><?php echo e($item->duration); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\User\source\repos\HW17PHP\resources\views/query/query04.blade.php ENDPATH**/ ?>