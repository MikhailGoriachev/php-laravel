<?php $__env->startSection('main_content'); ?>
    <div class="card mx-auto w-50 text-center bg-light shadow-sm border border-3 rounded-3 p-3 mb-5">
        <div class="card-body bg-gradient">
            <h5 class="card-title">Данные о разработчике</h5>
            <p class="card-text"><b>Студент:</b> Зейдлиц Виктория</p>
            <p class="card-text"><b>Группа: </b> ПД011 г.Донецк 2022</p>
        </div>
        <hr/>
        <img src="/img/img_laravel.png" class="card-img-bottom h-100 w-100 "  alt="..."/>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\User\source\repos\HW17PHP\resources\views/home/about.blade.php ENDPATH**/ ?>