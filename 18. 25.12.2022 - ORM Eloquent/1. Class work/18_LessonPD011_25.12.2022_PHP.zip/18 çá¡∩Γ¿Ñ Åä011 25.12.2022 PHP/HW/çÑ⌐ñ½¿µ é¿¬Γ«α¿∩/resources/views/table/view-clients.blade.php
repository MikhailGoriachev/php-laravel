@extends('layouts.layout')

@section('main_content')

    <h4 class="text-center">Таблица клиенты</h4>
    <table class="table table-bordered w-75 mx-auto my-5">
        <thead>
        <tr>
            <th>ИД</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Паспортные данные</th>
        </tr>
        </thead>
        <tbody>
        @foreach($clients as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->surname }}</td>
                <td>{{ $item->name }}</td>
                <td>{{ $item->patronymic }}</td>
                <td class="text-center">{{ $item->passport }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>


@endsection
