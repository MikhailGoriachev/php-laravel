@extends('layouts.layout')

@section('main_content')

    <h4 class="text-center">Выбирает из таблицы информацию об автомобилях, страховая стоимость которых находится в заданном диапазоне</h4>
    <table class="table table-bordered w-75 mx-auto my-5">
        <thead>
        <tr>
            <th>ИД</th>
            <th>Модель</th>
            <th>Цвет</th>
            <th>Госномер</th>
            <th>Год выпуска</th>
            <th>Страховая стоимость</th>
            <th>Стоимость 1дн.проката</th>
        </tr>
        </thead>
        <tbody>
        @foreach($cars as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->model }}</td>
                <td>{{ $item->color }}</td>
                <td>{{ $item->car_number }}</td>
                <td>{{ $item->year }}</td>
                <td>{{ $item->insurance_pay }}</td>
                <td>{{ $item->pay_rental_day }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>


@endsection



