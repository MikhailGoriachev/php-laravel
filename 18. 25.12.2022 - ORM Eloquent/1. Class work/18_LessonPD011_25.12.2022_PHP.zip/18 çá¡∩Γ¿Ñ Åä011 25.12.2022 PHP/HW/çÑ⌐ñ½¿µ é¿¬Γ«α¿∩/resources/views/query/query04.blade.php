@extends('layouts.layout')

@section('main_content')

    <h4 class="text-center">Выбирает из информацию о клиентах, бравших автомобиль напрокат в некоторый определенный день. </h4>
    <table class="table table-bordered lg:max-w-[90rem] mx-auto my-5">
        <thead>
        <tr>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Паспортные данные</th>
            <th>Дата проката</th>
            <th>Кол-во дней</th>
        </tr>
        </thead>
        <tbody>
        @foreach($clients as $item)
            <tr>
                <td>{{ $item->surname }}</td>
                <td>{{ $item->name }}</td>
                <td>{{ $item->patronymic }}</td>
                <td class="text-center">{{ $item->passport }}</td>
                <td>{{ $item->rental_start_date }}</td>
                <td>{{ $item->duration }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>


@endsection


