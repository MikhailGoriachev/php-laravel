@extends('layouts.layout')

@section('main_content')

    <h4 class="text-center">Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса</h4>
    <table class="table table-bordered w-75 mx-auto my-5">
        <thead>
        <tr>
            <th>Госномер</th>
            <th>Модель</th>
            <th>Цвет</th>
            <th>Страховая стоимость</th>
            <th>Страховой взнос</th>
        </tr>
        </thead>
        <tbody>
        @foreach($cars as $item)
            <tr>
                <td>{{ $item->car_number }}</td>
                <td>{{ $item->model }}</td>
                <td>{{ $item->year }}</td>
                <td>{{ $item->insurance_pay }}</td>
                <td>{{ $item->cost_rental }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>


@endsection





