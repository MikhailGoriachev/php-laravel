@extends('layouts.layout')

@section('main_content')

    <h4 class="text-center">Таблица модели авто</h4>
    <table class="table table-bordered w-75 mx-auto my-5">
        <thead>
        <tr>
            <th>ИД</th>
            <th>Наименование модели</th>
        </tr>
        </thead>
        <tbody>
        @foreach($models as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->model }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>


@endsection
