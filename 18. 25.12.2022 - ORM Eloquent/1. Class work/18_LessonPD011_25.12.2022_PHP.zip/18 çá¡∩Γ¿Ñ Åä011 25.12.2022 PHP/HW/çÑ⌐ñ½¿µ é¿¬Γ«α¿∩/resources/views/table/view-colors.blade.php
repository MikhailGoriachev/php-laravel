@extends('layouts.layout')

@section('main_content')

    <h4 class="text-center">Таблица цвета авто</h4>
    <table class="table table-bordered w-75 mx-auto my-5">
        <thead>
        <tr>
            <th>ИД</th>
            <th>Наименование цвета</th>
        </tr>
        </thead>
        <tbody>
        @foreach($colors as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->color }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>


@endsection
