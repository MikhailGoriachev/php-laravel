@extends('layouts.layout')

@section('main_content')

    <h4 class="text-center">Таблица проката автомобилей</h4>
    <table class="table table-bordered lg:max-w-[90rem] mx-auto my-5">
        <thead>
        <tr>
            <th>ИД</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Модель</th>
            <th>Госномер</th>
            <th>Страховая стоимость</th>
            <th>Стоимость 1дн.проката</th>
            <th>Дата проката</th>
            <th>Кол-во дней</th>
            <th class="text-center">
                <a class="btn btn-success" href="/query/insert" title="Добавить...">
                    <i class="bi bi-plus-lg"></i> Добавить
                </a>
            </th>
        </tr>
        </thead>
        <tbody>
        @foreach($rentals as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->surname }}</td>
                <td>{{ $item->name }}</td>
                <td>{{ $item->model }}</td>
                <td>{{ $item->car_number }}</td>
                <td>{{ $item->insurance_pay }}</td>
                <td>{{ $item->pay_rental_day }}</td>
                <td>{{ $item->rental_start_date }}</td>
                <td>{{ $item->duration }}</td>
                <td>
                    <a class="btn btn-danger" href="/query/delete/{{$item->id}}" title="Удалить">
                        <i class="bi bi-trash-fill"></i>
                    </a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>


@endsection


