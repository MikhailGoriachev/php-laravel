CREATE DATABASE  IF NOT EXISTS `car_rental_zeidlits` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `car_rental_zeidlits`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: car_rental_zeidlits
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cars` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `car_number` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` int NOT NULL,
  `insurance_pay` int NOT NULL,
  `pay_rental_day` int NOT NULL,
  `id_model` bigint unsigned NOT NULL,
  `id_color` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cars_id_model_foreign` (`id_model`),
  KEY `cars_id_color_foreign` (`id_color`),
  CONSTRAINT `cars_id_color_foreign` FOREIGN KEY (`id_color`) REFERENCES `colors` (`id`),
  CONSTRAINT `cars_id_model_foreign` FOREIGN KEY (`id_model`) REFERENCES `models` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES (1,'C850PK',2012,5000000,800,1,1,NULL,NULL),(2,'K801HT',2018,3000000,500,2,2,NULL,NULL),(3,'C948IX',2019,8000000,1450,3,3,NULL,NULL),(4,'A942KC',2020,10000000,1800,4,4,NULL,NULL),(5,'H924XI',2019,5000000,800,5,5,NULL,NULL),(6,'A043KC',2017,2000000,500,1,6,NULL,NULL),(7,'K841BC',2015,4000000,550,2,7,NULL,NULL),(8,'I964HA',2018,4000000,770,3,1,NULL,NULL),(9,'O842HX',2019,2500000,800,4,2,NULL,NULL),(10,'C843KI',2015,270000,800,5,3,NULL,NULL);
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `surname` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `patronymic` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `passport` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'Гончарова','Арина','Алексеевна','60 21 496730',NULL,NULL),(2,'Серов','Платон','Львович','25 12 497528',NULL,NULL),(3,'Котов','Михаил','Павлович','26 68 486782',NULL,NULL),(4,'Грачёва ','Василиса','Алексеевна','60 21 865832',NULL,NULL),(5,'Морозова','Таисия','Платоновна','36 68 899204',NULL,NULL),(6,'Семенова','Дарина','Марковна','25 12 863945',NULL,NULL),(7,'Лавров','Роман','Иванович','25 12 582419',NULL,NULL),(8,'Смирнов','Константин','Артёмович','36 68 793160',NULL,NULL),(9,'Грибова','Софья','Никитична','60 21 782041',NULL,NULL),(10,'Николаева','Валерия','Максимовна','60 21 921574',NULL,NULL),(11,'Рыбаков','Даниил','Георгиевич','25 12 943640',NULL,NULL),(12,'Островский','Александр','Михайлович','36 68 781539',NULL,NULL),(13,'Воронина','Василиса','Кирилловна','25 12 578126',NULL,NULL),(14,'Григорьев','Тихон','Антонович','60 21 839127',NULL,NULL),(15,'Денисова','Александра','Ивановна','36 68 936125',NULL,NULL);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colors`
--

DROP TABLE IF EXISTS `colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `color` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colors`
--

LOCK TABLES `colors` WRITE;
/*!40000 ALTER TABLE `colors` DISABLE KEYS */;
INSERT INTO `colors` VALUES (1,'красный',NULL,NULL),(2,'белый',NULL,NULL),(3,'чёрный',NULL,NULL),(4,'серый',NULL,NULL),(5,'жёлтый',NULL,NULL),(6,'синий',NULL,NULL),(7,'бордовый',NULL,NULL),(8,'зелёный',NULL,NULL);
/*!40000 ALTER TABLE `colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2019_12_14_000001_create_personal_access_tokens_table',1),(2,'2022_12_23_145316_create_colors_table',1),(3,'2022_12_23_150531_create_models_table',2),(4,'2022_12_23_150837_create_clients_table',3),(5,'2022_12_23_151427_create_cars_table',4),(6,'2022_12_23_155527_create_rentals_table',5);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `models` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `model` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `models`
--

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
INSERT INTO `models` VALUES (1,'Audi',NULL,NULL),(2,'BMW',NULL,NULL),(3,'Kia',NULL,NULL),(4,'Lexus',NULL,NULL),(5,'Infiniti',NULL,NULL),(6,'Porsche',NULL,NULL);
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rentals`
--

DROP TABLE IF EXISTS `rentals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rentals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `rental_start_date` date NOT NULL,
  `duration` int NOT NULL,
  `id_client` bigint unsigned NOT NULL,
  `id_car` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rentals_id_client_foreign` (`id_client`),
  KEY `rentals_id_car_foreign` (`id_car`),
  CONSTRAINT `rentals_id_car_foreign` FOREIGN KEY (`id_car`) REFERENCES `cars` (`id`),
  CONSTRAINT `rentals_id_client_foreign` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rentals`
--

LOCK TABLES `rentals` WRITE;
/*!40000 ALTER TABLE `rentals` DISABLE KEYS */;
INSERT INTO `rentals` VALUES (1,'2022-11-07',5,1,1,NULL,NULL),(3,'2022-11-15',4,3,3,NULL,NULL),(4,'2022-10-08',1,4,4,NULL,NULL),(5,'2022-10-27',8,5,5,NULL,NULL),(6,'2022-11-11',14,6,6,NULL,NULL),(7,'2022-11-25',1,7,7,NULL,NULL),(8,'2022-11-18',5,8,8,NULL,NULL),(9,'2022-10-14',8,9,9,NULL,NULL),(10,'2022-10-09',3,10,10,NULL,NULL),(11,'2022-12-01',18,5,7,NULL,NULL),(12,'2022-12-01',8,7,3,NULL,NULL),(13,'2022-12-01',9,1,1,NULL,NULL),(15,'2022-12-01',26,6,5,NULL,NULL),(18,'2022-12-01',24,2,2,NULL,NULL),(19,'2022-12-01',9,3,5,NULL,NULL),(20,'2022-12-01',8,7,2,NULL,NULL);
/*!40000 ALTER TABLE `rentals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-25 14:26:12
