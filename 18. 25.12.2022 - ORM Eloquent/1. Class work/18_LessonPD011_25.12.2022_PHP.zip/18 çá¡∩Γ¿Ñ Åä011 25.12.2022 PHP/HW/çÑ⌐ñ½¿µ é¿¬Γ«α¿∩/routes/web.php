<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\QueryController;
use App\Http\Controllers\TableController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// главная
Route::get('/', [ HomeController::class, 'index']);

// о разработчике
Route::get('/about', [ HomeController::class, 'about']);

// таблицы
Route::get('/view-colors', [ TableController::class, 'viewColors']);
Route::get('/view-models', [ TableController::class, 'viewModels']);
Route::get('/view-clients', [ TableController::class, 'viewClients']);
Route::get('/view-cars', [ TableController::class, 'viewCars']);
Route::get('/view-rentals', [ TableController::class, 'viewRentals']);

// запросы
Route::get('/query01', [ QueryController::class, 'query01']);
Route::get('/query02', [ QueryController::class, 'query02']);
Route::get('/query03', [ QueryController::class, 'query03']);
Route::get('/query04', [ QueryController::class, 'query04']);
Route::get('/query05', [ QueryController::class, 'query05']);
Route::get('/query06', [ QueryController::class, 'query06']);


// добавление записи в таблицу rentals
Route::get('/query/insert', [ QueryController::class, 'insert']);

// изменение записи по идентификатору в таблице products
Route::get('/query/update/{id}', [QueryController::class, 'update']);


// удаление записи по идентификатору в таблице rentals
Route::get('/query/delete/{id?}', [QueryController::class, 'delete']);

