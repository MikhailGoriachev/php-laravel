<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {

        // таблица цвет
        DB::table('colors')->insert([
            ['color'=>'красный'],
            ['color'=>'белый'],
            ['color'=>'чёрный'],
            ['color'=>'серый'],
            ['color'=>'жёлтый'],
            ['color'=>'синий'],
            ['color'=>'бордовый'],
            ['color'=>'зелёный'],
        ]);

        // таблица модель
        DB::table('models')->insert([
            ['model'=>'Audi'],
            ['model'=>'BMW'],
            ['model'=>'Kia'],
            ['model'=>'Lexus'],
            ['model'=>'Infiniti'],
            ['model'=>'Porsche'],
        ]);

        // таблица клиенты
        DB::table('clients')->insert([
            ['surname'=>'Гончарова', 'name'=>'Арина', 'patronymic'=>'Алексеевна', 'passport'=>'60 21 496730'],
            ['surname'=>'Серов', 'name'=>'Платон', 'patronymic'=>'Львович', 'passport'=>'25 12 497528'],
            ['surname'=>'Котов', 'name'=>'Михаил', 'patronymic'=>'Павлович', 'passport'=>'26 68 486782'],
            ['surname'=>'Грачёва ', 'name'=>'Василиса', 'patronymic'=>'Алексеевна', 'passport'=>'60 21 865832'],
            ['surname'=>'Морозова', 'name'=>'Таисия', 'patronymic'=>'Платоновна', 'passport'=>'36 68 899204'],
            ['surname'=>'Семенова', 'name'=>'Дарина', 'patronymic'=>'Марковна', 'passport'=>'25 12 863945'],
            ['surname'=>'Лавров', 'name'=>'Роман', 'patronymic'=>'Иванович', 'passport'=>'25 12 582419'],
            ['surname'=>'Смирнов', 'name'=>'Константин', 'patronymic'=>'Артёмович', 'passport'=>'36 68 793160'],
            ['surname'=>'Грибова', 'name'=>'Софья', 'patronymic'=>'Никитична', 'passport'=>'60 21 782041'],
            ['surname'=>'Николаева', 'name'=>'Валерия', 'patronymic'=>'Максимовна', 'passport'=>'60 21 921574'],
            ['surname'=>'Рыбаков', 'name'=>'Даниил', 'patronymic'=>'Георгиевич', 'passport'=>'25 12 943640'],
            ['surname'=>'Островский', 'name'=>'Александр', 'patronymic'=>'Михайлович', 'passport'=>'36 68 781539'],
            ['surname'=>'Воронина', 'name'=>'Василиса', 'patronymic'=>'Кирилловна', 'passport'=>'25 12 578126'],
            ['surname'=>'Григорьев', 'name'=>'Тихон', 'patronymic'=>'Антонович', 'passport'=>'60 21 839127'],
            ['surname'=>'Денисова', 'name'=>'Александра', 'patronymic'=>'Ивановна', 'passport'=>'36 68 936125'],

        ]);

        // таблица авто
        DB::table('cars')->insert([
            ['id_model'=>'1', 'id_color'=>'1', 'car_number'=>'C850PK', 'year'=>'2012', 'insurance_pay'=>'5000000', 'pay_rental_day'=>'800'],
            ['id_model'=>'2', 'id_color'=>'2', 'car_number'=>'K801HT', 'year'=>'2018', 'insurance_pay'=>'3000000', 'pay_rental_day'=>'500'],
            ['id_model'=>'3', 'id_color'=>'3', 'car_number'=>'C948IX', 'year'=>'2019', 'insurance_pay'=>'8000000', 'pay_rental_day'=>'1450'],
            ['id_model'=>'4', 'id_color'=>'4', 'car_number'=>'A942KC', 'year'=>'2020', 'insurance_pay'=>'10000000', 'pay_rental_day'=>'1800'],
            ['id_model'=>'5', 'id_color'=>'5', 'car_number'=>'H924XI', 'year'=>'2019', 'insurance_pay'=>'5000000', 'pay_rental_day'=>'800'],
            ['id_model'=>'1', 'id_color'=>'6', 'car_number'=>'A043KC', 'year'=>'2017', 'insurance_pay'=>'2000000', 'pay_rental_day'=>'500'],
            ['id_model'=>'2', 'id_color'=>'7', 'car_number'=>'K841BC', 'year'=>'2015', 'insurance_pay'=>'4000000', 'pay_rental_day'=>'550'],
            ['id_model'=>'3', 'id_color'=>'1', 'car_number'=>'I964HA', 'year'=>'2018', 'insurance_pay'=>'4000000', 'pay_rental_day'=>'770'],
            ['id_model'=>'4', 'id_color'=>'2', 'car_number'=>'O842HX', 'year'=>'2019', 'insurance_pay'=>'2500000', 'pay_rental_day'=>'800'],
            ['id_model'=>'5', 'id_color'=>'3', 'car_number'=>'C843KI', 'year'=>'2015', 'insurance_pay'=>'270000', 'pay_rental_day'=>'800'],

        ]);

        // таблица прокат
        DB::table('rentals')->insert([
            ['id_client'=>'1', 'id_car'=>'1', 'rental_start_date'=>'2022-11-07', 'duration'=>'5'],
            ['id_client'=>'2', 'id_car'=>'2', 'rental_start_date'=>'2022-10-12', 'duration'=>'12'],
            ['id_client'=>'3', 'id_car'=>'3', 'rental_start_date'=>'2022-11-15', 'duration'=>'4'],
            ['id_client'=>'4', 'id_car'=>'4', 'rental_start_date'=>'2022-10-08', 'duration'=>'1'],
            ['id_client'=>'5', 'id_car'=>'5', 'rental_start_date'=>'2022-10-27', 'duration'=>'8'],
            ['id_client'=>'6', 'id_car'=>'6', 'rental_start_date'=>'2022-11-11', 'duration'=>'14'],
            ['id_client'=>'7', 'id_car'=>'7', 'rental_start_date'=>'2022-11-25', 'duration'=>'1'],
            ['id_client'=>'8', 'id_car'=>'8', 'rental_start_date'=>'2022-11-18', 'duration'=>'5'],
            ['id_client'=>'9', 'id_car'=>'9', 'rental_start_date'=>'2022-10-14', 'duration'=>'8'],
            ['id_client'=>'10', 'id_car'=>'10', 'rental_start_date'=>'2022-10-09', 'duration'=>'3'],
        ]);



        // \App\Models\User::factory(10)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
    }
}
