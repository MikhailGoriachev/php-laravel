<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class TableController extends Controller
{
    // таблица цвет
    public function viewColors(): View{
        // получить все записи из таблицы
        $colors = DB::table('colors')
            ->select('id', 'color')
            ->get();

        return view('table.view-colors', ['colors'=>$colors]);

    }

    // таблица модель
    public function viewModels(): View{
        // получить все записи из таблицы
        $models = DB::table('models')
            ->select('id', 'model')
            ->get();

        return view('table.view-models', ['models'=>$models]);
    }

    // таблица клиенты
    public function viewClients(): View{
        // получить все записи из таблицы
        $clients = DB::table('clients')
            ->select('id', 'surname', 'name', 'patronymic', 'passport')
            ->get();

        return view('table.view-clients', ['clients'=>$clients]);
    }

    // таблица автомобили
    public function viewCars(): View{
        // получить все записи из таблицы
        $cars = DB::table('cars')
            ->join('colors', 'cars.id_color', '=', 'colors.id')
            ->join('models', 'cars.id_model', '=', 'models.id')
            ->select('cars.id as id', 'model', 'color', 'car_number', 'year', 'insurance_pay', 'pay_rental_day')
            ->get();

        return view('table.view-cars', ['cars'=>$cars]);
    }

    // таблица проката авто
    public function viewRentals(): View{
        // получить все записи из таблицы
        $rentals = DB::table('rentals')
            ->join('clients', 'rentals.id_client', '=', 'clients.id')
            ->join('cars', 'rentals.id_car', '=', 'cars.id')
            ->join('models', 'cars.id_model', '=', 'models.id')
            ->select('rentals.id as id', 'surname', 'name', 'model', 'car_number', 'insurance_pay', 'pay_rental_day', 'rental_start_date', 'duration')
            ->orderBy('id')
            ->get();

        return view('table.view-rentals', ['rentals'=>$rentals]);
    }


} // class TableController
