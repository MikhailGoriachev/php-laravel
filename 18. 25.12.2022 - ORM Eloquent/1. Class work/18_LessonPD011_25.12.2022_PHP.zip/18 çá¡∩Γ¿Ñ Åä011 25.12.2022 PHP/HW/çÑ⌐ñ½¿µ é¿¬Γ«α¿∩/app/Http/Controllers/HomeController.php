<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    // действие контроллера index
    public function index() {
        // обращение к странице отображения действия index в каталоге home
        return view('home.index');
    } // index

    // действие контроллера about
    public function about() {
        // обращение к странице отображения действия about в каталоге home
        return view('home.about');
    } // about
}
