<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class QueryController extends Controller
{
    // Выбирает из информацию об автомобилях,
    // стоимость одного дня проката которых меньше заданной
    public function query01(): View{
        $cars = DB::table('cars')
            ->join('colors', 'cars.id_color', '=', 'colors.id')
            ->join('models', 'cars.id_model', '=', 'models.id')
            ->where('pay_rental_day', '<', 1000)
            ->select('cars.id as id', 'model', 'color', 'car_number', 'year', 'insurance_pay', 'pay_rental_day')
            ->get();

        return view('query.query01', ['cars'=>$cars]);
    }


    // Выбирает из таблицы информацию об автомобилях,
    // страховая стоимость которых находится в заданном диапазоне
    public function query02(): View{
        $cars = DB::table('cars')
            ->join('colors', 'cars.id_color', '=', 'colors.id')
            ->join('models', 'cars.id_model', '=', 'models.id')
            ->whereBetween('insurance_pay', [1000000, 4000000])
            ->select('cars.id as id', 'model', 'color', 'car_number', 'year', 'insurance_pay', 'pay_rental_day')
            ->get();

        return view('query.query02', ['cars'=>$cars]);
    }


    // Выбирает информацию о клиентах,
    // серия-номер паспорта которых начинается с заданной цифры.
    // Включает поля Код клиента, Паспорт, Дата начала проката,
    // Количество дней проката, Модель автомобиля
    public function query03(): View{
        $clients = DB::table('rentals')
            ->join('clients', 'rentals.id_client', '=', 'clients.id')
            ->join('cars', 'rentals.id_car', '=', 'cars.id')
            ->join('models', 'cars.id_model', '=', 'models.id')
            ->where('passport', 'like', '2%')
            ->select('surname', 'name', 'patronymic', 'passport', 'model', 'duration', 'rental_start_date')
            ->get();

        return view('query.query03', ['clients'=>$clients]);
    }


    // Выбирает из информацию о клиентах,
    // бравших автомобиль напрокат в некоторый определенный день.
    public function query04(): View{
        $clients = DB::table('rentals')
            ->join('clients', 'rentals.id_client', '=', 'clients.id')
            ->whereDate('rental_start_date', '=', '2022-11-11')
            ->select('surname', 'name', 'patronymic', 'passport', 'duration', 'rental_start_date')
            ->get();

        return view('query.query04', ['clients'=>$clients]);
    }


    // Выбирает информацию обо всех автомобилях,
    // для которых значение в поле Страховая стоимость автомобиля
    // попадает в некоторый заданный интервал
    public function query05(): View{
        $cars = DB::table('cars')
            ->join('colors', 'cars.id_color', '=', 'colors.id')
            ->join('models', 'cars.id_model', '=', 'models.id')
            ->whereBetween('insurance_pay', [100000, 2000000])
            ->select('cars.id as id', 'model', 'color', 'car_number', 'year', 'insurance_pay', 'pay_rental_day')
            ->get();

        return view('query.query05', ['cars'=>$cars]);
    }


    // Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса.
    // Включает поля Госномер автомобиля, Модель автомобиля,
    // Год выпуска автомобиля, Страховая стоимость автомобиля, Страховой взнос.
    // Сортировка по полю Год выпуска автомобиля
    public function query06(): View{
        $cars = DB::table('cars')
            ->join('models', 'cars.id_model', '=', 'models.id')
            ->select('model', 'car_number', 'year', 'insurance_pay', 'cars.insurance_pay*(10/100) as cost_rental')
            ->orderBy('year')
            ->get();

        return view('query.query06', ['cars'=>$cars]);
    }


    // Добавить факт проката автомобиля
    public function insert(): View {

        DB::table('rentals')->insert([
            'id_car' => random_int(1, 7),
            'id_client'  => random_int(1, 10),
            'rental_start_date'  => '2022-12-1',
            'duration'  => random_int(5, 30),
        ]);

        $rentals = DB::table('rentals')
            ->join('clients', 'rentals.id_client', '=', 'clients.id')
            ->join('cars', 'rentals.id_car', '=', 'cars.id')
            ->join('models', 'cars.id_model', '=', 'models.id')
            ->select('rentals.id as id', 'surname', 'name', 'model', 'car_number', 'insurance_pay', 'pay_rental_day', 'rental_start_date', 'duration')
            ->orderBy('id')
            ->get();

        return view('query.insert', ['rentals'=>$rentals]);

    }


    // Измените длительность выбранного факта проката автомобиля
    public function update($id): View {

        return view('query.update');
    }


    // Удалите выбранный факт проката автомобиля
    public function delete($id): View {
        DB::table('rentals')->where('id', $id)->delete();

        $rentals = DB::table('rentals')
            ->join('clients', 'rentals.id_client', '=', 'clients.id')
            ->join('cars', 'rentals.id_car', '=', 'cars.id')
            ->join('models', 'cars.id_model', '=', 'models.id')
            ->select('rentals.id as id', 'surname', 'name', 'model', 'car_number', 'insurance_pay', 'pay_rental_day', 'rental_start_date', 'duration')
            ->orderBy('id')
            ->get();

        return view('query.delete', ['id' => $id, 'rentals'=>$rentals]);
    }


} // class QueryController
