<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\Query1Request;
use App\Http\Requests\Query2Request;

class RentalController extends Controller
{
    private int $price ;
    private int $price2;
    // выводит таблицу бренды
    public function show_brends(){
        return view('brends');
    }
    // выводит таблицу цвета
    public function show_colors(){
        return view('colors');
    }
    // выводит таблицу клиенты
    public function show_clients(){
        $clients = DB::table('clients')->get();
        return view('clients', ['clients' => $clients]);
    }
    // выводит таблицу машины
    public function show_cars() {
        $cars = DB::table('cars')
            ->join('brands', 'cars.brand_id', '=', 'brands.id')
            ->join('colors', 'cars.color_id', '=', 'colors.id')
            ->select('cars.id', 'brand', 'color', 'yearRelease', 'num', 'insurance', 'price')
            ->get();
        return view('cars', ['cars' => $cars]);
    }
    // выводит таблицу аренда
    public function show_rental() {
        $rentals = DB::table('rentals')
            ->join('cars', 'rentals.car_id', '=', 'cars.id')
            ->join('clients', 'rentals.client_id', '=', 'clients.id')
            ->select('rentals.id', 'start_date', 'count', 'num', 'surname', 'firstName', 'patronymic', 'passport')
            ->get();
        return view('rentals', ['rentals' => $rentals]);
    }

    public function query1(){
        return view('form_query1');
    }
    // Выбирает из информацию об автомобилях, стоимость одного дня проката которых меньше заданной
    public function query1_res(Query1Request $req){
        $this->price = $req->input('price');
        $cars = DB::table('cars')
            ->join('brands', 'cars.brand_id', '=', 'brands.id')
            ->join('colors', 'cars.color_id', '=', 'colors.id')
            ->where('price', '<', $this->price)
            ->select('cars.id', 'brand', 'color', 'yearRelease', 'num', 'insurance', 'price')
            ->get();
        return view('cars', ['cars' => $cars]);
    }
    // Выбирает из таблицы информацию об автомобилях,
    // страховая стоимость которых находится в заданном диапазоне
    public function query2(){

        return view('form_query2');
    }
    public function query2_res(Query2Request $req){
        $this->price = $req->input('price');
        $this->price2 = $req->input('price2');
        $cars = DB::table('cars')
            ->join('brands', 'cars.brand_id', '=', 'brands.id')
            ->join('colors', 'cars.color_id', '=', 'colors.id')
            ->whereBetween('insurance', [$this->price, $this->price2])
            ->select('cars.id', 'brand', 'color', 'yearRelease', 'num', 'insurance', 'price')
            ->get();
        return view('cars', ['cars' => $cars]);
    }
    // Выбирает информацию о клиентах, серия-номер паспорта которых начинается с заданной цифры.
    // Включает поля Код клиента, Паспорт, Дата начала проката, Количество дней проката, Модель автомобиля
    public  function query3(){
        return view('form_query3');
    }
    public function query3_res(Request $req){
        $this->price = $req->input('price');
        $clients = DB::table('rentals')
            ->join('cars', 'rentals.car_id', '=', 'cars.id')
            ->join('clients', 'rentals.client_id', '=','clients.id')
            ->where('passport', 'like', $this->price)
            ->select('clients.id', 'passport', 'start_date', 'count', 'brand_id')
            ->get();
        return view('query3', ['clients' => $clients]);
    }
}
