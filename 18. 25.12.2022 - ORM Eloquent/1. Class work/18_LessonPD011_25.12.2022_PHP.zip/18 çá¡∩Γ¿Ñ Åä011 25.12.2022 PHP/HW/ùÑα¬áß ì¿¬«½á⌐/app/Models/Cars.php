<?php

namespace App\Models;

class Cars
{
    public int $id;
    public string $brand;      // модель
    public string $color;      // цвет
    public int $yearRelease;          // год выпуска
    public string $num;        // гос номер
    public int $insurance;     // страхование
    public int $price;         // Стоимость одного дня проката
    public static function showTop() : void{
        echo "<table>
              <thead>
              <tr>
              <th>id</th>
              <th>бренд</th>
              <th>цвет</th>
              <th>год выпуска</th>
              <th>госномер</th>
              <th>страховка</th>
              <th>цена</th>
              </tr>
              </thead>";
    }
    public function __toString(){
        return "<tr>
                <td>$this->id</td>
                <td>$this->brand</td>
                <td>$this->color</td>
                <td>$this->yearRelease</td>
                <td>$this->num</td>
                <td>$this->insurance</td>
                <td>$this->price</td>
                </tr>";
    }
}
