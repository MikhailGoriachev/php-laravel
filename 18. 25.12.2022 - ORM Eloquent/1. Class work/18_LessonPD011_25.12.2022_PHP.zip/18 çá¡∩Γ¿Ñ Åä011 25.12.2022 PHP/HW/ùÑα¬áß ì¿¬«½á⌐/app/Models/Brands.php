<?php

namespace App\Models;

class Brands
{
    public int $id;
    public string $brand;
    public static function showTop(): void{
        echo "<table>
              <thead>
              <tr>
              <th>id</th>
              <th>Бренд</th>
              </tr>
              </thead>";

    }
    public function __toString(){
        return "<tr><td>$this->id</td><td>$this->brend</td></tr>";
    }
}
