﻿

<?php $__env->startSection('title', 'Запрос 6'); ?>

<?php $__env->startSection('queriesActive', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">

        <h4 class="text-center">Запрос 6</h4>

        <div class="row">
            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Модель</th>
                    <th>Цвет</th>
                    <th>Госномер</th>
                    <th>Год выпуска</th>
                    <th>Страховая плата</th>
                    <th>Цена проката (сутки)</th>
                    <th>Страховой взнос</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $data->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="align-middle">
                        <th><?php echo e($item->id); ?></th>
                        <td><?php echo e($item->brand_name); ?></td>
                        <td><?php echo e($item->color_name); ?></td>
                        <td><?php echo e($item->plate); ?></td>
                        <td><?php echo e($item->year_manufacture); ?></td>
                        <td><?php echo e($item->inshurance_pay); ?></td>
                        <td><?php echo e($item->rental); ?></td>
                        <td><?php echo e($item->rental * 0.9); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\18 Занятие ПД011 25.12.2022 PHP\HW\Горячев Михаил\resources\views/carRentals/queries/query06.blade.php ENDPATH**/ ?>