﻿

<?php $__env->startSection('title', 'Модели'); ?>

<?php $__env->startSection('tablesActive', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">
        <h4 class="text-center">Прокаты</h4>

        <div class="row">
            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Клиент</th>
                    <th>Паспорт</th>
                    <th>Модель</th>
                    <th>Цвет</th>
                    <th>Номер</th>
                    <th>Страх. стоимость</th>
                    <th>Аренда</th>
                    <th>Дата</th>
                    <th>Длительность</th>
                    <th class="text-center">
                        <a class="btn btn-success" href="add/rental"><i class="bi bi-plus-lg"></i>Добавить...</a>
                    </th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $data->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="align-middle">
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->last_name . ' ' . mb_substr($item->first_name, 0, 1) . '.' .
                            mb_substr($item->patronymic, 0, 1) . '.'); ?>

                        </td>
                        <td><?php echo e($item->passport); ?></td>
                        <td><?php echo e($item->brand_name); ?></td>
                        <td><?php echo e($item->color_name); ?></td>
                        <td><?php echo e($item->plate); ?></td>
                        <td><?php echo e($item->inshurance_pay); ?></td>
                        <td><?php echo e($item->rental); ?></td>
                        <td><?php echo e($item->date_start); ?></td>
                        <td><?php echo e($item->duration); ?></td>
                        <td class='text-center'>
                            <a class="btn btn-warning" href='edit/rental/<?php echo e($item->id); ?>'><i class='bi bi-pencil-fill'></i></a>
                            <a class="btn btn-danger" href="/remove/rental/<?php echo e($item->id); ?>" title="Удалить">
                                <i class="bi bi-trash-fill"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\17. 22.12.2022 -\2. Home work\home-work\resources\views/carRentals/tables/rentals.blade.php ENDPATH**/ ?>