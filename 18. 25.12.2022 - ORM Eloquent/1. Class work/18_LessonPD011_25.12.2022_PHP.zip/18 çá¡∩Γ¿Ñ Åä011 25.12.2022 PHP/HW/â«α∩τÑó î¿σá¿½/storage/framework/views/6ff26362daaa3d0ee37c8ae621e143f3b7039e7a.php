﻿

<?php $__env->startSection('title', 'Ввод размера массива'); ?>

<?php $__env->startSection('arrayActive', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <div class="min-vh-100">
        <section class="w-50 mx-auto my-4 bg-light shadow-sm border rounded-3 p-3">

            <form action="/array/<?php echo e($n); ?>" method="post">
                <?php echo csrf_field(); ?>

                <h4 class="text-center mb-4">Массив. Ввод данных</h4>

                <div class="row">

                    
                    <div class="col">
                        <div class="form-floating">
                            <input name="min" class="form-control" type="number" step="any" placeholder=" "
                                   value="<?php echo e($min); ?>" required>
                            <label class="form-label">Минимум диапазона</label>
                        </div>
                    </div>

                    
                    <div class="col">
                        <div class="form-floating">
                            <input name="max" class="form-control" type="number" step="any" placeholder=" "
                                   value="<?php echo e($max); ?>" required>
                            <label class="form-label">Максимум диапазона</label>
                        </div>
                    </div>

                </div>

                <div class="mt-5">
                    <input class="btn btn-primary w-10rem me-2" type="submit" value="Создать массив">
                    <a class="btn btn-secondary w-10rem" href="/">На главную</a>
                </div>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\13. 12.12.2022 -\2. Home work\home-work\resources\views/calculate/arrayForm.blade.php ENDPATH**/ ?>