﻿

<?php $__env->startSection('title', 'Выражения'); ?>

<?php $__env->startSection('content'); ?>
    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">

        <h4 class="text-center">Выражения</h4>

        <div class="container-fluid">
            <div class="row">
                <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card w-22rem m-3 p-0 shadow-sm">
                        <div class="card-header">
                            <h5 class="text-center">Выражение №<?php echo e($exp['n']); ?></h5>
                        </div>

                        <ul class="list-group list-group-flush">
                            <li class="list-group-item text-center">
                                Исходные данные
                            </li>
                            <li class="list-group-item">
                                &alpha;: <b><?php echo e($exp['a']); ?></b>
                            </li>
                            <li class="list-group-item">
                                &beta;: <b><?php echo e($exp['b']); ?></b>
                            </li>
                            <li class="list-group-item text-center">
                                Результат
                            </li>
                            <li class="list-group-item">
                                z<sub>1</sub>: <b><?php echo e($exp['z1']); ?></b>
                            </li>
                            <li class="list-group-item">
                                z<sub>2</sub>: <b><?php echo e($exp['z2']); ?></b>
                            </li>
                        </ul>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\13. 12.12.2022 -\2. Home work\home-work\resources\views/calculate/evaluate.blade.php ENDPATH**/ ?>
