<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <!-- Подключение к CSS файлам -->
    <link  rel="stylesheet" href="../css/styles.css"/>
    <!-- Подключение Bootstrap -->
    <link  rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<!--#region панель навигации -->
<nav class="navbar navbar-expand-sm bg-dark navbar-dark shadow">
    <div class="container-fluid">
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav">
                <!-- Главная -->
                <li class="nav-item">
                    <a href="../" class="nav-link mx-3">Главная</a></li>
                <!-- Инструкторы -->
                <li class="nav-item">
                    <a href="Proc4.php" class="nav-link  mx-3">Proc4</a></li>
                <li class="nav-item">
                    <a href="Proc11.php" class="nav-link  mx-3">Proc11</a></li>
                <li class="nav-item">
                    <a class="nav-link  mx-3">Proc12</a></li>
                <li class="nav-item">
                    <a href="Proc18.php" class="nav-link  mx-3">Proc18</a></li>
            </ul>
        </div>
    </div>
</nav>

<main>

    <!-- Показ задачи-->
    <p class="m-2">
        <a class="btn btn-primary" data-bs-toggle="collapse" href="#multiCollapse"
           role="button" aria-expanded="true" aria-controls="multiCollapse">Переключить показ задачи</a></p>
    <div class="row">
        <div class="col">
            <div class="collapse multi-collapse" id="multiCollapse">
                <div class="card card-body">
                    <b>Proc12.</b>Описать функцию sortInc3(a, b, c), меняющую содержимое
                    переменных a, b, c таким образом, чтобы их значения оказались
                    упорядоченными по возрастанию (a, b, c — вещественные параметры,
                    являющиеся одновременно входными и выходными). С помощью этой
                    функции упорядочить по возрастанию два данных набора из трех чисел:
                    (a1, b1, c1) и (a2, b2, c2).
                </div>
            </div>
        </div>
    </div>

    <!-- Proc12 -->
    <?php
    // объявление функции
    function sortInc3(&$a, &$b, &$c){
        if ($a > $b){
            $t = $a;
            $a = $b;
            $b = $t;
        }

        if ($a > $c){
            $t = $a;
            $a = $c;
            $c = $t;
        }

        if ($b > $c){
            $t = $b;
            $b = $c;
            $c = $t;
        }
    }

    $a = 1 + rand( 0, (10 - 1) * 100 ) / 100;
    $b = 1 + rand( 0, (10 - 1) * 100 ) / 100;
    $c = 1 + rand( 0, (10 - 1) * 100 ) / 100;
    $i=1;

    $str = "<tr>
                  <td>$i</td>
                  <td>$a</td>
                  <td>$b</td>
                  <td>$c</td>";
    sortInc3($a,$b,$c);
    $str = "$str  <td>$a</td>
                  <td>$b</td>
                  <td>$c</td>
                  </tr>";

    $a = 1 + rand( 0, (10 - 1) * 100 ) / 100;
    $b = 1 + rand( 0, (10 - 1) * 100 ) / 100;
    $c = 1 + rand( 0, (10 - 1) * 100 ) / 100;
    $i++;
    $str = "$str<tr>
                  <td>$i</td>
                  <td>$a</td>
                  <td>$b</td>
                  <td>$c</td>";
    sortInc3($a,$b,$c);
    $str = "$str  <td>$a</td>
                  <td>$b</td>
                  <td>$c</td>
                  </tr>";
    echo <<< _E0T
            <div class="container col-6">
                <table class="table table-striped">
                  <thead>
                   <tr>
                         <td>№</th>
                         <td>a1</th>
                         <td>b1</th>
                         <td>c1</th>
                         <td>a2</th>
                         <td>b2</th>
                         <td>c2</th>
                       </tr>
                    </thead>
                    <tbody>
                        $str
                        </tbody>
                </table>
            </div>
            _E0T;

    ?>

</main>

<!--#region подвал страницы -->
<footer class="container-fluid text-info bg-dark text-center">
    <p class="p-1">Донецк, 2022, ПД011, Гайдаш Дмитрий, <a href="mailto:madventcher@gmail.com" target="_blank">madventcher@gmail.com</a></p>
</footer>
<!--#endregion-->
</body>
</html>