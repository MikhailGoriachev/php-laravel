<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" />
    <!-- Подключение к CSS файлам -->
    <link  rel="stylesheet" href="../css/styles.css"/>
    <!-- Подключение Bootstrap -->
    <link  rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<!--#region панель навигации -->
<nav class="navbar navbar-expand-sm bg-dark navbar-dark shadow">
    <div class="container-fluid">
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav">
                <!-- Главная -->
                <li class="nav-item">
                    <a href="../" class="nav-link mx-3">Главная</a></li>
                <!-- Инструкторы -->
                <li class="nav-item">
                    <a class="nav-link  mx-3">Proc4</a></li>
                <li class="nav-item">
                    <a href="Proc11.php" class="nav-link  mx-3">Proc11</a></li>
                <li class="nav-item">
                    <a href="Proc12.php" class="nav-link  mx-3">Proc12</a></li>
                <li class="nav-item">
                    <a href="Proc18.php" class="nav-link  mx-3">Proc18</a></li>
            </ul>
        </div>
    </div>
</nav>

<main>
    <!-- Показ задачи-->
    <p class="m-2">
        <a class="btn btn-primary" data-bs-toggle="collapse" href="#multiCollapse"
           role="button" aria-expanded="true" aria-controls="multiCollapse">Переключить показ задачи</a></p>
    <div class="row">
        <div class="col">
            <div class="collapse multi-collapse" id="multiCollapse">
                <div class="card card-body">
                    <b>Proc4.</b>Описать функцию trianglePS(a, p, s), вычисляющую по стороне a равностороннего треугольника его периметр p = 3·a и площадь
                    s = a2· sqrt(3)/4 (a — входной, p и s — выходные параметры). С помощью этой функции найти периметры и площади трех равносторонних треугольников с данными сторонами.
                </div>
            </div>
        </div>
    </div>

    <!-- Proc4 -->
     <?php
     // объявление функции
     function trianglePS($a, &$p, &$s){
         $p = 3 * $a;
         $s = 2 * $a * sqrt(3.) / 4.;
     }
     $a = 1 + rand( 0, (10 - 1) * 100 ) / 100;
     trianglePS($a,$p,$s);
     $i=1;
     $s = number_format($s,3);
     $str = "<tr>
                  <td>$i</td>
                  <td>$a</td>
                  <td>$p</td>
                  <td>$s</td>
             </tr>";
     $a = 1 + rand( 0, (10 - 1) * 100 ) / 100;
     trianglePS($a,$p,$s);
     $i++;
     $s = number_format($s,3);
     $str = "$str<tr>
                  <td>$i</td>
                  <td>$a</td>
                  <td>$p</td>
                  <td>$s</td>
             </tr>";
     $a = 1 + rand( 0, (10 - 1) * 100 ) / 100;
     trianglePS($a,$p,$s);
     $i++;
     $s = number_format($s,3);
     $str = "$str<tr>
                  <td>$i</td>
                  <td>$a</td>
                  <td>$p</td>
                  <td>$s</td>
             </tr>";

     echo <<< _E0T
            <div class="container col-6">
                <table class="table table-striped">
                  <thead>
                   <tr>
                         <td>№</th>
                         <td>a</th>
                         <td>p</th>
                         <td>s</th>
                       </tr>
                    </thead>
                    <tbody>
                        $str
                        </tbody>
                </table>
            </div>
            _E0T;

     ?>
</main>

<!--#region подвал страницы -->
<footer class="container-fluid text-info bg-dark text-center">
    <p class="p-1">Донецк, 2022, ПД011, Гайдаш Дмитрий, <a href="mailto:madventcher@gmail.com" target="_blank">madventcher@gmail.com</a></p>
</footer>
<!--#endregion-->
</body>
</html>