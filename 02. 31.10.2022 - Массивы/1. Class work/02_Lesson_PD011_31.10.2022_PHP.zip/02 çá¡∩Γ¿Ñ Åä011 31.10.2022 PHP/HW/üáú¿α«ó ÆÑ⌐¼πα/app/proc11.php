<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width" />
    <!-- Подключение к CSS файлам -->
    <link  rel="stylesheet" href="../css/styles.css"/>
    <!-- Подключение Bootstrap -->
    <link  rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"/>

    <!-- Подключение иконок Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Подключение иконки для вкладки в браузере-->
    <link rel="shortcut icon" href="/imgs/koi-fish.png" type="image/x-icon" />
</head>

<body>
<!--#region панель навигации -->
<nav class="navbar navbar-expand-sm bg-dark navbar-dark shadow">
    <div class="container-fluid">
        <a class="navbar-brand mx-2" href="../index.html">
            <img class="img-brand" src="../imgs/brand.png" alt="brand">
        </a>

        <div class="collapse navbar-collapse">
            <ul class="navbar-nav">
                <!-- Proc 4 - вычисление площади и периметра равностороннего треугольника -->
                <li class="nav-item">
                    <a class="nav-link mx-3" href="proc4.php">Proc 4 trianglePS</a>
                </li>

                <!-- Proc 11 - определение максимального и минимально из двух чисел -->
                <li class="nav-item">
                    <a class="nav-link  mx-3" href="proc11.php">Proc 11 minMax</a>
                </li>

                <!-- Proc 12 - сортировка по возрастанию -->
                <li class="nav-item">
                    <a class="nav-link  mx-3" href="proc12.php">Proc 12 sortInc3</a>
                </li>

                <!-- Proc 18 - нахождение площади круга с радиусом r -->
                <li class="nav-item">
                    <a class="nav-link  mx-3" href="proc18.php">Proc 18 circleS</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!--#endregion -->

<main>

    <h1 class="text-primary text-center mt-3"> Proc 11 </h1>
    <div class="container col-8">
        <h3 class="text-primary">Условие задачи</h3>
        <p>
            <b>Proc11.</b> Описать функцию <i>minMax(x, y)</i>, записывающую в переменную x минимальное из значений x и y,
            а в переменную y — максимальное из этих значений
            (x и y — вещественные параметры, являющиеся одновременно входными и выходными).
            Используя четыре вызова этой функции, найти минимальное и максимальное из данных чисел a, b, c, d.
        </p>

        <?php
        // объявление функции
        function minMax(&$x, &$y){
            if ($x > $y):
                $temp = $x;
                $x = $y;
                $y = $temp;
            endif;
        }

        $a = 1 + rand(0, 100) / (100 / (10 - 1));
        $b = 1 + rand(0, 100) / (100 / (10 - 1));
        $c = 1 + rand(0, 100) / (100 / (10 - 1));
        $d = 1 + rand(0, 100) / (100 / (10 - 1));
        $number = 1;
        $str = "<tr><td class='text-center'>$number</td><td class='text-center'>Исходные</td><td class='text-center'>$a</td>" .
               "<td class='text-center'>$b</td><td class='text-center'>$c</td><td class='text-center'>$d</td>".
               "<td class='text-center'></td><td class='text-center'></td></tr>";
        $number++;

        $str = $str . "<tr><td class='text-center'>$number</td><td class='text-center'>a и b</td><td class='text-center'>$a</td>" .
               "<td class='text-center'>$b</td><td class='text-center'></td><td class='text-center'></td>";
        minMax($a,$b);
        $str = $str . "<td class='text-center'>$a</td><td class='text-center'>$b</td></tr>";
        $number++;

        $str = $str . "<tr><td class='text-center'>$number</td><td class='text-center'>c и d</td><td class='text-center'></td>" .
               "<td class='text-center'></td><td class='text-center'>$c</td><td class='text-center'>$d</td>";
        minMax($c,$d);
        $str = $str . "<td class='text-center'>$c</td><td class='text-center'>$d</td></tr>";
        $number++;

        $str = $str . "<tr><td class='text-center'>$number</td><td class='text-center'>max(a, b) и max(c, d)</td><td class='text-center'></td>" .
               "<td class='text-center'>$b</td><td class='text-center'></td><td class='text-center'>$d</td>";
        minMax($b,$d);
        $str = $str . "<td class='text-center'>$b</td><td class='text-center'>$d</td></tr>";
        $number++;

        $str = $str . "<tr><td class='text-center'>$number</td><td class='text-center'>min(a, b) и min(c, d)</td><td class='text-center'>$a</td>" .
               "<td class='text-center'></td><td class='text-center'>$c</td><td class='text-center'></td>";
        minMax($a,$c);
        $str = $str . "<td class='text-center'>$a</td><td class='text-center'>$c</td></tr>";
        $number++;

        echo  <<< _EOT
                <table class="table table-striped align-middle">
                    <thead>
                        <tr>
                            <th class="text-center">№</th>
                            <th class="text-center">сравнение</th>
                            <th class="text-center">a</th>
                            <th class="text-center">b</th>
                            <th class="text-center">c</th> 
                            <th class="text-center">d</th> 
                            <th class="text-center">min</th> 
                            <th class="text-center">max</th> 
                        </tr>
                    </thead> 
                    <tbody class="table-group-divider"> 
                        $str
                    </tbody>
                </table>
            _EOT;

        ?>

    </div>
</main>

<!--#region подвал страницы -->
<footer class="container-fluid bg-black text-light text-center">
    <p class="p-1">Багиров Теймур ПД011, г. Донецк 2022г; адрес разработчика: <a href="mailto:t.bagirov2000@gmail.com" target="_blank">t.bagirov2000@gmail.com</a></p>
</footer>
<!--#endregion-->

</body>
</html>
