<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width" />
    <!-- Подключение к CSS файлам -->
    <link  rel="stylesheet" href="../css/styles.css"/>
    <!-- Подключение Bootstrap -->
    <link  rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"/>

    <!-- Подключение иконок Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Подключение иконки для вкладки в браузере-->
    <link rel="shortcut icon" href="/imgs/koi-fish.png" type="image/x-icon" />
</head>

<body>
<!--#region панель навигации -->
<nav class="navbar navbar-expand-sm bg-dark navbar-dark shadow">
    <div class="container-fluid">
        <a class="navbar-brand mx-2" href="../index.html">
            <img class="img-brand" src="../imgs/brand.png" alt="brand">
        </a>

        <div class="collapse navbar-collapse">
            <ul class="navbar-nav">
                <!-- Proc 4 - вычисление площади и периметра равностороннего треугольника -->
                <li class="nav-item">
                    <a class="nav-link mx-3" href="proc4.php">Proc 4 trianglePS</a>
                </li>

                <!-- Proc 11 - определение максимального и минимально из двух чисел -->
                <li class="nav-item">
                    <a class="nav-link  mx-3" href="proc11.php">Proc 11 minMax</a>
                </li>

                <!-- Proc 12 - сортировка по возрастанию -->
                <li class="nav-item">
                    <a class="nav-link  mx-3" href="proc12.php">Proc 12 sortInc3</a>
                </li>

                <!-- Proc 18 - нахождение площади круга с радиусом r -->
                <li class="nav-item">
                    <a class="nav-link  mx-3" href="proc18.php">Proc 18 circleS</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!--#endregion -->

<main>

    <h1 class="text-primary text-center mt-3"> Proc 12 </h1>
    <div class="container col-8">
        <h3 class="text-primary">Условие задачи</h3>
        <p>
            <b>Proc12.</b> Описать функцию <i>sortInc3(a, b, c)</i>, меняющую содержимое переменных a, b, c таким образом,
            чтобы их значения оказались упорядоченными по возрастанию
            (a, b, c — вещественные параметры, являющиеся одновременно входными и выходными).
            С помощью этой функции упорядочить по возрастанию два данных набора из трех чисел: (a1, b1, c1) и (a2, b2, c2).
        </p>

        <?php
        // объявление функции
        function sortInc3(&$a, &$b, &$c){
            $temp = 0.;
            if($a > $b){
                $temp = $a;
                $a = $b;
                $b = $temp;
            }

            if($b > $c){
                $temp = $c;
                $c = $b;
                $b = $temp;
            }

            if($a > $c){
                $temp = $a;
                $a = $c;
                $c = $temp;
            }
        }

        $a = 1 + rand(0, 100) / (100 / (10 - 1));
        $b = 1 + rand(0, 100) / (100 / (10 - 1));
        $c = 1 + rand(0, 100) / (100 / (10 - 1));
        $number = 1;
        $str = "<tr><td class='text-center'>$number</td><td class='text-center'>Исходный набор</td><td class='text-center'>$a</td>" .
            "<td class='text-center'>$b</td><td class='text-center'>$c</td>";
        sortInc3($a,$b,$c);
        $str = $str . "<tr><td class='text-center'></td><td class='text-center'>Отсортированный набор</td><td class='text-center'>$a</td>" .
            "<td class='text-center'>$b</td><td class='text-center'>$c</td>";
        $number++;

        $a = 1 + rand(0, 100) / (100 / (10 - 1));
        $b = 1 + rand(0, 100) / (100 / (10 - 1));
        $c = 1 + rand(0, 100) / (100 / (10 - 1));
        $str = $str . "<tr><td class='text-center'>$number</td><td class='text-center'>Исходный набор</td><td class='text-center'>$a</td>" .
            "<td class='text-center'>$b</td><td class='text-center'>$c</td>";
        sortInc3($a,$b,$c);
        $str = $str . "<tr><td class='text-center'></td><td class='text-center'>Отсортированный набор</td><td class='text-center'>$a</td>" .
            "<td class='text-center'>$b</td><td class='text-center'>$c</td>";
        $number++;

        echo  <<< _EOT
                <table class="table table-striped align-middle">
                    <thead>
                        <tr>
                            <th class="text-center">№</th>
                            <th class="text-center">сравнение</th>
                            <th class="text-center">a</th>
                            <th class="text-center">b</th>
                            <th class="text-center">c</th>  
                        </tr>
                    </thead> 
                    <tbody class="table-group-divider"> 
                        $str
                    </tbody>
                </table>
            _EOT;

        ?>

    </div>
</main>

<!--#region подвал страницы -->
<footer class="container-fluid bg-black text-light text-center">
    <p class="p-1">Багиров Теймур ПД011, г. Донецк 2022г; адрес разработчика: <a href="mailto:t.bagirov2000@gmail.com" target="_blank">t.bagirov2000@gmail.com</a></p>
</footer>
<!--#endregion-->

</body>
</html>
