<nav class="navbar navbar-expand-sm navbar-main bg-body sticky-top shadow mb-2">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#appNavbarMain">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="appNavbarMain">
            <ul class="navbar-nav ms-3">
                <li class="nav-item me-2">
                    <a href="../../index.php" class="nav-link <?= PAGE == 'index' ? 'active' : ''; ?>" title="Перейти на страницу">
                        Главная </a>
                </li>
                <li class="nav-item me-2">
                    <a href="/pages/proc4.php" class="nav-link <?= PAGE == 'proc4' ? 'active' : ''; ?>" title="Перейти на страницу">
                        Proc 4 </a>
                </li>
                <li class="nav-item me-2">
                    <a href="/pages/proc11.php" class="nav-link <?= PAGE == 'proc11' ? 'active' : ''; ?>" title="Перейти на страницу">
                        Proc 11 </a>
                </li>
                <li class="nav-item me-2">
                    <a href="/pages/proc12.php" class="nav-link <?= PAGE == 'proc12' ? 'active' : ''; ?>" title="Перейти на страницу">
                        Proc 12 </a>
                </li>
                <li class="nav-item me-2">
                    <a href="/pages/proc18.php" class="nav-link <?= PAGE == 'proc18' ? 'active' : ''; ?>" title="Перейти на страницу">
                        Proc 18 </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
