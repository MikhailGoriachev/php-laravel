<?php
include_once("../inc/functions.php");
const HEADER = 'Proc 12';
const PAGE = 'proc12';

const MIN = 1;
const MAX = 10;
const COUNT = 2;

$a = null;
$b = null;
$c = null;
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="../css/style.css">

    <title><?= HEADER; ?> - Домашняя Работа</title>
</head>

<body>
<?php include_once("../inc/partial/header.php") ?>
<?php include_once("../inc/partial/navbar.php") ?>

<div class="container-fluid mh-100 mh-80-vh">
    <main class="mt-4 mx-5" id="main">
        <h5>Упорядочивание значений по возрастанию:</h5>
        <table class="table mt-3 w-25">
            <thead>
            <th>Начальные значения</th>
            <th>Упорядоченные значения</th>
            </thead>
            <tbody>
            <?php for ($i = 0; $i < COUNT; $i++) {
                $a = getRandomFloat(MIN, MAX);
                $b = getRandomFloat(MIN, MAX);
                $c = getRandomFloat(MIN, MAX); ?>

                <tr>
                    <td><?= number_format($a, 2) ?>,
                        <?= number_format($b, 2) ?>,
                        <?= number_format($c, 2) ?></td>

                    <?php sortInc3($a, $b, $c); ?>

                    <td><?= number_format($a, 2) ?>,
                        <?= number_format($b, 2) ?>,
                        <?= number_format($c, 2) ?></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </main>
</div>

<?php include_once("../inc/partial/footer.php") ?>

</body>
</html>
