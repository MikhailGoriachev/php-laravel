<?php
include_once("../inc/functions.php");
const HEADER = 'Proc 12';
const PAGE = 'proc12';

const MIN = 1;
const MAX = 10;
const COUNT = 2;

ob_start();
?>

<h5>Упорядочивание значений по возрастанию:</h5>

<table class="table mt-3 w-25">
    <thead>
    <tr>
        <th>Начальные значения</th>
        <th>Упорядоченные значения</th>
    </tr>
    </thead>
    <tbody>
    <?php for ($i = 0; $i < COUNT; $i++) {
        $a = getRandomFloat(MIN, MAX);
        $b = getRandomFloat(MIN, MAX);
        $c = getRandomFloat(MIN, MAX); ?>

        <tr>
            <td><?= number_format($a, 2) ?>,
                <?= number_format($b, 2) ?>,
                <?= number_format($c, 2) ?></td>

            <?php sortInc3($a, $b, $c); ?>

            <td><?= number_format($a, 2) ?>,
                <?= number_format($b, 2) ?>,
                <?= number_format($c, 2) ?></td>
        </tr>
    <?php } ?>
    </tbody>
</table>


<?php
$content = ob_get_clean();
include_once("../inc/layout.php");
?>

