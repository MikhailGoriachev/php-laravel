<?php
include_once("../inc/functions.php");
const HEADER = 'Proc 18';
const PAGE = 'proc18';

const MIN = 1;
const MAX = 10;
const COUNT = 3;

ob_start();
?>

<h5>Площадь круга:</h5>

<table class="table mt-3 w-25">
    <thead>
    <tr>
        <th>Радиус</th>
        <th>Площадь</th>
    </tr>
    </thead>
    <tbody>
    <?php for ($i = 0; $i < COUNT; $i++) {
        $r = getRandomFloat(MIN, MAX); ?>
        <tr>
            <td><?= number_format($r, 2) ?></td>
            <td><?= number_format(circleS($r), 2) ?></td>
        </tr>
    <?php } ?>
    </tbody>
</table>

<?php
$content = ob_get_clean();
include_once("../inc/layout.php");
?>
