<?php
include_once("../inc/functions.php");

const HEADER = 'Proc 4';
const PAGE = 'proc4';
const MIN = 1;
const MAX = 10;
const COUNT = 3;

ob_start();
?>

<h5>Площадь и периметр равносторонних треугольников:</h5>

<table class="table mt-3 w-25">
    <thead>
    <tr>
        <th>Сторона</th>
        <th>Площадь</th>
        <th>Периметр</th>
    </tr>
    </thead>
    <tbody>
    <?php for ($i = 0; $i < COUNT; $i++) {
        $a = getRandomFloat(MIN, MAX);
        trianglePS($a, $p, $s); ?>
        <tr>
            <td><?= number_format($a, 2) ?></td>
            <td><?= number_format($p, 2) ?></td>
            <td><?= number_format($s, 2) ?></td>
        </tr>
    <?php } ?>
    </tbody>
</table>

<?php
$content = ob_get_clean();
include_once("../inc/layout.php");
?>
