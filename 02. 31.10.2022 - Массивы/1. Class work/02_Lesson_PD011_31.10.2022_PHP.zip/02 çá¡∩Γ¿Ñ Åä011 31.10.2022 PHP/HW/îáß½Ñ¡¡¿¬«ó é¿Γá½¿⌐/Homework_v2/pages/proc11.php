<?php
include_once("../inc/functions.php");

const HEADER = 'Proc 11';
const PAGE = 'proc11';

const MIN = 1;
const MAX = 10;

$a = getRandomFloat(MIN, MAX);
$b = getRandomFloat(MIN, MAX);
$c = getRandomFloat(MIN, MAX);
$d = getRandomFloat(MIN, MAX);

$min1 = $a;
$max1 = $b;
$min2 = $c;
$max2 = $d;

minMax($min1, $max1);
minMax($min2, $max2);
minMax($min1, $min2);
minMax($max1, $max2);

ob_start();
?>

<div class="card w-25">
    <div class="card-header"><b>Минимальное и максимальное из четырех чисел:</b></div>
    <div class="card-body">
        <div>a = <?= number_format($a, 2); ?>,
            b = <?= number_format($b, 2); ?>,
        </div>
        <div>c = <?= number_format($c, 2); ?>,
            d = <?= number_format($d, 2); ?>,
        </div>
    </div>
    <div class="card-footer">
        <div>min = <?= number_format($min1, 2); ?></div>
        <div>max = <?= number_format($max2, 2); ?></div>
    </div>
</div>

<?php
$content = ob_get_clean();
include_once("../inc/layout.php");
?>
