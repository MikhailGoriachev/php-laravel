<?php

function getRandomFloat($from, $to): float|int
{
    return mt_rand($from, $to - 1) + mt_rand() / mt_getrandmax();
}

function trianglePS($a, &$p, &$s): void
{
    $p = 3 * $a;
    $s = $a ** 2 * sqrt(3) / 4;
}

function minMax(&$x, &$y): void
{
    if ($x > $y) {
        $temp = $x;
        $x = $y;
        $y = $temp;
    }
}

function sortInc3(&$a, &$b, &$c): void
{
    minMax($a, $c);
    minMax($a, $b);
    minMax($b, $c);
}

function circleS($r): float|int
{
    return pi() * $r ** 2;
}
