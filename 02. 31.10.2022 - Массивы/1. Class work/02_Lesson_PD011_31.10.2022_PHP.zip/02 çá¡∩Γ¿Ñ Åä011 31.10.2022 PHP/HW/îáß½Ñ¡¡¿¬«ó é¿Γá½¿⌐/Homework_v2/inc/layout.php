<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="../css/style.css">

    <title><?= HEADER; ?> - Домашняя Работа</title>
</head>

<body>
<?php include_once("partial/header.php") ?>
<?php include_once("partial/navbar.php") ?>

<div class="container-fluid mh-100 mh-80-vh">
    <main class="mt-4 mx-5" id="main">

        <?php if (isset($content)) {
            echo $content;
        }; ?>

    </main>
</div>

<?php include_once("partial/footer.php") ?>

</body>
</html>