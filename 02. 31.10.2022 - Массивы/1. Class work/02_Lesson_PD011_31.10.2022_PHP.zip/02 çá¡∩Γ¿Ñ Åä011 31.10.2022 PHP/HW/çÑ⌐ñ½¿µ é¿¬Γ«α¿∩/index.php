<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Стили -->
    <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
    <!-- внешнее подключение стилевого файла  -->
    <link rel="stylesheet" href="style/index.css">
    <!-- Скрипты -->
    <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="lib/bootstrap-icons/bootstrap-icons.css">

    <title>HomeWork</title>

    <!-- логотип -->
    <link rel="shortcut icon" type="image/x-icon" href="img/program-64.png">
</head>
<body class="body">

<main>
    <nav class="navbar navbar-expand-sm bg-primary navbar-light" >
        <div class="container-fluid">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">На главную</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="./htdocs/page1.php">Proc4</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="./htdocs/page2.php">Proc11</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="./htdocs/page3.php">Proc12</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="./htdocs/page4.php">Proc18</a>
                </li>
            </ul>
        </div>
    </nav>

    <section class="col-12 col-md-12 px-5 mt-3">
        <h2 class="h2">Теоретическая часть</h2>
        <ul>
            <li>Понятие о PHP, для чего нужен PHP</li>
            <li>Серверные теги PHP, базовый синтаксис PHP</li>
            <li>Основные типы данных, переменные</li>
            <li>Вывод, оператор echo, функция <b>printf()</b> – форматированный вывод</li>
            <li>Основные операции языка</li>
            <li>Операторы <b>if(), if() else, if() elseif() … else, switch() … case</b></li>
            <li>Понятие о функциях, передача параметров по значению, по ссылке</li>
            <li>Константы в PHP, определение констант, предопределенные константы </li>
            <li>Специальный тип <b>null</b></li>
            <li>Проверка принадлежности переменной заданному типу, получение типа переменной, назначение типа переменной</li>
            <li>Понятие о <b>heredoc</b>-синтаксисе, <b>newdoc</b>-синтаксисе для вывода длинных строк с большим количеством разметки</li>
            <li>Логические и битовые операции в PHP</li>
            <li>Запись чисел в шестнадцатеричной, восьмеричной и двоичной системах счисления</li>
        </ul>

        <h2 class="h2">Практическая часть</h2>
        <p>
            Разработайте веб-приложение на языке <b>PHP</b> с использованием изученных возможностей. На главной странице разместите
            также текст этого задания.  Результаты должны быть выделены (например, выделение цветом и жирностью). Выполнить
            стилизацию приложения при помощи Bootstrap или другими наборами стилей. Обязательно используйте навигационное меню,
            каждую задачу реализуйте на собственной странице.
        </p>
        <p>
            На странице задачи отображать условие задачи, выводить результаты работы задачи. Все числовые значения для выполнения
            задач формировать при помощи функции – генератора случайных чисел, не используйте формы, циклы.
        </p>
        <ul>
            <li>
                <b>Proc4</b>. Описать функцию trianglePS(a, p, s), вычисляющую по стороне a равностороннего треугольника его периметр p = 3·a и площадь
                s = a2· sqrt(3)/4 (a — входной, p и s — выходные параметры). С помощью этой функции найти периметры и площади
                трех равносторонних треугольников с данными сторонами.
            </li>
            <li>
                <b>Proc11</b>. Описать функцию minMax(x, y), записывающую в переменную x минимальное из значений x и y, а в
                переменную y — максимальное из этих значений (x и y — вещественные параметры, являющиеся одновременно входными и
                выходными). Используя четыре вызова этой функции, найти минимальное и максимальное из данных чисел a, b, c, d.
            </li>
            <li>
                <b>Proc12</b>. Описать функцию sortInc3(a, b, c), меняющую содержимое переменных a, b, c таким образом, чтобы
                их значения оказались упорядоченными по возрастанию (a, b, c — вещественные параметры, являющиеся одновременно
                входными и выходными). С помощью этой функции упорядочить по возрастанию два данных набора из трех чисел: (a1, b1, c1) и (a2, b2, c2).
            </li>
            <li>
                <b>Proc18</b>. Описать функцию circleS(r), находящую площадь круга радиуса r (r — вещественное). С помощью этой
                функции найти площади трех кругов с радиусами – случайными числами. Площадь круга радиуса R вычисляется по формуле S = π·R2.
            </li>
        </ul>

        <h2 class="h2">Дополнительно</h2>
        <p>Запись занятия можно скачать по <a href="https://cloud.mail.ru/public/uFgy/7YBa2v3kY"><b>этой ссылке</b></a>.
            Материалы занятия в этом же архиве. </p>
    </section>
</main>

<!-- подвал страницы-->
<footer class="container-fluid">
    <div id="footer" class="row col-12">
        <h3>Данные о разработчике:</h3>
        <p>
            группа:<b> ПД011 г.Донецк 2022г.</b><br>студент: <b>Зейдлиц Виктория</b>
        </p>
    </div>
</footer>
</body>
</html>
