<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Стили -->
    <link rel="stylesheet" href="/lib/bootstrap/css/bootstrap.min.css">
    <!-- внешнее подключение стилевого файла  -->
    <link rel="stylesheet" href="/style/index.css">
    <!-- Скрипты -->
    <script src="/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="/lib/bootstrap-icons/bootstrap-icons.css">

    <title>HomeWork</title>

    <!-- логотип -->
    <link rel="shortcut icon" type="image/x-icon" href="/img/program-64.png">
</head>
<body class="body">

<main>
    <nav class="navbar navbar-expand-sm bg-primary navbar-light" >
        <div class="container-fluid">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">На главную</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="page1.php">Proc4</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="page2.php">Proc11</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="page3.php">Proc12</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="page4.php">Proc18</a>
                </li>
            </ul>
        </div>
    </nav>
    <section class="col-12 col-md-12 px-5 mt-3">
        <!-- Задача Proc12 -->
        <div class="accordion accordion-flush" id="accordionFlushExample">
            <div>
                <h2 class="accordion-header" id="flush-heading">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse" aria-expanded="false" aria-controls="flush-collapse">
                        Задача Proc12
                    </button>
                </h2>
                <div id="flush-collapse" class="accordion-collapse collapse" aria-labelledby="flush-heading" data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body">
                        <b>Proc12</b>. Описать функцию sortInc3(a, b, c), меняющую содержимое переменных a, b, c таким образом,
                        чтобы их значения оказались упорядоченными по возрастанию (a, b, c — вещественные параметры, являющиеся
                        одновременно входными и выходными). С помощью этой функции упорядочить по возрастанию два данных набора из трех чисел: (a1, b1, c1) и (a2, b2, c2).
                    </div>
                </div>
            </div>
        </div>

        <!-- Решение Proc12 -->
        <div class="mt-3">
            <?php
            require_once("../functions.php");
            $a = rand(-10, 10);
            $b = rand(-10, 10);
            $c = rand(-10, 10);
            echo "Значения :  a1 = $a, b1 =$b, c1 = $c";
            sortInc($a, $b, $c);
            ?>
            <br>
            <br>
            <?php echo "Значения упорядочены:  a1 = $a, b1 =$b, c1 = $c"?>
            <hr>
            <?php
            $a = rand(-10, 10);
            $b = rand(-10, 10);
            $c = rand(-10, 10);
            echo "Значения :  a2 = $a, b2 =$b, c2 = $c";
            sortInc($a, $b, $c);
            ?>
            <br>
            <br>
            <?php echo "Значения упорядочены:  a2 = $a, b2 =$b, c2 = $c"?>
        </div>
    </section>

</main>

<!-- подвал страницы-->
<footer class="container-fluid">
    <div id="footer" class="row col-12">
        <h3>Данные о разработчике:</h3>
        <p>
            группа:<b> ПД011 г.Донецк 2022г.</b><br>студент: <b>Зейдлиц Виктория</b>
        </p>
    </div>
</footer>
</body>
</html>
<?php

