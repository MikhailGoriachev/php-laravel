<?php

// Задача proc4
// (a — входной, p и s — выходные параметры)
function trianglePS(float $a, &$p,&$s) {

    // вычисление периметра и площади
    $p = 3 * $a;
    $s = $a * $a * M_SQRT3 / 4;
} // trianglePS


// Задача proc11
// (x и y — являющиеся одновременно входными и выходными)
function minMax(&$x, &$y){
    if($x > $y) {
        $x += $y;
        $y = $x - $y;
        $x -= $y;
    }
} // minMax


// Задача proc12
// (a, b, c — являющиеся одновременно входными и выходными)
function sortInc(&$a, &$b, &$c){

   if($a > $b) [$a, $b] = [$b, $a];
   if($a > $c) [$a, $c] = [$c, $a];
   if($b > $c) [$b, $c] = [$c, $b];

} // sortInc


// Задача proc18
function circleS(float $r){

   return M_PI * $r * $r;

} // circleS


// lcg_value() возвращает псевдослучайное число в диапазоне (0, 1)
// случайное вещественное число
function random_float($min, $max)
{
    return($min + lcg_value() * (abs($max - $min)));
}