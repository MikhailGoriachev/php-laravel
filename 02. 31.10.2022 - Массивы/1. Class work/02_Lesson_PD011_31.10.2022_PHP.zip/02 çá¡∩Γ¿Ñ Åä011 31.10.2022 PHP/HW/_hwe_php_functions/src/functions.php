<?php

require_once "utils.php";

// Proc4.
// Описать функцию trianglePS(a, p, s), вычисляющую по стороне a равностороннего
// треугольника его периметр p = 3·a и площадь s = a**2· sqrt(3)/4 (a — входной,
// p и s — выходные параметры).
function trianglePS($a, &$p, &$s) {
    $p = 3 * $a;
    $s = $a * $a * sqrt(3) / 4;
} // trianglePS


// вывод строки таблицы для задачи Proc4
function toTableRowProc04($row, $a, $p, $s) {
    echo "<tr>
        <td>$row</td>
        <td class='text-end pe-3'>".sprintf("%.3f", $a)."</td>
        <td class='text-end pe-3'>".sprintf("%.3f", $p)."</td>
        <td class='text-end pe-3'>".sprintf("%.3f", $s)."</td>
    </tr>";
} // toTableRowProc04

// С помощью функции trianglePS(a, p, s) найти периметры и площади трех
// равносторонних треугольников с данными сторонами.
function proc4() {
    // цикл не используем по заданию :)
    $row = 1;
    $a = random_float(10, 50);
    trianglePS($a, $p, $s);
    toTableRowProc04($row++, $a, $p, $s);

    $a = random_float(10, 50);
    trianglePS($a, $p, $s);
    toTableRowProc04($row++, $a, $p, $s);

    $a = random_float(10, 50);
    trianglePS($a, $p, $s);
    toTableRowProc04($row++, $a, $p, $s);
} // proc4

// Proc11.
// Описать функцию minMax(x, y), записывающую в переменную x минимальное
// из значений x и y, а в переменную y — максимальное из этих значений
// (x и y — вещественные параметры, являющиеся одновременно входными
// и выходными).
function minMax(&$x, &$y) {
    // if ($x > $y) [$x, $y] = [$y, $x];
    if ($x > $y) swap($x, $y);
} // minMax

// Используя четыре вызова этой функции, найти минимальное и максимальное
// из данных чисел a, b, c, d.
function proc11() {
    $a = random_float(-100, 100);
    $b = random_float(-100, 100);
    $c = random_float(-100, 100);
    $d = random_float(-100, 100);

    // вывод исходных данных
    echo "
        <h5>Исходные данные</h5>
        <table class='table table-bordered w-50'>
            <thead>
                <tr>
                    <th class='text-end pe-3'>a</th>
                    <th class='text-end pe-3'>b</th>
                    <th class='text-end pe-3'>c</th>
                    <th class='text-end pe-3'>d</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class='text-end pe-3'>".sprintf("%.3f", $a)."</td>
                    <td class='text-end pe-3'>".sprintf("%.3f", $b)."</td>
                    <td class='text-end pe-3'>".sprintf("%.3f", $c)."</td>
                    <td class='text-end pe-3'>".sprintf("%.3f", $d)."</td>
                </tr>
            </tbody>
        </table> 
    ";

    // определение минимального и максимального значений
    // $a, $c - минимальные значения пар
    // $b, $s - максимальные значения пар
    minMax($a, $b);
    minMax($c, $d);

    // минимальный - это минимальный из минимальных
    // значение будет в переменной $a
    minMax($a, $c);

    // максимальный - это максимальный из максимальных
    // значение будет в переменной $d
    minMax($b, $d);

    // вывод результата
    echo "
        <h5>Результаты вычислений</h5>
        <ul class='ms-5'>
            <li>Минимальное значение: <b>".sprintf("%.3f", $a)."</b></li>
            <li>Максимальное значение: <b>".sprintf("%.3f", $d)."</b></li>
        </ul>   
    ";
} // proc11


// Proc12.
// Описать функцию sortInc3(a, b, c), меняющую содержимое переменных a, b, c
// таким образом, чтобы их значения оказались упорядоченными по возрастанию
// (a, b, c — вещественные параметры, являющиеся одновременно входными
// и выходными).
function sortInc3(&$a, &$b, &$c) {
    minMax($a, $b);
    minMax($b, $c);
    minMax($a, $b);
} // sortInc3

// выод строки таблицы для proc12
function toTableRowProc12($text, $a, $b, $c) {
    echo "<tr>
        <td class='text-start'>$text</td>
        <td class='text-end pe-3'>".sprintf("%.3f", $a)."</td>
        <td class='text-end pe-3'>".sprintf("%.3f", $b)."</td>
        <td class='text-end pe-3'>".sprintf("%.3f", $c)."</td>
    </tr>";
}

// С помощью этой функции упорядочить по возрастанию два данных набора из трех
// чисел: (a1, b1, c1) и (a2, b2, c2).
function proc12() {
    $a = random_float(-100, 100);
    $b = random_float(-100, 100);
    $c = random_float(-100, 100);

    // вывод исходных данных
    toTableRowProc12("Исходный набор 1", $a, $b, $c);

    sortInc3($a, $b, $c);
    toTableRowProc12("Упорядоченный набор 1", $a, $b, $c);

    $a = random_float(-100, 100);
    $b = random_float(-100, 100);
    $c = random_float(-100, 100);
    toTableRowProc12("Исходный набор 2", $a, $b, $c);

    sortInc3($a, $b, $c);
    toTableRowProc12("Упорядоченный набор 2", $a, $b, $c);
} // proc12

// Proc18.
// Описать функцию circleS(r), находящую площадь круга радиуса r
// (r — вещественное).
// Площадь круга радиуса R вычисляется по формуле S = π·R**2.
function circleS($r) {
    return pi() * $r * $r;
    // return pi() * $r ** 2;
} // circleS

// вывод стооки таблицы для задачи Proc18
function toTableRowProc18($row, $r, $s) {
    echo "<tr>
        <td>$row</td>
        <td class='text-end pe-3'>".sprintf("%.3f", $r)."</td>
        <td class='text-end pe-3'>".sprintf("%.3f", $s)."</td>
    </tr>";
} // toTableRowProc18

// С помощью функции circleS(r) найти площади трех кругов с радиусами –
// случайными числами.
function proc18() {
    // Цикл не используем - по заданию :)
    $r = random_float(0.1, 100);
    $s = circleS($r);
    toTableRowProc18(1, $r, $s);

    $r = random_float(0.1, 100);
    $s = circleS($r);
    toTableRowProc18(2, $r, $s);

    $r = random_float(0.1, 100);
    $s = circleS($r);
    toTableRowProc18(3, $r, $s);
} // proc18