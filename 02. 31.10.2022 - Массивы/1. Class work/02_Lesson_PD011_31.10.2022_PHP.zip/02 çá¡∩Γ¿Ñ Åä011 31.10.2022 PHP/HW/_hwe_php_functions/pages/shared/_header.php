<!-- навигация по приложению, переходы по заданию -->
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand active" href="<?= $prefixIndex ?>./index.php">ПД011</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#appNavbar-1">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="appNavbar-1">
            <ul class="navbar-nav">
                <!-- Переход страницу решения Proc4 -->
                <li class="nav-item">
                    <a class="nav-link <?= $activeProc4 ?>" href="<?= $prefix ?>proc04.php"
                       title="Переход на страницу решения задачи Proc4">Proc4</a>
                </li>

                <!-- Переход страницу решения задачи Proc11 -->
                <li class="nav-item">
                    <a class="nav-link <?= $activeProc11 ?>" href="<?= $prefix ?>proc11.php"
                       title="Переход на страницу решения задачи Proc11">Proc11</a>
                </li>

                <!-- Переход страницу решения Proc12 -->
                <li class="nav-item">
                    <a class="nav-link <?= $activeProc12 ?>" href="<?= $prefix ?>proc12.php"
                       title="Переход на страницу решения задачи Proc12">Proc12</a>
                </li>

                <!-- Переход страницу решения задачи Proc18 -->
                <li class="nav-item">
                    <a class="nav-link <?= $activeProc18 ?>" href="<?= $prefix ?>proc18.php"
                       title="Переход на страницу решения задачи Proc18">Proc18</a>
                </li>

            </ul>
        </div>
    </div>
</nav>


