<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>Задание на 31.10.2022</title>
    <!-- подключение файла-иконки -->
    <link rel="shortcut icon" href="../images/blimp.png" type="image/x-icon">

    <!-- подключение bootstrap -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- подключение собственных стилей -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php
    // загрузка панели навигации
    $activeProc4 = "";
    $activeProc11 = "";
    $activeProc12 = "active";
    $activeProc18 = "";

    $prefixIndex = ".";
    $prefix = "";

    include_once "../pages/shared/_header.php";
?>

<!-- размещение контента страницы -->
<main class="container mt-5">
    <div class="row">
        <p>
            <b>Proc12.</b> Описать функцию <i>sortInc3(a, b, c)</i>, меняющую содержимое переменных a, b, c таким образом,
            чтобы их значения оказались упорядоченными по возрастанию (<i>a, b, c</i> — вещественные параметры, являющиеся
            одновременно входными и выходными). С помощью этой функции упорядочить по возрастанию два данных набора
            из трех чисел: (a<sub>1</sub>, b<sub>1</sub>, c<sub>1</sub>) и (a<sub>2</sub>, b<sub>2</sub>, c<sub>2</sub>).
        </p>
        <h5>Решение задачи Proc12 - упорядочивание двух наборов чисел</h5>
        <table class="table table-bordered table-striped w-50">
            <thead>
            <tr>
                <th></th>
                <th class="text-end pe-3">a</th>
                <th class="text-end pe-3">b</th>
                <th class="text-end pe-3">c</th>
            </tr>
            </thead>
            <tbody>
                <?php
                     require_once "../src/functions.php";
                     proc12();
                ?>
            </tbody>
        </table>
    </div>
</main>

<?php include "../pages/shared/_footer.php" ?>
</body>
</html>
