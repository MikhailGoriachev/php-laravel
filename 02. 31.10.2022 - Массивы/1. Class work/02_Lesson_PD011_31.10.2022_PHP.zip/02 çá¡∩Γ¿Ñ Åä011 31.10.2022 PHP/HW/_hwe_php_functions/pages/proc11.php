<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>Задание на 31.10.2022</title>
    <!-- подключение файла-иконки -->
    <link rel="shortcut icon" href="/images/blimp.png" type="image/x-icon">

    <!-- подключение bootstrap -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- подключение собственных стилей -->
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>

<?php
    // загрузка панели навигации
    $activeProc4 = "";
    $activeProc11 = "active";
    $activeProc12 = "";
    $activeProc18 = "";

    $prefixIndex = ".";
    $prefix = "";

    include_once "../pages/shared/_header.php";
?>

<!-- размещение контента страницы -->
<main class="container mt-5">
    <div class="row">
        <p>
            <b>Proc11.</b> Описать функцию <i>minMax(x, y)</i>, записывающую в переменную x минимальное
            из значений x и y, а в переменную y — максимальное из этих значений (<i>x</i> и <i>y</i> — вещественные
            параметры, являющиеся одновременно входными и выходными). Используя четыре вызова этой функции, найти
            минимальное и максимальное из данных чисел a, b, c, d.
        </p>
        <h5>Решение задачи Proc11 - поиск минимального и максимального в наборе чисел</h5>
        <?php
             require_once "../src/functions.php";
             proc11();
        ?>
    </div>
</main>

<?php include "../pages/shared/_footer.php" ?>
</body>
</html>
