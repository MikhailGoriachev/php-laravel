<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8"/>
    <meta name="vi  ewport" content="width=device-width, initial-scale=1"/>

    <title>Задание на 31.10.2022</title>
    <!-- подключение файла-иконки -->
    <link rel="shortcut icon" href="../images/blimp.png" type="image/x-icon">

    <!-- подключение bootstrap -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- подключение собственных стилей -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php
    // загрузка панели навигации
    $activeProc4 = "active";
    $activeProc11 = "";
    $activeProc12 = "";
    $activeProc18 = "";

    $prefixIndex = ".";
    $prefix = "";

    include_once "../pages/shared/_header.php";
?>

<!-- размещение контента страницы -->
<main class="container mt-5">
    <div class="row">
        <p>
            <b>Proc4.</b> Описать функцию <i>trianglePS(a, p, s)</i>, вычисляющую по стороне a равностороннего
            треугольника его периметр <i>p = 3·a</i> и площадь <i>s = a<sup>2</sup>·sqrt(3)/4</i> (<i>a</i> —
            входной, <i>p</i> и <i>s</i> — выходные параметры). С помощью этой функции найти периметры и площади
            трех равносторонних треугольников с данными сторонами.
        </p>
        <h5>Решение задачи Proc4 - периметры и площади трех равносторонних треугольников</h5>
        <table class="table table-bordered table-striped w-50">
            <thead>
                <tr>
                    <th>Номер</th>
                    <th class="text-end pe-3">Сторона a</th>
                    <th class="text-end pe-3">Периметр</th>
                    <th class="text-end pe-3">Площадь</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    require_once "../src/functions.php";
                    proc4();
                ?>
            </tbody>
        </table>
    </div>
</main>

<?php include "../pages/shared/_footer.php" ?>
</body>
</html>
