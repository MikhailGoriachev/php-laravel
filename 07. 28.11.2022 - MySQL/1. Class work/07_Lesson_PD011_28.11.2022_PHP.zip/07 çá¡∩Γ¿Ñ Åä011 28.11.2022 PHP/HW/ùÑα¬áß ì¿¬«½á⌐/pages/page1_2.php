<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width" />
    <title>Задание</title>
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css"/>
    <script src="../lib/js/bootstrap.bundle.min.js"></script>
    <link href="../css/style.css" rel="stylesheet"/>
</head>
<body>
<nav class="navbar fixed navbar-light bg-light">
    <div class="container-fluid">
        <ul class="nav" role="tablist">
            <li class="nav-item">
                <a class="nav-link" href="../index.php">Задание</a>
            </li>
            <li>
                <a class="nav-link" href="page1.php">Вариант 12</a>
            </li>
            <li>
                <a class="nav-link" href="page1_2.php">Вариант 15</a>
            </li>
        </ul>
    </div>
</nav>
<div class="container-fluid">
    <main class="col-sm p-3">
        <?php
        require_once "../models/Variant15.php";
        $variant15 = new models\Variant15();
        $variant15->createMatrix();
        echo "<h6>Вариант 15</h6>";
        $variant15->show();
        $index = $variant15->zeroColumn();
        if ($index != -1)
            echo "<hr><h6>столбец $index содержит ноль</h6>";
        else
            echo "<hr><h6>нет столбцов содержащих ноль</h6>";

        ?>
    </main>
    <footer class="container-fluid bg-light p-3 mt-1">
        <p>Черкас Николай группа ПД-011 г.Донецк 2022 г.</p>
    </footer>
</div>
</body>
</html>
