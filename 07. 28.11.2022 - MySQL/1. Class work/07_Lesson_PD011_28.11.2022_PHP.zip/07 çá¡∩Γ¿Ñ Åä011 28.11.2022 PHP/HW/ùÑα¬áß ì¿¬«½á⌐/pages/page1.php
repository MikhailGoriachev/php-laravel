<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width" />
    <title>Задание</title>
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css"/>
    <script src="../lib/js/bootstrap.bundle.min.js"></script>
    <link href="../css/style.css" rel="stylesheet"/>
</head>
<body>
<nav class="navbar fixed navbar-light bg-light">
    <div class="container-fluid">
        <ul class="nav" role="tablist">
            <li class="nav-item">
                <a class="nav-link" href="../index.php">Задание</a>
            </li>
            <li>
                <a class="nav-link" href="page1.php">Вариант 12</a>
            </li>
            <li>
                <a class="nav-link" href="page1_2.php">Вариант 15</a>
            </li>
        </ul>
    </div>
</nav>
<div class="container-fluid">
    <main class="col-sm p-3">
        <?php
        require_once "../models/Variant12.php";
        $variant12 = new models\Variant12();
        $variant12->createMatrix();
        echo "<h6>Вариант 12</h6>";
        $variant12->show();
        $index = $variant12->pozitiv();
        if ($index != -1)
            echo "<hr><h6>строка $index содержит положительный элемент</h6>";
        else
            echo "<hr><h6>нет положительных элементов</h6>";
        $variant12->zeroDel();
        echo "<hr><h6>удалены строки и столбцы содержащие ноль</h6>";
        $variant12->show();

        ?>
    </main>
    <footer class="container-fluid bg-light p-3 mt-1">
        <p>Черкас Николай группа ПД-011 г.Донецк 2022 г.</p>
    </footer>
</div>
</body>
</html>
