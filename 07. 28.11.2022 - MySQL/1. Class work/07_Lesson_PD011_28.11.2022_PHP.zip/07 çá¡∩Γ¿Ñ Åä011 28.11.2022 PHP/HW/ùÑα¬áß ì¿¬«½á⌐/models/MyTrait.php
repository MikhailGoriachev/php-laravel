<?php

namespace models;

trait MyTrait
{
    public $matrix, $col, $row;

    // создание матрицы
    function createMatrix(){
        $max = mt_rand(10, 20);
        for ($i = 1; $i < $this->row; $i++){
            for ($j = 1; $j < $this->col; $j++){
                $this->matrix[$i][$j] = mt_rand(-5, 20);
            }
        }
    }
    // вывод матрыцы
    function show(){
        echo "<table>";
        foreach ($this->matrix as $items){
            echo "<tr>";

                foreach ($items as $it)
                    echo "<td>$it </td>";
                echo "</tr>";
        }
        echo "</table>";
    }
}