<?php

namespace models;
require_once "MyTrait.php";

class Variant12
{
    use MyTrait;
    function __construct()
    {
        $this->col = mt_rand(10, 20);
        $this->row = mt_rand(5, 7);
    }
    // номер первой из строк, содержащих хотя бы один положительный элемент
    function pozitiv(){
        $index = -1;
        for ($i = 1; $i < $this->row; $i++){
            if ($index != -1) break;
            for ($j = 1; $j < $this->col; $j++){
                if ($this->matrix[$i][$j] >= 0){
                    $index = $i;
                    break;
                }
            }
        }
        return $index;
    }
    // удаляет стр и столбцы с 0;
    function zeroDel(){
        $listCol = [];
        $listRow = [];
        foreach ($this->matrix as $key => $items){
            foreach ($items as $key2 => $item){
                if ($item == 0){
                    array_push($listCol, $key2);
                    array_push($listRow, $key);
                }
            }
        }
        foreach ($listRow as $item){
            foreach ($this->matrix as $keyRow => $itemRow)
                if ($item == $keyRow) unset($this->matrix[$keyRow]);
        }
        foreach ($listCol as $itemCol){
            foreach ($this->matrix as $key => $items){
                foreach ($items as $key2 => $item){
                    if ($itemCol == $key2) unset($this->matrix[$key][$key2]);
                }
            }
        }
    }
}