<?php

namespace models;
require_once "MyTrait.php";
class Variant15
{
    use MyTrait;
    function __construct()
    {
        $this->col = mt_rand(10, 20);
        $this->row = mt_rand(5, 10);
    }
    // номер первого из столбцов, содержащих хотя бы один нулевой элемент.
    function zeroColumn(){
        $col = -1;
        for ($i = 1; $i < $this->col; $i++){
            if ($col != -1) break;
            for ($j = 1; $j < $this->row; $j++){
                if ($this->matrix[$j][$i] == 0){
                    $col = $i;
                    break;
                }
            }
        }
        return $col;
    }
}