<?php namespace TraitsPdo;  ?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>Задание на 28.11.2022</title>
    <!-- подключение файла-иконки -->
    <link rel="shortcut icon" href="../images/blimp.png" type="image/x-icon">

    <!-- подключение bootstrap -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- подключение собственных стилей -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php
// загрузка панели навигации

// активность страниц
$activeTask01 = "active";
$activeTask02 = "";

// собственно загрузка панели навигации
include_once "../pages/shared/_header.php";
?>

<!-- размещение контента страницы -->
<main class="container mt-5">

    <details>
        <summary><b>Задача 1.</b> Применение трейтов.</summary>
        <p>Реализуйте обработку прямоугольных матриц по GET-запросу. Размеры матриц
            формируйте при помощи генератора случайных чисел, заполнение матриц – целыми случайными числами.
        </p>
        <p>При помощи исключений обрабатывать ошибки времени исполнения.</p>
        <ul class="ms-5">
            <li><b>Вариант 12.</b> Найти номер первой из строк, содержащих хотя бы один положительный элемент (0 считаем
                положительным числом). Уплотнить заданную матрицу, удаляя из нее строки и столбцы, заполненные
                нулями.
            </li>
            <li><b>Вариант 15.</b> Определить номер первого из столбцов, содержащих хотя бы один нулевой элемент.
                Характеристикой строки целочисленной матрицы назовем сумму ее отрицательных четных элементов.
                Переставляя строки заданной матрицы, расположить их в соответствии с убыванием характеристик.
            </li>
        </ul>
        <p>
            Решение по каждому варианту надо разместить в отдельном классе (Variant12, Variant15). Работу с матрицей
            (создание, вывод в таблицу, заполнение матрицы значениями), реализовать в трейте. Добавлять трейт к каждому
            из классов решения (Variant12, Variant15).
        </p>
    </details>

    <h5 class="my-3">Решение задачи 1 - Использование трейтов</h5>

    <?php
        require_once("../src/task1/task1.php");
    ?>

    <div class="row">
        <div class="col-5 m-3">
            <h5>Обработка по варианту 12</h5>
            <?php variant12(); ?>
        </div>
        <div class="col-5 m-3">
            <h5>Обработка по варианту 15</h5>
            <?php variant15(); ?>
        </div>
    </div>

</main>

<!-- загрузка подвала страницы -->
<?php include "../pages/shared/_footer.php" ?>
</body>
</html>

