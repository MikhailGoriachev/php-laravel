<!-- навигация по приложению, переходы по заданию -->
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand active" href="/index.php">ПД011</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#appNavbar-1">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="appNavbar-1">
            <ul class="navbar-nav">
                <!-- Переход на страницу решения задачи 1 - работа с трейтами -->
                <li class="nav-item">
                    <a class="nav-link <?= $activeTask01 ?>" href="/pages/task01.php"
                       title="Переход на страницу решения задачи 1 - применение трейтов">Трейты/Матрицы</a>
                </li>

                <!-- Переход на страницу решения задачи 2 - работа с PDO, запросы к БД SQLite3 -->
                <li class="nav-item">
                    <a class="nav-link <?= $activeTask02 ?>" href="/pages/task02.php"
                       title="Переход на страницу решения задачи 2 - выполнение запросов к БД SQLite3">PDO/Запросы к БД</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
