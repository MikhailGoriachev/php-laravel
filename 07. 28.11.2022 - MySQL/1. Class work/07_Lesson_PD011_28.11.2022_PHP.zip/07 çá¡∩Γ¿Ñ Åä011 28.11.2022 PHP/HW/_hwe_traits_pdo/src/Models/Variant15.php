<?php

namespace TraitsPdo;

class Variant15
{
    use MatrixTrait;

    // Определить номер первого из столбцов, содержащих хотя бы один
    // нулевой элемент.
    public function firstColumnNumberByPredicate($predicate) {
        $n = count($this->matrix[0]);
        for ($j = 0; $j < $n; $j++) {
            $cols = array_column($this->matrix, $j);
            if ($predicate($cols)):
                return $j+1;
            endif;
        } // for $j

        // штатный выход из цикла возможен только если
        // не сработал предикат - в матрице нет столбцов,
        // соответствущих предикату
        return -1;
    } // firstColumnNumberByPredicate

    // Характеристикой строки целочисленной матрицы назовем сумму ее
    // отрицательных четных элементов. Переставляя строки заданной
    // матрицы, расположить их в соответствии с убыванием характеристик

    // Возвращает характеристики строк
    function calcRowsCharacteristics($innerFunction) {
        $characteristics = [];

        foreach ($this->matrix as $row) {
            $characteristics[] = array_reduce($row, $innerFunction, 0);
        }

        return $characteristics;
    } // calcRowsCharacteristics


    // перестановка строк матрицы по убывастанию значений вспомогательного
    // массива (массива характеристик)
    function matrixOrderByRow(&$rows, $comparer) {
        $m = count($rows);
        for ($i = 0; $i < $m; $i++) {

            for ($j = $i + 1; $j < $m; $j++) {

                if($comparer($rows[$i], $rows[$j]) >= 0) {
                    // перестановка значений в массиве характеристик
                    swap($rows[$i], $rows[$j]);

                    // перестановка строк матрицы
                    swap($matrix[$i], $matrix[$j]);
                } // if
            } // for j
        } // for i
    } // matrixOrderByRow

} // class Variant15