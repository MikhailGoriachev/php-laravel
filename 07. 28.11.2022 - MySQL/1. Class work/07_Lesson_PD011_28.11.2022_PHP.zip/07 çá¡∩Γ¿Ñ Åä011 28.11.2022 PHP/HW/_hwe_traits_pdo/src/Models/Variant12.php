<?php

namespace TraitsPdo;

class Variant12
{
    use MatrixTrait;

    // Найти номер первой из строк, содержащих хотя бы один положительный элемент
    // (0 считаем положительным числом)
    public function firstRowNumberByPredicate($predicate) {
        $numRow = 1;
        foreach ($this->matrix as $row):
             if ($predicate($row)):
                 return $numRow;
             endif;
             $numRow++;
        endforeach;

        // штатный выход из цикла возможен только если
        // не сработал предикат - в матрице нет строк, соответствущих
        // предикату
        return -1;
    } // firstRowNumberByPredicate

    // Уплотнить заданную матрицу, удаляя из нее строки и столбцы, заполненные нулями
    public function compress() {
        /*
        Цикл по строкам
            Если очередная строка состоит только из нулей То удаляем строку
        КонецЦикла

        Цикл по столбцам
            Если очередной столбец состоит только из нулей То удаляем столбец
        КонецЦикла
        */
    } // compress
} // class Variant12