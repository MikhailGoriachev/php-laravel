<?php

namespace TraitsPdo;

// Работа с матрицей (создание, вывод в таблицу, заполнение матрицы 
// значениями), реализована в трейте 
trait MatrixTrait
{
    // матрица для обработки
	public $matrix;

    // диапазон генерации значений матрицы
    public $lo;
	public $hi;

    // конструктор в трейте - не нужен конструктор в классе
    function __construct($matrix = null, $lo = -10, $hi = 10) {
        if (is_null($matrix)):
            // гарантированно $m != $n, прямоугольная матрица
            $m = random_int(4, 12);
            do
                $n = random_int(4, 12);
            while($n == $m);
            $this->create($m, $n);
        else:
            $this->matrix = $matrix;  // клонировать ???
        endif;

        $this->lo = $lo;
        $this->hi = $hi;

        $this->fill();
    } // __construct
	
	// создание матрицы
	function create($m, $n) {
		$this->matrix = [];

		// Заполнение матрицы случайными целыми числами
		for ($i = 0; $i < $m; $i++) {
			$this->matrix[] = array_pad([], $n, 0);
		} // for i
	} // createMatrix
	
	// заполнение матрицы значениями 
	function fill() {
		// Заполнение матрицы случайными целыми числами
		$m = count($this->matrix);
		for ($i = 0; $i < $m; $i++) {
			$this->matrix[$i] = array_map(fn() => random_int($this->lo, $this->hi), $this->matrix[$i]);
		} // for i
	} // fill
	
	// вывод матрицы в таблицу
	// вывод матрицы в виде прямоугольной таблицы
	function show($title = "Матрица для обработки") {

		echo "
			<h5 class='text-center'>$title</h5>
			<table class='table w-75 mx-auto my-2'>
			<tbody>";

		foreach ($this->matrix as $row):
			echo "<tr>";

			foreach ($row as $datum) :
				echo "<td class='text-end'>$datum</td>";
			endforeach;

			echo "</tr>";
		endforeach;

		echo "</tbody></table>";
	} // show
} // trait MatrixTrait