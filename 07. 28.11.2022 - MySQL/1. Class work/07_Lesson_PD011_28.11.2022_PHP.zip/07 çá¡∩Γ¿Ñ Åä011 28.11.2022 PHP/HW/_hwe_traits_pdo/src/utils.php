<?php
// вспомогательные функции

// генерация вещественного случайного числа в диапазоне значений [lo, hi]
function random_float ($lo, $hi) {
    return ($lo + lcg_value()*(abs($hi - $lo)));
} // random_float

// обмен двух переменных
function swap(&$a, &$b) {
    // языковая конструкция, начиная с версии языка PHP 7.1
    [$a, $b] = [$b, $a];
} // swap

// вывод предупреждения
function alert($title, $text){
    echo "
    <div class='alert alert-warning'>
        <strong>$title</strong><br>$text
    </div>";
} // alert


// вывод сообщения
function info($title, $text){
    echo "
    <div class='alert alert-success'>
        <strong>$title</strong><br>$text
    </div>";
} // alert


