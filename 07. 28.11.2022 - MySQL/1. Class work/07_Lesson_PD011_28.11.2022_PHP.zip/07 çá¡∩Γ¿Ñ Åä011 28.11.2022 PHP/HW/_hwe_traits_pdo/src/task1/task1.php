<?php

namespace TraitsPdo;

require_once "../src/utils.php";
require_once("../src/Models/MatrixTrait.php");
require_once("../src/Models/Variant12.php");
require_once("../src/Models/Variant15.php");


// решение задачи 1 - вариант 12
function variant12() {
    $v12 = new Variant12();

    $v12->show();

    // в строке есть хотя бы один положительный элемент, если
    // максимальный элемент строки положительный
    $firstRow = $v12->firstRowNumberByPredicate(fn($row) => max($row) >= 0);
    echo "<p>Номер первой строки, содержащей хотя бы один положительный элемент: $firstRow</p>";

    // сжатие матрицы, выбрасывая из нее строки и столбцы, состоящие только из нулей
    $v12->compress();
    $v12->show("Из матрицы удалены строки и столбцы, состоящие только из нулей");
} // variant12

// решение задачи 1 - вариант 15
function variant15() {
    $v15 = new Variant15();

    $v15->show();

    // Определить номер первого из столбцов, содержащих хотя бы один
    // нулевой элемент.
    $firstColumn = $v15->firstColumnNumberByPredicate(fn($column)=>count(array_filter($column, fn($datum) => $datum == 0)));
    echo "<p>Номер первого столбца, содержащего хотя бы один нулевой элемент: $firstColumn</p>";

    // Характеристикой строки целочисленной матрицы назовем сумму ее
    // отрицательных четных элементов. Переставляя строки заданной
    // матрицы, расположить их в соответствии с убыванием характеристик

} // variant15