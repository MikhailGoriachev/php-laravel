--
-- Файл сгенерирован с помощью SQLiteStudio v3.3.3 в Пт апр 8 20:53:51 2022
--
-- Использованная кодировка текста: UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Таблица: appointments
DROP TABLE IF EXISTS appointments;

CREATE TABLE appointments (
    id         INTEGER  PRIMARY KEY AUTOINCREMENT
                        NOT NULL,
    id_doctor           REFERENCES doctors (id) 
                        NOT NULL,
    id_patient          REFERENCES patients (id) 
                        NOT NULL,
    date       DATETIME NOT NULL
);

INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (1, 10, 9, '12.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (2, 10, 1, '12.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (3, 4, 5, '12.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (4, 9, 7, '13.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (5, 9, 8, '13.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (6, 10, 9, '13.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (7, 6, 2, '13.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (8, 2, 7, '13.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (9, 4, 4, '14.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (10, 2, 9, '14.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (11, 4, 8, '14.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (12, 1, 5, '14.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (13, 5, 8, '15.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (14, 3, 7, '15.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (15, 9, 6, '15.03.2022');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (16, 1, 4, '15.03.2022');

-- Таблица: categories
DROP TABLE IF EXISTS categories;

CREATE TABLE categories (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    category_name TEXT    NOT NULL
);

INSERT INTO categories (id, category_name) VALUES (1, 'терапевт');
INSERT INTO categories (id, category_name) VALUES (2, 'хирург');
INSERT INTO categories (id, category_name) VALUES (3, 'офтальмолог');
INSERT INTO categories (id, category_name) VALUES (4, 'уролог');
INSERT INTO categories (id, category_name) VALUES (5, 'акушер-гинеколог');
INSERT INTO categories (id, category_name) VALUES (6, 'семейный врач');
INSERT INTO categories (id, category_name) VALUES (7, 'оториноларинголог');
INSERT INTO categories (id, category_name) VALUES (8, 'стоматолог-терапевт');
INSERT INTO categories (id, category_name) VALUES (9, 'стоматолог-хирург');
INSERT INTO categories (id, category_name) VALUES (10, 'инфекционист');
INSERT INTO categories (id, category_name) VALUES (11, 'пульманолог');

-- Таблица: doctors
DROP TABLE IF EXISTS doctors;

CREATE TABLE doctors (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    id_person   INTEGER REFERENCES persons (id),
    id_category INTEGER REFERENCES categories (id),
    price       DOUBLE  NOT NULL
                        CHECK (price > 0),
    interest    DOUBLE  NOT NULL
                        CHECK (interest BETWEEN 1 AND 100) 
);

INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (1, 11, 1, 1500.0, 20.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (2, 12, 1, 1500.0, 30.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (3, 13, 1, 1500.0, 25.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (4, 14, 3, 1600.0, 20.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (5, 15, 3, 1600.0, 30.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (6, 16, 2, 2000.0, 20.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (7, 17, 2, 2000.0, 30.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (8, 18, 10, 1200.0, 20.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (9, 18, 8, 2000.0, 25.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (10, 20, 8, 2300.0, 30.0);

-- Таблица: patients
DROP TABLE IF EXISTS patients;

CREATE TABLE patients (
    id        INTEGER  PRIMARY KEY AUTOINCREMENT,
    id_person INTEGER  REFERENCES persons (id),
    dob       DATETIME NOT NULL,
    address   TEXT     NOT NULL
);

INSERT INTO patients (id, id_person, dob, address) VALUES (1, 10, '23.11.1956', 'Донецк, ул. Куйбышева, 34, 12');
INSERT INTO patients (id, id_person, dob, address) VALUES (2, 9, '19.10.1987', 'Донецк, ул. Воинская, 23, 2');
INSERT INTO patients (id, id_person, dob, address) VALUES (3, 8, '08.11.2000', 'Донецк, ул. Гоголя, 121, 11');
INSERT INTO patients (id, id_person, dob, address) VALUES (4, 1, '30.12.1977', 'Донецк, ул. Гоголя, 121, 89');
INSERT INTO patients (id, id_person, dob, address) VALUES (5, 2, '01.11.1965', 'Донецк, ул. Куйбышева, 34, 87');
INSERT INTO patients (id, id_person, dob, address) VALUES (6, 7, '09.11.1951', 'Донецк, ул. Гоголя, 121, 100');
INSERT INTO patients (id, id_person, dob, address) VALUES (7, 6, '08.04.1993', 'Донецк, ул. Воинская, 23, 5');
INSERT INTO patients (id, id_person, dob, address) VALUES (8, 3, '24.02.1971', 'Донецк, ул. Куйбышева, 34, 19');
INSERT INTO patients (id, id_person, dob, address) VALUES (9, 5, '09.05.1945', 'Донецк, ул. Воинская, 23, 11');
INSERT INTO patients (id, id_person, dob, address) VALUES (10, 4, '08.11.1967', 'Донецк, ул. Куйбышева, 34, 19');

-- Таблица: persons
DROP TABLE IF EXISTS persons;

CREATE TABLE persons (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    surname    TEXT    NOT NULL,
    name       TEXT    NOT NULL,
    patronymic TEXT    NOT NULL
);

INSERT INTO persons (id, surname, name, patronymic) VALUES (1, 'Иванова', 'Вероника', 'Денисовна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (2, 'Сергеева', 'Серафима', 'Степановна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (3, 'Денисов', 'Дмитрий', 'Денисович');
INSERT INTO persons (id, surname, name, patronymic) VALUES (4, 'Жир', 'Владислав', 'Леонидович');
INSERT INTO persons (id, surname, name, patronymic) VALUES (5, 'Молодцова', 'Марина', 'Романовна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (6, 'Шляховая', 'Татьяна', 'Евгеньевна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (7, 'Пожар', 'Илья', 'Олегович');
INSERT INTO persons (id, surname, name, patronymic) VALUES (8, 'Соломаха', 'Алина', 'Николаевна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (9, 'Биленко', 'Артем', 'Дмитриевич');
INSERT INTO persons (id, surname, name, patronymic) VALUES (10, 'Сенько', 'Юлия', 'Игнатьевна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (11, 'Васечко', 'Ирина', 'Даниловна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (12, 'Коробка', 'Елена', 'Денисовна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (13, 'Зачипиленко', 'Валерий', 'Григорьевич');
INSERT INTO persons (id, surname, name, patronymic) VALUES (14, 'Гаврилов', 'Дмитрий', 'Валерьевич');
INSERT INTO persons (id, surname, name, patronymic) VALUES (15, 'Ловда', 'Михаил', 'Максимович');
INSERT INTO persons (id, surname, name, patronymic) VALUES (16, 'Ястремский', 'Антон', 'Артемьевич');
INSERT INTO persons (id, surname, name, patronymic) VALUES (17, 'Ермолина', 'Алина', 'Николаевна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (18, 'Кленцарь', 'Татьяна', 'Ильинична');
INSERT INTO persons (id, surname, name, patronymic) VALUES (19, 'Васечко', 'Татьяна', 'Даниловна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (20, 'Корнецкий', 'Алексей', 'Александрович');

-- Представление: view_appointments
DROP VIEW IF EXISTS view_appointments;
CREATE VIEW view_appointments AS
    SELECT appointments.id,
           appointments.date,
           view_patients.patient_surname,
           view_patients.patient_name,
           view_patients.patient_patronymic,
           view_patients.dob,
           view_patients.address,
           view_doctors.doctor_surname,
           view_doctors.doctor_name,
           view_doctors.doctor_patronymic,
           view_doctors.category_name,
           view_doctors.price,
           view_doctors.interest
      FROM appointments
           JOIN
           view_doctors ON appointments.id_doctor = view_doctors.id
           JOIN
           view_patients ON appointments.id_patient = view_patients.id;


-- Представление: view_doctors
DROP VIEW IF EXISTS view_doctors;
CREATE VIEW view_doctors AS
    SELECT doctors.id,
           persons.surname AS doctor_surname,
           persons.name AS doctor_name,
           persons.patronymic AS doctor_patronymic,
           categories.category_name,
           doctors.price,
           doctors.interest
      FROM doctors
           JOIN
           persons ON doctors.id_person = persons.id
           JOIN
           categories ON doctors.id_category = categories.id;


-- Представление: view_patients
DROP VIEW IF EXISTS view_patients;
CREATE VIEW view_patients AS
    SELECT patients.id,
           persons.surname AS patient_surname,
           persons.name AS patient_name,
           persons.patronymic AS patient_patronymic,
           patients.dob,
           patients.address
      FROM patients
           JOIN
           persons ON patients.id_person = persons.id;


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
