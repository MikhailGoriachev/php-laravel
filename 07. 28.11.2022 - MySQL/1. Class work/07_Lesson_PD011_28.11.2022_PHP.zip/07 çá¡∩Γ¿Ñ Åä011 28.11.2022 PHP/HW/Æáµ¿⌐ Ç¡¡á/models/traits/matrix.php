<?php

//Работу с матрицей (создание, вывод в таблицу, заполнение
// матрицы значениями), реализовать в трейте.

trait Matrix{

    private array $matrix; //матрица
    private int $row; //кол-во строк
    private int $col; //кол-во столбцов

    //создание аполнение матрицы значениями
    function __construct($nMin = 3, $nMax = 6, $min = -3, $max = 3){

        $this->row = rand($nMin, $nMax);
        $this->col = rand($nMin, $nMax);

        for($i = 0; $i < $this->row; $i++) {

            for($j = 0; $j < $this->col; $j++) {

                $this->matrix[$i][$j] = rand($min, $max);
            }
        }
    }

    //вывод в таблицу
    function show($caption = "") :void{

        echo ' <p class="ms-4 fs-5 mt-3">'.$caption.'</p>

            <table class="m-4">
                <tbody>          
        ';

        foreach($this->matrix as $row){

            echo "<tr>";

            foreach($row as $item) {

                echo "<td class='text-center p-2'>".$item."</td>";
            }

            echo "</tr>";
        }

        echo "     </tbody>
            </table>";

    }

}