
<?php

require_once "traits\matrix.php";
require_once "../infrastructure/utils.php";

class Variant15{

    // задать использование трейта с конструктором
    use Matrix;

    //Определить номер первого из столбцов, содержащих хотя бы один
    // нулевой элемент.
    function solveTask01():void{

        for ($i = 0; $i < $this->col; $i++) {
            $arr_col = array_column($this->matrix, $i);

            $index = in_array(0, $arr_col);

            if($index !== false){
                echo " Номер первого из столбцов, содержащих хотя бы один нулевой элемент: ".$i;
                return;
            }
        }

        echo " Номер первого из столбцов, содержащих хотя бы один нулевой элемент не найден";

    }

    //Характеристикой строки целочисленной матрицы назовем сумму
    // ее отрицательных четных элементов.
    //Переставляя строки заданной матрицы, расположить их
    // в соответствии с убыванием характеристик.
    function solveTask02():void{

        // массив характеристик
        $columnsCharacteristics = [];

        // формируем массив значений характеристик
        for ($i = 0; $i < $this->row; $i++) {
            $arr = $this->matrix[$i];

            $columnsCharacteristics[] = array_reduce($arr, function ($sum, $item) {
                if ($item < 0 && $item % 2 == 0) {
                    $sum += $item;
                }
                return $sum;
            }, 0);
        }

        // перестановка строк по убыванию характеристик
        for ($i = 0; $i < $this->col; $i++) {

            for ($j = $i + 1; $j < sizeof($columnsCharacteristics); $j++) {

                if($columnsCharacteristics[$i] < $columnsCharacteristics[$j]) {
                    // перестановка значений в массиве характеристик
                    swap($columnsCharacteristics[$i], $columnsCharacteristics[$j]);

                    // перестановка строк матрицы
                    for ($k = 0; $k < $this->col; $k++) {
                        swap($this->matrix[$i][$k], $this->matrix[$j][$k]);
                    } // for k
                } // if
            } // for j
        } // for i

        $this->show("Строки матрицы, расположены по убыванию характеристик");
    }
}