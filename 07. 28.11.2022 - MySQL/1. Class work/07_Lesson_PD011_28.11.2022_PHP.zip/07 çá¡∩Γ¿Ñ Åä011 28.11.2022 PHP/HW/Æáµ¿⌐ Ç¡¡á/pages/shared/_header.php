<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
    <div class="container-fluid">
        <div style="width: 70%; margin: auto;">
            <div class="navbar-collapse" id="appNavbar-1">
                <ul class="navbar-nav fs-4">
                    <li class="nav-item pt-1">
                        <a class="nav-link <?= $activeIndex ?>" href="/index.php">Страница с заданием</a>
                    </li>
                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link <?= $activePage01 ?>" href="/pages/page01.php">Задача 1</a>
                    </li>

                    <li class="nav-item dropdown pt-1 ps-3">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Запросы
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="/pages/queries/query01.php">Запрос 1 с параметрами</a></li>
                            <li><a class="dropdown-item" href="/pages/queries/query02.php">Запрос 2 с параметрами</a></li>
                            <li><a class="dropdown-item" href="/pages/queries/query03.php"">Запрос 3 с параметрами </a></li>
                            <li><a class="dropdown-item" href="/pages/queries/query04.php"">Запрос 4 с параметрами </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/pages/queries/query05.php"">Запрос 5 с вычисляемыми полями </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/pages/queries/query06.php"">Итоговый запрос 6</a></li>
                            <li><a class="dropdown-item" href="/pages/queries/query07.php"">Итоговый запрос 7</a></li>

                        </ul>
                    </li>

                </ul>
            </div>
        </div>
    </div>
</nav>