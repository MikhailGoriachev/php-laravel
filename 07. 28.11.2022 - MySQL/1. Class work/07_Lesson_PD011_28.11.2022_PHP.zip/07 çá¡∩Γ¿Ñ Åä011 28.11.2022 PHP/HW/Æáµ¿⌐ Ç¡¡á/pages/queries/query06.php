
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_28.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="/lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/lib/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<?php
// активность страниц

$activePage01 = $activeIndex = $activePage02 = $activePage03 = "";

// загрузка панели навигации
include_once "../shared/_header.php";
?>

<main class="container-fluid" >

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-3 bg-white m-3 border-warning-top border-warning-bottom">

            <p class="mb-5 ms-4 fs-4 mt-3">Для каждой даты вычисляет максимальную стоимость приема</p>

            <?php
            //подключили функции
            require_once("../../tasks/task02.php");
            doQuery06();
            ?>

        </div>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../shared/_footer.php" ?>

</body>
</html>





