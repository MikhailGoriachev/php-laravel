
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_28.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="/lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/lib/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<?php
// активность страниц

$activePage01 = $activeIndex = $activePage02 = $activePage03 = "";

// загрузка панели навигации
include_once "../shared/_header.php";
?>

<main class="container-fluid" >

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-3 bg-white m-3 border-warning-top border-warning-bottom">

            <p class="mb-2 ms-4 fs-4 mt-3">Выбирает информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов </p>


            <form class="w-25 m-4" method="post">

                <div>
                    <label for="str" class="form-label">Введите последовательность:</label>
                    <input class="form-control" name="str" type="text" required/>
                </div>

                <div class="d-flex mt-3 justify-content-end">
                    <input class="btn btn-primary" type="submit"/>
                </div>

            </form>

            <?php
            //подключили функции
            require_once("../../tasks/task02.php");
            doQuery01();
            ?>

        </div>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../shared/_footer.php" ?>

</body>
</html>
