<?php

// обмен значений
function swap(&$x, &$y): void
{
    $temp = $x;
    $x = $y;
    $y = $temp;
}