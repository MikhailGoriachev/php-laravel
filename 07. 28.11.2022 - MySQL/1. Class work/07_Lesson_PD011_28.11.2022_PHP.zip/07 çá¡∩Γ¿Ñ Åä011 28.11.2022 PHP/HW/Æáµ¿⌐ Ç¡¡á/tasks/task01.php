<?php

require_once("..\models\Variant15.php");
require_once("..\models\Variant12.php");

$v15 = new Variant15();
$v12 = new Variant12();

$v15->show("Исходная матрица");

$v12->solveTask01();
$v15->solveTask01();
$v15->solveTask02();