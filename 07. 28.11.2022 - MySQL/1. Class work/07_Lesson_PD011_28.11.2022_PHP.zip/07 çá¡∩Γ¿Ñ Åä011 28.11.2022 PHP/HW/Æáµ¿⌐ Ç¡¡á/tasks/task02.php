<?php

const DB = new PDO('sqlite:../../app_data/Appointment.db');

//Выбирает информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов
function doQuery01() :void{

     if(isset($_POST['str'])){

         $surname = $_POST['str'];

         $query = "select *
	                from Patients 
	                where Patients.surname like '$surname%'; ";

         $stmt = DB->query($query);

         //$stmt->bindParam(':surname', $surname, PDO::PARAM_STR);
         //$stmt->();

         // обход результата
         echo "
          <table class='mt-4 table table-bordered'>
          <tr><th>id</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Дата рождения</th><th>Адрес пациента</th></tr>";
         while ($row = $stmt->fetch()) {
             echo "
                <tr>
                <td>{$row['Id']}</td>
                <td>{$row['surname']}</td>
                <td>{$row['name']}</td>
                <td>{$row['patronymic']}</td>
                <td>{$row['Date_of_Birth']}</td>
                <td>{$row['address']}</td>
                </tr>";
         }
         echo "</table>";
     }
}

//Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше заданного
function doQuery02() :void{

    if(isset($_POST['str'])){

        $tax = $_POST['str'];

        $query = "	select *
	                    from Doctors
	                    where Doctors.tax > :tax; ";

        $stmt = DB->prepare($query);
        $stmt->bindParam(':tax', $tax, PDO::PARAM_INT);
        $stmt->execute();

        // обход результата
        echo "
          <table class='table table-bordered '>
          <tr><th>id</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Процент</th></tr>";
        while ($row = $stmt->fetch()) {
            echo "
                <tr>
                <td>{$row['Id']}</td>
                <td>{$row['surname']}</td>
                <td>{$row['name']}</td>
                <td>{$row['patronymic']}</td>
                <td>{$row['tax']}</td>
                </tr>";
        }
        echo "</table>";
    }
}

//Выбирает информацию о приемах за некоторый период
function doQuery03() :void{

    if(isset($_POST['str01']) && isset($_POST['str02'])){

        $date01 = $_POST['str01'];
        $date02 = $_POST['str02'];

        $query = "	select 
		                ViewReceipts.Doctor,
		                ViewReceipts.Patient,
		                ViewReceipts.Specialtie,
		            ViewReceipts.[date]
	                from ViewReceipts
                    where [date] between :date01 and :date02 ";

        $stmt = DB->prepare($query);
        $stmt->bindParam(':date01', $date01, PDO::PARAM_STR);
        $stmt->bindParam(':date02', $date02, PDO::PARAM_STR);
        $stmt->execute();

        // обход результата
        echo "
          <table class='table table-bordered '>
          <tr><th>Пациент</th><th>Доктор</th><th>Специальность</th><th>Дата</th></tr>";
        while ($row = $stmt->fetch()) {
            echo "
                <tr>
                <td>{$row['Doctor']}</td>
                <td>{$row['Patient']}</td>
                <td>{$row['Specialtie']}</td>
                <td>{$row['date']}</td>
                </tr>";
        }
        echo "</table>";
    }
}

//Выбирает из таблицы информацию о врачах с заданной специальностью
function doQuery04() :void{

    $query = "	select 
		                *
	                from Specialties ;";

    $st = DB->query($query);
    $results = $st->fetchAll();

    echo "
    
        <form class='w-25 m-4' method='post'>
        
       <select class='form-select' name='sp'>
                        <option selected > Выберите специальность </option >";
        foreach ($results as $row)
            echo " <option value = '{$row['Id']}'>{$row['name']}</option >";

      echo "
                </select >
        
                <div class='d-flex mt-3 justify-content-end' >
                    <input class='btn btn-primary' type = 'submit' />
                </div > </form>";

    if(isset($_POST['sp'])){

        $sp = $_POST['sp'];

        $query = "	select 
		                    *
	                    from ViewDoctors 
                        where ViewDoctors.SpecialtieId = :sp ";

        $stmt = DB->prepare($query);
        $stmt->bindParam(':sp', $sp, PDO::PARAM_STR);
        $stmt->execute();

        // обход результата
        echo "
          <table class='table table-bordered '>
          <tr><th>id</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Специальность</th><th>Процент</th></tr>";
        while ($row = $stmt->fetch()) {
            echo "
                <tr>
                <td>{$row['Id']}</td>
                <td>{$row['surname']}</td>
                <td>{$row['name']}</td>
                <td>{$row['patronymic']}</td>
                <td>{$row['Specialtie']}</td>
                <td>{$row['tax']}</td>
                </tr>";
        }
        echo "</table>";
    }


}

//Вычисляет размер заработной платы врача за каждый прием. Включает поля
// Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость
// приема, Зарплата. Сортировка по полю Специальность врача
function doQuery05() :void{

    $query = "			select 
		                    Doctor,
		                    ViewReceipts.Specialtie,
		                    ViewReceipts.price,
		                    ViewReceipts.price *(ViewReceipts.tax/100) - (ViewReceipts.tax/100)*ViewReceipts.price *13/100 as Salary
	                    from ViewReceipts
                        order by ViewReceipts.Specialtie;";

    $st = DB->query($query);
    $results = $st->fetchAll();

    // обход результата
    echo "
      <table class='table table-bordered'>
      <tr><th>Доктор</th><th>Специальность</th><th>Стоимость приема</th><th>Зарплата</th></tr>";
    foreach ($results as $row) {
        echo "
        <tr>
        <td>{$row['Doctor']}</td>
        <td>{$row['Specialtie']}</td>
        <td>{$row['price']}</td>
        <td>{$row['Salary']}</td>
        </tr>";
    }
    echo "</table>";

}

//Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
function doQuery06() :void{

    $query = "		select 
		                Receipts.[date],
		                MAX(price) as [max]
	                from Receipts
                    group by Receipts.[date]
                    order by Receipts.[date]";

    $st = DB->query($query);
    $results = $st->fetchAll();

    // обход результата
    echo "
      <table class='table table-bordered'>
      <tr><th>Дата</th><th>Максимальная стоимость</th></tr>";
    foreach ($results as $row) {
        echo "
        <tr>
        <td>{$row['date']}</td>
        <td>{$row['max']}</td>
        </tr>";
    }
    echo "</table>";

}

//Выполняет группировку по полю Специальность. Для каждой специальности вычисляет средний Процент
// отчисления на зарплату от стоимости приема
function doQuery07() :void{

    $query = "	select 
		            Specialties.[name],
		            AVG(tax) as [AVG]
	                from Specialties left join  Doctors on Specialties.Id = Doctors.id_specialtie
                    group by Specialties.[name]";

    $st = DB->query($query);
    $results = $st->fetchAll();

    // обход результата
    echo "
      <table class='table table-bordered'>
      <tr><th>Специальность</th><th>Средний Процент</th></tr>";
    foreach ($results as $row) {
        echo "
        <tr>
        <td>{$row['name']}</td>
        <td>{$row['AVG']}</td>
        </tr>";
    }
    echo "</table>";

}