<?php

// диапазон для генерация строк матрицы
const MIN_ROW = 3, MAX_ROW = 5;

// диапазон для генерации столбцов
const MIN_COLUMN = 3, MAX_COLUMNS = 5;

// диапазон значений для генерации
const MIN_VALUE = -10, MAX_VALUE = 10;

function swap(&$x, &$y) {
    $temp = $x;
    $x = $y;
    $y = $temp;
}

// вывод в консоль браузера
function debug($message){
    echo("<script>console.log('PHP: " . $message . "');</script>");
}