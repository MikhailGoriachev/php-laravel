<?php

class DbController
{

    // база данных
    private PDO $db;

    // конструктор
    public function __construct(string $connection = 'sqlite:../../app_data/Polyclinic.db')
    {
        // подключиться к БД
        $this->db = new PDO($connection);
    } // __construct

    // TODO падает с исключением
//    // деструктор
//    public function __destruct()
//    {
//        // закрыть соединение с БД
//        $this->db = null;
//    } // __destruct

    // вывод таблицы Person
    public function getPersons(): array
    {
        $query = "
            select 
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
            from
                Persons
            order by
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
        ";

        return $this->db->query($query)->fetchAll();
    } // getPersons

    // вывод таблицы докторов
    public function getDoctors(): array
    {
        $query = "
            select 
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
                , Specialties.Title as TitleSpec
                , Doctors.Price
                , Doctors.Percent
            from
                Doctors join Persons on Doctors.IdPerson = Persons.Id
                        join Specialties on Doctors.IdSpeciality = Specialties.Id
            order by
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
                , Specialties.Title 
                , Doctors.Price
                , Doctors.Percent
        ";

        return $this->db->query($query)->fetchAll();
    } // getDoctors

    // вывод таблицы пациентов
    public function getPatients(): array
    {
        $query = "
            select 
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
                , Patients.DateOfBirth
                , Patients.Address
            from
                Patients join Persons on Patients.IdPerson = Persons.Id
            order by
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
                , Patients.DateOfBirth
                , Patients.Address
        ";

        return $this->db->query($query)->fetchAll();
    } // getPersons

    // вывод таблицы специальностей
    public function getSpecialties(): array
    {
        $query = "
            select
                Specialties.Title
            from
                Specialties
            order by
                Specialties.Title
        ";

        return $this->db->query($query)->fetchAll();
    } // getSpecialties

    // вывод таблицы приемов
    public function getConsultations(): array
    {
        $query = "
            select
                Consultations.Date
                , DoctorFullName
                , PatientFullName
            from
                Consultations join (
                    select 
                        Doctors.Id,
                        Persons.Surname || ' ' || substr(Persons.Name,1,1) || 
		        '. ' || substr(Persons.Patronymic,1,1) || 
		        '.' as DoctorFullName
                    from 
                        Doctors join Persons on Doctors.IdPerson = Persons.Id ) as d on d.Id = Consultations.IdDoctor
                        join (select 
                            Patients.Id
                            , Persons.Surname || ' ' || substr(Persons.Name,1,1) || 
		        '. ' || substr(Persons.Patronymic,1,1) || 
		        '.' as PatientFullName
                          from
                              Patients join Persons on Patients.IdPerson = Persons.Id ) as p on p.Id = Consultations.IdPatient
            order by
                Consultations.Date
        ";

        return $this->db->query($query)->fetchAll();
    } // getSpecialties

    // Выбирает информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов
    public function query01(string $surname)
    {
        $query = "
            select 
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
                , Patients.DateOfBirth
                , Patients.Address
            from
                Patients join Persons on Patients.IdPerson = Persons.Id
            where
                Persons.Surname like :surname 
            order by
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
                , Patients.DateOfBirth
                , Patients.Address
        ";

        $surname = $surname . "%";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':surname', $surname, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchAll();
    } // query01

    // Выбирает информацию о врачах,
    // для которых значение в поле Процент отчисления на зарплату, больше заданного
    public function query02(float $percent)
    {
        $query = "
            select 
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
                , Specialties.Title as TitleSpec
                , Doctors.Price
                , Doctors.Percent
            from
                Doctors join Persons on Doctors.IdPerson = Persons.Id
                        join Specialties on Doctors.IdSpeciality = Specialties.Id            
            where
                Doctors.Percent > :percent
            order by
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
                , Specialties.Title 
                , Doctors.Price
                , Doctors.Percent
        ";

        $stmt = $this->db->prepare($query);
        // TODO костыль или фича?
        $stmt->bindParam(':percent', $percent, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchAll();
    } // query02

    // Выбирает информацию о приемах за некоторый период
    public function query03(string $startDate, string $finalDate)
    {
        $query = "
            select
                Consultations.Date
                , DoctorFullName
                , PatientFullName
            from
                Consultations join (
                    select 
                        Doctors.Id,
                        Persons.Surname || ' ' || substr(Persons.Name,1,1) || 
		        '. ' || substr(Persons.Patronymic,1,1) || 
		        '.' as DoctorFullName
                    from 
                        Doctors join Persons on Doctors.IdPerson = Persons.Id ) as d on d.Id = Consultations.IdDoctor
                        join (select 
                            Patients.Id
                            , Persons.Surname || ' ' || substr(Persons.Name,1,1) || 
		        '. ' || substr(Persons.Patronymic,1,1) || 
		        '.' as PatientFullName
                          from
                              Patients join Persons on Patients.IdPerson = Persons.Id ) as p on p.Id = Consultations.IdPatient
            where
                Consultations.Date >= :startDate and Consultations.Date <= :finalDate
            order by
                Consultations.Date
        ";

        $stmt = $this->db->prepare($query);
        // TODO костыль или фича?
        $stmt->bindParam(':startDate', $startDate, PDO::PARAM_STR);
        $stmt->bindParam(':finalDate', $finalDate, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchAll();
    } // query03

    // Выбирает из таблицы информацию о врачах с заданной специальностью
    public function query04(string $spec)
    {
        $query = "
            select 
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
                , Specialties.Title as TitleSpec
                , Doctors.Price
                , Doctors.Percent
            from
                Doctors join Persons on Doctors.IdPerson = Persons.Id
                        join Specialties on Doctors.IdSpeciality = Specialties.Id            
            where
                Specialties.Title like :spec
            order by
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
                , Specialties.Title 
                , Doctors.Price
                , Doctors.Percent
        ";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':spec', $spec, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchAll();
    } // query04

    // Вычисляет размер заработной платы врача за каждый прием.
    // Включает поля Фамилия врача, Имя врача, Отчество врача,
    // Специальность врача, Стоимость приема, Зарплата. Сортировка по полю Специальность врача
    public function query05()
    {
        $query = "
            select 
                Persons.Surname
                , Persons.Name
                , Persons.Patronymic
                , Specialties.Title as TitleSpec
                , Doctors.Price
                , ((Doctors.Price / 100) * Doctors.Percent) - (((Doctors.Price / 100) * Doctors.Percent) / 100) * 13 as PayDoctor
            from
                Consultations join Doctors on Consultations.IdDoctor = Doctors.Id
                              join Persons on Doctors.IdPerson = Persons.Id
                              join Specialties on Doctors.IdSpeciality = Specialties.Id            
            order by
                Specialties.Title 
        ";

        return $this->db->query($query)->fetchAll();
    } // query05

    // Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
    public function query06()
    {
        $query = "
            select
                Consultations.Date
                , max(Doctors.Price) as MaxPrice
            from
                Consultations join Doctors on Consultations.IdDoctor = Doctors.Id
            group by
                Consultations.Date
            order by
                Consultations.Date
        ";

        return $this->db->query($query)->fetchAll();
    } // query06

    // Выполняет группировку по полю Специальность.
    // Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема
    public function query07()
    {
        $query = "
            select
                Specialties.Title
                , count(Doctors.Percent) as Total
                , avg(ifnull(Doctors.Percent, 0)) as AvgPercent
            from
                Specialties left join Doctors on Specialties.Id = Doctors.IdSpeciality
            group by
                Specialties.Title
            order by
                Specialties.Title
        ";

        return $this->db->query($query)->fetchAll();
    } // query07
}