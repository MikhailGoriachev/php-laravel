<?php


use Models\Task01\MatrixTrait;
spl_autoload_register();
require_once 'MatrixTrait.php';
// Вариант 12. Найти номер первой из строк,
// содержащих хотя бы один положительный элемент (0 считаем положительным числом).
// Уплотнить заданную матрицу, удаляя из нее строки и столбцы, заполненные нулями.
class Variant12 {

    // подключение трейта
    use MatrixTrait;

    // конструктор
    public function __construct() {
        // создание матрицы
        $this->createMatrix();

        // инициализация матрицы случайными значениями
        $this->fillMatrix();
    } // __construct

    // Найти номер первой из строк, содержащих хотя бы один положительный элемент (
    // 0 считаем положительным числом)
    public function getNumberFirstRowContainsPosNum(): int {
        $number = 0;
        $rows = sizeof($this->matrix);
        for ($i = 0; $i < $rows; $i++)
            if (max($this->matrix[$i]) >= 0) {
                $number = ++$i;
                break;
            }

        return $number;
    } // getNumberFirstRowContainsPosNum

    // Уплотнить заданную матрицу, удаляя из нее строки и столбцы, заполненные нулями
    public function compactMatrix() {
        // строки матрицы
        $rows = sizeof($this->matrix);

        // удалить строки которые содержат нули
        for ($i = 0; $i < $rows; $i++){
            // минимальный и максимальный элемент равны 0
            if(min($this->matrix[$i]) === 0 && max($this->matrix[$i]) === 0)
                unset($this->matrix[$i]);
        }

        // переиндексация элементов матрицы
        $this->matrix = array_values($this->matrix);

        // в матрицы остались строки
        // проверка столбцов
        $rows = sizeof($this->matrix);
        if($rows > 0) {

            // количество столбцов
            $cols = sizeof($this->matrix[0]);

            for ($i = 0; $i < $cols; $i++) {

                // столбец матрицы -> массив
                $arr = array_column($this->matrix, $i);

                // минимальный и максимальный элемент равны 0
                if(min($arr) === 0 && max($arr) === 0)
                    for ($j = 0; $j < $rows; $j++)
                        unset($this->matrix[$j][$i]);
            }
        }

        $this->matrix = array_values($this->matrix);

    } // compactMatrix

    public function setZero() {
        $this->matrix = [[0,0,0,0],[1,2,0,3],[3,4,0,5]];
    }

}