<?php

namespace Models\Task01;

// Работу с матрицей (создание, вывод в таблицу, заполнение матрицы значениями),
// реализованная в трейте
trait MatrixTrait {

    // прямоугольная матрица
    private array $matrix;

    // создание матрицы M x N
    public function createMatrix() {
        $this->matrix = [];
        // кол-во строк
        $rows = rand(MIN_ROW, MAX_ROW);

        // кол-во столбцов
        $columns = rand(MIN_COLUMN, MAX_COLUMNS);

        // заполнение случайными значениями
        for ($i = 0; $i < $rows; $i++)
            $this->matrix[$i] = array_pad([], $columns, 0);
    } // createMatrix

    // заполнение матрицы случайными значениями
    public function fillMatrix() {

        // кол-во строк
        $rows = count($this->matrix);

        // кол-во столбцов
        $columns = count($this->matrix);

        // заполнение случайными значениями
        for ($i = 0; $i < $rows; $i++)
            $this->matrix[$i] = array_map(fn() => rand(MIN_VALUE, MAX_VALUE), array_pad([], $columns, 0));

    } // fillMatrix

    // вывод матрицы
    function showMatrix() {

        echo "<table class='mx-auto my-2'>";

        foreach ($this->matrix as $column) {
            echo "<tr>";

            foreach ($column as $data)
                echo "<td class='text-end' style='width: 60px;'>$data</td>";

            echo "</tr>";
        } // foreach

        echo "</table>";
    } // showMatrix

}