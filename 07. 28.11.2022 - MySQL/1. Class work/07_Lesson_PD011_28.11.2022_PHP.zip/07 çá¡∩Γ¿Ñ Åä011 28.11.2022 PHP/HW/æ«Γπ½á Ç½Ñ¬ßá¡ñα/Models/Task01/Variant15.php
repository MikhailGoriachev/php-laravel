<?php

use Models\Task01\MatrixTrait;
spl_autoload_register();
require_once 'MatrixTrait.php';
// Вариант 15. Определить номер первого из столбцов, содержащих хотя бы один нулевой элемент.
// Характеристикой строки целочисленной матрицы назовем сумму ее отрицательных четных элементов.
// Переставляя строки заданной матрицы, расположить их в соответствии с убыванием характеристик.
class Variant15 {

    // подключение трейта
    use MatrixTrait;

    // конструктор
    public function __construct() {
        // создание матрицы
        $this->createMatrix();

        // инициализация матрицы случайными значениями
        $this->fillMatrix();
    } // __construct

    // Определить номер первого из столбцов, содержащих хотя бы один нулевой элемент
    public function getNumberFirstColumnContainsZero(): int{
        $number = 0;
        $cols = sizeof($this->matrix[0]);

        for ($i = 0; $i < $cols; $i++) {
            if(in_array(0, array_column($this->matrix, $i), true)) {
                $number = ++$i;
                break;
            } // if
        } // for

        return $number;
    } // getNumberFirstColumnContainsZero

    // Переставить строки матрицы, расположить их в соответствии с убыванием характеристик.
    public function sortRowsByDescCharacteristic(): void {
        // массив характеристик
        $rowsCharacteristics = [];

        $rows = sizeof($this->matrix);
        $cols = sizeof($this->matrix[0]);

        // формируем массив значений характеристик
        for ($i = 0; $i < $rows; $i++) {
            $rowsCharacteristics[] = array_reduce($this->matrix[$i], function ($sum, $item) {
                if ($item < 0 && $item % 2 === 0)
                    $sum += $item;

                return $sum;
            }, 0);
        } // for

        // перестановка строк по убыванию характеристик
        for ($i = 0; $i < $rows; $i++) {
            for ($j = $i + 1; $j < $rows; $j++) {

                if($rowsCharacteristics[$i] > $rowsCharacteristics[$j]) {
                    // перестановка значений в массиве характеристик
                    swap($rowsCharacteristics[$i], $rowsCharacteristics[$j]);

                    // перестановка строк матрицы
                    swap($this->matrix[$i], $this->matrix[$j]);
                } // if
            } // for j
        } // for i
    } // sortRowsByDescCharacteristic

}