<!DOCTYPE html>

<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Таблица персон</title>

    <link rel="icon" href="../../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../../lib/bootstrap/css/bootstrap.min.css"/>

    <script src="../../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Таблица персон</h1>
</header>

<?php
require_once '../../Controllers/DbController.php';

// активность страниц
$activeTask02 = "active";
$activeTask01 = "";

require_once '../../Helpers/utils.php';
require_once '../../Helpers/header.php';


?>

<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1">

    </div>

    <!--    основной блок контента-->
    <div class="col-sm-10">
        <?php
        $controller = new DbController();
        $rows = $controller->getPersons();

        if (sizeof($rows) > 0) {
            ?>

            <table class="table table-hover w-75 mx-auto mt-5">
                <thead>
                <tr class="text-center">
                    <th>Фамилия</th>
                    <th>Имя</th>
                    <th>Отчество</th>
                </tr>
                </thead>
                <tbody>
                <?php
                foreach ($rows as $row)
                    echo "<tr>
                        <td>{$row['Surname']}</td>
                        <td>{$row['Name']}</td>
                        <td>{$row['Patronymic']}</td>
                      </tr>";
                ?>
                </tbody>
            </table>
            <?php
        } else { ?>
            <h5 class="text-center mt-5">Данные отсутствуют</h5>
            <?php
        } ?>
    </div>

    <!--    правый сайд бар-->
    <div class="col-sm-1"></div>
</div>
<!--футер-->
<?php
require_once '../../Helpers/footer.php';
?>
</body>
</html>