<!DOCTYPE html>

<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Информация о приемах за заданный период</title>

    <link rel="icon" href="../../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../../lib/bootstrap/css/bootstrap.min.css"/>

    <script src="../../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Информация о приемах за заданный период</h1>
</header>

<?php
require_once '../../Controllers/DbController.php';

// активность страниц
$activeTask02 = "active";
$activeTask01 = "";

require_once '../../Helpers/utils.php';
require_once '../../Helpers/header.php';


?>

<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1">

    </div>

    <!--    основной блок контента-->
    <div class="col-sm-10">
        <?php
        if (isset($_POST['startDate']) && isset($_POST['finalDate'])) {
            $controller = new DbController();
            $rows = $controller->query03($_POST['startDate'], $_POST['finalDate']);
            if (sizeof($rows) > 0) {
                ?>
                <table class="table table-hover w-75 mx-auto mt-5">
                    <thead>
                    <tr class="text-center">
                        <th>Дата</th>
                        <th>Доктор</th>
                        <th>Пациент</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    foreach ($rows as $row)
                        echo "<tr>
                        <td class='text-center'>{$row['Date']}</td>
                        <td>{$row['DoctorFullName']}</td>
                        <td>{$row['PatientFullName']}</td>
                      </tr>";
                    ?>
                    </tbody>
                </table>
                <?php
            } else { ?>
                <h5 class="text-center mt-5">Данные отсутствуют</h5>
                <?php
            }
        } else { ?>
            <h5 class="h5 text-center mt-5">Введите диапазон дат</h5>
            <form method="post" class="w-50 mt-5 mx-auto">

                <div class="form-floating mb-2 mx-auto">
                    <input type="date"
                           name="startDate"
                           class="form-control"
                           placeholder="Начальная дата" required/>
                    <label class="form-label">Начальная дата</label>
                </div>

                <div class="form-floating mb-2 mx-auto">
                    <input type="date"
                           name="finalDate"
                           class="form-control"
                           placeholder="Конечная дата" required/>
                    <label for="finalDate" class="form-label">Конечная дата</label>
                </div>


                <div class="row">
                    <button type="submit" class="btn btn-outline-success mx-auto col-sm-3 mt-5">Поиск</button>
                </div>
            </form>
            <?php
        } ?>

        <form></form>


    </div>

    <!--    правый сайд бар-->
    <div class="col-sm-1"></div>
</div>
<!--футер-->
<?php
require_once '../../Helpers/footer.php';
?>
</body>
</html>