<!DOCTYPE html>

<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Задача 1</title>

    <link rel="icon" href="../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Задача 1</h1>
</header>

<?php

//use Models\Task01\Variant12;
//use Models\Task01\Variant15;
require_once '../Models/Task01/Variant12.php';
require_once '../Models/Task01/Variant15.php';
//spl_autoload_register();

// активность страниц
$activeTask01 = "active";
$activeTask02 = $activeMain = "";

require_once '../Helpers/utils.php';
require_once '../Helpers/header.php';
try {
    ?>

    <div class="row container-fluid bg-body">

        <!--    левый сайд бар-->
        <div class="col-sm-1">

        </div>

        <!--    основной блок контента-->
        <div class="col-sm-10">

            <div class="row">

                <div class="col-sm-5 mx-auto">

                    <h4 class="h4 text-center mt-5">Вариант 12</h4>

                    <?php
                    // инициализация варианта 12
                    $var12 = new Variant12();
                    ?>

                    <h6 class="h6 text-center mt-5 mb-5">Сгенерированная матрица</h6>

                    <?php
                    // вывод сгенерированной матрицы
                    $var12->showMatrix();
                    ?>

                    <h6 class="h6 text-center mt-5 mb-5">Номер первой строки содержащий хотя бы один положительный
                        элемент</h6>

                    <?php
                    // поиск строки
                    $number = $var12->getNumberFirstRowContainsPosNum();

                    // формирование результата
                    $result = $number > 0 ? "Номер первой строки: " . $number : "Нет строк содержащих хотя бы один положительный элемент";

                    // вывод результата в разметку
                    echo "<p class='text-center'><b>" . $result . "</b></p>";

                    $var12->setZero(); ?>

                    <h6 class="h6 text-center mt-5 mb-5">Матрица до уплотнения</h6>

                    <?php

                    $var12->showMatrix();

                    $var12->compactMatrix();

                    ?>

                    <h6 class="h6 text-center mt-5 mb-5">Матрица после уплотнения</h6>
                    <?php $var12->showMatrix(); ?>
                </div>

                <div class="col-sm-5 mx-auto">

                    <h4 class="h4 text-center mt-5">Вариант 15</h4>

                    <?php
                    // инициализация варианта 15
                    $var15 = new Variant15();
                    ?>

                    <h6 class="h6 text-center mt-5 mb-5">Сгенерированная матрица</h6>

                    <?php
                    // вывод сгенерированной матрицы
                    $var15->showMatrix();
                    ?>

                    <h6 class="h6 text-center mt-5 mb-5">Номер первого из столбцов, содержащих хотя бы один нулевой
                        элемент</h6>

                    <?php
                    // поиск столбца
                    $number = $var15->getNumberFirstColumnContainsZero();

                    // формирование результата
                    $result = $number > 0 ? "Номер первого столбца: " . $number : "Нет столбцов содержащих хотя бы один нулевой элемент";

                    // вывод результата в разметку
                    echo "<p class='text-center'><b>" . $result . "</b></p>";

                    $var15->sortRowsByDescCharacteristic();
                    ?>

                    <h6 class="h6 text-center mt-5 mb-5">Матрица после перестановки строк по убыванию
                        характеристики</h6>

                    <?php
                    $var15->showMatrix() ?>

                </div>

            </div>

        </div>
        <!--    правый сайд бар-->
        <div class="col-sm-1"></div>
    </div>
    <!--футер-->
    <?php
} catch (Exception $exception) {
    echo "<h4 class='text-center text-danger h4'>{$exception->getMessage()}</h4>";
}
require_once '../Helpers/footer.php';
?>
</body>
</html>