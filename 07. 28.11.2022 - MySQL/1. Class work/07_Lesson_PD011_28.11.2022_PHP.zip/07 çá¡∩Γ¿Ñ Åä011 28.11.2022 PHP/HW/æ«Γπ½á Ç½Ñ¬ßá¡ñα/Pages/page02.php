<!DOCTYPE html>

<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Запросы к БД</title>

    <link rel="icon" href="../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>

    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Запросы к БД</h1>
</header>

<?php
require_once '../Controllers/DbController.php';

// активность страниц
$activeTask02 = "active";
$activeTask01 = $activeMain ="";

require_once '../Helpers/utils.php';
require_once '../Helpers/header.php';


?>

<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1">

    </div>

    <!--    основной блок контента-->
    <div class="col-sm-10">

        <div class="row mt-5">
            <h5 class="h5 text-center mb-5">Таблицы</h5>
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="tables/persons.php">Персоны</a>
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="tables/doctors.php">Доктора</a>
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="tables/patients.php">Пациенты</a>
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="tables/speciality.php">Специальности</a>
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="tables/consultations.php">Приемы</a>
        </div>

        <div class="row mt-5">
            <h5 class="h5 text-center mb-5">Запросы</h5>
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="queries/query01.php">Пациенты с заданной фамилией</a>
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="queries/query02.php">Доктора c процентом больше заданного</a>
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="queries/query03.php">Информация о приемах за заданный период</a>
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="queries/query04.php">Врачи по заданной специальности</a>
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="queries/query05.php">Заработные платы врачей за каждый прием</a>
        </div>

        <div class="row mt-5">
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="queries/query06.php">Максимальная стоимость приема для каждой даты</a>
            <a class="btn btn-outline-dark col-sm-2 mx-auto" href="queries/query07.php">Средний процент отчисления для каждой специальности</a>
        </div>

    </div>

    <!--    правый сайд бар-->
    <div class="col-sm-1"></div>
</div>
<!--футер-->
<?php
require_once '../Helpers/footer.php';
?>
</body>
</html>
