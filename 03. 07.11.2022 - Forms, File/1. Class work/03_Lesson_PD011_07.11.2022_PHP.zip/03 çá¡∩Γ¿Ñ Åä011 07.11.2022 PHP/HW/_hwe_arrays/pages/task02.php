<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>Задание на 31.10.2022</title>
    <!-- подключение файла-иконки -->
    <link rel="shortcut icon" href="/images/blimp.png" type="image/x-icon">

    <!-- подключение bootstrap -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- подключение собственных стилей -->
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>

<?php
    // загрузка панели навигации

    // активность страниц
    $activeTask02 = "active";
    $activeTask01 = $activeTask03 = "";


    // собственно загрузка панели навигации
    include_once "../pages/shared/_header.php";
?>

<!-- размещение контента страницы -->
<main class="container mt-5">
    <div class="row">
        <details>
            <summary><b>Задача 2.</b> Обработка  ассоциативного массива</summary>
            <p>
                В ассоциативном массиве требуется хранить названия стран (ключи) и население этих стран
                (по данным Википедии, например 😊). Выполните следующие обработки массива:
            </p>
            <ul class="ms-5">
                <li>вывод неупорядоченного массива</li>
                <li>вывод массива, упорядоченного по ключам</li>
                <li>вывод массива, упорядоченного по значениям</li>
            </ul>
        </details>

        <h5 class="mt-3">Решение задачи 2 - работа с ассоциативным массивом</h5>
        <!-- тут будет рендеринг решения задачи 2 -->
        <?php
        require_once "../src/utils.php";
        require_once "../src/functions.php";

        task02();
        ?>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../pages/shared/_footer.php" ?>
</body>
</html>
