<?php
// вспомогательные функции

// генерация вещественного случайного числа в диапазоне значений [lo, hi]
function random_float ($lo, $hi) {
    return ($lo + lcg_value()*(abs($hi - $lo)));
} // random_float

// обмен двух переменных
function swap(&$a, &$b) {
    // языковая конструкция, начиная с версии языка PHP 7.1
    [$a, $b] = [$b, $a];
} // swap

// создание одномерного массива из $n элементов, заполнение массива случайными числами
// в диапазоне значений [$lo, $hi]
function createArray($n, $lo, $hi) {
    // array_pad — Дополнить размер массива определенным значением до заданной величины
    // array_map — Применяет callback-функцию ко всем элементам указанных массивов
    return array_map(fn() => rand($lo, $hi), array_pad([], $n, 0));
} // createArray

// создание прямоугольного массива размером $m x $n с диапазоном
// значений элементов [$lo, $hi]
function createMatrix($m, $n, $lo, $hi) {
    $matrix = [];

    // Заполнение матрицы случайными целыми числами
    for ($i = 0; $i < $m; $i++) {
        $matrix[] = array_map(fn() => rand($lo, $hi), array_pad([], $n, 0));
    } // for i

    return $matrix;
} // createMatrix

// вывод одномепорного массива в виде однострочной таблицы
function showArray($title, $data) {

    echo "<h5>$title</h5>
         <table class='w-75 table table-bordered'><tbody><tr><td>"
        .implode("</td><td>", $data)
        ."</td></tr></tbody></table>";
} // showArray


// вывод матрицы в виде прямоугольной таблицы
function showMatrix($title, $matrix) {

    echo "
        <h5 class='text-center'>$title</h5>
        <table class='table w-75 mx-auto my-2'><tbody>";

    foreach ($matrix as $row):
        echo "<tr>";

        foreach ($row as $datum) :
            echo "<td class='text-end'>$datum</td>";
        endforeach;

        echo "</tr>";
    endforeach;

    echo "</tbody></table>";
} // showMatrix

// вывод заголовка, матрицы и вспомогательного массива по строкам матрицы
// если элемент вспомогательного массива == null, ничего не выводить в этой строке
function showMatrixAndRowsArray($title, $matrix, $rowArr) {
    echo "
        <h5 class='text-center'>$title</h5>
        <table class='table mx-auto my-2 w-75' ><tbody>";

    $i = 0;
    foreach ($matrix as $row):
        echo "<tr>";

        foreach ($row as $datum) :
            echo "<td class='text-end'>$datum</td>";
        endforeach;

        // вывод вспомогательного элемиент строки матрицы
        echo "<td class='text-end bg-secondary text-white px-3'><b>$rowArr[$i]</b></td></tr>";
        $i++;
    endforeach;

    echo "</tbody></table>";
} // showMatrixAndRowsArray

// вывод заголовка, матрицы и вспомогательного массива по столбцам матрицы
// если элемент вспомогательного массива == null, ничего не выводить в этом
// элементе вспомогательного массива
function showMatrixAndColsArray($title, $matrix, $colArr) {
    echo "
        <h5 class='text-center'>$title</h5>
        <table class='table w-75 mx-auto my-2'><tbody>";

    foreach ($matrix as $row):
        echo "<tr>";

        foreach ($row as $datum) :
            echo "<td class='text-end'>$datum</td>";
        endforeach;
        echo "</td></tr>";
    endforeach;

    // вывод еще одной строки таблицы - вспомогательного массива для столбцов
    echo "<tr>";
    foreach ($colArr as $item) {
        echo "<td class='text-end text-white bg-secondary py-3'><b>$item</b></td>";
    } // foreach

    echo "</tr></tbody></table>";
} // showMatrixAndRowsArray

// перестановка столбцов матрицы
function swapCols($matrix, $col1, $col2) {
    $m = count($matrix);
    for ($i = 0; $i < $m; $i++) {
        swap($matrix[$i][$col1], $matrix[$i][$col2]);
    } // for $i
} // swapCols