<?php

require_once "utils.php";

// работа с ассоциативным массивом
function task02() {
    $countries = [
        "Россия" => 147_182_123,
        "США" => 336_023_460,
        "Франция" => 68_084_217,
        "Германия" => 83_019_200,
        "Великобритания" => 67_081_000,
        "Испания" => 47_394_223,
    ];

    // вывод неупорядоченного ассоциативного массива
    echo "<h5>Неупорядоченный ассоциативный массив</h5>";
    echo "<ul class='mx-5'>";
    foreach ($countries as $name => $population) {
        echo "<li>$name --> $population чел.</li>";
    }
    echo "</ul>";

    // вывод ассоциативного массива, упорядоченного по ключам
    ksort($countries);
    echo "<h5>Ассоциативный массив, упорядоченный по ключам</h5>";
    echo "<ul class='mx-5'>";
    foreach ($countries as $name => $population) {
        echo "<li>$name --> $population чел.</li>";
    }
    echo "</ul>";

    // вывод ассоциативного массива, упорядоченного по значениям
    natsort($countries);
    echo "<h5>Ассоциативный массив, упорядоченный по значениям</h5>";
    echo "<ul class='mx-5'>";
    foreach ($countries as $name => $population) {
        echo "<li>$name --> $population чел.</li>";
    }
    echo "</ul>";

} // task02

// ----------------------------------------------------------------------------

// Возвращает сумму элементов в тех строках, для которых сработает предикат
function sumRowsByPredicate($matrix, $predicate) {
    $sum = [];

    foreach ($matrix as $row):
        $sum[] = $predicate($row)?array_sum($row):null;
    endforeach;

    return $sum;
} // sumRowsByPredicate


// Вычислить сумму элементов в тех столбцах, для которых сработает предикат
function sumColsByPredicate($matrix, $predicate) {
    $sum = [];

    $n = count($matrix[0]);
    for ($j = 0; $j < $n; $j++) {
        $cols = array_column($matrix, $j);
        $sum[] = $predicate($cols)?array_sum($cols):null;
    } // for $j

    return $sum;
} // sumColsByPredicate

// Индексы строк и столбцов всех седловых точек матрицы. Элемент матрицы Aij является седловой
// точкой, если он минимальный в i-й строке и максимальный в j-м столбце
function showSaddlePoints($matrix) {
    echo "<h5 class='text-center my-3 text-danger'>Определение седловых точек - в разработке</h5>";
}

// Возвращает характеристики столбцов
function calcColumnsCharacteristics($matrix, $innerFunction) {
    $characteristics = [];

    $n = count($matrix[0]);
    for ($j = 0; $j < $n; $j++) {
        $cols = array_column($matrix, $j);
        $characteristics[] = array_reduce($cols, $innerFunction,0);
    }

    return $characteristics;
} // calcColumnsCharacteristics

// перестановка столбцов матрицы по убыванию значений вспомогательного массива
function matrixOrderByCol(&$matrix, &$cols, $comparer) {
    $n = count($cols);
    for ($i = 0; $i < $n; $i++) {

        for ($j = $i + 1; $j < $n; $j++) {

            if($comparer($cols[$i], $cols[$j]) >= 0) {
                // перестановка значений в массиве характеристик
                swap($cols[$i], $cols[$j]);

                // перестановка столбцов матрицы
                swapCols($matrix, $i, $j);
            } // if
        } // for j
    } // for i
} // matrixOrderByCol


// Возвращает характеристики столбцов
function calcRowsCharacteristics($matrix, $innerFunction) {
    $characteristics = [];

    foreach ($matrix as $row) {
        $characteristics[] = array_reduce($row, $innerFunction, 0);
    }

    return $characteristics;
} // calcRowsCharacteristics


// перестановка строк матрицы по возрастанию значений вспомогательного массива
function matrixOrderByRow(&$matrix, &$rows, $comparer) {
    $m = count($rows);
    for ($i = 0; $i < $m; $i++) {

        for ($j = $i + 1; $j < $m; $j++) {

            if($comparer($rows[$i], $rows[$j]) >= 0) {
                // перестановка значений в массиве характеристик
                swap($rows[$i], $rows[$j]);

                // перестановка строк матрицы
                swap($matrix[$i], $matrix[$j]);
            } // if
        } // for j
    } // for i
} // matrixOrderByCol


// Удаление строк матрицы с минимальной и максимальной характеристиками
function removeRowsMinChahrcterisitics($matrix, $rows) {
    echo "<h5 class='text-center my-3 text-danger'>Удаление строк матрицы с минимальной и максимальной характеристиками - в разработке</h5>";
}
// ----------------------------------------------------------------------------