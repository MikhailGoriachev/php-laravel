
<footer class="container-fluid mt-5">
    <div class="row align-items-center bg-light h-60-px">
        <h6 class="text-center">&copy;<?=date("Y");?>, Масленников Виталий, г. Донецк, КА «ШАГ», ПД011.</h6>
    </div>
</footer>