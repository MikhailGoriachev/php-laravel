<?php

function getRandomFloat($from, $to): float|int
{
    return mt_rand($from, $to - 1) + mt_rand() / mt_getrandmax();
}

function renderArray($arr, $highlightFn = null): string
{
    if (is_null($highlightFn))
        $highlightFn = fn($cur, $ind) => false;

    $ind = 0;
    return array_reduce($arr, function ($prev, $cur) use (&$ind, $highlightFn) {
        return $prev . "<td class='px-3" . ($highlightFn($cur, $ind++) ? " table-active color-1'" : "'") . ">" . rtrim(rtrim(number_format($cur, 2), '0'), '.') . "</td>";
    }, "");
}