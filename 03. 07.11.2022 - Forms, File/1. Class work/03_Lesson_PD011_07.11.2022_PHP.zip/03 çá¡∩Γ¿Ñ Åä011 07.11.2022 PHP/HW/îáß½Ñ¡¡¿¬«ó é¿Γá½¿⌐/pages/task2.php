<?php
const HEADER = 'Задание 2';
const PAGE = 'task2';

$countries = array(
    "Китай" => 1_424_944_000,
    "Индия" => 1_409_080_000,
    "США" => 336_023_460,
    "Индонезия" => 280_488_501,
    "Пакистан" => 227_866_022,
    "Бразилия" => 218_024_940,
    "Нигерия" => 216_826_390,
    "Бангладеш" => 179_650_173,
    "Россия" => 147_182_123,
    "Мексика" => 128_649_565
);

ob_start();

?>
<div class="container-fluid">
    <div class="row">
        <div class="col-auto">
            <div class="lead fs-5">Исходные значения:</div>

            <table class="table table-bordered text-center caption-top w-auto mt-2">
                <thead>
                <tr>
                    <th class="px-5">Страна</th>
                    <th class="px-5">Население</th>
                </tr>
                </thead>
                <tbody>
                <?php
                foreach ($countries as $key => $value) {
                    echo "<tr><td>$key</td> <td>$value</td></tr>";
                } ?>
                </tbody>
            </table>
        </div>

        <div class="col-auto">
            <div class="lead fs-5">Упорядочено по ключам:</div>

            <table class="table table-bordered text-center caption-top w-auto mt-2">
                <thead>
                <tr>
                    <th class="px-5">Страна</th>
                    <th class="px-5">Население</th>
                </tr>
                </thead>
                <tbody>
                <?php
                ksort($countries, SORT_STRING);
                foreach ($countries as $key => $value) {
                    echo "<tr><td>$key</td> <td>$value</td></tr>";
                } ?>
                </tbody>
            </table>
        </div>

        <div class="col-auto">
            <div class="lead fs-5">Упорядочено по значениям:</div>

            <table class="table table-bordered text-center caption-top w-auto mt-2">
                <thead>
                <tr>
                    <th class="px-5">Страна</th>
                    <th class="px-5">Население</th>
                </tr>
                </thead>
                <tbody>
                <?php
                natsort($countries);
                foreach ($countries as $key => $value) {
                    echo "<tr><td>$key</td> <td>$value</td></tr>";
                } ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php
$content = ob_get_clean();
include_once("../inc/layout.php");
?>
