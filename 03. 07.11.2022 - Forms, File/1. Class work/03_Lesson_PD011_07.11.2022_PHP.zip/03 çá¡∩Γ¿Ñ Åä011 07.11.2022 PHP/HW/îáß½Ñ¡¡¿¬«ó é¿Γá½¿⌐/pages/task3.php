<?php
include_once("../inc/functions.php");

const HEADER = 'Задание 3';
const PAGE = 'task3';

const N_ELEMENTS = 10;

const MIN = -5;
const MAX = 50;

ob_start();

$array = array_map(fn() => array_map(fn() => mt_rand(MIN, MAX), array_fill(0, N_ELEMENTS, null)),
    array_fill(0, N_ELEMENTS, null));;

?>
<div class="lead fs-5">Матрица с суммами строк, имеющих отрицательные значения:</div>
<table class="table table-bordered text-center mt-2">
    <tbody>
    <?php
    foreach ($array as $row) {
        $neg = null;
        echo "<tr>";
        foreach ($row as $item) {
            if ($item < 0) $neg = $item;
            echo "<td>$item</td>";
        }
        echo "<td>" . (!is_null($neg) ? "Σ: " . array_sum($row) : " ") . "</td>" . "</tr>";
    }
    ?>
    </tbody>
</table>

<div class="lead fs-5">Матрица с суммами столбцов, имеющих положительные значения:</div>
<table class="table table-bordered text-center mt-2">
    <tbody>
    <?php
    $array = array_map(fn() => array_map(fn() => mt_rand(-50, 5), array_fill(0, N_ELEMENTS, null)),
        array_fill(0, N_ELEMENTS, null));;

    foreach ($array as $row) {
        echo "<tr>";
        foreach ($row as $item) {
            echo "<td>$item</td>";
        }
        echo "</tr>";
    }
    ?>
    <tr>
        <?php
        for ($i = 0, $count = count($array); $i < $count; $i++) {
            echo "<td>" . (count(array_filter(array_column($array, $i), fn($v) => $v >= 0)) > 0 ? "Σ: " . array_sum(array_column($array, $i)) : " ") . "</td>";
        }
        ?>
    </tr>
    </tbody>
</table>


<?php

$array = array_map(fn() => array_map(fn() => mt_rand(1, 2), array_fill(0, N_ELEMENTS, null)),
    array_fill(0, N_ELEMENTS, null));

for ($i = 0, $count = count($array); $i < $count; $i++) {
    $min_row = $array[$i][0];
    $col_ind = 0;
    for ($j = 1; $j < $count; $j++) {
        if ($min_row > $array[$i][$j]) {
            $min_row = $array[$i][$j];
            $col_ind = $j;
        }
    }

    for ($k = 0; $k < $count; $k++)
        if ($min_row < $array[$k][$col_ind])
            break;

    if ($k == $count) {
        echo "Value of Saddle Point ", $min_row;
    }
}
?>


<div class="lead fs-5">Матрица для вычисления седловых точек:</div>
<table class="table table-bordered text-center mt-2 w-50">
    <tbody>
    <?php
    $array = array_map(fn() => array_map(fn() => mt_rand(1, 3), array_fill(0, 4, null)),
        array_fill(0, 4, null));

    foreach ($array as $row) {
        echo "<tr>";
        foreach ($row as $item) {
            echo "<td>$item</td>";
        }
        echo "</tr>";
    }
    ?>
    </tbody>
</table>

<div class="lead fs-5">Седловые точки:</div>
<table class="table w-50 text-center">
    <thead>
    <tr>
        <td>Строка</td>
        <td>Столбец</td>
    </tr>
    </thead>
    <tbody>
    <?php
    for ($i = 0, $countR = count($array); $i < $countR; $i++) {
        $minRow = min($array[$i]);

        for ($j = 0, $countC = count($array[$i]); $j < $countR; $j++) {
            if ($array[$i][$j] == $minRow && $array[$i][$j] == max(array_column($array, $j))) {
                echo "<tr><td>".($i + 1)."</td><td>".($j + 1)."</td></tr>";
            }
        }
    }
    ?>
    </tbody>
</table>


<?php
$content = ob_get_clean();
include_once("../inc/layout.php");
?>
