<?php
include_once("../inc/functions.php");

const HEADER = 'Задание 1';
const PAGE = 'task1';
const MIN = -10;
const MAX = 10;

const N_ELEMENTS = 10;

$array = array_map(fn() => getRandomFloat(MIN, MAX), array_fill(0, N_ELEMENTS, null));
// для варианта с нулями
$array2 = array_map(fn() => rand(-5, 5), array_fill(0, 10, null));


ob_start();
?>


<table class="table table-bordered text-center caption-top w-auto">
    <caption class="fs-5">Массив для обработки</caption>
    <tbody>
    <tr><?= renderArray($array) ?></tr>
    </tbody>
</table>


<table class="table table-bordered text-center caption-top w-auto">
    <caption class="fs-5">Элементы массива равные нулю</caption>
    <tbody>
    <tr><?= renderArray($array2, fn($el, $ind) => $el == 0) ?></tr>
    </tbody>
</table>
<p>Количество: <?= count(array_filter($array2, fn($el) => $el == 0)) ?></p>


<table class="table table-bordered text-center caption-top w-auto">
    <caption class="fs-5">Отрицательные элементы массива</caption>
    <tbody>
    <tr><?= renderArray($array, fn($el, $ind) => $el < 0) ?></tr>
    </tbody>
</table>
<p>Количество: <?= count(array_filter($array, fn($el) => $el < 0)) ?></p>


<table class="table table-bordered text-center caption-top w-auto">
    <caption class="fs-5">Элементы массива, расположенные после минимального (последнего)</caption>
    <tbody>
    <?php
    $indexes = array_keys($array, min($array));
    echo renderArray($array, function ($el, $i) use ($indexes) {
        return $i > $indexes[array_key_last($indexes)];
    }) ?>
    </tbody>
</table>
<p>Сумма:
    <?= number_format(array_sum(array_filter($array, function ($v, $k) use ($indexes) {
        return $k > $indexes[array_key_last($indexes)];
    }, ARRAY_FILTER_USE_BOTH)), 2); ?>
</p>


<table class="table table-bordered text-center caption-top w-auto">
    <caption class="fs-5">Элементы массива, расположенные после минимального по модулю (последнего)</caption>
    <tbody>
    <?php
    $indexOfMin = 0;
    array_walk($array, function ($v, $k) use (&$indexOfMin, $array) {
        if (abs($v) < abs($array[$indexOfMin]))
            $indexOfMin = $k;
    });

    echo renderArray($array, function ($el, $i) use ($indexOfMin) {
        return $i > $indexOfMin;
    })
    ?>
    </tbody>
</table>
<p>Сумма:
    <?php
    $ind = 0;
    echo number_format(array_reduce($array, function ($prev, $cur) use ($indexOfMin, &$ind) {
        return $ind++ > $indexOfMin ? $prev + abs($cur) : $prev;
    }, 0), 2) ?>

</p>


<table class="table table-bordered text-center caption-top w-auto">
    <caption class="fs-5">Элементы массива, упорядоченные по возрастанию модулей</caption>
    <tbody>
    <?php usort($array, fn($a, $b) => abs($a) <=> abs($b)); ?>
    <tr><?= renderArray($array) ?></tr>
    </tbody>
</table>


<table class="table table-bordered text-center caption-top w-auto">
    <caption class="fs-5">Элементы массива, упорядоченные по убыванию</caption>
    <tbody>
    <?php usort($array, fn($a, $b) => $b <=> $a); ?>
    <tr><?= renderArray($array) ?></tr>
    </tbody>
</table>


<table class="table table-bordered text-center caption-top w-auto">
    <caption class="fs-5">Отрицательные элементы массива в начале</caption>
    <tbody>
    <?php usort($array, fn($a, $b) => $a < 0 ? -1 : 1); ?>
    <tr><?= renderArray($array) ?></tr>
    </tbody>
</table>


<table class="table table-bordered text-center caption-top w-auto">
    <caption class="fs-5">Элементы массива заменены квадратами и отсортированы</caption>
    <tbody>
    <?php
    $mapped = array_map(fn($v) => $v < 0 ? $v ** 2 : $v, $array);
    sort($mapped);
    ?>
    <tr><?= renderArray($mapped) ?></tr>
    </tbody>
</table>


<table class="table table-bordered text-center caption-top w-auto">
    <caption class="fs-5">Из массива удалены отрицательные элементы</caption>
    <tbody>
    <?php
    foreach ($array as $key => $el) {
        if ($el < 0) {
            unset($array[$key]);
        }
    }
    ?>
    <tr><?= renderArray($array) ?></tr>
    </tbody>
</table>


<table class="table table-bordered text-center caption-top w-auto">
    <caption class="fs-5">После первого и перед последним элементами вставлено значение "ддмм"</caption>
    <tbody>
    <?php
    array_splice($array, 1, 0, Date("d") . Date("m"));
    array_splice($array, count($array) - 1, 0, Date("d") . Date("m"));
    ?>
    <tr><?= renderArray($array) ?></tr>
    </tbody>
</table>


<?php
$content = ob_get_clean();
include_once("../inc/layout.php");
?>
