/* База данных «Прокат автомобилей» */

/* создание представлений */

-- представление "Автомобили"
create or replace view cars_view as
select
    cars.id
    , cars.car_number
    , cars.`year`
    , cars.insurance_pay
    , cars.pay_rental_day
    , brands.`name` as model
    , colors.`name` as color
from
    cars join brands on cars.id_brand = brands.id
         join colors on cars.id_color = colors.id;
       
-- проверочный запрос для представления "Автомобили"
select * from cars_view;

-- представление для фактов проката
-- представление "Факты проката"
create or replace view rentals_view as
select
	rentals.id
    , clients.surname
    , clients.`name`
    , clients.patronymic
    , clients.passport
    , cars_view.car_number
    , cars_view.`year`
    , cars_view.insurance_pay
    , pay_rental_day
    , cars_view.model
    , cars_view.color
    , rentals.rental_start_date
    , rentals.duration
from
    rentals join clients on rentals.id_client = clients.id
            join cars_view on rentals.id_car = cars_view.id;
    
-- проверочный запрос для представления "Факты проката"    
select * from rentals_view;
       
-- ==========================================================================
       
/* Хранимые процедуры к запросам по заданию */
delimiter ::
       
-- Запрос 1.
-- Выбирает информацию об автомобилях, стоимость одного дня проката 
-- которых меньше заданной
drop procedure if exists query01::
create procedure query01(in pay_rd int)
begin
	select 
	   id
	   , car_number
	   , model
	   , `year`
	   , `color` 
	   , insurance_pay
	   , pay_rental_day
	from 
		cars_view
	where 
		pay_rental_day < pay_rd;
end::


-- Запрос 2.
-- Выбирает информацию об автомобилях, стоимость одного дня 
-- проката которых находится в заданном диапазоне значений
drop procedure if exists query02::
create procedure query02(in lo int, in hi int)
begin
	select 
	   id
	   , car_number
	   , model
	   , `year`
	   , `color` 
	   , insurance_pay
	   , pay_rental_day 
	from 
		cars_view 
	where 
		pay_rental_day between lo and hi;
end::


-- Запрос 3.
-- Выбирает информацию о клиентах, серия-номер паспорта которых 
-- начинается с цифры «2». Включает поля Код клиента, Паспорт, 
-- Дата начала проката, Количество дней проката, Модель автомобиля
drop procedure if exists query03::
create procedure query03(in first_symbol char)
begin
	select 
		rentals_view.surname
		, rentals_view.`name`
		, rentals_view.patronymic
		, rentals_view.passport
		, rentals_view.model
		, rentals_view.duration
		, rentals_view.rental_start_date
	from 
		rentals_view
	where 
		rentals_view.passport regexp concat('^', first_symbol)
	order by
		rentals_view.rental_start_date;
end::
    

    
 -- Запрос 4.  
 -- Выбирает информацию о клиентах, бравших автомобиль напрокат в некоторый 
 -- определенный день. 
drop procedure if exists query04::
create procedure query04(in date_start date)
begin
	select
		rentals_view.surname
		, rentals_view.`name`
		, rentals_view.patronymic
		, rentals_view.passport
		, rentals_view.duration
		, rentals_view.rental_start_date
	from 
		rentals_view
	where
	   rentals_view.rental_start_date = date_start;
end::   
    
    
-- Запрос 5.
-- Выбирает информацию обо всех автомобилях, для которых значение 
-- в поле Страховая стоимость автомобиля попадает в некоторый заданный 
-- интервал.
drop procedure if exists query05::
create procedure query05(in lo int, in hi int)
begin
	select 
	   id
	   , car_number
	   , model
	   , `year`
	   , `color` 
	   , insurance_pay
	   , pay_rental_day 
	from 
		cars_view 
	where 
		insurance_pay between lo and hi;
end::
  
  
-- Запрос 6. 
-- Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса.
-- Включает поля Госномер автомобиля, Модель автомобиля,
-- Год выпуска автомобиля, Страховая стоимость автомобиля,
-- Страховой взнос. Сортировка по полю Год выпуска автомобиля
drop procedure if exists query06::
create procedure query06()
begin
	select 
	   id
	   , car_number
	   , model
	   , `year`
	   , `color` 
	   , pay_rental_day
	   , insurance_pay
	   , insurance_pay * 0.1 as insurance_payment
	from 
		cars_view
	order by
		`year`;
end::    
    
-- Итоговый запрос 7.
-- Выполняет группировку по полю Модель автомобиля.
-- Для каждой модели вычисляет минимальную страховую стоимость автомобиля.
drop procedure if exists query07::
create procedure query07()
begin
	select
		model
		, COUNT(*) as `model_number`
		, MIN(insurance_pay) as min_insurance_pay
		, MAX(insurance_pay) as max_insurance_pay
	from
		cars_view
	group by
		model;
end::    
    
-- Итоговый запрос 8.   
-- Выполняет группировку по полю Код клиента.
-- Для каждого клиента вычисляет минимальное и максимальное значения по полю
-- Количество дней проката
drop procedure if exists query08::
create procedure query08()
begin
	select
		concat(clients.surname, ' ', substr(clients.`name`, 1, 1), '.', substr(clients.patronymic, 1, 1), '.') as `client`
		, clients.passport
		, COUNT(rentals.id_client) as rental_facts
		, ifnull(MIN(rentals.duration), 0) as min_duration
		, ifnull(MAX(rentals.duration), 0) as max_duration
	from
		clients left join rentals on rentals.id_client = clients.id
	group by
		clients.surname, clients.`name`, clients.patronymic, clients.passport;
end::
    
 delimiter ;