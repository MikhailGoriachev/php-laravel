use car_hire_procs_lv;

delimiter $$

/* пример функции, значение которой не зависит от параметров
   но  функция читает SQL-данные - reads sql data
 */
drop function if exists funQuery07$$

create function funQuery07() 
returns int reads sql data
begin
    declare result int;
   
    select 
		count(*) into result
	from (
		select
			model
			, COUNT(*) as `model_number`
			, MIN(insurance_pay) as min_insurance_pay
			, MAX(insurance_pay) as max_insurance_pay
		from
			cars_view
		group by
			model
   ) as subquery;
    
    return result;
end$$


delimiter ;

set @r = car_hire_procs_lv.funQuery07();
select @r as r;