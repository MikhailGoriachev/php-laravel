/* База данных «Прокат автомобилей» */
      
/* Вызов процедур к запросам по заданию */
       
-- Запрос 1.
-- Выбирает информацию об автомобилях, стоимость одного дня проката 
-- которых меньше заданной
set @pay_rental_day = 500;
call car_hire_procs_lv.query01(@pay_rental_day);

set @pay_rental_day = 1000;
call car_hire_procs_lv.query01(@pay_rental_day);

set @pay_rental_day = 2000;
call car_hire_procs_lv.query01(@pay_rental_day);


-- Запрос 2.
-- Выбирает информацию об автомобилях, стоимость одного дня 
-- проката которых находится в заданном диапазоне значений
set @lo = 500, @hi = 1000;
call car_hire_procs_lv.query02(@lo, @hi);

set @lo = 1001, @hi = 1500;
call car_hire_procs_lv.query02(@lo, @hi);

set @lo = 1501, @hi = 3000;
call car_hire_procs_lv.query02(@lo, @hi);

-- Запрос 3.
-- Выбирает информацию о клиентах, серия-номер паспорта которых 
-- начинается с цифры «2». Включает поля Код клиента, Паспорт, 
-- Дата начала проката, Количество дней проката, Модель автомобиля
set @first_char = '2';
call car_hire_procs_lv.query03(@first_char);

set @first_char = '3';
call car_hire_procs_lv.query03(@first_char);

set @first_char = '1';
call car_hire_procs_lv.query03(@first_char);    
   
   
 -- Запрос 4.  
 -- Выбирает информацию о клиентах, бравших автомобиль напрокат в некоторый 
 -- определенный день. 
set @date_start = '2022-11-23';
call car_hire_procs_lv.query04(@date_start);
   
set @date_start = '2022-11-22';
call car_hire_procs_lv.query04(@date_start);

set @date_start = '2022-11-25';
call car_hire_procs_lv.query04(@date_start);
   
   
-- Запрос 5.
-- Выбирает информацию обо всех автомобилях, для которых значение 
-- в поле Страховая стоимость автомобиля попадает в некоторый заданный 
-- интервал.
set @lo = 1000000, @hi = 4000000;
call car_hire_procs_lv.query05(@lo, @hi);

set @lo = 4000001, @hi = 8000000;
call car_hire_procs_lv.query05(@lo, @hi);

set @lo = 8000001, @hi = 10000000;
call car_hire_procs_lv.query05(@lo, @hi);
  
  
-- Запрос 6. 
-- Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса.
-- Включает поля Госномер автомобиля, Модель автомобиля,
-- Год выпуска автомобиля, Страховая стоимость автомобиля,
-- Страховой взнос. Сортировка по полю Год выпуска автомобиля
call car_hire_procs_lv.query06();
    
    
-- Итоговый запрос 7.
-- Выполняет группировку по полю Модель автомобиля.
-- Для каждой модели вычисляет минимальную страховую стоимость автомобиля.
call car_hire_procs_lv.query07();
    
    
-- Итоговый запрос 8.   
-- Выполняет группировку по полю Код клиента.
-- Для каждого клиента вычисляет минимальное и максимальное значения по полю
-- Количество дней проката
call car_hire_procs_lv.query08();

 