CREATE DATABASE  IF NOT EXISTS `cars_rentals_sotula` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `cars_rentals_sotula`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: cars_rentals_sotula
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (6,'Audi'),(5,'Mercedes'),(1,'Skoda'),(3,'Suzuki'),(4,'Toyota'),(2,'Volkswagen');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cars` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_model` int NOT NULL,
  `id_color` int NOT NULL,
  `plate` varchar(6) NOT NULL,
  `year_manufacture` year NOT NULL,
  `insurance_cost` double unsigned NOT NULL,
  `cost_one_day` double unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plate_UNIQUE` (`plate`),
  KEY `fk_cars_models_idx` (`id_model`),
  KEY `fk_cars_colors_idx` (`id_color`),
  CONSTRAINT `fk_cars_colors` FOREIGN KEY (`id_color`) REFERENCES `colors` (`id`),
  CONSTRAINT `fk_cars_models` FOREIGN KEY (`id_model`) REFERENCES `models` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES (1,2,5,'С167РК',2018,3300000,5600),(2,4,7,'Т306РК',2018,4100000,6100),(3,2,5,'С168РК',2016,3300000,5500),(4,4,7,'Т312РК',2018,4100000,1900),(5,2,5,'О169РК',2016,4300000,6100),(6,1,4,'Н177РК',2018,2800000,1890),(7,2,5,'С170РК',2018,3200000,5600),(8,4,7,'Т315РК',2018,4100000,1500),(9,2,5,'С201РК',2018,3300000,5500),(10,1,4,'Н176РК',2016,2800000,2500),(11,1,4,'Н179РК',2018,2700000,2700),(12,7,2,'В012РК',2016,4100000,6100),(13,7,2,'В015РК',2018,4200000,6200),(14,2,5,'С212РК',2016,3100000,5400),(15,4,7,'Т397РК',2020,2800000,2800),(16,1,4,'Н175РК',2018,2800000,2700),(17,2,5,'С192РК',2016,3100000,5600),(18,4,7,'Т317РК',2020,2900000,1800),(19,7,5,'В019РК',2018,4000000,6000);
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `cars_view`
--

DROP TABLE IF EXISTS `cars_view`;
/*!50001 DROP VIEW IF EXISTS `cars_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `cars_view` AS SELECT 
 1 AS `id`,
 1 AS `brand`,
 1 AS `model`,
 1 AS `plate`,
 1 AS `year_manufacture`,
 1 AS `insurance_cost`,
 1 AS `cost_one_day`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `surname` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `patronymic` varchar(60) NOT NULL,
  `passport` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `passport_UNIQUE` (`passport`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'Юрковский','Марк','Максимилианович','12 21 345671'),(2,'Якубовская','Диана','Павловна','12 21 123452'),(3,'Шапиро','Федор','Федорович','22 21 456123'),(4,'Вожжаев','Сергей','Денисович','12 21 123122'),(5,'Хроменко','Игорь','Владимирович','12 21 342121'),(6,'Пелых','Марина','Ульяновна','11 21 121212'),(7,'Лапотникова','Тамара','Оскаровна','21 21 098181'),(8,'Огородников','Сергей','Иванович','12 21 091911'),(9,'Яйло','Екатерина','Николаевна','12 21 345675'),(10,'Лосева','Инна','Степановна','12 21 187651'),(11,'Михайлович','Анна','Валентиновна','09 20 000122'),(12,'Тарапата','Михаил','Исаакович','09 20 001981'),(13,'Трубихин','Эдуард','Михайлович','09 21 121921'),(14,'Чмыхало','Олег','Тарасович','12 20 021121'),(15,'Князьков','Степан','Сидорович','09 19 002165'),(16,'Потемкина','Наталья','Павловна','09 19 002213'),(17,'Гритченко','Степан','Романович','09 19 002129'),(18,'Селиванов','Александр','Михайлович','11 18 000503'),(19,'Царькова','Лариса','Ильинична','11 18 000523'),(20,'Яструб','Владимир','Данилович','14 21 091811'),(21,'Мелашенко','Александр','Алексеевич','14 21 345675'),(22,'Пономаренко','Владислав','Дмитриевич','23 21 185659'),(23,'Хавалджи','Любовь','Амировна','13 20 000112'),(24,'Пархоменко','Ирина','Владимировна','08 20 001781'),(25,'Демидова','Алина','Александровна','08 21 126921'),(26,'Лысенко','Елена','Егоровна','18 20 061121'),(27,'Федосенко','Оксана','Владимировна','08 19 402165'),(28,'Богатырева','Екатерина','Алексеевна','28 19 032213'),(29,'Иванова','Валентина','Степановна','14 19 003129'),(30,'Ильюшин','Сергей','Юрьевич','13 18 000603');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colors`
--

DROP TABLE IF EXISTS `colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colors`
--

LOCK TABLES `colors` WRITE;
/*!40000 ALTER TABLE `colors` DISABLE KEYS */;
INSERT INTO `colors` VALUES (5,'бело-желтый'),(1,'белый'),(6,'желтый'),(10,'зеленый'),(3,'красный'),(7,'светло-желтый'),(8,'светло-зеленый'),(2,'серебристый'),(9,'сливочно-белый'),(4,'фиолетовый');
/*!40000 ALTER TABLE `colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `models` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_brand` int NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_models_brands_idx` (`id_brand`),
  CONSTRAINT `fk_models_brands` FOREIGN KEY (`id_brand`) REFERENCES `brands` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `models`
--

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
INSERT INTO `models` VALUES (1,1,'Fabia New'),(2,2,'Polo'),(3,1,'Octavia Tour'),(4,1,'Roomster'),(5,1,'Octavia A5'),(6,3,'Grand Vitara'),(7,4,'Camry'),(8,2,'EOS'),(9,5,'210'),(10,6,'A8 Quatro');
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `models_view`
--

DROP TABLE IF EXISTS `models_view`;
/*!50001 DROP VIEW IF EXISTS `models_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `models_view` AS SELECT 
 1 AS `id`,
 1 AS `brand`,
 1 AS `model`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `rentals`
--

DROP TABLE IF EXISTS `rentals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rentals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_client` int NOT NULL,
  `id_car` int NOT NULL,
  `date_start` date NOT NULL,
  `duration` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rentals_clients_idx` (`id_client`),
  KEY `fk_rentals_cars_idx` (`id_car`),
  CONSTRAINT `fk_rentals_cars` FOREIGN KEY (`id_car`) REFERENCES `cars` (`id`),
  CONSTRAINT `fk_rentals_clients` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rentals`
--

LOCK TABLES `rentals` WRITE;
/*!40000 ALTER TABLE `rentals` DISABLE KEYS */;
INSERT INTO `rentals` VALUES (19,13,1,'2022-09-01',15),(20,1,5,'2022-09-01',6),(21,15,8,'2022-09-03',5),(22,11,10,'2022-09-03',9),(23,9,9,'2022-09-04',12),(24,6,3,'2022-09-05',12),(25,7,2,'2022-10-11',13),(26,8,19,'2022-10-20',6),(27,12,11,'2022-11-01',8),(28,16,1,'2022-11-03',3),(29,19,2,'2022-11-04',2),(30,3,8,'2022-11-06',10),(31,5,3,'2022-11-22',4),(32,2,9,'2022-11-23',15),(33,17,1,'2022-11-23',3),(34,10,7,'2022-11-30',13),(35,4,2,'2022-11-30',6),(36,14,5,'2022-11-30',7),(37,20,11,'2022-12-01',15),(38,18,4,'2022-12-02',7),(39,3,10,'2022-12-02',3);
/*!40000 ALTER TABLE `rentals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `rentals_view`
--

DROP TABLE IF EXISTS `rentals_view`;
/*!50001 DROP VIEW IF EXISTS `rentals_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `rentals_view` AS SELECT 
 1 AS `id_rental`,
 1 AS `id_client`,
 1 AS `date_start`,
 1 AS `full_name_client`,
 1 AS `passport`,
 1 AS `brand`,
 1 AS `model`,
 1 AS `plate`,
 1 AS `year_manufacture`,
 1 AS `insurance_cost`,
 1 AS `cost_one_day`,
 1 AS `duration`,
 1 AS `price`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'cars_rentals_sotula'
--

--
-- Dumping routines for database 'cars_rentals_sotula'
--
/*!50003 DROP PROCEDURE IF EXISTS `query01` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `query01`(in cost_one_day double)
begin
	select
		cars_view.brand
		, cars_view.model
		, cars_view.plate
		, cars_view.year_manufacture
		, cars_view.insurance_cost
		, cars_view.cost_one_day
	from
		cars_view
	where
		cars_view.cost_one_day < cost_one_day;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `query02` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `query02`(in min_insurance_cost double, in max_insurance_cost double)
begin
	select
		cars_view.brand
		, cars_view.model
		, cars_view.plate
		, cars_view.year_manufacture
		, cars_view.insurance_cost
		, cars_view.cost_one_day
	from
		cars_view
	where
		cars_view.insurance_cost between min_insurance_cost and max_insurance_cost;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `query03` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `query03`(in start_num int)
begin
	declare start_str varchar(2);
    set start_str := CONCAT("^", start_num);
	select
		rentals_view.id_client
		, rentals_view.full_name_client
		, rentals_view.passport
		, rentals_view.date_start
		, rentals_view.duration
		, CONCAT(rentals_view.brand, " ", rentals_view.model) as model
	from
		rentals_view
	where
		rentals_view.passport regexp start_str;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `query04` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `query04`(in search_date date)
begin
	select
		rentals_view.full_name_client
		, rentals_view.passport
		, rentals_view.date_start
	from
		rentals_view
	where
		rentals_view.date_start like search_date;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `query05` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `query05`(in min_insurance_cost double, in max_insurance_cost double)
begin
	select
		cars_view.brand
		, cars_view.model
		, cars_view.plate
		, cars_view.year_manufacture
		, cars_view.insurance_cost
		, cars_view.cost_one_day
	from
		cars_view
	where
		cars_view.insurance_cost between min_insurance_cost and max_insurance_cost;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `query06` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `query06`()
begin
	select
		cars_view.plate
		, CONCAT(cars_view.brand, " ", cars_view.model) as model
		, cars_view.year_manufacture
		, cars_view.insurance_cost
		, (cars_view.insurance_cost) * 0.1 as insurance_fee
	from
		cars_view
	order by
		cars_view.year_manufacture;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `query07` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `query07`()
begin
	select
		cars_view.brand
		, cars_view.model
		, MIN(cars_view.insurance_cost) as minimal_insurance_cost
	from
		cars_view
	group by
		cars_view.brand
		, cars_view.model;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `query08` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `query08`()
begin
	select
		rentals_view.full_name_client
        , COUNT(rentals_view.full_name_client) as count_rentals
		, MIN(rentals_view.duration) as minimal_duration
		, MAX(rentals_view.duration) as maximal_duration
	from
		rentals_view
	group by
		rentals_view.id_client
	order by
		rentals_view.full_name_client;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `cars_view`
--

/*!50001 DROP VIEW IF EXISTS `cars_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cars_view` AS select `cars`.`id` AS `id`,`brands`.`name` AS `brand`,`models`.`name` AS `model`,`cars`.`plate` AS `plate`,`cars`.`year_manufacture` AS `year_manufacture`,`cars`.`insurance_cost` AS `insurance_cost`,`cars`.`cost_one_day` AS `cost_one_day` from ((`cars` join `models` on((`cars`.`id_model` = `models`.`id`))) join `brands` on((`models`.`id_brand` = `brands`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `models_view`
--

/*!50001 DROP VIEW IF EXISTS `models_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `models_view` AS select `models`.`id` AS `id`,`brands`.`name` AS `brand`,`models`.`name` AS `model` from (`models` join `brands` on((`models`.`id_brand` = `brands`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rentals_view`
--

/*!50001 DROP VIEW IF EXISTS `rentals_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rentals_view` AS select `rentals`.`id` AS `id_rental`,`clients`.`id` AS `id_client`,`rentals`.`date_start` AS `date_start`,concat(`clients`.`surname`,' ',substr(`clients`.`name`,1,1),'.',substr(`clients`.`name`,1,1),'.') AS `full_name_client`,`clients`.`passport` AS `passport`,`brands`.`name` AS `brand`,`models`.`name` AS `model`,`cars`.`plate` AS `plate`,`cars`.`year_manufacture` AS `year_manufacture`,`cars`.`insurance_cost` AS `insurance_cost`,`cars`.`cost_one_day` AS `cost_one_day`,`rentals`.`duration` AS `duration`,(`rentals`.`duration` * `cars`.`cost_one_day`) AS `price` from ((((`rentals` join `clients` on((`rentals`.`id_client` = `clients`.`id`))) join `cars` on((`rentals`.`id_car` = `cars`.`id`))) join `models` on((`cars`.`id_model` = `models`.`id`))) join `brands` on((`models`.`id_brand` = `brands`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-04 15:40:10
