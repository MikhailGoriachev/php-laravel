use cars_rentals_sotula;

-- замена оператора исполнения директива MySQL
delimiter $$

-- Выбирает информацию об автомобилях, 
-- стоимость одного дня проката которых меньше заданной
drop procedure if exists query01$$

create procedure query01(in cost_one_day double)
begin
	select
		cars_view.brand
		, cars_view.model
		, cars_view.plate
		, cars_view.year_manufacture
		, cars_view.insurance_cost
		, cars_view.cost_one_day
	from
		cars_view
	where
		cars_view.cost_one_day < cost_one_day;
end$$

-- Выбирает информацию об автомобилях,
-- страховая стоимость которых находится в заданном диапазоне значений
drop procedure if exists query02$$

create procedure query02(in min_insurance_cost double, in max_insurance_cost double)
begin
	select
		cars_view.brand
		, cars_view.model
		, cars_view.plate
		, cars_view.year_manufacture
		, cars_view.insurance_cost
		, cars_view.cost_one_day
	from
		cars_view
	where
		cars_view.insurance_cost between min_insurance_cost and max_insurance_cost;
end$$

-- Выбирает информацию о клиентах, серия-номер паспорта которых начинается с заданной параметром цифры.
-- Включает поля Код клиента, Паспорт, Дата начала проката, Количество дней проката, Модель автомобиля
drop procedure if exists query03$$
create procedure query03(in start_num int)
begin
	declare start_str varchar(2);
    set start_str := CONCAT("^", start_num);
	select
		rentals_view.id_client
		, rentals_view.full_name_client
		, rentals_view.passport
		, rentals_view.date_start
		, rentals_view.duration
		, CONCAT(rentals_view.brand, " ", rentals_view.model) as model
	from
		rentals_view
	where
		rentals_view.passport regexp start_str;
end$$

-- Выбирает информацию о клиентах, бравших автомобиль напрокат в некоторый определенный день. 
drop procedure if exists query04$$
create procedure query04(in search_date date)
begin
	select
		rentals_view.full_name_client
		, rentals_view.passport
		, rentals_view.date_start
	from
		rentals_view
	where
		rentals_view.date_start like search_date;
end$$

-- Выбирает информацию об автомобилях, для которых значение в поле
-- Страховая стоимость автомобиля попадает в некоторый заданный интервал. 
drop procedure if exists query05$$
create procedure query05(in min_insurance_cost double, in max_insurance_cost double)
begin
	select
		cars_view.brand
		, cars_view.model
		, cars_view.plate
		, cars_view.year_manufacture
		, cars_view.insurance_cost
		, cars_view.cost_one_day
	from
		cars_view
	where
		cars_view.insurance_cost between min_insurance_cost and max_insurance_cost;
end$$

-- Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса.
-- Включает поля Госномер автомобиля, Модель автомобиля, Год выпуска автомобиля,
-- Страховая стоимость автомобиля, Страховой взнос. Сортировка по полю Год выпуска автомобиля
drop procedure if exists query06$$
create procedure query06()
begin
	select
		cars_view.plate
		, CONCAT(cars_view.brand, " ", cars_view.model) as model
		, cars_view.year_manufacture
		, cars_view.insurance_cost
		, (cars_view.insurance_cost) * 0.1 as insurance_fee
	from
		cars_view
	order by
		cars_view.year_manufacture;
end$$

-- Выполняет группировку по полю Модель автомобиля.
-- Для каждой модели вычисляет минимальную страховую стоимость автомобиля.
drop procedure if exists query07$$
create procedure query07()
begin
	select
		cars_view.brand
		, cars_view.model
		, MIN(cars_view.insurance_cost) as minimal_insurance_cost
	from
		cars_view
	group by
		cars_view.brand
		, cars_view.model;
end$$

-- Выполняет группировку по полю Код клиента.
-- Для каждого клиента вычисляет минимальное и максимальное значения по полю Количество дней проката
drop procedure if exists query08$$
create procedure query08()
begin
	select
		rentals_view.full_name_client
        , COUNT(rentals_view.full_name_client) as count_rentals
		, MIN(rentals_view.duration) as minimal_duration
		, MAX(rentals_view.duration) as maximal_duration
	from
		rentals_view
	group by
		rentals_view.id_client
	order by
		rentals_view.full_name_client;
end$$

-- возврат оператора исполнения директива MySQL
delimiter ;