CREATE DATABASE  IF NOT EXISTS `entrance_exams_sotula` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `entrance_exams_sotula`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: entrance_exams_sotula
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `discipline`
--

DROP TABLE IF EXISTS `discipline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discipline` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discipline`
--

LOCK TABLES `discipline` WRITE;
/*!40000 ALTER TABLE `discipline` DISABLE KEYS */;
INSERT INTO `discipline` VALUES (1,'Литература'),(2,'Иностранный язык'),(3,'География'),(4,'Биология'),(5,'Информатика'),(6,'Алгебра'),(7,'Физика'),(8,'Химия'),(9,'Философия'),(10,'История');
/*!40000 ALTER TABLE `discipline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollees`
--

DROP TABLE IF EXISTS `enrollees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enrollees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_person` int NOT NULL,
  `birth_year` year NOT NULL,
  `address` varchar(100) NOT NULL,
  `passport` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `passport_UNIQUE` (`passport`),
  KEY `fk_enrollee_persons_idx` (`id_person`),
  CONSTRAINT `fk_enrollee_persons` FOREIGN KEY (`id_person`) REFERENCES `persons` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollees`
--

LOCK TABLES `enrollees` WRITE;
/*!40000 ALTER TABLE `enrollees` DISABLE KEYS */;
INSERT INTO `enrollees` VALUES (1,11,2003,'г. Донецк, ул. Раздольная, д. 14, кв. 27','14 09 775233'),(2,12,1997,'г. Донецк, пр. Мира, д. 8','12 52 574311'),(3,13,1999,'г. Макеевка, ул. Ленина, д. 91, кв. 12','23 66 106821'),(4,14,2001,'г. Торез, ул. Пушкина, д. 22, кв. 9','01 12 517927'),(5,15,1999,'г. Донецк, ул. Пушкина, д. 13','04 51 580231'),(6,16,2000,'г. Донецк, бул. Шахтостроителей, д. 31, кв. 2','11 02 515706'),(7,17,2001,'г. Макеевка, ул. Холмовая, д. 2','03 01 821362'),(8,18,2003,'г. Макеевка, пр. Автомобилистов, д. 13','32 51 436898'),(9,19,2000,'г. Донецк, пр. Ильича, д. 112, кв. 42','01 23 067584'),(10,20,1996,'г. Донецк, ул. Армавирская, д. 11, кв. 22','09 01 518645');
/*!40000 ALTER TABLE `enrollees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `enrollees_view`
--

DROP TABLE IF EXISTS `enrollees_view`;
/*!50001 DROP VIEW IF EXISTS `enrollees_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `enrollees_view` AS SELECT 
 1 AS `id`,
 1 AS `full_name_enrollee`,
 1 AS `birth_year`,
 1 AS `address`,
 1 AS `passport`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `examiners`
--

DROP TABLE IF EXISTS `examiners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `examiners` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_person` int NOT NULL,
  `payment` double unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_examiners_persons_idx` (`id_person`),
  CONSTRAINT `fk_examiners_persons` FOREIGN KEY (`id_person`) REFERENCES `persons` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examiners`
--

LOCK TABLES `examiners` WRITE;
/*!40000 ALTER TABLE `examiners` DISABLE KEYS */;
INSERT INTO `examiners` VALUES (1,1,435),(2,2,512),(3,3,426),(4,4,569),(5,5,309),(6,6,384),(7,7,496),(8,8,607),(9,9,351),(10,10,475);
/*!40000 ALTER TABLE `examiners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `examiners_view`
--

DROP TABLE IF EXISTS `examiners_view`;
/*!50001 DROP VIEW IF EXISTS `examiners_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `examiners_view` AS SELECT 
 1 AS `id`,
 1 AS `full_name_examiner`,
 1 AS `payment`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_discipline` int NOT NULL,
  `id_examiner` int NOT NULL,
  `id_enrollee` int NOT NULL,
  `date` date NOT NULL,
  `result` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_exams_disciplines_idx` (`id_discipline`),
  KEY `fk_exams_examiners_idx` (`id_examiner`),
  KEY `fk_exams_enrollee_idx` (`id_enrollee`),
  CONSTRAINT `fk_exams_disciplines` FOREIGN KEY (`id_discipline`) REFERENCES `discipline` (`id`),
  CONSTRAINT `fk_exams_enrollee` FOREIGN KEY (`id_enrollee`) REFERENCES `enrollees` (`id`),
  CONSTRAINT `fk_exams_examiners` FOREIGN KEY (`id_examiner`) REFERENCES `examiners` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES (1,3,5,2,'2022-11-12',4),(2,1,3,5,'2022-11-12',5),(3,7,2,1,'2022-11-13',3),(4,10,1,6,'2022-11-14',4),(5,2,4,8,'2022-11-14',5),(6,9,8,3,'2022-11-17',3),(7,2,4,4,'2022-11-17',2),(8,4,6,9,'2022-11-18',3),(9,1,3,7,'2022-11-18',4),(10,4,6,10,'2022-11-18',5);
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `exams_view`
--

DROP TABLE IF EXISTS `exams_view`;
/*!50001 DROP VIEW IF EXISTS `exams_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `exams_view` AS SELECT 
 1 AS `examiner_id`,
 1 AS `full_name_examiner`,
 1 AS `payment`,
 1 AS `full_name_enrollee`,
 1 AS `birth_year`,
 1 AS `address`,
 1 AS `passport`,
 1 AS `name`,
 1 AS `date`,
 1 AS `result`,
 1 AS `tax`,
 1 AS `salary`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `persons`
--

DROP TABLE IF EXISTS `persons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `persons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `surname` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `patronymic` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persons`
--

LOCK TABLES `persons` WRITE;
/*!40000 ALTER TABLE `persons` DISABLE KEYS */;
INSERT INTO `persons` VALUES (1,'Юрковский','Марк','Максимилианович'),(2,'Якубовская','Диана','Павловна'),(3,'Шапиро','Федор','Федорович'),(4,'Вожжаев','Сергей','Денисович'),(5,'Хроменко','Игорь','Владимирович'),(6,'Пелых','Марина','Ульяновна'),(7,'Лапотникова','Тамара','Оскаровна'),(8,'Огородников','Сергей','Иванович'),(9,'Яйло','Екатерина','Николаевна'),(10,'Лосева','Инна','Степановна'),(11,'Михайлович','Анна','Валентиновна'),(12,'Тарапата','Михаил','Исаакович'),(13,'Трубихин','Эдуард','Михайлович'),(14,'Чмыхало','Олег','Тарасович'),(15,'Князьков','Степан','Сидорович'),(16,'Потемкина','Наталья','Павловна'),(17,'Гритченко','Степан','Романович'),(18,'Селиванов','Александр','Михайлович'),(19,'Царькова','Лариса','Ильинична'),(20,'Яструб','Владимир','Данилович'),(21,'Мелашенко','Александр','Алексеевич'),(22,'Пономаренко','Владислав','Дмитриевич'),(23,'Хавалджи','Любовь','Амировна'),(24,'Пархоменко','Ирина','Владимировна'),(25,'Демидова','Алина','Александровна'),(26,'Лысенко','Елена','Егоровна'),(27,'Федосенко','Оксана','Владимировна'),(28,'Богатырева','Екатерина','Алексеевна'),(29,'Иванова','Валентина','Степановна'),(30,'Ильюшин','Сергей','Юрьевич');
/*!40000 ALTER TABLE `persons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'entrance_exams_sotula'
--

--
-- Dumping routines for database 'entrance_exams_sotula'
--
/*!50003 DROP FUNCTION IF EXISTS `query01` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `query01`(surname varchar(100), passport varchar(15)) RETURNS int
    READS SQL DATA
begin
	declare result int;
    declare surname_regexp varchar(101);
    declare passport_regexp varchar(16);
    
    set surname_regexp := CONCAT("^", surname);
    set passport_regexp := CONCAT("^", passport);
    
	select
		COUNT(*) into result
	from
		(select
			 *
		 from
			 enrollees_view
		 where
			 enrollees_view.full_name_enrollee regexp surname_regexp 
			 and enrollees_view.passport regexp passport_regexp) as t;
             
	return result;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `query02` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `query02`(surname varchar(100)) RETURNS int
    READS SQL DATA
begin
	declare result int;
    declare surname_regexp varchar(101);

	set surname_regexp := CONCAT("^", surname);

	select
		COUNT(*) into result
	from
		(select
			 *
		 from
			 exams_view
		 where
			 exams_view.full_name_examiner regexp surname_regexp) as t;
	        
	return result;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `query03` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `query03`(passport varchar(15)) RETURNS int
    READS SQL DATA
begin
	declare result int;
    declare passport_regexp varchar(16);

	set passport_regexp := CONCAT("^", passport);

	select
		COUNT(*) into result
	from
		(select
			*
		 from
			 exams_view
		 where
			 exams_view.passport regexp passport_regexp) as t;
	       
	return result;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `query04` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `query04`(passport varchar(15)) RETURNS int
    READS SQL DATA
begin
	declare result int;
    declare passport_regexp varchar(16);

	set passport_regexp := CONCAT("^", passport);

	select
		COUNT(*) into result
	from
		(select
			*
		 from
			 enrollees_view
		 where
			 enrollees_view.passport regexp passport_regexp) as t;
        
	return result;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `query05` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `query05`() RETURNS int
    READS SQL DATA
begin
	declare result int;
    
	select
		COUNT(*) into result
	from
		(select
			 *
		 from
			 examiners_view) as t;
        
	return result;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `query06` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `query06`() RETURNS int
    READS SQL DATA
begin
	declare result int;
    
	select
		COUNT(*) into result
	from
		(select
			 exams_view.examiner_id
             , exams_view.full_name_examiner
             , exams_view.tax
             , exams_view.salary
		 from
			 exams_view
		 order by
			 exams_view.examiner_id) as t;
        
	return result;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `query07` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `query07`() RETURNS int
    READS SQL DATA
begin
	declare result int;
    
	select
		COUNT(*) into result
	from
		(select 
			 enrollees_view.birth_year
             , COUNT(enrollees_view.id) as count 
		 from 
			 enrollees_view 
		 group by 
			 enrollees_view.birth_year) as t;
        
	return result;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `query08` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `query08`() RETURNS int
    READS SQL DATA
begin
	declare result int;
    
	select
		COUNT(*) into result
	from
		(select 
			 exams_view.`date`
             , AVG(exams_view.result) as avg_result
		 from 
			 exams_view 
		 group by 
			 exams_view.`date`) as t;
        
	return result;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `enrollees_view`
--

/*!50001 DROP VIEW IF EXISTS `enrollees_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `enrollees_view` AS select `enrollees`.`id` AS `id`,concat(`persons`.`surname`,' ',substr(`persons`.`name`,1,1),'.',substr(`persons`.`patronymic`,1,1),'.') AS `full_name_enrollee`,`enrollees`.`birth_year` AS `birth_year`,`enrollees`.`address` AS `address`,`enrollees`.`passport` AS `passport` from (`enrollees` join `persons` on((`enrollees`.`id_person` = `persons`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `examiners_view`
--

/*!50001 DROP VIEW IF EXISTS `examiners_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `examiners_view` AS select `examiners`.`id` AS `id`,concat(`persons`.`surname`,' ',substr(`persons`.`name`,1,1),'.',substr(`persons`.`patronymic`,1,1),'.') AS `full_name_examiner`,`examiners`.`payment` AS `payment` from (`examiners` join `persons` on((`examiners`.`id_person` = `persons`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `exams_view`
--

/*!50001 DROP VIEW IF EXISTS `exams_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `exams_view` AS select `examiner`.`id` AS `examiner_id`,`examiner`.`full_name_examiner` AS `full_name_examiner`,`examiner`.`payment` AS `payment`,`enrollee`.`full_name_enrollee` AS `full_name_enrollee`,`enrollee`.`birth_year` AS `birth_year`,`enrollee`.`address` AS `address`,`enrollee`.`passport` AS `passport`,`discipline`.`name` AS `name`,`exams`.`date` AS `date`,`exams`.`result` AS `result`,(`examiner`.`payment` * 0.13) AS `tax`,(`examiner`.`payment` - (`examiner`.`payment` * 0.13)) AS `salary` from (((`exams` join `discipline` on((`exams`.`id_discipline` = `discipline`.`id`))) join (select `examiners`.`id` AS `id`,concat(`persons`.`surname`,' ',substr(`persons`.`name`,1,1),'.',substr(`persons`.`patronymic`,1,1),'.') AS `full_name_examiner`,`examiners`.`payment` AS `payment` from (`examiners` join `persons` on((`examiners`.`id_person` = `persons`.`id`)))) `examiner` on((`exams`.`id_examiner` = `examiner`.`id`))) join (select `enrollees`.`id` AS `id`,concat(`persons`.`surname`,' ',substr(`persons`.`name`,1,1),'.',substr(`persons`.`patronymic`,1,1),'.') AS `full_name_enrollee`,`enrollees`.`birth_year` AS `birth_year`,`enrollees`.`address` AS `address`,`enrollees`.`passport` AS `passport` from (`enrollees` join `persons` on((`enrollees`.`id_person` = `persons`.`id`)))) `enrollee` on((`exams`.`id_enrollee` = `enrollee`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-04 23:11:23
