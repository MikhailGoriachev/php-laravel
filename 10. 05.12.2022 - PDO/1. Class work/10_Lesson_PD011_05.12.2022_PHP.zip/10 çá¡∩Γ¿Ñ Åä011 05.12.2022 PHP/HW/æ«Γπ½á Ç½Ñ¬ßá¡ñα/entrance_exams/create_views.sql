use entrance_exams_sotula;

-- представление абитуриентов
create or replace view enrollees_view as
select
	enrollees.id
    , CONCAT(persons.surname, " "
		, SUBSTRING(persons.`name`, 1, 1),"."
		, SUBSTRING(persons.patronymic, 1, 1),".") as full_name_enrollee
	, enrollees.birth_year
    , enrollees.address
    , enrollees.passport
from
	enrollees join persons on enrollees.id_person = persons.id;
    
-- представление экзаменаторов
create or replace view examiners_view as
select
	examiners.id
	, CONCAT(persons.surname, " "
		, SUBSTRING(persons.`name`, 1, 1),"."
		, SUBSTRING(persons.patronymic, 1, 1),".") as full_name_examiner
	, examiners.payment
from
	examiners join persons on examiners.id_person = persons.id;

-- представление экзаменов
create or replace view exams_view as
select
    examiner.id as examiner_id
	, examiner.full_name_examiner
	, examiner.payment
	, enrollee.full_name_enrollee
	, enrollee.birth_year
	, enrollee.address
	, enrollee.passport
    , discipline.`name`
    , exams.`date`
    , exams.result
    , (examiner.payment * 0.13) as tax
    , (examiner.payment - (examiner.payment * 0.13)) as salary
from
	exams join discipline on exams.id_discipline = discipline.id
		  join (select 	
					examiners.id
					, CONCAT(persons.surname, " "
						, SUBSTRING(persons.`name`, 1, 1),"."
						, SUBSTRING(persons.patronymic, 1, 1),".") as full_name_examiner
					, examiners.payment
				from
					examiners join persons on examiners.id_person = persons.id) as examiner on exams.id_examiner = examiner.id
		  join (select
					enrollees.id
					, CONCAT(persons.surname, " "
						, SUBSTRING(persons.`name`, 1, 1),"."
						, SUBSTRING(persons.patronymic, 1, 1),".") as full_name_enrollee
					, enrollees.birth_year
					, enrollees.address
					, enrollees.passport
				from
					enrollees join persons on enrollees.id_person = persons.id) as enrollee on exams.id_enrollee = enrollee.id;