use entrance_exams_sotula;

delimiter $$

-- Выбирает информацию об абитуриентах с заданной фамилией,
-- серией/номером паспорта
drop function if exists query01$$

create function query01(surname varchar(100), passport varchar(15))
returns int reads sql data
begin
	declare result int;
    declare surname_regexp varchar(101);
    declare passport_regexp varchar(16);
    
    set surname_regexp := CONCAT("^", surname);
    set passport_regexp := CONCAT("^", passport);
    
	select
		COUNT(*) into result
	from
		(select
			 *
		 from
			 enrollees_view
		 where
			 enrollees_view.full_name_enrollee regexp surname_regexp 
			 and enrollees_view.passport regexp passport_regexp) as t;
             
	return result;
end$$

-- Выбирает информацию об экзаменах, которые были приняты экзаменатором с заданной фамилией
drop function if exists query02$$

create function query02(surname varchar(100))
returns int reads sql data
begin
	declare result int;
    declare surname_regexp varchar(101);

	set surname_regexp := CONCAT("^", surname);

	select
		COUNT(*) into result
	from
		(select
			 *
		 from
			 exams_view
		 where
			 exams_view.full_name_examiner regexp surname_regexp) as t;
	        
	return result;
end$$

-- Выбирает информацию об экзаменах, сданных абитуриентом с заданным номером/серией паспорта
drop function if exists query03$$

create function query03(passport varchar(15))
returns int reads sql data
begin
	declare result int;
    declare passport_regexp varchar(16);

	set passport_regexp := CONCAT("^", passport);

	select
		COUNT(*) into result
	from
		(select
			*
		 from
			 exams_view
		 where
			 exams_view.passport regexp passport_regexp) as t;
	       
	return result;
end$$

-- Выбирает информацию об абитуриенте с заданным номером/серией паспорта. 
drop function if exists query04$$

create function query04(passport varchar(15))
returns int reads sql data
begin
	declare result int;
    declare passport_regexp varchar(16);

	set passport_regexp := CONCAT("^", passport);

	select
		COUNT(*) into result
	from
		(select
			*
		 from
			 enrollees_view
		 where
			 enrollees_view.passport regexp passport_regexp) as t;
        
	return result;
end$$

-- Выбирает информацию обо всех экзаменаторах
drop function if exists query05$$

create function query05()
returns int reads sql data
begin
	declare result int;
    
	select
		COUNT(*) into result
	from
		(select
			 *
		 from
			 examiners_view) as t;
        
	return result;
end$$

-- Вычисляет для каждого экзамена размер налога (Налог=Размер оплаты*13%) и 
-- зарплаты экзаменатора (Зарплата=Размер оплаты - Налог). Сортировка по полю Код экзаменатора
drop function if exists query06$$

create function query06()
returns int reads sql data
begin
	declare result int;
    
	select
		COUNT(*) into result
	from
		(select
			 exams_view.examiner_id
             , exams_view.full_name_examiner
             , exams_view.tax
             , exams_view.salary
		 from
			 exams_view
		 order by
			 exams_view.examiner_id) as t;
        
	return result;
end$$

-- Выполняет группировку по полю Год рождения в таблице АБИТУРИЕНТЫ.
-- Для каждой группы определяет количество абитуриентов (итоги по полю Код абитуриента)
drop function if exists query07$$

create function query07()
returns int reads sql data
begin
	declare result int;
    
	select
		COUNT(*) into result
	from
		(select 
			 enrollees_view.birth_year
             , COUNT(enrollees_view.id) as count 
		 from 
			 enrollees_view 
		 group by 
			 enrollees_view.birth_year) as t;
        
	return result;
end$$


-- Выполняет группировку по полю Дата сдачи экзамена в таблице ЭКЗАМЕНЫ.
-- Для каждой даты определяет среднее значения по полю Оценка
drop function if exists query08$$

create function query08()
returns int reads sql data
begin
	declare result int;
    
	select
		COUNT(*) into result
	from
		(select 
			 exams_view.`date`
             , AVG(exams_view.result) as avg_result
		 from 
			 exams_view 
		 group by 
			 exams_view.`date`) as t;
        
	return result;
end$$

delimiter ;


