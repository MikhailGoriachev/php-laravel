use car_rental_cherkas;

insert into colors (id, color)
    values
    (null, "красный"),
    (null, "оранжевый"),
    (null, "желтый"),
    (null, "зеленый"),
    (null, "синий"),
    (null, "фиолетовый");
select * from colors;
    
insert into brends (id, brend)
    values
    (null, "Audi"),
    (null, 'Cadillac'),
    (null, 'Dacia'),
    (null, 'Honda'),
    (null, 'Daewoo'),
    (null, 'Genesis'),
    (null, 'Fiat'),
    (null, 'Jeep'),
    (null, 'Ferrari'),
    (null, 'Lada');
select * from brends;

insert into cars(id, brend_id, color_id, `year`, `number`, insurance, price)
    values
    (null, 1, 2, 2000, 'м976мм', 1500000, 1900),
    (null, 8, 6, 2010, 'в555рх', 1000000, 1500),
    (null, 5, 5, 2005, 'е231ту', 3000000, 2000),
    (null, 9, 3, 1999, 'а565аа', 4500000, 2000),
    (null, 10, 1, 2020, 'к998ак', 1500000, 1300),
    (null, 7, 5, 2021, 'е988оо', 1000000, 1990),
    (null, 9, 3, 2012, 'о767ее', 2500000, 2300),
    (null, 2, 4, 1990, 'в788ек', 1400000, 1500),
    (null, 5, 1, 2003, 'н777ор', 4000000, 2300),
    (null, 3, 2, 2005, 'р909ст', 1000000, 1300);
select * from cars;

insert into clients (id, surname, first_name, patronymic, passport)
    values
    (null, 'Ефремов', 'Сергей', 'Иванович', '4095 233675'),
    (null, 'Деревянко', 'Валерий', 'Сергеевич', '5088 323249'),
    (null, 'Метунова', 'Наталья', 'Владимировна', '2280 454545'),
    (null, 'Захарова', 'Валентина', 'Пертровна', '5170 123454'),
    (null, 'Михалюк', 'Александр', 'Валерьевич', '4545 987655'),
    (null, 'Лабузов', 'Алексей', 'Егорович', '4899 542323'),
    (null, 'Кротов', 'Дмитрий', 'Васильевич', '3990 784321'),
    (null, 'Мазурчак', 'Александп', 'Ефимович', '3535 999899'),
    (null, 'Проценко', 'Наталья', 'Егоровна', '2353 768452'),
    (null, 'Козаченко', 'Татьяна', 'Сергевна', '4949 550090');
select * from clients;

insert into rental (id, start_date, `count`, car_id, client_id)
    values
    (null, '2022-05-12', 5, 7, 5),
    (null, '2022-05-18', 10, 9, 1),
    (null, '2022-06-01', 3, 5, 2),
    (null, '2022-06-03', 8, 7, 7),
    (null, '2022-07-15', 1, 3, 8),
    (null, '2022-07-18', 15, 9, 7),
    (null, '2022-07-18', 5, 6, 3),
    (null, '2022-07-19', 4, 2, 4),
    (null, '2022-08-1', 8, 8, 8),
    (null, '2022-09-3', 1, 5, 4);
    
select * from rental; 