create database if not exists car_rental_cherkas;
use car_rental_cherkas;

drop table if exists rental;
drop table if exists cars;
drop table if exists colors;
drop table if exists brends;
drop table if exists clients;

create table colors (
    id int unsigned auto_increment,
    color varchar(20) unique not null,
    primary key(id),
    check(color != "")
    ) engine=InnoDB;
    
create table brends (
    id int unsigned auto_increment,
    brend varchar(20) unique not null,
    primary key(id),
    check(brend != "")
    ) engine=InnoDB;
    
create table cars (
    id int unsigned auto_increment,
    brend_id int unsigned default null,
    color_id int unsigned default null,
    `year` int not null,                  /* год выпуска */
    `number` varchar(30) not null unique, /* госномер */
    insurance int not null,               /*страховка*/
    price int not null,                   /*стоимость одного дня*/
    primary key(id),
    foreign key (brend_id) references brends (id) on delete cascade on update cascade,
    foreign key (color_id) references colors (id) on delete cascade on update cascade
    ) engine=InnoDB;
    
create table clients (
    id int unsigned auto_increment,
    surname varchar(30) not null,
    first_name varchar(30) not null,
    patronymic varchar(30) not null,
    passport varchar(30) not null,
    primary key(id),
    check(surname != "" and first_name != "" and patronymic != "" and passport != "")
    ) engine=InnoDB;
    
create table rental (
    id int unsigned auto_increment,
    start_date date not null,
	`count` int not null,
    car_id int unsigned default null,
    client_id int unsigned default null,
    primary key(id),
    foreign key(car_id) references cars(id) on delete cascade on update cascade,
    foreign key(client_id) references clients(id) on delete cascade on update cascade
    ) engine=InnoDB;
    