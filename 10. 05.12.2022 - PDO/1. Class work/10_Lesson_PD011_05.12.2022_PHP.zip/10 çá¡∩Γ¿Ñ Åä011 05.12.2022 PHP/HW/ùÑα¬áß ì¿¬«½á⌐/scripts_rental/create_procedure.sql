use car_rental_cherkas;

delimiter $$

drop procedure if exists Price_less_parameter$$
-- Выбирает информацию об автомобилях, стоимость 
-- одного дня проката которых меньше заданной
create procedure Price_less_parameter(in price int)
begin
    select
        *
	from
        cars
	where
        cars.price < price;
end$$

drop procedure if exists Insurance_between_parameters$$
-- Выбирает информацию об автомобилях, страховая стоимость 
-- которых находится в заданном диапазоне значений
create procedure Insurance_between_parameters(in min_price int, in max_price int)
begin 
    select
        *
	from
        cars
	where
        cars.insurance between min_price and max_price;
end$$

drop procedure if exists Client_passport$$   
-- Выбирает информацию о клиентах, серия-номер паспорта которых
-- начинается с заданной параметром цифры. Включает поля
-- Код клиента, Паспорт, Дата начала проката, Количество дней проката, Модель автомобиля
create procedure Client_passport(in num varchar(10))
begin
    select
        clients.id,
        clients.passport,
        rental.start_date,
        rental.`count`,
        brends.brend
	from
        rental join clients on rental.client_id = clients.id
               join (cars join brends on cars.brend_id = brends.id) on rental.car_id = cars.id
	where
        clients.passport like num;
end$$

drop procedure if exists Insurance_between$$ 
-- Выбирает информацию об автомобилях, для которых значение в поле Страховая
-- стоимость автомобиля попадает в некоторый заданный интервал
create procedure Insurance_between(in min int, in max int)
begin
    select
        brends.brend,
        cars.`number`,
        colors.color,
        cars.`year`,
        cars.insurance,
        cars.price
	from
        cars join brends on cars.brend_id = brends.id
             join colors on cars.color_id = colors.id
	where
        cars.insurance between min and max;
end$$ 

delimiter $$
drop procedure if exists Car_Day$$ 
-- Выбирает информацию о клиентах, бравших автомобиль 
-- напрокат в некоторый определенный день
create procedure Car_Day(in d varchar(20))
begin
    select
        clients.surname,
        clients.first_name,
        clients.patronymic,
        clients.passport,
        rental.start_date
	from
        rental join clients on rental.client_id = clients.id
	where
        rental.start_date = d;
end$$ 
delimiter ;


