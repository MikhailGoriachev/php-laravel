use car_rental_cherkas;

-- Выбирает информацию об автомобилях, 
-- стоимость одного дня проката которых меньше заданной
call car_rental_cherkas.Price_less_parameter(2000);

call car_rental_cherkas.Price_less_parameter(1500);

call car_rental_cherkas.Price_less_parameter(3000);

-- Выбирает информацию об автомобилях, страховая стоимость которых 
-- находится в заданном диапазоне значений
call car_rental_cherkas.Insurance_between_parameters(10, 1500000);

call car_rental_cherkas.Insurance_between_parameters(1500000, 2000000);

call car_rental_cherkas.Insurance_between_parameters(2000000, 3000000);

-- Выбирает информацию о клиентах, серия-номер паспорта которых
-- начинается с заданной параметром цифры.
call car_rental_cherkas.Client_passport(2);
call car_rental_cherkas.Client_passport(3);

-- Выбирает информацию об автомобилях, для которых значение в поле Страховая
-- стоимость автомобиля попадает в некоторый заданный интервал
call car_rental_cherkas.Insurance_between_parameters(0, 1500000);
call car_rental_cherkas.Insurance_between_parameters(1500000, 2000000);
call car_rental_cherkas.Insurance_between_parameters(2000000, 3500000);

-- Выбирает информацию о клиентах, бравших автомобиль напрокат
-- в некоторый определенный день. 
call Car_Day('2022-07-18');
call Car_Day('2022-07-19');
call Car_Day('2022-09-03');