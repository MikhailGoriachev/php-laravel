CREATE DATABASE  IF NOT EXISTS `exams_cherkas` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `exams_cherkas`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: exams_cherkas
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `disciplines`
--

DROP TABLE IF EXISTS `disciplines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disciplines` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `discipline` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disciplines`
--

LOCK TABLES `disciplines` WRITE;
/*!40000 ALTER TABLE `disciplines` DISABLE KEYS */;
INSERT INTO `disciplines` VALUES (1,'Русский язык'),(2,'Математика'),(3,'Информатика'),(4,'Физика'),(5,'История'),(6,'Иностранный язык'),(7,'Экономическая история'),(8,'Философия'),(9,'Психология'),(10,'Физическая культура');
/*!40000 ALTER TABLE `disciplines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `examiners`
--

DROP TABLE IF EXISTS `examiners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `examiners` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `surname` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `patronymic` varchar(30) NOT NULL,
  `price` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `examiners_chk_1` CHECK (((`surname` <> _utf8mb4'') and (`first_name` <> _utf8mb4'') and (`patronymic` <> _utf8mb4'')))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examiners`
--

LOCK TABLES `examiners` WRITE;
/*!40000 ALTER TABLE `examiners` DISABLE KEYS */;
INSERT INTO `examiners` VALUES (1,'Бархотова','Марьямна','Трофимовна',1000),(2,'Поникаров','Валерий','Львович',1500),(3,'Гущин','Михаил','Макарович',1200),(4,'Синдеева','Рада','Захаровна',1000),(5,'Дегтярев','Иван','Маркович',1000),(6,'Ячевский','Константин','Никифорович',2000),(7,'Ярыкин','Афанасий','Иванович',1500),(8,'Кокорин','Василий','Петрович',1000),(9,'Милехин','Аркадий','Семенович',1200),(10,'Глен','Семен','Ираклиевич',1000);
/*!40000 ALTER TABLE `examiners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exams` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `date_exam` date NOT NULL,
  `examiner_id` int unsigned NOT NULL,
  `student_id` int unsigned NOT NULL,
  `discipline_id` int unsigned NOT NULL,
  `assessment` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `examiner_id` (`examiner_id`),
  KEY `student_id` (`student_id`),
  KEY `discipline_id` (`discipline_id`),
  CONSTRAINT `exams_ibfk_1` FOREIGN KEY (`examiner_id`) REFERENCES `examiners` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `exams_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `exams_ibfk_3` FOREIGN KEY (`discipline_id`) REFERENCES `disciplines` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES (1,'2022-01-12',1,3,4,5),(2,'2022-01-12',3,8,8,4),(3,'2022-01-15',8,5,7,5),(4,'2022-02-01',6,3,8,2),(5,'2022-02-01',9,5,1,5),(6,'2022-02-05',2,7,2,4),(7,'2022-02-21',8,9,4,5),(8,'2022-03-01',7,3,3,2),(9,'2022-03-05',6,6,7,5),(10,'2022-03-15',2,9,1,4),(11,'2022-05-12',5,5,5,5),(12,'2022-05-18',7,1,1,3);
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `surname` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `patronymic` varchar(30) NOT NULL,
  `age` year NOT NULL,
  `passport` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `passport` (`passport`),
  CONSTRAINT `students_chk_1` CHECK (((`surname` <> _utf8mb4'') and (`first_name` <> _utf8mb4'') and (`patronymic` <> _utf8mb4'') and (`passport` <> _utf8mb4'') and (`age` > 15) and (`age` < 55)))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'Ефремов','Сергей','Иванович',2033,'4824 931582'),(2,'Чучумашева','Татьяна','Юрьевна',2025,'4282 943547'),(3,'Ягнятев','Кузьма','Валентинович',2039,'4964 496269'),(4,'Силиванова','Мария','Федоровна',2049,'4946 633009'),(5,'Давыдкин','Филипп','Яковлевич',2051,'4290 948086'),(6,'Хабенская','Елена','Петровна',2030,'4783 780493'),(7,'Коракова','Таисия','Афанасьевна',2020,'4113 747388'),(8,'Ябловская','Клара','Алексеевна',2021,'4412 439378'),(9,'Карчагин','Евгений','Макарович',2019,'4341 180386'),(10,'Рожкова','Жанна','Севастьяновна',2023,'4497 420714');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_exams`
--

DROP TABLE IF EXISTS `view_exams`;
/*!50001 DROP VIEW IF EXISTS `view_exams`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_exams` AS SELECT 
 1 AS `date_exam`,
 1 AS `surname1`,
 1 AS `first_name1`,
 1 AS `patronymic1`,
 1 AS `surname`,
 1 AS `first_name`,
 1 AS `patronymic`,
 1 AS `passport`,
 1 AS `discipline`,
 1 AS `assessment`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'exams_cherkas'
--

--
-- Dumping routines for database 'exams_cherkas'
--
/*!50003 DROP PROCEDURE IF EXISTS `Find_by_surname_passport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Find_by_surname_passport`(s char(30), p char(30))
begin
    select
        *
	from
        students
	where
        students.surname = s and students.passport = p;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Select_exam_by_surname` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_exam_by_surname`(s char(30))
begin
    select
        exams_cherkas.view_exams.surname1 as преподаватель,
        exams_cherkas.view_exams.discipline as предмет,
        exams_cherkas.view_exams.assessment as оценка
	from
        exams_cherkas.view_exams
	where
        exams_cherkas.view_exams.surname1 = s;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Select_exam_student` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Select_exam_student`(p char(30))
begin
    select
        exams_cherkas.view_exams.surname as студент,
        exams_cherkas.view_exams.discipline as предмет,
        exams_cherkas.view_exams.assessment as оценка
	from
        exams_cherkas.view_exams
	where
        exams_cherkas.view_exams.passport = p;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `view_exams`
--

/*!50001 DROP VIEW IF EXISTS `view_exams`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_exams` AS select `exams`.`date_exam` AS `date_exam`,`examiners`.`surname` AS `surname1`,`examiners`.`first_name` AS `first_name1`,`examiners`.`patronymic` AS `patronymic1`,`students`.`surname` AS `surname`,`students`.`first_name` AS `first_name`,`students`.`patronymic` AS `patronymic`,`students`.`passport` AS `passport`,`disciplines`.`discipline` AS `discipline`,`exams`.`assessment` AS `assessment` from (((`exams` join `students` on((`exams`.`student_id` = `students`.`id`))) join `examiners` on((`exams`.`examiner_id` = `examiners`.`id`))) join `disciplines` on((`exams`.`discipline_id` = `disciplines`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-05 13:38:18
