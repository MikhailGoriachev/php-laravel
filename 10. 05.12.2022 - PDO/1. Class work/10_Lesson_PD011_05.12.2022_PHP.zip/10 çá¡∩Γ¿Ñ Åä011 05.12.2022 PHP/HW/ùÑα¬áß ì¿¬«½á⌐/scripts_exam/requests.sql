use exams_cherkas;
 
-- Выбирает информацию об абитуриентах с заданной фамилией, 
-- серией/номером паспорта
call Find_by_surname_passport('Силиванова', '4946 633009');
call Find_by_surname_passport('Ефремов', '4824 931582');
call Find_by_surname_passport('Ягнятев', '4964 496269');

-- Выбирает информацию об экзаменах, которые были приняты 
-- экзаменатором с заданной фамилией
select * from examiners;
call Select_exam_by_surname('Гущин');
call Select_exam_by_surname('Поникаров');
call Select_exam_by_surname('Милехин');

-- Выбирает информацию об экзаменах, сданных абитуриентом 
-- с заданным номером/серией паспорта
select * from students;
call Select_exam_student('4290 948086');
call Select_exam_student('4824 931582');
call Select_exam_student('4964 496269');