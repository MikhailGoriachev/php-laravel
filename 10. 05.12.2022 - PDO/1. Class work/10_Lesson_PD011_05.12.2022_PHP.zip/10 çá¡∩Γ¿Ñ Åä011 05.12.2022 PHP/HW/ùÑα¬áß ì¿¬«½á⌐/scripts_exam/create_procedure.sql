use exams_cherkas;

-- представление экзамены
create or replace view view_exams as
select
    exams.date_exam as date_exam,
    examiners.surname as surname1,
    examiners.first_name as first_name1,
    examiners.patronymic as patronymic1,
    students.surname as surname,
    students.first_name as first_name,
    students.patronymic as patronymic,
    students.passport as passport,
    disciplines.discipline as discipline,
    exams.assessment as assessment
from
    exams join students on exams.student_id = students.id
          join examiners on exams.examiner_id = examiners.id
          join disciplines on exams.discipline_id = disciplines.id;
          
select * from view_exams;

delimiter $$ 
drop procedure if exists Find_surname_passport$$
-- Выбирает информацию об абитуриентах с заданной фамилией, 
-- серией/номером паспорта
create procedure Find_by_surname_passport(s char(30), p char(30))
begin
    select
        *
	from
        students
	where
        students.surname = s and students.passport = p;
end$$

drop procedure if exists Select_exam_by_surname$$
-- Выбирает информацию об экзаменах, которые были приняты 
-- экзаменатором с заданной фамилией
create procedure Select_exam_by_surname(s char(30))
begin
    select
        exams_cherkas.view_exams.surname1 as преподаватель,
        exams_cherkas.view_exams.discipline as предмет,
        exams_cherkas.view_exams.assessment as оценка
	from
        exams_cherkas.view_exams
	where
        exams_cherkas.view_exams.surname1 = s;
end$$

drop procedure if exists Select_exam_student$$
-- Выбирает информацию об экзаменах, сданных абитуриентом 
-- с заданным номером/серией паспорта
create procedure Select_exam_student(p char(30))
begin
    select
        exams_cherkas.view_exams.surname as студент,
        exams_cherkas.view_exams.discipline as предмет,
        exams_cherkas.view_exams.assessment as оценка
	from
        exams_cherkas.view_exams
	where
        exams_cherkas.view_exams.passport = p;
end$$ 
delimiter ;
