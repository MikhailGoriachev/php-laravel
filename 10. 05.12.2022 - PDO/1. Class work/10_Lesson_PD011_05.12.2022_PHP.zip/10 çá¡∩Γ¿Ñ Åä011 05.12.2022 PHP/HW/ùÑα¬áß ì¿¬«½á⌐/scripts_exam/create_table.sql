create database if not exists exams_cherkas;
use exams_cherkas;

drop table if exists exams;
drop table if exists disciplines;
drop table if exists students;
drop table if exists examiners;

create table disciplines (
    id int unsigned auto_increment,
    discipline varchar(30) not null,
    primary key(id)
) engine=InnoDB;

-- АБИТУРИЕНТЫ
create table students (
    id int unsigned auto_increment,
    surname varchar(30) not null,
    first_name varchar(30) not null,
    patronymic varchar(30) not null,
    age year not null,
    passport varchar(30) not null unique,
    check(surname != "" and first_name != "" and patronymic != "" 
	      and passport != "" and (age > 15 and age < 55)),
    primary key(id)
) engine=InnoDB;

-- ЭКЗАМЕНАТОРЫ
create table examiners (
    id int unsigned auto_increment,
    surname varchar(30) not null,
    first_name varchar(30) not null,
    patronymic varchar(30) not null, 
    price int unsigned not null, -- размер оплаты 
    check(surname != "" and first_name != "" and patronymic != ""),
    primary key(id)
) engine=InnoDB;

-- экзамены
create table exams (
    id int unsigned auto_increment,
    date_exam date not null,
    examiner_id int unsigned not null,
    student_id int unsigned not null,
    discipline_id int unsigned not null,
    assessment int not null,
    primary key(id),
    foreign key (examiner_id) references examiners(id) on delete cascade on update cascade,
    foreign key(student_id) references students(id) on delete cascade on update cascade,
    foreign key(discipline_id) references disciplines(id) on delete cascade on update cascade
) engine=InnoDB;