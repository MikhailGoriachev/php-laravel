use rent_a_car_tatsiy_anna;

delimiter ::

-- удаляем процедуры если они существуют 
drop procedure if exists proc01::
drop procedure if exists proc02::
drop procedure if exists proc03::
drop procedure if exists proc04::
drop procedure if exists proc05::
drop procedure if exists proc06::
drop procedure if exists proc07::
drop procedure if exists proc08::

-- Хранимая процедура 1
-- Выбирает информацию об автомобилях, стоимость одного дня проката которых меньше заданной 
create procedure proc01(in price int) 
begin
	select * from cars_view where cost_one_day < price;
end::

-- Хранимая процедура 2
-- Выбирает информацию об автомобилях, страховая стоимость которых находится в заданном диапазоне значений 
create procedure proc02(in insurance_cost_b int, in insurance_cost_e int) 
begin
	select * from cars_view where insurance_cost between insurance_cost_b and insurance_cost_e;
end::

-- Хранимая процедура 3
-- Выбирает информацию о клиентах, серия-номер паспорта которых начинается с заданной параметром цифры. 
-- Включает поля Код клиента, Паспорт, Дата начала проката, Количество дней проката, Модель автомобиля 
create procedure proc03(in n varchar(1)) 
begin
	select 
		id_customer,
        passport,
        `date`,
        amount,
        models.title
    from rents_view join models on rents_view.id_model = models.id
    where passport regexp concat('^', n);
end::

-- Хранимая процедура 4
-- Выбирает информацию о клиентах, бравших автомобиль напрокат в некоторый определенный день.  
create procedure proc04(in d date) 
begin
	select 
		id_customer,
        surname,
        `name`,
        patronymic,
        passport,
        `date`
	from rents_view
    where `date` = d;
end::

-- Хранимая процедура 5
-- Выбирает информацию об автомобилях, для которых значение в поле Страховая стоимость автомобиля попадает в некоторый заданный интервал.  
-- смотреть запрос 2

-- Хранимая процедура 6
-- Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса. Включает поля Госномер автомобиля, Модель автомобиля, 
-- Год выпуска автомобиля, Страховая стоимость автомобиля, Страховой взнос. Сортировка по полю Год выпуска автомобиля 
create procedure proc06() 
begin
	select 
		state_number,
        model_title,
        `year`,
        insurance_cost,
        insurance_cost*0.1 as insurance_premium
	from cars_view
    order by `year`;
end::

-- Хранимая процедура 7
-- Выполняет группировку по полю Модель автомобиля. Для каждой модели вычисляет минимальную страховую стоимость автомобиля. 
create procedure proc07() 
begin
	select 
		id_model,
        model_title,
        min(insurance_cost) as min_insurance_cost
	from cars_view
    group by id_model, model_title;
end::

-- Хранимая процедура 8
-- Выполняет группировку по полю Код клиента. Для каждого клиента вычисляет минимальное и максимальное значения по полю Количество дней проката  
create procedure proc08() 
begin
	select 
		id_customer,
        min(amount) as min_amount,
        max(amount) as max_amount
	from rents_view
    group by id_customer;
end::

delimiter ;
