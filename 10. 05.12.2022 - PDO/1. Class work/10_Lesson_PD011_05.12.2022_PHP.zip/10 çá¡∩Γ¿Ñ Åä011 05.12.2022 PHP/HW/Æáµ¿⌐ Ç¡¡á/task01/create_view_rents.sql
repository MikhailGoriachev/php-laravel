use rent_a_car_tatsiy_anna;

-- представление авто
create or replace view cars_view as
	select 
	`cars`.`id`,
    `cars`.`id_model`,
    models.title as model_title,
    `cars`.`id_color`,
    colors.title as color_title,
    `cars`.`year`,
    `cars`.`state_number`,
    `cars`.`cost_one_day`,
    `cars`.`insurance_cost`
FROM `rent_a_car_tatsiy_anna`.`cars` join models on `cars`.`id_model` = models.id
									 join colors on `cars`.`id_color` = colors.id;
                                     
-- представление прокат авто 
create or replace view rents_view as
select
	`rents`.`id`,
    `rents`.`id_customer`,
    
    `customers`.`surname`,
    `customers`.`name`,
    `customers`.`patronymic`,
    `customers`.`passport`,

    `rents`.`id_car`,
    
    `cars`.`id_model`,
    `cars`.`id_color`,
    `cars`.`year`,
    `cars`.`state_number`,
    `cars`.`cost_one_day`,
    `cars`.`insurance_cost`,

    `rents`.`date`,
    `rents`.`amount`
FROM `rent_a_car_tatsiy_anna`.`rents` join customers on `rents`.`id_customer` = customers.id
									  join cars on `rents`.`id_car` = cars.id;

