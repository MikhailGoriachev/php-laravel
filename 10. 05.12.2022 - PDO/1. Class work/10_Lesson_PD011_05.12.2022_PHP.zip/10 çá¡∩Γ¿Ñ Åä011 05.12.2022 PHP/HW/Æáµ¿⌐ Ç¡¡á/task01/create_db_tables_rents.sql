CREATE DATABASE  IF NOT EXISTS `rent_a_car_tatsiy_anna` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `rent_a_car_tatsiy_anna`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: rent_a_car_tatsiy_anna
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cars` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_model` int NOT NULL,
  `id_color` int NOT NULL,
  `year` int NOT NULL,
  `state_number` varchar(9) NOT NULL,
  `cost_one_day` int NOT NULL,
  `insurance_cost` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cars_models_idx` (`id_model`),
  KEY `fk_cars_colors_idx` (`id_color`),
  CONSTRAINT `fk_cars_colors` FOREIGN KEY (`id_color`) REFERENCES `colors` (`id`),
  CONSTRAINT `fk_cars_models` FOREIGN KEY (`id_model`) REFERENCES `models` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES (1,1,1,2001,'А845КА349',2000,200000),(2,2,2,2005,'В958ЕУ943',3000,500000),(3,3,3,2010,'Р459НО403',4000,800000),(4,4,4,2012,'Н953ША49',5000,200000),(5,5,5,2015,'Г932ОТ32',2000,800000),(6,6,6,2018,'Н934ВТ83',3500,800000),(7,7,7,2020,'П943ВЛ39',4000,600000),(8,8,8,2020,'Н472КУ39',3500,700000),(9,9,9,2017,'Г564АЛ42',4000,800000),(10,10,10,2020,'В843СМ84',4000,600000);
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colors`
--

DROP TABLE IF EXISTS `colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colors`
--

LOCK TABLES `colors` WRITE;
/*!40000 ALTER TABLE `colors` DISABLE KEYS */;
INSERT INTO `colors` VALUES (1,'белый'),(2,'зелёный'),(3,'синий'),(4,'красный'),(5,'бежевый'),(6,'серый'),(7,'чёрный'),(8,'бирюзовый'),(9,'фиолетовый'),(10,'оранжевый');
/*!40000 ALTER TABLE `colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `surname` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `patronymic` varchar(45) NOT NULL,
  `passport` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Федоров','Дмитрий','Александрович','4028491230'),(2,'Меркулова','Виктория','Мироновна','8640324959'),(3,'Емельянов','Максим','Романович','0583438562'),(4,'Климова','Кира','Николаевна','5834092962'),(5,'Котова','Вероника','Романовна','5940932056'),(6,'Крюков','Лев','Леонович','8593205563'),(7,'Соколова','Екатерина','Львовна','1275076352'),(8,'Орлов','Алексей','Витальевич','0056422876'),(9,'Иванова','Кристина','Алексеевна','0756745424'),(10,'Федорова','София','Павловна','9458939235');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `models` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `models`
--

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
INSERT INTO `models` VALUES (1,' Lada 2107'),(2,' Lada 2106'),(3,'Kia Rio'),(4,'Lada 4×4 «Нива»'),(5,'Hyundai Solaris'),(6,' Lada 2110'),(7,'Renault Logan'),(8,'Lada 2114'),(9,'Ford Focus'),(10,'Lada 2109');
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rents`
--

DROP TABLE IF EXISTS `rents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_customer` int NOT NULL,
  `id_car` int NOT NULL,
  `date` date NOT NULL,
  `amount` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rents_customers_idx` (`id_customer`),
  KEY `fk_rents_cars_idx` (`id_car`),
  CONSTRAINT `fk_rents_cars` FOREIGN KEY (`id_car`) REFERENCES `cars` (`id`),
  CONSTRAINT `fk_rents_customers` FOREIGN KEY (`id_customer`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rents`
--

LOCK TABLES `rents` WRITE;
/*!40000 ALTER TABLE `rents` DISABLE KEYS */;
INSERT INTO `rents` VALUES (1,1,1,'2022-12-04',3),(2,2,2,'2022-12-04',4),(3,3,3,'2022-12-04',5),(4,4,4,'2022-12-05',8),(5,5,5,'2022-12-06',3),(6,6,6,'2022-12-06',5),(7,7,7,'2022-12-06',6),(8,8,8,'2022-12-06',4),(9,9,9,'2022-12-06',5),(10,10,10,'2022-12-06',6);
/*!40000 ALTER TABLE `rents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-04 20:00:46
