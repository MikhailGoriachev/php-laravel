CREATE DATABASE  IF NOT EXISTS `results_of_exams_tatsiy_anna` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `results_of_exams_tatsiy_anna`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: results_of_exams_tatsiy_anna
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicants`
--

DROP TABLE IF EXISTS `applicants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_person` int NOT NULL,
  `address` varchar(255) NOT NULL,
  `year` int NOT NULL,
  `passport` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_applicants_person_idx` (`id_person`),
  CONSTRAINT `fk_applicants_person` FOREIGN KEY (`id_person`) REFERENCES `person` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicants`
--

LOCK TABLES `applicants` WRITE;
/*!40000 ALTER TABLE `applicants` DISABLE KEYS */;
INSERT INTO `applicants` VALUES (1,11,'город Видное, спуск Гагарина, 44',2003,'0483274910'),(2,12,'город Наро-Фоминск, въезд Гагарина, 74',2002,'4838214936'),(3,13,'город Раменское, наб. Ленина, 74',2002,'5932619345'),(4,14,'город Наро-Фоминск, бульвар Ладыгина, 99',2003,'8695830684'),(5,15,'город Одинцово, бульвар Ладыгина, 15',2003,'0058477395'),(6,16,'город Ступино, наб. Домодедовская, 97',2003,'0483298853'),(7,17,'город Пушкино, спуск Ладыгина, 73',2002,'0483982845'),(8,18,'город Шатура, проезд Бухарестская, 98',2001,'0437843825'),(9,19,'город Орехово-Зуево, пр. Ломоносова, 50',2001,'0587473833'),(10,20,'город Балашиха, пер. Ломоносова, 21',2002,'7584937503');
/*!40000 ALTER TABLE `applicants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disciplines`
--

DROP TABLE IF EXISTS `disciplines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disciplines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disciplines`
--

LOCK TABLES `disciplines` WRITE;
/*!40000 ALTER TABLE `disciplines` DISABLE KEYS */;
INSERT INTO `disciplines` VALUES (1,'русский язык'),(2,'литература'),(3,'математика'),(4,'иностранный язык'),(5,'история'),(6,'химия'),(7,'биология'),(8,'физика'),(9,'география'),(10,'астрономия');
/*!40000 ALTER TABLE `disciplines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `examiners`
--

DROP TABLE IF EXISTS `examiners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `examiners` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_person` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_examiners_person_idx` (`id_person`),
  CONSTRAINT `fk_examiners_person` FOREIGN KEY (`id_person`) REFERENCES `person` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examiners`
--

LOCK TABLES `examiners` WRITE;
/*!40000 ALTER TABLE `examiners` DISABLE KEYS */;
INSERT INTO `examiners` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),(9,9),(10,10);
/*!40000 ALTER TABLE `examiners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `id_discipline` int NOT NULL,
  `id_applicant` int NOT NULL,
  `id_examiner` int NOT NULL,
  `price` int(10) unsigned zerofill NOT NULL,
  `result` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_exams_disciplines_idx` (`id_discipline`),
  KEY `fk_exams_applicants_idx` (`id_applicant`),
  KEY `fk_exams_examiners_idx` (`id_examiner`),
  CONSTRAINT `fk_exams_applicants` FOREIGN KEY (`id_applicant`) REFERENCES `applicants` (`id`),
  CONSTRAINT `fk_exams_disciplines` FOREIGN KEY (`id_discipline`) REFERENCES `disciplines` (`id`),
  CONSTRAINT `fk_exams_examiners` FOREIGN KEY (`id_examiner`) REFERENCES `examiners` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES (1,'2022-11-30',1,1,1,0000002000,5),(2,'2022-12-01',2,2,2,0000002000,3),(3,'2022-12-01',3,3,3,0000001200,4),(4,'2022-12-02',4,4,4,0000002300,3),(5,'2022-12-03',5,5,5,0000002500,2),(6,'2022-12-05',6,6,6,0000001500,4),(7,'2022-12-05',7,7,7,0000002000,5),(8,'2022-12-05',8,8,8,0000002000,4),(9,'2022-12-05',9,9,9,0000002000,3),(10,'2022-12-05',10,10,10,0000002000,5);
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `person` (
  `id` int NOT NULL AUTO_INCREMENT,
  `surname` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `patronymic` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,'Молчанова','Анастасия','Максимовна'),(2,'Галкина','Дарья','Марковна'),(3,'Черкасов','Руслан','Русланович'),(4,'Еремина','Александра','Артёмовна'),(5,'Ершова','Мария','Михайловна'),(6,'Зайцев','Кирилл','Владимирович'),(7,'Краснов','Матвей','Максимович'),(8,'Никифоров','Егор','Артёмович'),(9,'Бирюков','Алексей','Александрович'),(10,'Ермолаева','София','Николаевна'),(11,'Гущина','Валерия','Леонидовна'),(12,'Захаров','Артём','Георгиевич'),(13,'Киселева','Виктория','Алексеевна'),(14,'Захаров','Адам','Никитич'),(15,'Соловьев','Матвей','Никитич'),(16,'Рожков','Артём','Даниилович'),(17,'Киселев','Лев','Кириллович'),(18,'Попов','Тимофей','Иванович'),(19,'Борисова','Арина','Максимовна'),(20,'Иванова','Анна','Александровна');
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-04 19:53:43
