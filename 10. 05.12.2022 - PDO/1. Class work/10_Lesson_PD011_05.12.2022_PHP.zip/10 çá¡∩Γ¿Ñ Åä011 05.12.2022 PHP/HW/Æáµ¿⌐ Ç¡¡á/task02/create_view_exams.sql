use results_of_exams_tatsiy_anna;

-- представление экзаменаторы
create or replace view examiners_view as
	select 
	`examiners`.`id`,
    `examiners`.`id_person`,
    
    `person`.`surname`,
    `person`.`name`,
    `person`.`patronymic`

FROM `results_of_exams_tatsiy_anna`.`examiners` join person on `examiners`.`id_person` =  `person`.`id`;

-- представление абитуриенты
create or replace view applicants_view as
	select
	`applicants`.`id`,
    `applicants`.`id_person`,
    
	`person`.`surname`,
    `person`.`name`,
    `person`.`patronymic`,
    
    `applicants`.`address`,
    `applicants`.`year`,
    `applicants`.`passport`
FROM `results_of_exams_tatsiy_anna`.`applicants` join person on `applicants`.`id_person` =  `person`.`id`;

-- представление экзамены 
create or replace view exams_view as
	select
	`exams`.`id`,
    `exams`.`date`,
    
    `exams`.`id_discipline`,
    `disciplines`.`title`,

    `exams`.`id_applicant`,
    `applicants_view`.`id_person` as applicants_person_id,
    `applicants_view`.`surname` as applicants_surname,
    `applicants_view`.`name`as applicants_name,
    `applicants_view`.`patronymic`as applicants_patronymic,
    `applicants_view`.`address`,
    `applicants_view`.`year`,
    `applicants_view`.`passport`,
    
    `exams`.`id_examiner`,
    `examiners_view`.`id_person` as examiners_person_id,
    `examiners_view`.`surname` as examiners_surname,
    `examiners_view`.`name` as examiners_name,
    `examiners_view`.`patronymic` as examiners_patronymic,
    
    `exams`.`price`,
    `exams`.`result`
FROM `results_of_exams_tatsiy_anna`.`exams` join disciplines on `exams`.`id_discipline` = disciplines.id 
											join applicants_view on `exams`.`id_applicant` = applicants_view.id
                                            join examiners_view on `exams`.`id_examiner` = examiners_view.id;



		