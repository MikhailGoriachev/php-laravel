use results_of_exams_tatsiy_anna;

delimiter ::

-- удаляем функции если они существуют 
drop function if exists fun01::
drop function if exists fun02::
drop function if exists fun03::
drop function if exists fun04::
drop function if exists fun05::
drop function if exists fun06::
drop function if exists fun07::
drop function if exists fun08::

-- Хранимая функция 1
-- Выбирает информацию об абитуриентах с заданной фамилией, серией/номером паспорта 
create function fun01(sur varchar(45), p varchar(10)) 
returns int reads sql data
begin
	declare result int;
		select count(*) into result from applicants_view where surname like sur and passport like p;
    return result;
end::

-- Хранимая функция 2
-- Выбирает информацию об экзаменах, которые были приняты экзаменатором с заданной фамилией 
create function fun02(sur varchar(45)) 
returns int reads sql data
begin
	declare result int;
		select count(*) into result from exams_view where examiners_surname like sur;
    return result;
end::

-- Хранимая функция 3  
-- Выбирает информацию об экзаменах, сданных абитуриентом с заданным номером/серией паспорта 
create function fun03(p varchar(10)) 
returns int reads sql data
begin
	declare result int;
		select count(*) into result from exams_view where passport like p;
    return result;
end::

-- Хранимая функция 4
-- Выбирает информацию об абитуриенте с заданным номером/серией паспорта.  
create function fun04(p varchar(10)) 
returns int reads sql data
begin
	declare result int;
		select count(*) into result from applicants_view where passport like p;
    return result;
end::

-- Хранимая функция 5
-- Выбирает информацию обо всех экзаменаторах 
create function fun05() 
returns int reads sql data
begin
	declare result int;
		select count(*) into result from examiners_view;
    return result;
end::

-- Хранимая функция 6 
-- Вычисляет для каждого экзамена размер налога (Налог=Размер оплаты*13%) и зарплаты экзаменатора 
-- (Зарплата=Размер оплаты - Налог). Сортировка по полю Код экзаменатора 
create function fun06() 
returns int reads sql data
begin
	declare result int;
		select count(*) into result from ( select id, price*0.13 as tax, price-price*0.13 as salary from exams_view order by id_examiner) as t;
    return result;
end::

-- Хранимая функция 7
-- Выполняет группировку по полю Год рождения в таблице АБИТУРИЕНТЫ. Для каждой группы определяет 
-- количество абитуриентов (итоги по полю Код абитуриента) 
create function fun07() 
returns int reads sql data
begin
	declare result int;
		select count(*) into result from ( select `year`, count(id) from applicants_view group by `year`) as t;
    return result;
end::

-- Хранимая функция 8 
-- Выполняет группировку по полю Дата сдачи экзамена в таблице ЭКЗАМЕНЫ. Для каждой даты определяет
-- среднее значения по полю Оценка 
create function fun08() 
returns int reads sql data
begin
	declare result int;
		select count(*) into result from ( select `date`, avg(result) from exams_view group by `date`) as t;
    return result;
end::

delimiter ;



