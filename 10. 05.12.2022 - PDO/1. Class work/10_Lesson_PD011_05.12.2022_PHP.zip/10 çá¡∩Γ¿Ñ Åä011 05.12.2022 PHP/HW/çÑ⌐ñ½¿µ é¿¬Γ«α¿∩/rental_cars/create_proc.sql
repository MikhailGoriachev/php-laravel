-- База данных «Прокат автомобилей»

delimiter $$
-- 1. Хранимая процедура
-- Выбирает информацию об автомобилях, стоимость
-- одного дня проката которых меньше заданной
drop procedure if exists ProcQuery1$$

create procedure ProcQuery1(in pay_day int)
begin
   select * from view_cars where pay_rental_day < pay_day;
end$$


-- 2. Хранимая процедура
-- Выбирает информацию об автомобилях, страховая стоимость
-- которых находится в заданном диапазоне значений
drop procedure if exists ProcQuery2$$

create procedure ProcQuery2(in insurance_lo int, in insurance_hi int)
begin
   select * from view_cars where insurance_pay between insurance_lo and insurance_hi;
end$$


-- 3. Хранимая процедура
-- Выбирает информацию о клиентах, серия-номер паспорта
-- которых начинается с заданной параметром цифры.
-- Включает поля Код клиента, Паспорт,
-- Дата начала проката, Количество дней проката, Модель автомобиля
drop procedure if exists ProcQuery3$$

create procedure ProcQuery3(in passport varchar(2))
begin
select 
    * 
from 
    view_clients
where 
    passport regexp '^passport'
order by
    rental_start_date;
end$$


-- 4. Хранимая процедура
-- Выбирает информацию о клиентах, бравших
-- автомобиль напрокат в некоторый определенный день. 
drop procedure if exists ProcQuery4$$

create procedure ProcQuery4(in rental_date date)
begin
   select 
    * 
from 
    view_clients
where
   rental_start_date = rental_date;
end$$


-- 5. Хранимая процедура
-- Выбирает информацию об автомобилях, для которых значение
-- в поле Страховая стоимость автомобиля попадает в некоторый заданный интервал.
 drop procedure if exists ProcQuery5$$

create procedure ProcQuery5(in insurance_from int, in insurance_to int)
begin
   select * from view_cars where insurance_pay between insurance_from and insurance_to;
end$$


-- 6. Хранимая процедура
-- Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса.
-- Включает поля Госномер автомобиля, Модель автомобиля,
-- Год выпуска автомобиля, Страховая стоимость автомобиля,
-- Страховой взнос. Сортировка по полю Год выпуска автомобиля
 drop procedure if exists ProcQuery6$$

create procedure ProcQuery6()
begin
   select 
	 cars.car_number
	 , models.model
	 , cars.`year`
	 , cars.insurance_pay
	 , (cars.pay_rental_day*rentals.duration)/1.1 as cost_rental
from 
    rentals join(cars join models on cars.id_model = models.id)
			on rentals.id_car = cars.id
order by
    `year`;
end$$


-- 7. Хранимая процедура
-- Выполняет группировку по полю Модель автомобиля.
-- Для каждой модели вычисляет минимальную страховую стоимость автомобиля.
 drop procedure if exists ProcQuery7$$

create procedure ProcQuery7()
begin
    select
	 models.model
     , COUNT(*) as cnt_model
	 , MIN(cars.insurance_pay) as min_insurance_pay
	 , MAX(cars.insurance_pay) as max_insurance_pay
 from
    models join cars on models.id = cars.id_model
 group by
	models.model;
end$$


-- 8. Хранимая процедура
-- Выполняет группировку по полю Код клиента.
-- Для каждого клиента вычисляет минимальное и максимальное значения
-- по полю Количество дней проката
 drop procedure if exists ProcQuery8$$

create procedure ProcQuery8()
select
	concat(clients.surname, ' ', substr(clients.`name`, 1, 1), '.', substr(clients.patronymic, 1, 1), '.') as fullname
	, clients.passport
	, COUNT(rentals.id_client) as rental_facts
	, MIN(rentals.duration) as min_duration
	, MAX(rentals.duration) as max_duration
from
   rentals join clients on rentals.id_client = clients.id
group by
   clients.surname, clients.`name`, clients.patronymic, clients.passport;
end$$   

-- возврат разделителя
delimiter ;