-- База данных «Учет результатов сдачи вступительных экзаменов»

delimiter $$

-- 1. Хранимая функция 
-- Выбирает информацию об абитуриентах с заданной фамилией, серией/номером паспорта
drop function if exists funcQuery1$$

create function funcQuery1(surname varchar(20), passport_num varchar(10))
returns 

return 





-- возврат разделителя
delimiter ;