CREATE DATABASE  IF NOT EXISTS `entrance_exams` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `entrance_exams`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: entrance_exams
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `disciplines`
--

DROP TABLE IF EXISTS `disciplines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disciplines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name_discipline` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disciplines`
--

LOCK TABLES `disciplines` WRITE;
/*!40000 ALTER TABLE `disciplines` DISABLE KEYS */;
INSERT INTO `disciplines` VALUES (1,'физика'),(2,'химия'),(3,'биология'),(4,'литература'),(5,'информатика и ИКТ'),(6,'география'),(7,'история'),(8,'обществознание'),(9,'иностранный язык');
/*!40000 ALTER TABLE `disciplines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `examiners`
--

DROP TABLE IF EXISTS `examiners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `examiners` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_person` int NOT NULL,
  `pay_examination` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_examiners_persons_idx` (`id_person`),
  CONSTRAINT `fk_examiners_persons` FOREIGN KEY (`id_person`) REFERENCES `persons` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examiners`
--

LOCK TABLES `examiners` WRITE;
/*!40000 ALTER TABLE `examiners` DISABLE KEYS */;
INSERT INTO `examiners` VALUES (1,14,700),(2,15,1200),(3,16,580),(4,17,950),(5,18,420),(6,19,800),(7,20,1000),(8,21,630),(9,22,700);
/*!40000 ALTER TABLE `examiners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_disciplines` int NOT NULL,
  `id_examiners` int NOT NULL,
  `id_students` int NOT NULL,
  `date_exam` date NOT NULL,
  `score` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_exams_disciplines_idx` (`id_disciplines`),
  KEY `fk_exams_examiners_idx` (`id_examiners`),
  KEY `fk_exams_students_idx` (`id_students`),
  CONSTRAINT `fk_exams_disciplines` FOREIGN KEY (`id_disciplines`) REFERENCES `disciplines` (`id`),
  CONSTRAINT `fk_exams_examiners` FOREIGN KEY (`id_examiners`) REFERENCES `examiners` (`id`),
  CONSTRAINT `fk_exams_students` FOREIGN KEY (`id_students`) REFERENCES `students` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES (1,2,2,6,'2022-11-07',4),(2,3,3,3,'2022-11-05',3),(3,5,5,1,'2022-11-14',4),(4,6,6,2,'2022-11-15',5),(5,2,2,3,'2022-11-07',3),(6,3,3,4,'2022-11-05',3),(7,4,4,5,'2022-11-17',4),(8,5,5,2,'2022-11-14',5),(9,7,7,6,'2022-11-08',5),(10,5,5,3,'2022-11-14',4),(11,2,2,1,'2022-11-07',4),(12,4,4,6,'2022-11-17',5),(13,3,3,2,'2022-11-05',5),(14,1,1,1,'2022-11-09',3),(15,2,2,4,'2022-11-07',4),(16,7,7,5,'2022-11-08',4),(17,8,8,3,'2022-11-19',4),(18,3,3,5,'2022-11-05',5),(19,5,5,4,'2022-11-14',5),(20,6,6,5,'2022-11-15',5);
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persons`
--

DROP TABLE IF EXISTS `persons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `persons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `surname` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `patronymic` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persons`
--

LOCK TABLES `persons` WRITE;
/*!40000 ALTER TABLE `persons` DISABLE KEYS */;
INSERT INTO `persons` VALUES (1,'Гончарова','Арина','Алексеевна'),(2,'Серов','Платон','Львович'),(3,'Котов ','Михаил','Павлович'),(4,'Грачёва ','Василиса','Алексеевна'),(5,'Морозова','Таисия','Платоновна'),(6,'Семёнова ','Дарина','Марковна'),(7,'Лавров','Роман','Андреевич'),(8,'Смирнов','Константин','Артёмович'),(9,'Грибова','Софья','Никитична'),(10,'Николаева','Валерия','Максимовна'),(11,'Рыбаков','Даниил','Георгиевич'),(12,'Островский','Александр','Михайлович'),(13,'Воронина','Василиса','Кирилловна'),(14,'Григорьев','Тихон','Кириллович'),(15,'Денисова','Александра','Ивановна'),(16,'Жукова','Дарина','Михайловна'),(17,'Иванова','Софья','Данииловна'),(18,'Ковалева ','Полина','Андреевна'),(19,'Корнеев','Марк','Леонидович'),(20,'Мещеряков','Максим','Платонович'),(21,'Иванова','Софья','Данииловна'),(22,'Иванов','Николай','Артёмович'),(23,'Джемакулов','Якуб','Кемалович'),(24,'Шевченко','Галина','Николаевна'),(25,'Зинкевич','Олег','Дмитриевич');
/*!40000 ALTER TABLE `persons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_person` int NOT NULL,
  `address` varchar(70) NOT NULL,
  `year_of_birth` int NOT NULL,
  `passport` varchar(12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_students_persons_idx` (`id_person`),
  CONSTRAINT `fk_students_persons` FOREIGN KEY (`id_person`) REFERENCES `persons` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,1,'ул.Малышко,д.55',2005,'60 24 568123'),(2,2,'ул.Железнодорожная,д.42',2004,'60 32 567156'),(3,3,'ул.Терешкова д.12,кв.3',2005,'34 22 792950'),(4,4,'ул.Судовая, д.15',2004,'34 82 750358'),(5,5,'ул.Садовая, д.8',2005,'57 81 604950'),(6,6,'ул.Университетская,д.22,кв.59',2004,'62 20 567430'),(7,7,'ул.Архитекторов, д.3,кв.12',2004,'34 73 694038'),(8,8,'ул.Садовая, д.14',2005,'57 40 572938'),(9,9,'ул.Садовая, д.15',2005,'62 69 618402'),(10,10,'ул.Судовая, д.20',2003,'57 39 244375'),(11,11,'ул.Кирова, д.8',2003,'34 67 572946'),(12,12,'ул.Содовая, д.20',2005,'62 58 562947');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_examiners`
--

DROP TABLE IF EXISTS `view_examiners`;
/*!50001 DROP VIEW IF EXISTS `view_examiners`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_examiners` AS SELECT 
 1 AS `surname`,
 1 AS `name`,
 1 AS `patronymic`,
 1 AS `pay_examination`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_exams`
--

DROP TABLE IF EXISTS `view_exams`;
/*!50001 DROP VIEW IF EXISTS `view_exams`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_exams` AS SELECT 
 1 AS `fullname_examiner`,
 1 AS `name_discipline`,
 1 AS `fullname_student`,
 1 AS `date_exam`,
 1 AS `score`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_students`
--

DROP TABLE IF EXISTS `view_students`;
/*!50001 DROP VIEW IF EXISTS `view_students`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_students` AS SELECT 
 1 AS `surname`,
 1 AS `name`,
 1 AS `patronymic`,
 1 AS `passport`,
 1 AS `year_of_birth`,
 1 AS `address`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `view_examiners`
--

/*!50001 DROP VIEW IF EXISTS `view_examiners`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_examiners` AS select `persons`.`surname` AS `surname`,`persons`.`name` AS `name`,`persons`.`patronymic` AS `patronymic`,`examiners`.`pay_examination` AS `pay_examination` from (`examiners` join `persons` on((`examiners`.`id_person` = `persons`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_exams`
--

/*!50001 DROP VIEW IF EXISTS `view_exams`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_exams` AS select concat(`persons`.`surname`,' ',substr(`persons`.`name`,1,1),'.',substr(`persons`.`patronymic`,1,1),'.') AS `fullname_examiner`,`disciplines`.`name_discipline` AS `name_discipline`,concat(`persons`.`surname`,' ',substr(`persons`.`name`,1,1),'.',substr(`persons`.`patronymic`,1,1),'.') AS `fullname_student`,`exams`.`date_exam` AS `date_exam`,`exams`.`score` AS `score` from (((`exams` join (`examiners` join `persons` on((`examiners`.`id_person` = `persons`.`id`))) on((`exams`.`id_examiners` = `examiners`.`id`))) join (`students` join `persons` `p` on((`students`.`id_person` = `p`.`id`))) on((`exams`.`id_examiners` = `examiners`.`id`))) join `disciplines` on((`exams`.`id_disciplines` = `disciplines`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_students`
--

/*!50001 DROP VIEW IF EXISTS `view_students`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_students` AS select `persons`.`surname` AS `surname`,`persons`.`name` AS `name`,`persons`.`patronymic` AS `patronymic`,`students`.`passport` AS `passport`,`students`.`year_of_birth` AS `year_of_birth`,`students`.`address` AS `address` from (`students` join `persons` on((`students`.`id_person` = `persons`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-04 23:53:33
