<?php

// база данных
$db = 'solar_system';

// DSN - Data Source Name
$dsn = "mysql:host=localhost;port=3306;dbname=$db;charset=utf8";

// пользователь БД
$user = 'root';

// пароль пользователя
$password = '___sP123456890...';
