
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_28.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="/lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/lib/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<?php
// активность страниц
$activePage02 = "active";

$activePage01 = $activeIndex  = $activePage03 = "";

// загрузка панели навигации
include_once "shared/_header.php";
?>

<main class="container-fluid" >

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-3 bg-white m-3 border-warning-top border-warning-bottom">

            <?php
            //подключили функции
            require_once("../infrastructure/utils.php");
            require_once("../tasks/task02.php");

            //в зависимости от номера запроса формируем форму(если она нужна), выполняем запрос
            if(isset($_POST['query'])){

                $query = $_POST['query'];

                switch ($query) {
                    case 'query01':

                        echo ' <p class="mb-2 ms-4 fs-4 mt-3">Выбирает информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов </p>';

                        echo ' 
            <form class="w-25 m-4" method="post">

                <div>
                    <label for="str" class="form-label">Введите последовательность:</label>
                    <input class="form-control" name="str" type="text" required/>
                </div>

                <div class="d-flex mt-3 justify-content-end">
                    <button class="btn btn-primary" type="submit" name="answer" value="answer01">Ок</button>
                </div>

            </form>';
                        break;
                    case 'query02':

                        echo '  <p class="mb-2 ms-4 fs-4 mt-3">Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше заданного </p>';

                        echo '          
            <form class="w-25 m-4" method="post">

                <div>
                    <label for="str" class="form-label">Введите процент отчисления:</label>
                    <input class="form-control" name="str" type="number" required min="1" max="99"/>
                </div>

                <div class="d-flex mt-3 justify-content-end">
                    <button class="btn btn-primary" type="submit" name="answer" value="answer02">Ок</button>
                </div>

            </form>';

                        break;
                    case 'query03':

                        echo '<p class="mb-2 ms-4 fs-4 mt-3">Выбирает информацию о приемах за некоторый период  </p>';

                        echo   '            
            <form class="w-25 m-4" method="post">

                <div>
                    <label for="str01" class="form-label">Введите начальную дату:</label>
                    <input class="form-control" name="str01" type="date" required />
                </div>

                <div>
                    <label for="str02" class="form-label">Введите конечную дату:</label>
                    <input class="form-control" name="str02" type="date" required />
                </div>

                <div class="d-flex mt-3 justify-content-end">
                    <button class="btn btn-primary" type="submit" name="answer" value="answer03">Ок</button>
                </div>

            </form>';

                        break;
                    case 'query04':

                        echo '<p class="mb-2 ms-4 fs-4 mt-3">Выбирает из таблицы информацию о врачах с заданной специальностью</p>';

                        $query = "	select 
		                *
	                from Specialties ;";

                        $st = DB->query($query);
                        $results = $st->fetchAll();

                        echo "
    
        <form class='w-25 m-4' method='post'>
        
       <select class='form-select' name='sp'>
                        <option selected > Выберите специальность </option >";
                        foreach ($results as $row)
                            echo " <option value = '{$row['Id']}'>{$row['name']}</option >";

                        echo "
                </select >
        
                <div class='d-flex mt-3 justify-content-end'>
                    <button class='btn btn-primary' type='submit' name='answer' value='answer04'>Ок</button>
                </div> </form>";

                        break;
                    case 'query05':
                        doQuery05();
                        break;
                    case 'query06':
                        doQuery06();
                        break;
                    case 'query07':
                        doQuery07();
                        break;
                    case 'query08':
                        viewSpecialties();
                        break;
                    case 'query09':
                        viewDoctors();
                        break;
                    case 'query10':
                        viewPatients();
                        break;
                    case 'query11':

                        echo '            
            
            <div class="me-1 justify-content-end d-flex">

                <div class="row">

                    <div class="col-3 mt-3">

                        <div class="btn-group me-5">

                            <a class="btn btn-success" style="width: 200px;" href="addForm.php" >Добавить запись</a>

                        </div>
                    </div>
                </div>

            </div>';

                        viewReceipts();
                        break;
                }
            }

            deleteReceipts();

            //выполняем запросы, которым нужна форма
            if(isset($_POST['answer'])){

                $answer = $_POST['answer'];

                switch ($answer){

                    case 'answer01':
                        doQuery01();
                        break;

                    case 'answer02':
                        doQuery02();
                        break;

                    case 'answer03':
                        doQuery03();
                        break;

                    case 'answer04':
                        doQuery04();
                        break;

                }
            }

            ?>

        </div>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "shared/_footer.php" ?>

</body>
</html>
