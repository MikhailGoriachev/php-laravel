<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top" xmlns="http://www.w3.org/1999/html"
     xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
    <div class="container-fluid">
        <div style="width: 70%; margin: auto;">
            <div class="navbar-collapse" id="appNavbar-1">
                <ul class="navbar-nav fs-4">
                    <li class="nav-item pt-1">
                        <a class="nav-link <?= $activeIndex ?>" href="/index.php">Страница с заданием</a>
                    </li>
                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link <?= $activePage01 ?>" href="/pages/page01.php">Задача 1</a>
                    </li>

                    <li class="nav-item ps-3">
                        <form method="post" action="/pages/page02.php">
                        <button class="nav-link bg-dark border-transparent <?= $activePage02 ?>" type="submit" name="query" value="query08">Специальности</button>
                        </form>
                    </li>

                    <li class="nav-item ps-3">
                        <form method="post" action="/pages/page02.php">
                            <button class="nav-link bg-dark border-transparent <?= $activePage02 ?>" type="submit" name="query" value="query09">Врачи</button>
                        </form>
                    </li>

                    <li class="nav-item ps-3">
                        <form method="post" action="/pages/page02.php">
                            <button class="nav-link bg-dark border-transparent <?= $activePage02 ?>" type="submit" name="query" value="query10">Пациенты</button>
                        </form>
                    </li>

                    <li class="nav-item ps-3">
                        <form method="post" action="/pages/page02.php">
                            <button class="nav-link bg-dark border-transparent <?= $activePage02 ?>" type="submit" name="query" value="query11">Приемы</button>
                        </form>
                    </li>

                    <li class="nav-item dropdown pt-1 ps-3">
                        <form method="post" action="/pages/page02.php">
                        <a class="nav-link dropdown-toggle <?= $activePage02 ?>" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Запросы
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdown">
                            <form method="post" action="/pages/page02.php">
                                <li><button type="submit" name="query" value="query01" class="dropdown-item">Запрос 1 с параметрами</button></li>
                                <li><button class="dropdown-item" type="submit" name="query" value="query02">Запрос 2 с параметрами</button></li>
                                <li><button class="dropdown-item" type="submit" name="query" value="query03">Запрос 3 с параметрами </button></li>
                                <li><button class="dropdown-item" type="submit" name="query" value="query04">Запрос 4 с параметрами </button></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><button class="dropdown-item" type="submit" name="query" value="query05">Запрос 5 с вычисляемыми полями </button></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><button class="dropdown-item" type="submit" name="query" value="query06">Итоговый запрос 6</button></li>
                                <li><button class="dropdown-item" type="submit" name="query" value="query07">Итоговый запрос 7</button></li>
                            </form>
                        </ul>
                    </li>

                </ul>
            </div>
        </div>
    </div>
</nav>