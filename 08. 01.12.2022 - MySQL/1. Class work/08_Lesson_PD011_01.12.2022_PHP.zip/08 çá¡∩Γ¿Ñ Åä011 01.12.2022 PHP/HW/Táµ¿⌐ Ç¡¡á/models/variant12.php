
<?php

require_once "traits\matrix.php";

class Variant12{

    // задать использование трейта с конструктором
    use Matrix;

    //Найти номер первой из строк, содержащих хотя бы один положительный
    // элемент
    function solveTask01():void{

        for($i = 0; $i < $this->row; $i++) {

            $arr = array_filter($this->matrix[$i], fn($a) => $a >= 0);

            if(sizeof($arr) > 0){
                echo " Номер первой из строк, содержащих хотя бы один положительный: ".$i."<br>";
                return;
            }
        }

        echo " Номер первой из строк, содержащих хотя бы один положительный не найден<br>";
    }

    //Вычислить суммы элементов в тех столбцах, которые не содержат отрицательных элементов.
    function solveTask01_5():void{

        for ($i = 0; $i < $this->col; $i++) {
            $arr_col = array_column($this->matrix, $i);

            $arr = array_filter($arr_col,fn($a) => $a < 0);

            if(sizeof($arr) <= 0){
                $sum = array_sum($arr_col);

                echo "Сумма элементов в ".$i." столбце, который не содержат отрицательных элементов: ".$sum."<br>";
            }
        }
    }

    //Уплотнить заданную матрицу, удаляя из нее строки и столбцы,
    // заполненные нулями.
    function solveTask02():void{

        //добавляем в матрицу строку и столбец заполненые нулями
        $arr_col = array_pad([], $this->col, 0);
        $arr_row = array_pad([], $this->row, 0);

        $this->matrix = array_splice($this->matrix,rand(0,$this->row-1),0,$arr_row);

        $this->show("Добавили в матрицу строку и столбец заполненые нулями");

    }
}