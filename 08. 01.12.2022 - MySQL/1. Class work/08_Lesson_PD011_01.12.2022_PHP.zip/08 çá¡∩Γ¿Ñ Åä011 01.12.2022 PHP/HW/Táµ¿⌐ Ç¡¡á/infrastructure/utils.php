<?php

// обмен значений
function swap(&$x, &$y): void
{
    $temp = $x;
    $x = $y;
    $y = $temp;
}

// вывод сообщения
function info($title, $text){
    echo "
    <div class='alert alert-success'>
        <strong>$title</strong><br>$text
    </div>";
} // alert