<?php

require_once('..\models\variant15.php');
require_once('..\models\variant12.php');

$v15 = new Variant15();
$v12 = new Variant12();

$v12->show("Исходная матрица");
$v15->show("Исходная матрица");

$v12->solveTask01();
$v12->solveTask01_5();
$v12->solveTask02();

$v15->solveTask01();
$v15->solveTask01_5();
$v15->solveTask02();