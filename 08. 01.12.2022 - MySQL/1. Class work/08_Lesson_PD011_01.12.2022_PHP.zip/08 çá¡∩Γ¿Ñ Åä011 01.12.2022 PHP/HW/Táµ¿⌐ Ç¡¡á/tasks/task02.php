<?php

const DB = new PDO('sqlite:../app_data/Appointment.db');

//вывод таблицы специвльности
function viewSpecialties():void{

    echo ' <p class="mb-2 ms-4 fs-4 mt-3">Таблица специальностей: </p>';

    $query = "	select 
		                *
	                from Specialties ;";

    $st = DB->query($query);

    // обход результата
    echo "
          <table class='mt-4 table table-bordered'>
          <tr><th>id</th><th>Специальность</th></tr>";
    while ($row = $st->fetch()) {
        echo "
                <tr>
                <td>{$row['Id']}</td>
                <td>{$row['name']}</td>
                </tr>";
    }
    echo "</table>";
}

//вывод таблицы врачи
function viewDoctors():void{

    echo ' <p class="mb-2 ms-4 fs-4 mt-3">Таблица врачи: </p>';

    $query = "	select 
		                *
	                from ViewDoctors ;";

    $st = DB->query($query);

    // обход результата
    echo "
          <table class='mt-4 table table-bordered'>
          <tr><th>id</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Специальность</th><th>Процент</th></tr>";
    while ($row = $st->fetch()) {
        echo "
                <tr>
                <td>{$row['Id']}</td>
                <td>{$row['surname']}</td>
                <td>{$row['name']}</td>
                <td>{$row['patronymic']}</td>
                <td>{$row['Specialtie']}</td>
                <td>{$row['tax']}</td>
                </tr>";
    }
    echo "</table>";

}

//вывод таблицы пациенты
function viewPatients():void{

    echo ' <p class="mb-2 ms-4 fs-4 mt-3">Таблица пациентов: </p>';

    $query = "	select 
		                *
	                from Patients ;";

    $st = DB->query($query);

    // обход результата
    echo "
          <table class='mt-4 table table-bordered'>
          <tr><th>id</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Дата рождения</th><th>Адрес пациента</th></tr>";
    while ($row = $st->fetch()) {
        echo "
                <tr>
                <td>{$row['Id']}</td>
                <td>{$row['surname']}</td>
                <td>{$row['name']}</td>
                <td>{$row['patronymic']}</td>
                <td>{$row['Date_of_Birth']}</td>
                <td>{$row['address']}</td>
                </tr>";
    }
    echo "</table>";

}

//вывод таблицы записи на прием
function viewReceipts():void{

    echo ' <p class="mb-2 ms-4 fs-4 mt-3">Таблица приемы: </p>';

    $query = "	select 
		                *
	                from ViewReceipts ;";

    $st = DB->query($query);

    // обход результата
    echo "
 <form method='post'>
          <table class='table table-bordered '>
          <tr><th>Id</th><th>Пациент</th><th>Доктор</th><th>Специальность</th><th>Дата</th><th>Стоимость</th></tr>";
    while ($row = $st->fetch()) {
        echo "
                <tr>
                <td>{$row['Id']}</td>
                <td>{$row['Patient']}</td>
                <td>{$row['Doctor']}</td>
                <td>{$row['Specialtie']}</td>
                <td>{$row['date']}</td>
                <td>{$row['price']}</td>
                <td><form method='post' action='#'><button class='btn btn-danger' type='submit' name='id_delete' value='{$row['Id']}'>Удалить</button></form></td>
                <td><form method='post' action='addForm.php'><button class='btn btn-primary' type='submit' name='edit' value='{$row['Id']}'>Изменить</button></form></td>
                </tr>";
    }
    echo "</table></form>";

}

//Удаление записи
function deleteReceipts(){

    if (isset($_POST['id_delete'])) {

        $id = $_POST['id_delete'];

        $stmt = DB->prepare(" delete from Receipts WHERE Id = :id ");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        info('Удаление:', 'Запись успешно удалена');
    }

}

//добавление/изменение записи
function addReceipts($id): void
{

    if($id != -1){

        $query = "	select 
		                *
	                from Receipts 
                    where Receipts.Id = :id;";

        $stmt = DB->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $receipt = $stmt->fetch();

        $price = $receipt['price'];
        $date = $receipt['date'];
        $doctor = $receipt['id_doctor'];
        $patient = $receipt['id_patient'];
        $proc = 'edit';
    }
    else{

        $price = 1000;
        $date = '';
        $doctor = '';
        $patient = '';
        $proc = 'add';

    }

    $query = "	select 
		                *
	                from Doctors ;";

    $st = DB->query($query);
    $results_doctors = $st->fetchAll();

    $query = "	select 
		                *
	                from Patients ;";

    $st = DB->query($query);
    $results_patients = $st->fetchAll();

    echo '
    <form class="w-25 m-4" method="post">

    <input type="hidden" name="id" value='.$id.' />

    <select class="form-select" name="doctor" required>
                        <option selected >Выберите доктора</option >';
                        foreach ($results_doctors as $row)
                            echo " <option value = '{$row['Id']}'>{$row['surname']} {$row['name']} {$row['patronymic']}</option >";

                        echo '
    </select>
    
        <select class="form-select" name="patient" required>
                        <option selected> Выберите пациента </option >';
    foreach ($results_patients as $row)
        echo " <option value = '{$row['Id']}'>{$row['surname']} {$row['name']} {$row['patronymic']}</option >";


    echo '
    </select>
    
                <div>
                    <label for="date" class="form-label">Введите дату:</label>
                    <input class="form-control" name="date" type="date"  value='.$date.' required />
                </div>
                
                <div>
                    <label for="price" class="form-label">Введите стоимость:</label>
                    <input class="form-control" name="price" type="number" value='.$price.' required min="500" max="10000"/>
                </div>
    
               <div class="d-flex mt-3 justify-content-end">
                    <button class="btn btn-success" type="submit" name="proc" value='.$proc.'>Добавить</button>
               </div>
    
</form>';

}

//Выбирает информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов
function doQuery01() :void{

     if(isset($_POST['str'])){

         echo ' <p class="mb-2 ms-4 fs-4 mt-3">Выбирает информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов </p>';

         $surname = $_POST['str'];

         $query = "select *
	                from Patients 
	                where Patients.surname like '$surname%'; ";

         $stmt = DB->query($query);

         // обход результата
         echo "
          <table class='mt-4 table table-bordered'>
          <tr><th>id</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Дата рождения</th><th>Адрес пациента</th></tr>";
         while ($row = $stmt->fetch()) {
             echo "
                <tr>
                <td>{$row['Id']}</td>
                <td>{$row['surname']}</td>
                <td>{$row['name']}</td>
                <td>{$row['patronymic']}</td>
                <td>{$row['Date_of_Birth']}</td>
                <td>{$row['address']}</td>
                </tr>";
         }
         echo "</table>";
     }
}

//Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше заданного
function doQuery02() :void{

    if(isset($_POST['str'])){

        echo '  <p class="mb-2 ms-4 fs-4 mt-3">Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше заданного </p>';

        $tax = $_POST['str'];

        $query = "	select *
	                    from Doctors
	                    where Doctors.tax > :tax; ";

        $stmt = DB->prepare($query);
        $stmt->bindParam(':tax', $tax, PDO::PARAM_INT);
        $stmt->execute();

        // обход результата
        echo "
          <table class='table table-bordered '>
          <tr><th>id</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Процент</th></tr>";
        while ($row = $stmt->fetch()) {
            echo "
                <tr>
                <td>{$row['Id']}</td>
                <td>{$row['surname']}</td>
                <td>{$row['name']}</td>
                <td>{$row['patronymic']}</td>
                <td>{$row['tax']}</td>
                </tr>";
        }
        echo "</table>";
    }
}

//Выбирает информацию о приемах за некоторый период
function doQuery03() :void{

    if(isset($_POST['str01']) && isset($_POST['str02'])){

        echo '<p class="mb-2 ms-4 fs-4 mt-3">Выбирает информацию о приемах за некоторый период  </p>';

        $date01 = $_POST['str01'];
        $date02 = $_POST['str02'];

        $query = "	select 
		                ViewReceipts.Doctor,
		                ViewReceipts.Patient,
		                ViewReceipts.Specialtie,
		            ViewReceipts.[date]
	                from ViewReceipts
                    where [date] between :date01 and :date02 ";

        $stmt = DB->prepare($query);
        $stmt->bindParam(':date01', $date01, PDO::PARAM_STR);
        $stmt->bindParam(':date02', $date02, PDO::PARAM_STR);
        $stmt->execute();

        // обход результата
        echo "
          <table class='table table-bordered '>
          <tr><th>Пациент</th><th>Доктор</th><th>Специальность</th><th>Дата</th></tr>";
        while ($row = $stmt->fetch()) {
            echo "
                <tr>
                <td>{$row['Doctor']}</td>
                <td>{$row['Patient']}</td>
                <td>{$row['Specialtie']}</td>
                <td>{$row['date']}</td>
                </tr>";
        }
        echo "</table>";
    }
}

//Выбирает из таблицы информацию о врачах с заданной специальностью
function doQuery04() :void{

    echo '<p class="mb-2 ms-4 fs-4 mt-3">Выбирает из таблицы информацию о врачах с заданной специальностью</p>';

    if(isset($_POST['sp'])){

        $sp = $_POST['sp'];

        $query = "	select 
		                    *
	                    from ViewDoctors 
                        where ViewDoctors.SpecialtieId = :sp ";

        $stmt = DB->prepare($query);
        $stmt->bindParam(':sp', $sp, PDO::PARAM_STR);
        $stmt->execute();

        // обход результата
        echo "
          <table class='table table-bordered '>
          <tr><th>id</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Специальность</th><th>Процент</th></tr>";
        while ($row = $stmt->fetch()) {
            echo "
                <tr>
                <td>{$row['Id']}</td>
                <td>{$row['surname']}</td>
                <td>{$row['name']}</td>
                <td>{$row['patronymic']}</td>
                <td>{$row['Specialtie']}</td>
                <td>{$row['tax']}</td>
                </tr>";
        }
        echo "</table>";
    }


}

//Вычисляет размер заработной платы врача за каждый прием. Включает поля
// Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость
// приема, Зарплата. Сортировка по полю Специальность врача
function doQuery05() :void{

    echo '<p class="mb-5 ms-4 fs-4 mt-3">Вычисляет размер заработной платы врача за каждый прием.</p>';

    $query = "			select 
		                    Doctor,
		                    ViewReceipts.Specialtie,
		                    ViewReceipts.price,
		                    ViewReceipts.price *(ViewReceipts.tax/100) - (ViewReceipts.tax/100)*ViewReceipts.price *13/100 as Salary
	                    from ViewReceipts
                        order by ViewReceipts.Specialtie;";

    $st = DB->query($query);
    $results = $st->fetchAll();

    // обход результата
    echo "
      <table class='table table-bordered'>
      <tr><th>Доктор</th><th>Специальность</th><th>Стоимость приема</th><th>Зарплата</th></tr>";
    foreach ($results as $row) {
        echo "
        <tr>
        <td>{$row['Doctor']}</td>
        <td>{$row['Specialtie']}</td>
        <td>{$row['price']}</td>
        <td>{$row['Salary']}</td>
        </tr>";
    }
    echo "</table>";

}

//Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
function doQuery06() :void{

    echo '<p class="mb-5 ms-4 fs-4 mt-3">Для каждой даты вычисляет максимальную стоимость приема</p>';

    $query = "		select 
		                Receipts.[date],
		                MAX(price) as [max]
	                from Receipts
                    group by Receipts.[date]
                    order by Receipts.[date]";

    $st = DB->query($query);
    $results = $st->fetchAll();

    // обход результата
    echo "
      <table class='table table-bordered'>
      <tr><th>Дата</th><th>Максимальная стоимость</th></tr>";
    foreach ($results as $row) {
        echo "
        <tr>
        <td>{$row['date']}</td>
        <td>{$row['max']}</td>
        </tr>";
    }
    echo "</table>";

}

//Выполняет группировку по полю Специальность. Для каждой специальности вычисляет средний Процент
// отчисления на зарплату от стоимости приема
function doQuery07() :void{

    echo ' <p class="mb-5 ms-4 fs-4 mt-3">Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема</p>';

    $query = "	select 
		            Specialties.[name],
		            AVG(tax) as [AVG]
	                from Specialties left join  Doctors on Specialties.Id = Doctors.id_specialtie
                    group by Specialties.[name]";

    $st = DB->query($query);
    $results = $st->fetchAll();

    // обход результата
    echo "
      <table class='table table-bordered'>
      <tr><th>Специальность</th><th>Средний Процент</th></tr>";
    foreach ($results as $row) {
        echo "
        <tr>
        <td>{$row['name']}</td>
        <td>{$row['AVG']}</td>
        </tr>";
    }
    echo "</table>";

}
