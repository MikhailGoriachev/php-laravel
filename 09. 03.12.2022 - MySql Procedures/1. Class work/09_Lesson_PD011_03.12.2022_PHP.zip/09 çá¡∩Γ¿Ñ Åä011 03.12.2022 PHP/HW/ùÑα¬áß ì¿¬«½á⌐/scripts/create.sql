 create database if not exists car_rental;
 use car_rental;
 
 drop table if exists rental;
 drop table if exists clients;
 drop table if exists cars;
 
 create table clients (
     id int unsigned auto_increment,
     surname varchar(30) not null,
     first_name varchar(30) not null,
     putronymic varchar(30) not null,
     passport varchar(30) not null unique,
     primary key(id),
     check(surname != "" and first_name != "" and putronymic != "")
     ) engine=InnoDB; 
     
create table cars(
    id int unsigned auto_increment,
    brend varchar(30) not null,
    color varchar(30) not null,
    `year` int not null,
    `number` varchar(30) not null unique,
    insurance int not null,               /*страховка*/
    price int not null,                   /*стоимость одного дня*/
    primary key(id),
    check(`number` != "")
) engine=InnoDB;
 
create table rental (
    id int unsigned auto_increment,
    start_date date not null,
    `count` int not null,
    car_id int unsigned default null,
    client_id int unsigned default null,
    primary key(id),
    foreign key (car_id) references cars (id) on delete cascade on update cascade,
    foreign key (client_id) references clients (id) on delete cascade on update cascade
    ) engine=InnoDB; 