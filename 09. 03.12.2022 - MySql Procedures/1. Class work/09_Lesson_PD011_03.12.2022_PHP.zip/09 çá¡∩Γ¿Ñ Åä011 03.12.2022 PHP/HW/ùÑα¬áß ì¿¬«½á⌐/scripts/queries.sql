use car_rental;

-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях,
-- стоимость одного дня проката которых меньше 1900
select
    * 
from 
    cars
where price < 1900;

-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях,
-- страховая стоимость которых находится в диапазоне 
-- от 2000 000 до 3000 000
select
    *
from 
    cars
where insurance between 2000000 and 3000000;

-- Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ПРОКАТ информацию о клиентах,
-- серия-номер паспорта которых начинается с цифры «2». Включает поля 
-- Код клиента, Паспорт, Дата начала проката, Количество дней проката,
--  Модель автомобиля
select
    clients.id,
    clients.passport,
    rental.start_date,
    rental.count,
    cars.brend
from
    rental join clients on rental.client_id = clients.id
           join cars on rental.car_id = cars.id
where
    clients.passport regexp '^2';
    
-- Выбирает из таблицы КЛИЕНТЫ и ПРОКАТ информацию о клиентах,
-- бравших автомобиль напрокат в некоторый определенный день
select
    clients.surname,
    clients.first_name,
    clients.putronymic,
    rental.start_date
from
    rental join clients on rental.client_id = clients.id
where
    rental.start_date = '2022-07-18';
    
-- Выбирает из таблицы АВТОМОБИЛИ информацию обо всех автомобилях,
-- для которых значение в поле Страховая стоимость автомобиля попадает
-- в некоторый заданный интервал. 
select
    *
from
    cars
where
    insurance between 1500000 and 2500000;
    
-- Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса.
-- Включает поля Госномер автомобиля, Модель автомобиля, Год выпуска автомобиля,
-- Страховая стоимость автомобиля, Страховой взнос. Сортировка по полю Год выпуска
-- автомобиля
select 
    number as номер,
    brend as модель,
    insurance,
    insurance / 10 as vznos
from
    cars;