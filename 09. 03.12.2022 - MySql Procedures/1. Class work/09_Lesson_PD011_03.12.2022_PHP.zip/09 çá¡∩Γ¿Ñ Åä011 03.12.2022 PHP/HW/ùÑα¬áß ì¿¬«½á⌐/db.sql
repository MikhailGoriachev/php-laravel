CREATE DATABASE  IF NOT EXISTS `car_rental` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `car_rental`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: car_rental
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cars` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `brend` varchar(30) NOT NULL,
  `color` varchar(30) NOT NULL,
  `year` int NOT NULL,
  `number` varchar(30) NOT NULL,
  `insurance` int NOT NULL,
  `price` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `number` (`number`),
  CONSTRAINT `cars_chk_1` CHECK ((`number` <> _utf8mb4''))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES (1,'Audi','красный',2000,'м976мм',1500000,1900),(2,'Cadillac','белый',2010,'в555рх',1000000,1500),(3,'Dacia','зеленый',2005,'е231ту',3000000,2000),(4,'Honda','белый',1999,'а565аа',4500000,2000),(5,'Daewoo','белый',2020,'к998ак',1500000,1300),(6,'Honda','синий',2021,'е988оо',1000000,1990),(7,'Genesis','зеленый',2012,'о767ее',2500000,2300),(8,'Fiat','красный',1990,'в788ек',1400000,1500),(9,'Jeep','красный',2003,'н777ор',4000000,2300),(10,'Ferrari','черный',2005,'р909ст',1000000,1300);
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `surname` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `putronymic` varchar(30) NOT NULL,
  `passport` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `passport` (`passport`),
  CONSTRAINT `clients_chk_1` CHECK (((`surname` <> _utf8mb4'') and (`first_name` <> _utf8mb4'') and (`putronymic` <> _utf8mb4'')))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'Ефремов','Сергей','Иванович','4095 233675'),(2,'Деревянко','Валерий','Сергеевич','5088 323249'),(3,'Метунова','Наталья','Владимировна','2280 454545'),(4,'Захарова','Валентина','Пертровна','5170 123454'),(5,'Михалюк','Александр','Валерьевич','4545 987655'),(6,'Лабузов','Алексей','Егорович','4899 542323'),(7,'Кротов','Дмитрий','Васильевич','3990 784321'),(8,'Мазурчак','Александп','Ефимович','3535 999899'),(9,'Проценко','Наталья','Егоровна','2353 768452'),(10,'Козаченко','Татьяна','Сергевна','4949 550090');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rental`
--

DROP TABLE IF EXISTS `rental`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rental` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `start_date` date NOT NULL,
  `count` int NOT NULL,
  `car_id` int unsigned DEFAULT NULL,
  `client_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `car_id` (`car_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `rental_ibfk_1` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rental_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rental`
--

LOCK TABLES `rental` WRITE;
/*!40000 ALTER TABLE `rental` DISABLE KEYS */;
INSERT INTO `rental` VALUES (1,'2022-05-12',5,7,5),(2,'2022-05-18',10,9,1),(3,'2022-06-01',3,5,2),(4,'2022-06-03',8,7,7),(5,'2022-07-15',1,3,8),(6,'2022-07-18',15,9,7),(7,'2022-07-18',5,6,3),(8,'2022-07-19',4,2,4),(9,'2022-08-01',8,8,8),(10,'2022-09-03',1,5,4);
/*!40000 ALTER TABLE `rental` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-02 22:48:26
