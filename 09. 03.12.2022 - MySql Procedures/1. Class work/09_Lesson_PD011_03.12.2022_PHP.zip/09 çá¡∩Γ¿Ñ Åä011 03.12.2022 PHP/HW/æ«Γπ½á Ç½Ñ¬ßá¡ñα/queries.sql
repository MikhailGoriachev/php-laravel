use cars_rentals;

-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях,
-- стоимость одного дня проката которых меньше 1900
select
	cars_view.brand
    , cars_view.model
    , cars_view.plate
    , cars_view.year_manufacture
    , cars_view.insurance_cost
    , cars_view.cost_one_day
from
	cars_view
where
	cars_view.cost_one_day < 1900;
    
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях,
-- страховая стоимость которых находится в диапазоне от 2 000 000 до 3 000 000

select
	cars_view.brand
    , cars_view.model
    , cars_view.plate
    , cars_view.year_manufacture
    , cars_view.insurance_cost
    , cars_view.cost_one_day
from
	cars_view
where
	cars_view.insurance_cost between 2000000 and 3000000;
    
-- Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ПРОКАТ информацию о клиентах,
-- серия-номер паспорта которых начинается с цифры «2».
-- Включает поля Код клиента, Паспорт, Дата начала проката, Количество дней проката, Модель автомобиля

select
	rentals_view.id_client
    , rentals_view.full_name_client -- нет по заданию
    , rentals_view.passport
    , rentals_view.date_start
    , rentals_view.duration
    , CONCAT(rentals_view.brand, " ", rentals_view.model) as model
from
	rentals_view
where
	rentals_view.passport regexp "^2";

-- Выбирает из таблицы КЛИЕНТЫ и ПРОКАТ информацию о клиентах,
-- бравших автомобиль напрокат в некоторый определенный день. 

select
	rentals_view.full_name_client
    , rentals_view.passport
    , rentals_view.date_start
from
	rentals_view
where
	rentals_view.date_start like "2022-11-30";

-- Выбирает из таблицы АВТОМОБИЛИ информацию обо всех автомобилях,
-- для которых значение в поле Страховая стоимость автомобиля попадает в некоторый заданный интервал. 

select
	cars_view.brand
    , cars_view.model
    , cars_view.plate
    , cars_view.year_manufacture
    , cars_view.insurance_cost
    , cars_view.cost_one_day
from
	cars_view
where
	cars_view.insurance_cost between 3000000 and 3500000;

-- Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса.
-- Включает поля Госномер автомобиля, Модель автомобиля, Год выпуска автомобиля,
-- Страховая стоимость автомобиля, Страховой взнос. Сортировка по полю Год выпуска автомобиля
-- Страховой взнос, выплачиваемый фирмой, равен 10 процентам от страховой стоимости автомобиля
select
	cars_view.plate
    , CONCAT(cars_view.brand, " ", cars_view.model) as model
    , cars_view.year_manufacture
    , cars_view.insurance_cost
    , (cars_view.insurance_cost) * 0.1 as insurance_fee
from
	cars_view
order by
	cars_view.year_manufacture;

-- Выполняет группировку по полю Модель автомобиля.
-- Для каждой модели вычисляет минимальную страховую стоимость автомобиля.
select
	cars_view.brand
    , cars_view.model
    , MIN(cars_view.insurance_cost) as minimal_insurance_cost
from
	cars_view
group by
	cars_view.brand
    , cars_view.model;
    
-- Выполняет группировку по полю Код клиента. Для каждого клиента вычисляет
-- минимальное и максимальное значения по полю Количество дней проката

-- Шапиро Ф.Ф. 3 10
select
	rentals_view.full_name_client
    , MIN(rentals_view.duration) as minimal_duration
    , MAX(rentals_view.duration) as maximal_duration
from
	rentals_view
group by
	rentals_view.id_client
order by
	rentals_view.full_name_client;