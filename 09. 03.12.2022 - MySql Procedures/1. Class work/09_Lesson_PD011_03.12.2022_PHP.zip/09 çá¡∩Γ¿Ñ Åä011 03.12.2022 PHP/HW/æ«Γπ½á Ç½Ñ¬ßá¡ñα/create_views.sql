-- представление моделей автомобилей
create or replace view models_view as
select
	models.id
    , brands.`name` as brand
    , models.`name` as model
from
	models join brands on models.id_brand = brands.id
order by
	brand, model;
    
-- представление автомобилей
create or replace view cars_view as
select
	cars.id
	, brands.`name` as brand
    , models.`name` as model
    , cars.plate
    , cars.year_manufacture
    , cars.insurance_cost
    , cars.cost_one_day
from
	cars join models on cars.id_model = models.id
		 join brands on models.id_brand = brands.id
order by
	brand
    , model
    , cars.plate
    , cars.year_manufacture
    , cars.insurance_cost
    , cars.cost_one_day;
         
-- представление фактов проката
create or replace view rentals_view as
select
	rentals.id as id_rental
    , clients.id as id_client
    , rentals.date_start
    , CONCAT(clients.surname, " "
		, SUBSTRING(clients.`name`, 1, 1),"."
		, SUBSTRING(clients.`name`, 1, 1),".") as full_name_client
	, clients.passport
    , brands.`name` as brand
    , models.`name` as model
    , cars.plate
    , cars.year_manufacture
    , cars.insurance_cost
    , cars.cost_one_day
    , rentals.duration
    , rentals.duration * cars.cost_one_day as price
from
	rentals join clients on rentals.id_client = clients.id
			join cars on rentals.id_car = cars.id
            join models on cars.id_model = models.id
			join brands on models.id_brand = brands.id
order by
	rentals.date_start
    , full_name_client
    , clients.passport
    , brand
    , model
    , cars.plate
    , cars.year_manufacture
    , cars.insurance_cost
    , cars.cost_one_day
    , rentals.duration
    , price;
