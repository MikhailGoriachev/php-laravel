-- База данных «Прокат автомобилей»


-- Запрос 1.
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях,
-- стоимость одного дня проката которых меньше 1900
select * from view_cars where pay_rental_day < 1900;


-- Запрос 2.
-- Выбирает из таблицы АВТОМОБИЛИ информацию об автомобилях, 
-- страховая стоимость которых находится в диапазоне от 2000 000 до 3000 000
select * from view_cars where insurance_pay between 2000000 and 3000000;


-- Запрос 3.
-- Выбирает из таблиц КЛИЕНТЫ, АВТОМОБИЛИ и ПРОКАТ информацию о клиентах,
-- серия-номер паспорта которых начинается с цифры «2».
-- Включает поля Код клиента, Паспорт, Дата начала проката,
-- Количество дней проката, Модель автомобиля
select 
	clients.surname
	, clients.`name`
	, clients.patronymic
	, clients.passport
	, models.model
	, rentals.duration
	, rentals.rental_start_date
from 
	rentals join(cars join models on cars.id_model = models.id)
			on rentals.id_car = cars.id
			join clients on rentals.id_client = clients.id
where 
    clients.passport regexp '^2'
order by
    rentals.rental_start_date;
    
    
 -- Запрос 4.  
 -- Выбирает из таблицы КЛИЕНТЫ и ПРОКАТ информацию о клиентах,
 -- бравших автомобиль напрокат в некоторый определенный день. 
 select
	clients.surname
	, clients.`name`
	, clients.patronymic
	, clients.passport
	, rentals.duration
	, rentals.rental_start_date
from 
	rentals join clients on rentals.id_client = clients.id
where
   rentals.rental_start_date = '2022-11-11';
   
   
-- Запрос 5.
-- Выбирает из таблицы АВТОМОБИЛИ информацию обо всех автомобилях,
-- для которых значение в поле Страховая стоимость автомобиля
-- попадает в некоторый заданный интервал.
  select * from view_cars where insurance_pay between 5000000 and 10000000;
  
  
-- Запрос 6. 
-- Вычисляет для каждого автомобиля величину выплачиваемого страхового взноса.
-- Включает поля Госномер автомобиля, Модель автомобиля,
-- Год выпуска автомобиля, Страховая стоимость автомобиля,
-- Страховой взнос. Сортировка по полю Год выпуска автомобиля
select 
	 cars.car_number
	 , models.model
	 , cars.`year`
	 , cars.insurance_pay
	 , (cars.pay_rental_day*rentals.duration)/1.1 as cost_rental
from 
    rentals join(cars join models on cars.id_model = models.id)
			on rentals.id_car = cars.id
order by
    `year`;
    
 -- Итоговый запрос 7.
 -- Выполняет группировку по полю Модель автомобиля.
 -- Для каждой модели вычисляет минимальную страховую стоимость автомобиля.
 select
	 models.model
     , COUNT(*) as `number`
	 , MIN(cars.insurance_pay) as min_insurance_pay
	 , MAX(cars.insurance_pay) as max_insurance_pay
 from
    models join cars on models.id = cars.id_model
 group by
	models.model;
    

-- Итоговый запрос 8.   
-- Выполняет группировку по полю Код клиента.
-- Для каждого клиента вычисляет минимальное и максимальное значения по полю
-- Количество дней проката
select
	concat(clients.surname, ' ', substr(clients.`name`, 1, 1), '.', substr(clients.patronymic, 1, 1), '.') as fullname
	, clients.passport
    , COUNT(rentals.id_client) as rental_facts
	, MIN(rentals.duration) as min_duration
	, MAX(rentals.duration) as max_duration
from
   rentals join clients on rentals.id_client = clients.id
group by
   clients.surname, clients.`name`, clients.patronymic, clients.passport ;
 