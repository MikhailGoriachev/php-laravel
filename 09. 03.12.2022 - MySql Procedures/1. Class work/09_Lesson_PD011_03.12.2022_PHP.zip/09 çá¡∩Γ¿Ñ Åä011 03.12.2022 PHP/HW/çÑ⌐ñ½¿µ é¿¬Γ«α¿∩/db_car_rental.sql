CREATE DATABASE  IF NOT EXISTS `car_rental` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `car_rental`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: car_rental
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cars` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_model` int NOT NULL,
  `id_color` int NOT NULL,
  `car_number` varchar(8) NOT NULL,
  `year` int NOT NULL,
  `insurance_pay` int(10) unsigned zerofill NOT NULL,
  `pay_rental_day` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cars_models_idx` (`id_model`),
  KEY `fk_cars_colors_idx` (`id_color`),
  CONSTRAINT `fk_cars_colors` FOREIGN KEY (`id_color`) REFERENCES `colors` (`id`),
  CONSTRAINT `fk_cars_models` FOREIGN KEY (`id_model`) REFERENCES `models` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES (1,2,2,'C850PK',2012,0005000000,800),(2,3,1,'K801HT',2018,0003000000,500),(3,4,2,'C948IX',2019,0008000000,1450),(4,4,7,'A942KC',2020,0010000000,1800),(5,2,7,'H924XI',2019,0005000000,800),(6,3,4,'A043KC',2017,0002000000,500),(7,3,2,'K841BC',2015,0004000000,550),(8,2,3,'I964HA',2018,0004000000,770),(9,3,6,'O842HX',2019,0002500000,800),(10,1,1,'C843KI',2015,0000270000,800),(11,6,5,'H952OA',2018,0010000000,2000),(12,4,2,'I916AO',2019,0015000000,2000),(13,1,3,'K824IA',2015,0002800000,1000),(14,6,2,'H947CK',2021,0012000000,1500),(15,5,2,'O716HI',2020,0007000000,1000);
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `surname` varchar(50) NOT NULL,
  `name` varchar(40) NOT NULL,
  `patronymic` varchar(60) NOT NULL,
  `passport` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'Гончарова','Арина','Алексеевна','60 21 496730'),(2,'Серов','Платон','Львович','25 12 497528'),(3,'Котов','Михаил','Павлович','26 68 486782'),(4,'Грачёва ','Василиса','Алексеевна','60 21 865832'),(5,'Морозова','Таисия','Платоновна','36 68 899204'),(6,'Семенова','Дарина','Марковна','25 12 863945'),(7,'Лавров','Роман','Иванович','25 12 582419'),(8,'Смирнов','Константин','Артёмович','36 68 793160'),(9,'Грибова','Софья','Никитична','60 21 782041'),(10,'Николаева','Валерия','Максимовна','60 21 921574'),(11,'Рыбаков','Даниил','Георгиевич','25 12 943640'),(12,'Островский','Александр','Михайлович','36 68 781539'),(13,'Воронина','Василиса','Кирилловна','25 12 578126'),(14,'Григорьев','Тихон','Антонович','60 21 839127'),(15,'Денисова','Александра','Ивановна','36 68 936125');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colors`
--

DROP TABLE IF EXISTS `colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `color` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colors`
--

LOCK TABLES `colors` WRITE;
/*!40000 ALTER TABLE `colors` DISABLE KEYS */;
INSERT INTO `colors` VALUES (1,'красный'),(2,'белый'),(3,'чёрный'),(4,'серый'),(5,'жёлтый'),(6,'синий'),(7,'бордовый'),(8,'зелёный');
/*!40000 ALTER TABLE `colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `models` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `models`
--

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
INSERT INTO `models` VALUES (1,'Audi'),(2,'BMW'),(3,'Kia'),(4,'Lexus'),(5,'Infiniti'),(6,'Porsche');
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rentals`
--

DROP TABLE IF EXISTS `rentals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rentals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_client` int NOT NULL,
  `id_car` int NOT NULL,
  `rental_start_date` date NOT NULL,
  `duration` int(10) unsigned zerofill NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rentals_clients_idx` (`id_client`),
  KEY `fk_rentals_cars_idx` (`id_car`),
  CONSTRAINT `fk_rentals_cars` FOREIGN KEY (`id_car`) REFERENCES `cars` (`id`),
  CONSTRAINT `fk_rentals_clients` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rentals`
--

LOCK TABLES `rentals` WRITE;
/*!40000 ALTER TABLE `rentals` DISABLE KEYS */;
INSERT INTO `rentals` VALUES (1,3,1,'2022-11-07',0000000005),(2,9,2,'2022-10-12',0000000012),(3,5,2,'2022-11-15',0000000004),(4,2,4,'2022-10-08',0000000001),(5,5,3,'2022-10-27',0000000008),(6,6,6,'2022-11-11',0000000014),(7,7,9,'2022-11-25',0000000001),(8,8,8,'2022-11-18',0000000005),(9,1,9,'2022-10-14',0000000008),(10,10,14,'2022-10-09',0000000003),(11,11,12,'2022-10-24',0000000012),(12,12,11,'2022-11-10',0000000021),(13,10,10,'2022-11-23',0000000004);
/*!40000 ALTER TABLE `rentals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_cars`
--

DROP TABLE IF EXISTS `view_cars`;
/*!50001 DROP VIEW IF EXISTS `view_cars`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_cars` AS SELECT 
 1 AS `id`,
 1 AS `model`,
 1 AS `color`,
 1 AS `car_number`,
 1 AS `year`,
 1 AS `insurance_pay`,
 1 AS `pay_rental_day`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `view_cars`
--

/*!50001 DROP VIEW IF EXISTS `view_cars`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_cars` AS select `cars`.`id` AS `id`,`models`.`model` AS `model`,`colors`.`color` AS `color`,`cars`.`car_number` AS `car_number`,`cars`.`year` AS `year`,`cars`.`insurance_pay` AS `insurance_pay`,`cars`.`pay_rental_day` AS `pay_rental_day` from ((`cars` join `models` on((`cars`.`id_model` = `models`.`id`))) join `colors` on((`cars`.`id_color` = `colors`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-02 17:06:15
