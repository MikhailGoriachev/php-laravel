<!DOCTYPE html>

<html lang="ru" class="h-100" xmlns:style="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Главная страница</title>

    <link rel="icon" href="img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css"/>
    <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Главная страница</h1>
</header>


<!--панель навигации-->
<nav class="navbar navbar-expand-sm bg-black navbar-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="img/php.png" alt="logo">
        </a>
        <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbar-hide">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar-hide">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="#">Главная страница</a>
                </li>

                <?php
                require_once 'src/utils.php';

                if (isset($_POST['login']) && $_POST['login'] === 'true' || isset($_COOKIE[SESSION_NAME])) {
                    // создание сессии
                    session_name(SESSION_NAME);
                    session_start();

                    // данные от формы входа
                    if (isset($_POST['login']) && $_POST['login'] === 'true') {

                        // запись в журнал
                        sessionWriteLog(FOLDER_NAME_APP_DATA . '/' . FILE_NAME_SESSION_LOG, true);

                        // установка признака доступа к функционалу
                        $_SESSION['access'] = true;
                    } elseif (isset($_POST['login']) && $_POST['login'] === 'false'){ // были получены данные от формы выхода

                        deleteSession();
                    }
                } // if

                // установлен доступ к функционалу
                if (isset($_SESSION['access'])) {
                    // есть доступ
                    // вывод разметки перехода на страницы выполнения задач
                    // и формы с кнопкой завер
                    if ($_SESSION['access']) {
                        echo "
                        <li class='nav-item'>
                            <a class='nav-link' href='pages/page01.php'>Задача 1</a>
                        </li>
                        <li class='nav-item'>
                            <a class='nav-link' href='pages/page02.php'>Задача 2</a>
                        </li>
                        <li class='nav-item'>
                            <a class='nav-link' href='pages/page03.php'>Задача 3</a>
                        </li>
                        </ul>
                        <div class='text-end'>
                            <form method='post'>
                              <input type='hidden' name='login' value=false>
                              <input type='submit' class='btn btn-danger' value='Выход'/>
                            </form>
                        </div>
                    ";
                    }
                } else {
                    echo "
                          </ul>
                          <div class='text-end'>
                            <form method='post'>
                              <input type='hidden' name='login' value=true>
                              <input type='submit' class='btn btn-success' value='Вход'/>
                            </form>
                          </div>
                         ";
                } ?>
            </ul>
        </div>
    </div>
</nav>


<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1"></div>

    <!--    основной блок контента-->
    <div class="col-sm-10">
        <h3 class="text-info h3 mt-3">Теоретическая часть</h3>

        <ul>
            <li>Основы работы со строками в PHP. Работа с многобайтными кодировками строк</li>
            <li>Понятие о регулярных выражениях в PHP</li>
            <li>Работа с куки в PHP, массив $_COOKIE, чтение и запись куки, удаление куки</li>
            <li>Работа с сессиями в PHP, массив $_SESSION</li>
            <li>Создание и удаление сессий, чтение и запись переменных в сессии</li>
            <li>Введение в объектно-ориентированное программирование в PHP</li>
            <li>Конструктор и деструктор класса</li>
            <li>Свойства класса</li>
            <li>Методы класса</li>
            <li>Статические свойства и константы</li>
            <li>Статические методы класса</li>
            <li>Создание объектов классов, оператор <b>new</b></li>
            <li>Работа с массивами объектов</li>
            <li>Magic-методы классов – перегруженные геттер и сеттер __get(), __set(), перегруженный вызов метода
                __call(), формирование строкового представления объекта класса __toString()
            </li>
            <li>Клонирование объектов в PHP, ключевое слово clone, magic-метод __clone()</li>
            <li>Исключения в PHP, ключевые слова try, catch, finally</li>
            <li>Классы исключений, иерархия исключений</li>
            <li>Собственные классы исключений</li>
        </ul>

        <h3 class="text-info h3">Практическая часть</h3>

        <p>Разработайте приложение с обработкой данных на PHP. На главной странице разместите это задание, на других
            страницах – решение задачи.</p>

        <p>Работа с приложением должна быть организована в виде сессии. В файле формата CSV хранить данные о моменте
            начала и завершения сессии. Начало сессии – момент нажатия кнопки «Вход», окончание сессии – момент нажатия
            кнопки «Выход». Логин и пароль не использовать. Переходы на решения задач – только после начала сессии.</p>

        <p>Доступ к функционалу приложения открывается только после создания сессии (клик по кнопке «Вход»). По клику на
            кнопку «Выход» удаляется сессия, запрещается доступ к функционалу.</p>

        <p><b>Задача 1.</b> Требуется вычислять параметры плоских геометрических фигур. Параметры фигур вводить в форме.
            Тип фигуры выбирается пользователем, при помощи радиокнопок:</p>

        <ul>
            <li>Прямоугольник</li>
            <li>Квадрат</li>
            <li>Треугольник</li>
        </ul>

        <p>Параметры фигуры для вычисления задаются чек-боксами:</p>

        <ul>
            <li>площадь</li>
            <li>периметр</li>
        </ul>

        <p>Собственно вычисление выполнять при клике на кнопку "Вычислить" типа submit. Необходимые числовые параметры
            вводить при помощи строки ввода с типом number. Сохранять исходные данные в куки, если куки определены,
            выводить данные в поля формы из куки.</p>

        <p>Требуется также вести журнал операций – текстовый файл, в котором записывать дату и время выполнения расчета,
            исходные данные расчета, результаты расчета.</p>

        <p>Предусмотрите страницу для просмотра журнала, очистки журнала.</p>

        <p><b>Задача 2.</b> Загружать текстовый файл в кодировке UTF-8 на сервер, папка uploaded в приложении. Выводить
            на
            страницу текст из файла, а также:</p>

        <ul>
            <li>только строки, содержащие двузначные числа.</li>
            <li>только строки, не содержащие символов ".,!?:"</li>
        </ul>

        <p>Выполните стилизацию приложения при помощи Bootstrap или другими наборами стилей.</p>

        <p><b>Задача 3.</b> Обработка файла объектов в формате <b>CSV</b>. Объект – класс Планета (Солнечной системы) с
            закрытыми
            свойствами название, радиус, масса, количество спутников, расстояние до Солнца в а.е., фотография.
            Разработайте геттеры и сеттеры с выбросом исключений при не валидных данных. По кликам на кнопки типа
            «submit» реализуйте обработки:</p>

        <ul>
            <li>Демонстрация работы сеттеров (в том числе с не валидными данными) и геттеров – используйте генерацию
                данных, формы не нужны
            </li>
            <li>Вывод данных из файла на страницу с упорядочиванием по расстоянию</li>
            <li>Вывод данных из файла на страницу с упорядочиванием по алфавиту</li>
            <li>Вывод данных из файла на страницу с упорядочиванием по массе</li>
        </ul>

        <h3 class="text-info h3">Дополнительно</h3>

        <p>Материалы занятия – в этом же архиве. Запись занятия можно скачать <a
                    href="https://cloud.mail.ru/public/M7gR/iiSebrosv"><b>по этой
                    ссылке</b></a></p>
    </div>


    <!--    правый сайд бар-->
    <div class="col-sm-1"></div>

</div>

<!--футер-->
<?php
require_once 'src/shared/footer.php' ?>

</body>
</html>