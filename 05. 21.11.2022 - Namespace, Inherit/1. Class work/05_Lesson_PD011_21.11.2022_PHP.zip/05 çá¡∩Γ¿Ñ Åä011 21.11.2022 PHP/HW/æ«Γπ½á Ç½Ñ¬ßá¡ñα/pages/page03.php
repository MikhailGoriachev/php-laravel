<!DOCTYPE html>

<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Задача 3</title>

    <link rel="icon" href="../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>

    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Задача 3</h1>
</header>

<?php
// активность страниц
$activeTask03 = "active";
$activeTask01 = $activeTask02 = "";

require_once '../src/utils.php';
require_once '../src/shared/header.php';
require_once '../src/task03/task03.php';
session_name(SESSION_NAME);
session_start();
?>

<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1"></div>

    <!--    основной блок контента-->
    <div class="col-sm-10">
        <?php
        if (isset($_POST['login']) && $_POST['login'] === 'false') {
            sessionWriteLog('../' . FOLDER_NAME_APP_DATA . '/' . FILE_NAME_SESSION_LOG, false);
            deleteSession();
            echo errorAccessTask();
        } else {
            echo "
        <div class='w-100 mt-4'>
            <a href='#task3' class='btn btn-outline-dark w-100 mb-4' data-bs-toggle='collapse'>
                <strong>Задание</strong>
            </a>
            <div id='task3' class='collapse'>
                <p class='mt-3'><b>Задача 3.</b> Обработка файла объектов в формате CSV.
                    Объект – класс Планета (Солнечной системы) с закрытыми свойствами название,
                    радиус, масса, количество спутников, расстояние до Солнца в а.е., фотография.
                    Разработайте геттеры и сеттеры с выбросом исключений при не валидных данных.
                    По кликам на кнопки типа «submit» реализуйте обработки:</p>

                <ul>
                    <li>Демонстрация работы сеттеров (в том числе с не валидными данными) и геттеров – используйте
                        генерацию данных, формы не нужны
                    </li>
                    <li>Вывод данных из файла на страницу с упорядочиванием по расстоянию</li>
                    <li>Вывод данных из файла на страницу с упорядочиванием по алфавиту</li>
                    <li>Вывод данных из файла на страницу с упорядочиванием по массе</li>
                </ul>
            </div>
        </div>

        <div class='row'>
            <form class='mx-auto col-sm-4' method='post'>
                <input type='hidden' name='demo'>
                <div class='row'>
                    <button type='submit' class='btn btn-outline-dark col-sm-10 mx-auto'>GET/SET
                    </button>
                </div>
            </form>
        </div>

        <div class='row mt-3'>

            <!--            Упорядочить по расстоянию-->
            <form class='mx-auto col-sm-4' method='post'>
                <input type='hidden' name='sort' value='byDistance'>
                <div class='row'>
                    <button type='submit' class='btn btn-outline-dark col-sm-10 mx-auto'>Упорядочить по расстоянию
                    </button>
                </div>
            </form>

            <!--            Упорядочить по расстоянию-->
            <form class='mx-auto col-sm-4' method='post'>
                <input type='hidden' name='sort' value='byName'>
                <div class='row'>
                    <button type='submit' class='btn btn-outline-dark col-sm-10 mx-auto'>Упорядочить по алфавиту
                    </button>
                </div>
            </form>

            <!--            Упорядочить по массе-->
            <form class='mx-auto col-sm-4' method='post'>
                <input type='hidden' name='sort' value='byMass'>
                <div class='row'>
                    <button type='submit' class='btn btn-outline-dark col-sm-10 mx-auto'>Упорядочить по массе</button>
                </div>
            </form>


        </div>";
        }
        try {
            // файла нет - создание и запись
            if (!file_exists(FULL_PATH))
                writePlanetsToFile();

            // был получен признак сортировки
            if (isset($_POST['sort'])) {

                switch ($_POST['sort']) {

                    // сортировка по расстоянию
                    case 'byDistance':
                        echo "<h5 class='h5 text-center mt-5'>Вывод данных из файла на страницу с упорядочиванием по расстоянию</h5>";
                        showTable(sortPlanetFromFileByCompare('compareByDistance'));
                        break;

                    // сортировка по алфавиту
                    case 'byName':
                        echo "<h5 class='h5 text-center mt-5'>Вывод данных из файла на страницу с упорядочиванием по алфавиту</h5>";
                        showTable(sortPlanetFromFileByCompare('compareByName'));
                        break;

                    // сортировка по массе
                    case 'byMass':
                        echo "<h5 class='h5 text-center mt-5'>Вывод данных из файла на страницу с упорядочиванием по массе</h5>";
                        showTable(sortPlanetFromFileByCompare('compareByMass'));
                        break;
                }
                // демо геттеров и сеттеров + исключения
            } elseif (isset($_POST['demo'])) {

                // объект
                $planet = new Planet();

                // сеттеры
                $planet->setName("Земля-616");
                $planet->setRadius(6378.14);
                $planet->setMass(5.9742);
                $planet->setCountSatellites(1);
                $planet->setDistanceToSun(1.000);
                $planet->setImg("earth-616.jpg");

                // геттеры
                echo "<p class='text-center mt-5'><b><i>Название:</i></b> {$planet->getName()}</p>";
                echo "<p class='text-center'><b><i>Радиус:</i></b> {$planet->getRadius()}</p>";
                echo "<p class='text-center'><b><i>Масса:</i></b> {$planet->getMass()}</p>";
                echo "<p class='text-center'><b><i>Количество спутников:</i></b> {$planet->getCountSatellites()}</p>";
                echo "<p class='text-center'><b><i>Расстояние до солнца:</i></b> {$planet->getDistanceToSun()}</p>";
                echo "<img class='rounded mx-auto d-block' src='../img/task3/{$planet->getImg()}' alt='{$planet->getImg()}'/>";

                // выброс исключения
                $planet->setRadius(-100);
            }
            // обработка исключения
        } catch (Exception $ex) {
            echo "<p class='text-danger text-center mt-5'><b><i>Exception:</i></b> {$ex->getMessage()}</p>";
        }
        ?>
    </div>

    <!--    правый сайд бар-->
    <div class="col-sm-1"></div>

</div>

<!--футер-->
<?php
require_once '../src/shared/footer.php' ?>

</body>
</html>