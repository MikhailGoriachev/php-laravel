<!DOCTYPE html>

<html lang="ru" class="h-100">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Задача 1</title>

    <link rel="icon" href="../img/php.png" type="image/x-icon">

    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css"/>

    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="d-flex flex-column h-100">

<!--Заголовок страницы-->
<header class="container-fluid bg-black text-white text-center p-3 mt-5">
    <h1 class="h1">Задача 1</h1>
</header>

<?php
// активность страниц
$activeTask01 = "active";
$activeTask02 = $activeTask03 = "";

require_once '../src/utils.php';
require_once '../src/task01/task01.php';
require_once '../src/shared/header.php';
session_name(SESSION_NAME);
session_start();

// переменные
$sideA = null;
$sideB = null;
$sideC = null;
$area = false;
$perimeter = false;

// если данные пришли из формы
// устанавливаем пришедшие значения,
// а пустые - чистим
if ($_POST) {
    isset($_POST['type']) ? setcookie('type', $_POST['type']) : setcookie('type', 0, time() - 10);
    isset($_POST['area']) ? setcookie('area', true) : setcookie('area', 0, time() - 10);
    isset($_POST['perimeter']) ? setcookie('perimeter', true) : setcookie('perimeter', 0, time() - 10);
    isset($_POST['sideA']) ? setcookie('sideA', $_POST['sideA']) : setcookie('sideA', 0, time() - 10);
    isset($_POST['sideB']) ? setcookie('sideB', $_POST['sideB']) : setcookie('sideB', 0, time() - 10);
    isset($_POST['sideC']) ? setcookie('sideC', $_POST['sideC']) : setcookie('sideC', 0, time() - 10);
}

// при переходе на страницу и при наличии куки
// читаем в переменные
if (isset($_COOKIE['type']) && empty($_POST)) {

    $type = $_COOKIE['type'];
    $area = isset($_COOKIE['area']);
    $perimeter = isset($_COOKIE['perimeter']);

    $sideA = $_COOKIE['sideA'] ?? null;
    $sideB = $_COOKIE['sideB'] ?? null;
    $sideC = $_COOKIE['sideC'] ?? null;
}

?>

<div class="row container-fluid bg-body">

    <!--    левый сайд бар-->
    <div class="col-sm-1">

    </div>

    <!--    основной блок контента-->
    <div class="col-sm-10">
        <?php
        if (isset($_POST['login']) && $_POST['login'] === 'false') {

            sessionWriteLog('../' . FOLDER_NAME_APP_DATA . '/' . FILE_NAME_SESSION_LOG, false);
            deleteSession();
            echo errorAccessTask();
        } else {
            echo "
        <div class='w-100 mt-4'>
            <a href='#task1' class='btn btn-outline-dark w-100 mb-4' data-bs-toggle='collapse'>
                <strong>Задание</strong>
            </a>
            <div id='task1' class='collapse'>
                <p class='mt-3'><b>Задача 1.</b> Требуется вычислять параметры плоских геометрических фигур. Параметры фигур вводить в форме. Тип фигуры выбирается пользователем, при помощи радиокнопок:</p>

                <ul>
                    <li>Прямоугольник</li>
                    <li>Квадрат</li>
                    <li>Треугольник</li>
                </ul>

                <p>Параметры фигуры для вычисления задаются чек-боксами:</p>

                <ul>
                    <li>площадь</li>
                    <li>периметр</li>
                </ul>

                <p>Собственно вычисление выполнять при клике на кнопку \"Вычислить\" типа submit.
                 Необходимые числовые параметры вводить при помощи строки ввода с типом number.
                  Сохранять исходные данные в куки, если куки определены, выводить данные в поля формы из куки.</p>
                
                <p>Требуется также вести журнал операций – текстовый файл, в котором записывать
                 дату и время выполнения расчета, исходные данные расчета, результаты расчета.</p>

                <p>Предусмотрите страницу для просмотра журнала, очистки журнала.</p>
            </div>
        </div>
        
        <div class='row mt-3 d-flex justify-content-end'>
            <a class='btn btn-outline-dark col-sm-3' href='pageLog.php'>Открыть журнал</a>
        </div>
        
        <form method='post'>
        
        <div class='row'>
            <div class='col-sm-2 mx-auto'>
                <label class='form-label me-3'>Выберите тип фигуры:</label>
                <div class='form-check'>
                  <input class='form-check-input' type='radio' name='type' id='rectangle' value='rectangle' " . (isset($type) && $type === 'rectangle' ? 'checked' : '') . ">
                    <label class='form-check-label' for='rectangle'>
                        Прямоугольник
                    </label>
                </div>
                
                <div class='form-check'>
                    <input class='form-check-input' type='radio' name='type' id='square' value='square' "
            . (isset($type) && $type === 'square' ? 'checked' : '') . ">
                    <label class='form-check-label' for='square'>
                        Квадрат
                    </label>
                    </div>
                    
                <div class='form-check'>
                    <input class='form-check-input' type='radio' name='type' id='triangle' value='triangle' "
            . (isset($type) && $type === 'triangle' ? 'checked' : '') . ">
                    <label class='form-check-label' for='triangle'>
                        Треугольник
                    </label>
                    </div>
            </div>
            
           
            <div class='col-sm-2 mx-auto'>
                    <label class='form-label me-3'>Что вычислять:</label>
                    <div class='form-check'>
                        <input class='form-check-input' type='checkbox' name='perimeter' id='perimeter' value='perimeter' "
            . ($perimeter ? 'checked' : '') . ">
                        <label class='form-check-label' for='perimeter'>Периметр</label>
                    </div>
                    <div class='form-check'>
                        <input class='form-check-input' type='checkbox' name='area' id='area' value='area' "
            . ($area ? 'checked' : '') . ">
                        <label class='form-check-label' for='area'>Площадь</label>
                    </div>
            </div>
        </div>
       
        
        <div class='form-floating mt-3 col-sm-4 mx-auto' >
            <input class='form-control' id = 'sideA' name = 'sideA' type = 'number'
             placeholder = 'Сторона A (Квадрат, прямоугольник, треугольник)' min='1' value='" . $sideA . "'>
            <label for='sideA' >Сторона A (Квадрат, прямоугольник, треугольник)</label >
        </div >
        
        <div class='form-floating mt-3 col-sm-4 mx-auto' >
            <input class='form-control' id = 'sideB' name = 'sideB' type = 'number'
             placeholder = 'Сторона B (Прямоугольник, треугольник)' min='1' value='" . $sideB . "'>
            <label for='sideB' >Сторона B (Прямоугольник, треугольник)</label >
        </div >
        
        <div class='form-floating mt-3 col-sm-4 mx-auto' >
            <input class='form-control' id = 'sideC' name = 'sideC' type = 'number'
             placeholder = 'Сторона C (Треугольник)' min='1' value='" . $sideC . "'>
            <label for='sideC' >Сторона C (Треугольник)</label >
        </div >
        
        <div class='row mt-3'>
            <button class='btn btn-outline-success col-sm-3 mx-auto' type='submit'>Расчитать</button>
        </div>
        </form>
        ";

            try {
                if (isset($_POST['type']))
                    echo calcData();
            } catch (Exception $ex) {
                echo $ex->getMessage();
            }

        }

        ?>
        <!--    правый сайд бар-->
        <div class="col-sm-1"></div>
    </div>
</div>
<!--футер-->
<?php
require_once '../src/shared/footer.php' ?>

</body>
</html>