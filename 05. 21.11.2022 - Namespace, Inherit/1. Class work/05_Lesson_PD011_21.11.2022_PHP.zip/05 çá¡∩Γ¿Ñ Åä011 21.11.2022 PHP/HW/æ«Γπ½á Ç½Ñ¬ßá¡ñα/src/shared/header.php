<!--панель навигации-->
<nav class="navbar navbar-expand-sm bg-black navbar-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="../index.php">
            <img src="../img/php.png" alt="logo">
        </a>
        <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbar-hide">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar-hide">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">Главная страница</a>
                </li>
                <?php
                if (!isset($_POST['login'])) {

                    echo "
                            <li class='nav-item'>
                                <a class='nav-link <?= $activeTask01 ?>' href='page01.php'>Задача 1</a>
                            </li>
                            <li class='nav-item'>
                                <a class='nav-link <?= $activeTask02 ?>' href='page02.php'>Задача 2</a>
                            </li>
                            <li class='nav-item'>
                                <a class='nav-link <?= $activeTask03 ?>' href='page03.php'>Задача 3</a>
                            </li>
                        </ul>
                        
                        <div class='text-end'>
                            <form method='post'>
                                <input type='hidden' name='login' value=false>
                                <input type='submit' class='btn btn-danger' value='Выход'/>
                            </form>
                        </div>
                ";
                }
                ?>
        </div>
    </div>
</nav>