<?php

const FOLDER_NAME_UPLOAD = "../uploaded";

// загрузить файл
function downloadFile($inputName): string
{
    // создание папки при отсутствии
    if (!file_exists(FOLDER_NAME_UPLOAD))
        mkdir(FOLDER_NAME_UPLOAD);

    // имя загружаемого файла
    $fileName = $_FILES["$inputName"]["name"];

    // путь к файлу
    $filePath = FOLDER_NAME_UPLOAD . "/" . $fileName;

    // перемещение загруженного файла
    move_uploaded_file($_FILES["$inputName"]["tmp_name"], $filePath);

    return $filePath;
}

// вывести файл
function showFile($filePath) {
    $fr = @fopen($filePath, "r");

    echo "<h5 class='h5 text-center mt-3'>Текст из файла</h5>";

    while (!feof($fr)) {
        $str = fgets($fr);
        echo "$str<br>";
    }
    fclose($fr);
}

// вывод строк соответствующим регулярному выражению
function showRowsByRegex(string $filePath, string $pattern, string $header) {
    $fr = @fopen($filePath, "r");

    echo "<h5 class='h5 text-center mt-3'>$header</h5>";

    while (!feof($fr)) {
        $str = fgets($fr);
        if(preg_match($pattern, $str))
            echo "$str<br>";
    }
    fclose($fr);
}