<?php

// папка
const FOLDER_NAME_APP_DATA = 'app_data';

// имя лог файла для сессий
const FILE_NAME_SESSION_LOG = 'session.csv';

// имя сессии
const SESSION_NAME = 'mySession';

// запись в лог журнал для сессий
function sessionWriteLog($fileName, $isStartSession) {
    // открыть файл для добавления записи в конец
    $f = @fopen($fileName, 'a');

    // ошибка доступа к файлу
    if (!$f) {
        echo "
        <div class='alert alert-danger'>
            <strong>Ошибка</strong><br>
            Не могу открыть файл журнала <u>$fileName</u> для записи
        </div>";
        return;
    }

    // установка правильного часового пояса
    date_default_timezone_set('Europe/Moscow');

    // запись в файл журнала
    $csvStr = [ ($isStartSession ? 'Начало': 'Завершение') . ' сессии',
             date("d/m/Y"),
             date("H:i:s")];

    fputcsv($f, $csvStr, eol: "\r\n");

    fclose($f);
}

function errorAccessTask() {
    return "<h4 class='h4 text-center mt-5 text-danger'>Доступ к функционалу ограничен. Войдите в сессию.<h4>
            <img class='img-fluid mx-auto d-block' src='../img/lock.png' alt='lock.png'>
            <div class='row'>
                <a class='btn btn-outline-dark col-sm-5 mx-auto' href='../index.php'>Главная страница</a>
            </div>
            ";
}

function deleteSession() {
    $_SESSION = [];
    if (session_id() != "" || isset($_COOKIE[session_name()]))
        setcookie(session_name(), '', time() - 10, '/');
    session_destroy();
}