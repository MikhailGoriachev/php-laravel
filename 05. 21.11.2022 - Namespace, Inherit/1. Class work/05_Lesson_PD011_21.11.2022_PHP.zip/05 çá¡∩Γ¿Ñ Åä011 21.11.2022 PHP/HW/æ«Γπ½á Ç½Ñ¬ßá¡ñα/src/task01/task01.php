<?php


// имя лог файла для фигур
const FILE_NAME_FIGURE_LOG = 'figures.log';
const FULL_PATH_FIGURE_LOG = '../' . FOLDER_NAME_APP_DATA . '/' . FILE_NAME_FIGURE_LOG;

date_default_timezone_set('Europe/Moscow');

function calcData()
{

    $figure['type'] = $_POST['type'];
    $figure['area'] = isset($_POST['area']);
    $figure['perimeter'] = isset($_POST['perimeter']);

    if (!$figure['area'] && !$figure['perimeter'])
        return "<h5 class='text-center mt-5'>Не выбран параметр для вычисления</h5>";


    switch ($figure['type']) {

        // квадрат
        case 'square':
            if (isset($_POST['sideA']))
                $figure['sideA'] = $_POST['sideA'];
            else
                throw new Exception("<h5 class='text-center mt-5'>Не установлена сторона A для квадрата</h5>");

            $figure['areaValue'] = $figure['area'] ? $figure['sideA'] * $figure['sideA'] : "расчет не требуется";
            $figure['perimeterValue'] = $figure['perimeter'] ? $figure['sideA'] * 4 : "расчет не требуется";

            $result = "<ul class='list-group w-50 mx-auto my-5'>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Тип фигуры:</span> <b>Квадрат</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Сторона A:</span> <b>$figure[sideA]</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Площадь:</span> <b>$figure[areaValue]</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Периметр:</span> <b>$figure[perimeterValue]</b></li>
            </ul>";

            writeFigureLog("<tr><td>" . date("d/m/y") . " " . date("H:i:s") . "</td><td>Квадрат</td><td>$figure[sideA]</td><td></td><td></td><td>$figure[areaValue]</td><td>$figure[perimeterValue]</td></tr>\r\n");

            break;

        // прямоугольник
        case 'rectangle':
            if (isset($_POST['sideA']))
                $figure['sideA'] = $_POST['sideA'];
            else
                throw new Exception("<h5 class='text-center mt-5'>Не установлена сторона A для прямоугольника</h5>");

            if (isset($_POST['sideB']))
                $figure['sideB'] = $_POST['sideB'];
            else
                throw new Exception("<h5 class='text-center mt-5'>Не установлена сторона B для прямоугольника</h5>");

            $figure['areaValue'] = $figure['area'] ? $figure['sideA'] * $figure['sideB'] : "расчет не требуется";
            $figure['perimeterValue'] = $figure['perimeter'] ? ($figure['sideA'] + $figure['sideB']) * 2 : "расчет не требуется";

            $result = "<ul class='list-group w-50 mx-auto my-5'>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Тип фигуры:</span> <b>Прямоугольник</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Сторона A:</span> <b>$figure[sideA]</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Сторона B:</span> <b>$figure[sideB]</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Площадь:</span> <b>$figure[areaValue]</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Периметр:</span> <b>$figure[perimeterValue]</b></li>
            </ul>";

            writeFigureLog("<tr><td>" . date("d/m/y") . " " . date("H:i:s") . "</td><td>Прямоугольник</td><td>$figure[sideA]</td><td>$figure[sideB]</td><td></td><td>$figure[areaValue]</td><td>$figure[perimeterValue]</td></tr>\r\n");

            break;

        // треугольник
        case 'triangle':

            if (isset($_POST['sideA']))
                $figure['sideA'] = $_POST['sideA'];
            else
                throw new Exception("<h5 class='text-center mt-5'>Не установлена сторона A для треугольника</h5>");

            if (isset($_POST['sideB']))
                $figure['sideB'] = $_POST['sideB'];
            else
                throw new Exception("<h5 class='text-center mt-5'>Не установлена сторона B для треугольника</h5>");

            if (isset($_POST['sideC']))
                $figure['sideC'] = $_POST['sideC'];
            else
                throw new Exception("<h5 class='text-center mt-5'>Не установлена сторона C для треугольника</h5>");

            if (!($figure['sideA'] + $figure['sideB'] > $figure['sideC']
                && $figure['sideB'] + $figure['sideC'] > $figure['sideA']
                && $figure['sideA'] + $figure['sideC'] > $figure['sideB']))
                throw new Exception("<h5 class='text-center mt-5'>Не существует треугольника с указанными сторонами</h5>");

            if ($figure['area']) {
                $p = ($figure['sideA'] + $figure['sideB'] + $figure['sideC']) / 2;
                $figure['areaValue'] = sqrt($p * ($p - $figure['sideA']) * ($p - $figure['sideB']) * ($p - $figure['sideC']));
            } else
                $figure['areaValue'] = "расчет не требуется";

            $figure['perimeterValue'] = $figure['perimeter'] ?
                $figure['sideA'] + $figure['sideB'] + $figure['sideC']
                : "расчет не требуется";

            $result = "<ul class='list-group w-50 mx-auto my-5'>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Тип фигуры:</span> <b>Треугольник</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Сторона A:</span> <b>$figure[sideA]</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Сторона B:</span> <b>$figure[sideB]</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Сторона C:</span> <b>$figure[sideC]</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Площадь:</span> <b>$figure[areaValue]</b></li>
                <li class='list-group-item d-flex justify-content-between p-3'><span>Периметр:</span> <b>$figure[perimeterValue]</b></li>
            </ul>";

            writeFigureLog("<tr><td>" . date("d/m/y") . " " . date("H:i:s") . "</td><td>Треугольник</td><td>$figure[sideA]</td><td>$figure[sideB]</td><td>$figure[sideC]</td><td>$figure[areaValue]</td><td>$figure[perimeterValue]</td></tr>\r\n");

            break;
    }

    return $result;
}

function writeFigureLog($str)
{
    $f = @fopen(FULL_PATH_FIGURE_LOG, "a");
    @fputs($f, $str);
    @fclose($f);
}

function readFigureLog()
{
    $f = @fopen(FULL_PATH_FIGURE_LOG, "r");

    while (!feof($f))
        echo @fgets($f);

    @fclose($f);
}

function clearFigureLog()
{
    $f = @fopen(FULL_PATH_FIGURE_LOG, "w");
    fclose($f);
}