<?php
// класс Планета (Солнечной системы) с закрытыми свойствами
// название, радиус, масса,
// количество спутников, расстояние до Солнца в а.е., фотография
class Planet {
    // закрытые свойства класса
    private string $name;         // название
    private float $radius;        // радиус
    private float $mass;          // масса
    private int $countSatellites; // количество спутников
    private float $distanceToSun; // расстояние до Солнца в а.е.
    private string $img;          // фотография

    // конструктор
    public function __construct(string $name = "", float $radius = 0, float $mass = 0,
                                int    $countSatellites = 0, float $distanceToSun = 0, string $img = "") {
        $this->name = $name;
        $this->radius = $radius;
        $this->mass = $mass;
        $this->countSatellites = $countSatellites;
        $this->distanceToSun = $distanceToSun;
        $this->img = $img;
    } // __construct

    // геттеры и сеттеры

    // название
    public function getName(): string {return $this->name; }
    public function setName(string $name): void {
        if($name === "")
            throw new Exception("Недопустимое название планеты");
        $this->name = $name;
    }

    // радиус
    public function getRadius(): float { return $this->radius; }
    public function setRadius(float $radius): void {
        if($radius <= 0)
            throw new Exception("Недопустимый радиус планеты");
        $this->radius = $radius;
    }

    // масса
    public function getMass(): float { return $this->mass; }
    public function setMass(float $mass): void {
        if($mass <= 0)
            throw new Exception("Недопустимая масса планеты");
        $this->mass = $mass;
    }

    // количество спутников
    public function getCountSatellites(): int { return $this->countSatellites; }
    public function setCountSatellites(int $countSatellites): void {
        if($countSatellites < 0)
            throw new Exception("Недопустимое количество спутников");
        $this->countSatellites = $countSatellites;
    }

    // расстояние до солнца
    public function getDistanceToSun(): float { return $this->distanceToSun; }
    public function setDistanceToSun(float $distanceToSun): void {
        if($distanceToSun < 0)
            throw new Exception("Недопустимое расстояние до Солнца");
        $this->distanceToSun = $distanceToSun;
    }

    // изображение
    public function getImg(): string { return $this->img; }
    public function setImg(string $img): void {
        if($img === "")
            throw new Exception("Недопустимое имя файла изображения планеты");
        $this->img = $img;
    }

    // формирование строкового представления
    public function __toString(): string {
        return "$this->name $this->radius $this->mass $this->countSatellites $this->distanceToSun $this->img";
    }

    // вывод в строку таблицы
    public function toTableRow():string {
        return "<tr>
            <td>$this->name</td>
            <td class='text-center'>$this->radius</td>
            <td class='text-center'>$this->mass</td>
            <td class='text-center'>$this->countSatellites</td>
            <td class='text-center'>$this->distanceToSun</td>
            <td class='text-center'><img src='../img/task3/$this->img' alt='$this->img'></td>
        </tr>";
    }

}