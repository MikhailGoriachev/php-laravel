<?php

require_once ("models/Planet.php");

// имя файла
const FILE_NAME_PLANETS = 'planets.csv';

// полный путь к файлу
const FULL_PATH = '../' . FOLDER_NAME_APP_DATA . '/' . FILE_NAME_PLANETS;

// запись планет в файл
function writePlanetsToFile() {
    // массив планет для записи
    $planets = [
        new Planet("Меркурий", 2439.7, 0.33022, 0, 0.38, "mercury.jpg"),
        new Planet("Венера", 6051.8, 4.8690, 0, 0.723, "venus.jpg"),
        new Planet("Земля", 6378.14, 5.9742, 1, 1.000, "earth.jpg"),
        new Planet("Марс", 3397, 0.64191, 2, 1.524, "mars.jpg"),
        new Planet("Юпитер", 71492, 1898.8, 67, 5.204, "jupiter.jpg"),
        new Planet("Сатурн", 60268, 568.50, 62, 9.584, "saturn.jpg"),
        new Planet("Уран", 25559, 86.625, 27, 19.187, "uranus.jpg"),
        new Planet("Нептун", 24764, 102.78, 14, 30.021, "neptune.jpg"),
        new Planet("Плутон", 1151, 0.015, 5, 39.231, "pluto.jpg")
    ];

    // открыть файл для записи
    $f = @fopen(FULL_PATH, 'w');

    // запись данных в файл
    foreach ($planets as $planet)
        fputcsv($f, (array)$planet, eol: "\r\n");

    // закрыть файл
    fclose($f);
}

// сравнение по расстоянию
function compareByDistance(Planet $planet1, Planet $planet2) {
    return $planet1->getDistanceToSun() <=> $planet2->getDistanceToSun();
}

// сравнение по названию
function compareByName(Planet $planet1, Planet $planet2) {
    return $planet1->getName() <=> $planet2->getName();
}

// сравнение по массе
function compareByMass(Planet $planet1, Planet $planet2) {
    return $planet1->getMass() <=> $planet2->getMass();
}

// чтение из файла и сортировка массива планет
function sortPlanetFromFileByCompare(callable $callback) {

    // открыть файл для чтения
    $f = @fopen(FULL_PATH, 'r');

    // массив для хранения
    $arrPlanets = [];

    // чтение записи из файла
    // и добавление в массив
    while (true) {
        $arrData = fgetcsv($f);
        if (feof($f)) break;
        $arrPlanets[] = new Planet($arrData[0], $arrData[1], $arrData[2], $arrData[3], $arrData[4], $arrData[5]);
    }

    // закрытие файла
    fclose($f);

    // сортировка
    usort($arrPlanets, $callback);

    return $arrPlanets;
}

// вывод таблицы планет
function showTable($arrayPlanets) {

    echo "<table class='table table-hover mt-3'>
            <thead class='text-center'>
            <th>Название планеты</th>
            <th>Радиус, км</th>
            <th>Масса, 10<sup>24</sup> кг</th>
            <th>Количество спутников</th>
            <th>Расстояние до Солнца, а.е.</th>
            <th>Изображение</th>
        </thead>";

    // вывод строк таблицы
    foreach($arrayPlanets as $planet)
        echo "{$planet->toTableRow()}";

    echo "</table>";

}