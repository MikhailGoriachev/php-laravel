<?php

//подключили функции
require_once("../tasks/utils.php");

class Planet{

    private string $title;    //название
    private int $r;        //радиус
    private $w;    //масса
    private int $count;    //количество спутников
    private float $distance; //расстояние до Солнца
    private string $image;    //фотография

    // конструктор класса
    function __construct($title,$r,$w,$count,$distance,$image)
    {
        $this->title = $title;
        $this->r = $r;
        $this->w = $w;
        $this->count = $count;
        $this->distance = $distance;
        $this->image = $image;
    }

    //геттеры и сеттеры с выбросом исключений
    function getTitle(): string {return $this->title;}
    function setTitle($value): void
    {
        if(mb_strlen($value) == 0) throw new InvalidArgumentException("Title: Строка пуста");

        $this->title = $value;
    }

    function getR(): int {return $this->r;}
    function setR($value): void
    {
        if($value <= 0) throw new InvalidArgumentException("R <= 0");

        $this->r = $value;
    }

    function getW() {return $this->w;}
    function setW($value): void
    {
        if($value <= 0) throw new InvalidArgumentException("W <= 0");

        $this->w = $value;
    }

    function getCount(): int {return $this->count;}
    function setCount($value): void
    {
        if($value <= 0) throw new InvalidArgumentException("count <= 0");

        $this->count = $value;
    }

    function getDistance(): float {return $this->distance;}
    function setDistance($value): void
    {
        if($value <= 0) throw new InvalidArgumentException("distance <= 0");

        $this->distance = $value;
    }

    function getImage(): string {return $this->image;}
    function setImage($value): void
    {
        if(mb_strlen($value) == 0) throw new InvalidArgumentException("Image: Строка пуста");

        $this->image = $value;
    }

    //генератор планет
    static function getPlanet(){

        $planets = array(
            new Planet("Меркурий",2439,3.3022e23, 0,0.39, "mercury.png"),
            new Planet("Земля",6378, 5.9722e24, 1,1,"earth.png"),
            new Planet("Юпитер",71492,1.9e27,63,5.2,"jupiter.png"),
            new Planet("Сатурн",60300, 5.68e26,56,9.5,"saturn.png"),
            new Planet("Марс",3397,6.42e23,2,1.5,"mars.png"),
            new Planet("Венера",12103,4.87e24,0,0.4,"venus.png"),
            new Planet("Нептун", 24764, 1.02e26,13,30,"neptune.png"),
            new Planet("Уран",25360,8.68e25,27,19.6,"uranium.png")
        );

        return $planets[random_int(0, 7)];
    }

    public function toTableRow(): void
    {
       echo "<tr>
            <td>$this->title</td>
            <td>$this->r</td>
            <td>$this->w</td>
            <td>$this->count</td>
            <td>$this->distance</td>
            <td><img style='width: 100px' src='../images/$this->image'></td>
            
        </tr>";
    }

    public function __toString():string{
        return "$this->title;$this->r;$this->w;$this->count;$this->distance;$this->image";
    }

}

//класс для работы с коллекцией
class Bodies{

    private array $planets = array();

    function __constructor(): void {}

    public function init(){

        //если файла нет
        if (!file_exists(FILENAME_PLANETS)){

            //создаем

            //заполняем массив
            for ($i = 0; $i < 12; $i++) {
                $this->planets[$i] = Planet::getPlanet();
            }

            //записываем данные из массива в файл
            $fp = fopen(FILENAME_PLANETS, 'w');
            fputcsv($fp, $this->planets);
            fclose($fp);
        }

        // открыть файл для чтения
        $fd = @fopen(FILENAME_PLANETS, 'r') or die("<h4 style='color: tomato'>Не удалось открыть файл</h4>");

        $text = "";
        //читаем
        while(!feof($fd)):
            $str = htmlentities(fgets($fd));
            $text = $text.$str;
        endwhile;
        fclose($fd);

        //из CSV в массив строк
        $data = str_getcsv($text);

        //заполняем массив
        foreach ($data as $item){

            $arr = explode(";",$item);

            $this->planets[] = new Planet($arr[0], intval($arr[1]), floatval($arr[2]), intval($arr[3]), floatval($arr[4]), $arr[5]);
        }

    }

    //упорядочиванием по расстоянию
    function sortDistance() :void {
        usort($this->planets,fn($a,$b) => $a->getDistance() <=> $b->getDistance());
    }

    //упорядочиванием по алфавиту
    function sortTitle() :void {
        usort($this->planets,fn($a,$b) => strcmp($a->getTitle(),$b->getTitle()));
    }

    //упорядочиванием по массе
    function sortMass() :void {
        usort($this->planets,fn($a,$b) => $a->getW() <=> $b->getW());
    }

    //Демонстрация работы сеттеров
    function testing() :void{

        try {

            $this->planets[random_int(0, 11)]->setTitle("");
            $this->planets[random_int(0, 11)]->setR(-1);
            $this->planets[random_int(0, 11)]->setW(-1);

        }catch (InvalidArgumentException $ex){

            $msg = $ex->getMessage();
            echo "<span style='color:red;'>$msg</span><br>";
        }
    }

    public function show(): void
    {
        array_walk_recursive($this->planets,fn($p)=>$p->toTableRow());
    }
}

$bodies = new Bodies();
$bodies->init();

isset($_POST['order-by-destination']) ? $bodies->sortDistance(): "";
isset($_POST['order-by-title']) ? $bodies->sortTitle(): "";
isset($_POST['order-by-mass']) ? $bodies->sortMass(): "";

isset($_POST['test']) ? $bodies->testing() : "";

$bodies->show();
