<?php

// проверка существования папки file_exists("folder")
if (!file_exists("../app_data"))
    mkdir("../app_data");  // создание каталога

// установить правильный часовой пояс
date_default_timezone_set('Europe/Moscow');

// имя файла журнала операций
const FILENAME = "../app_data/report01.txt";

const FILENAME_PLANETS = "../app_data/planets.csv";

//находим площадь треугольника
function trArea($a, $b, $c): float
{

    $p = ($a + $b + $c) / 2;

    return sqrt($p * ($p - $a) * ($p - $b) * ($p - $c));
}

// чтение и вывод файла
function view($name, $pattern): string
{

    // открыть файл для чтения
    $fd = @fopen($name, 'r') or die("<h4 style='color: tomato'>Не удалось открыть файл $name</h4>");

    $text = "";
    while (!feof($fd)):
        $str = htmlentities(fgets($fd));
        //$text = $text.$str.'<br/>';
        $text = preg_match($pattern, $str) ? $text . $str . '<br/>' : $text;
    endwhile;
    fclose($fd);

    return $text;
} // view

// пример записи в текстовый файл
function write_to_file($name)
{
    $fd = fopen($name, 'r+') or die("<h4>Не удалось открыть файл $name</h4>");

    fclose($fd);
} // write_to_file

// пример записи в текстовый файл
function write_line_to_file($name, $line)
{
    $fd = fopen($name, 'r+') or die("<h4>Не удалось открыть файл $name</h4>");

    fseek($fd, 0, SEEK_END);// поместим указатель в конец
    fwrite($fd, $line);    // запишем строку в начало

    fclose($fd);
} // write_to_file

// очистка файла журнала
function task1LogClear($logName)
{
    // Открытие файла в режиме "w" уничтожает все записи файла
    $f = @fopen($logName, "w");
    if (!$f) {
        echo "
        <div class='alert alert-danger'>
            <strong>Ошибка</strong><br>
            Не могу открыть файл журнала <u>$logName</u> для очистки
        </div>";
        return;
    } // if

    fclose($f);
} // task1LogClear


// установка сессии
function start()
{
    session_name("start");
    session_start();
}

// вход в сессию
function login()
{

    start();

    $_SESSION['isLogged'] = true;
}


// выход из сессии
function exitS()
{
    // для удаления сессии необходимо
    $_SESSION = [];
    if (session_id() != "" || isset($_COOKIE[session_name()]))
        setcookie(session_name(), '', time() - 10, '/');
    session_destroy(); // удаление данных сессии на сервере
}

