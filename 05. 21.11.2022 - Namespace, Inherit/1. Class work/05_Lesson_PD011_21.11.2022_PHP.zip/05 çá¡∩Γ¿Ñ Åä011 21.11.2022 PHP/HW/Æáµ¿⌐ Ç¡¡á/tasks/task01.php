<?php

//подключили функции
require_once("../tasks/utils.php");

// формат вывода значений в разметку, журнал операций
const FMT = "%.3f";

if (!file_exists(FILENAME)) {
    $fd = fopen(FILENAME, "w");
    fclose($fd);
}

if (isset($_POST['type'])) {

    $type = $_POST['type'];

    if (!isset($_POST['a'])) {

        if (isset($_COOKIE['a'])) {

            // чтение куки
            $a = +$_COOKIE['a'];
        } else {

            $a = random_int(4, 11);

            // Куки еще не определен - создание, установка куки
            // setcookie("a", $a, time() + 3600);
        }
    } else $a = +$_POST['a'];

    echo " <form class='m-4 w-25' action='#' method='post'>
 
        <input type='hidden' value='$type' name='type'/>

              <div class='mb-3 mt-3' >
                 <label for='a'>Сторона А:</label>
                 <input type='number' name='a' id='a' class='form-control' min='1' max='100' required value='$a'/>
               </div>";

    if ($type == "rectangle" || $type == "triangle") {

        if (!isset($_POST['b'])) {

            if (isset($_COOKIE['b'])) {

                // чтение куки
                $b = +$_COOKIE['b'];
            } else {

                $b = random_int(4, 11);

                // Куки еще не определен - создание, установка куки
                //setcookie("b", $b, time() + 3600);
            }
        } else $b = +$_POST['b'];

        echo "              
              <div class='mb-3 mt-3' >
                 <label for='b'>Сторона B:</label>
                 <input type='number' name='b' id='b' class='form-control' min='1' max='100' required value='$b'/>
               </div>";

        if ($type == "triangle") {

            if (!isset($_POST['c'])) {

                if (isset($_COOKIE['c'])) {

                    // чтение куки
                    $c = +$_COOKIE['c'];
                } else {

                    $c = random_int(4, 11);

                    // Куки еще не определен - создание, установка куки
                    // setcookie("c", $c, time() + 3600);
                }
            } else $c = +$_POST['c'];


            echo "
              <div class='mb-3 mt-3' >
                 <label for='c'>Сторона C:</label>
                 <input type='number' name='c' id='c' class='form-control' min='1' max='100' required value='$c'/>
               </div>";
        }

    }

    $s = 'введите данные';
    $p = 'введите данные';

    $area = isset($_POST['area']);
    $perimeter = isset($_POST['perimeter']);

    $line = "";

    // Куки уже определен - изменение куки
    setcookie("a", $a, time() + 3600);

    switch ($_POST['type']) {
        case 'rectangle':

            $nameFigure = "Прямоугольник";
            $line = " b = " . $b;

            setcookie("b", $b, time() + 3600);

            $s = isset($_POST['area']) ? $a * $b : 'не выбрано';
            $p = $perimeter ? 2 * ($a + $b) : 'не выбрано';
            break;

        case 'square':
            $s = $area ? $a * $a : 'не выбрано';
            $p = $perimeter ? 4 * $a : 'не выбрано';

            $nameFigure = "Квадрат";
            break;

        case 'triangle':

            setcookie("b", $b, time() + 3600);
            setcookie("c", $c, time() + 3600);

            $line = " b = " . $b . " c = " . $c;

            $nameFigure = "Треугольник";

            $s = $area ? trArea($a, $b, $c) : 'не выбрано';
            $p = $perimeter ? $a + $b + $c : 'не выбрано';
            break;
    }

    echo "

                <p class='fs-5'>Параметры для вычисления:<br>
                    <div class='form-check fs-6'>
                        <input class='form-check-input' type='checkbox' name='area' value='area'>
                        <label class='form-check-label'>
                            Площадь
                        </label>
                    </div>
                    <div class='form-check fs-6'>
                        <input class='form-check-input' type='checkbox' name='perimeter' value='perimeter' >
                        <label class='form-check-label'>
                            Периметр
                        </label>
                    </div>
                </p>
                
                <div class='mt-3 d-flex justify-content-end'>
                    <input class='btn btn-primary' type='submit' value='Вычислить' />
                </div>
                </form>";


    //запись в журнал
    write_line_to_file(FILENAME, date('d-m-y H:i:s') . " " . $nameFigure . " a = " . $a . $line . " площадь: " . $s . " периметр: " . $p . "\r\n");


    echo "
         <ul class='list-unstyled m-5'>
                    <li><b>Результаты вычислений:</b></li>
                    <li>Площадь: " . $s . "</li>
                    <li>Периметр: " . $p . "</li>
                   
            </ul>";

} else {

    echo "
        <form class='m-4 w-25' action='#' method='post'>
        <p class='fs-5'>Тип фигуры:<br>
                    <div class='form-check fs-6'>
                        <label class='form-check-label'>
                            <input class='form-check-input'  type='radio' name='type' value='rectangle' checked/>
                                Прямоугольник
                            </label>
                    </div>

                    <div class='form-check fs-6'>
                        <label class='form-check-label'>
                            <input class='form-check-input' type='radio' name='type' value='square'/>
                            Квадрат
                        </label>
                    </div>

                    <div class='form-check fs-6'>
                        <label class='form-check-label'>
                            <input class='form-check-input' type='radio' name='type' value='triangle'/>
                            Треугольник
                        </label>
                    </div>

                </p>
               
                <div class='mt-3 d-flex justify-content-end'>
                    <input class='btn btn-primary' type='submit' value='OK' />
                </div>

            </form>";
}

