<?php

if ($_FILES && $_FILES['filename']['error'] == UPLOAD_ERR_OK) {

    if (!file_exists("../uploaded"))
        mkdir("../uploaded");  // создание каталога

    $name = '../uploaded/'.$_FILES['filename']['name'];
    $result = move_uploaded_file($_FILES['filename']['tmp_name'], $name);

    echo "<p class='fs-5 m-4 mt-5'>Файл <span style='color: blue'>$name</span> ".($result?'':'НЕ ').'загружен</p>';

    // вывод загруженного файла
    $str = view($name,"//");
    echo "<p class='ms-4'>$str</p><br/>";

    echo "<p class='ms-4 fs-5'>Только строки, содержащие двузначные числа:</p>";

    $str = view($name,"/\s\d{2}\s/");
    echo "<p class='ms-4'>$str</p><br/>";

    echo "<p class='ms-4 fs-5'>Только строки, не содержащие символов .,!?: </p>";

    $str = view($name,"/^((?![.,!?:]).)*$/");
    echo "<p class='ms-4'>$str</p>";

    $str = file_get_contents($name);
    write_to_file($name);
}