<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_21.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../lib/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<header class="container-fluid bg-primary text-center text-white">
</header>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
    <div class="container-fluid">
        <div style="width: 70%; margin: auto;">
            <div class="navbar-collapse">
                <ul class="navbar-nav fs-4">
                    <li class="nav-item pt-1">
                        <a class="nav-link" href="../index.php">Страница с заданием</a>
                    </li>
                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link " href="page01.php">Задача 1</a>
                    </li>
                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link" href="page02.php">Задача 2</a>
                    </li>
                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link active" href="#">Задача 3</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<main class="container-fluid" >

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-3 bg-white m-3 border-warning-top border-warning-bottom">


            <div class="me-1 justify-content-end d-flex">

                <div class="row">

                    <div class="col-3 mt-3">

                        <div class="btn-group me-5">

                            <form method="post" action="#">

                                <input type='hidden' name='test'/>

                                <input type="submit" class="btn btn-primary"  value="Демонстрация работы" style="width: 200px;"/>

                            </form>

                            <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">
                                Сортировки по заданию
                            </button>
                            <ul class="dropdown-menu">

                                <li>
                                    <form method="post" action="#">

                                        <input type='hidden' name='order-by-destination'/>

                                        <input class="dropdown-item" type="submit" value="По расстоянию"/>

                                    </form>
                                </li>


                                <li>
                                    <form method="post" action="#">

                                        <input type='hidden' name='order-by-title'/>

                                        <input  type="submit"  value="По алфавиту"/>

                                    </form>
                                </li>

                                <li>
                                    <form method="post" action="#">

                                    <input type='hidden' name='order-by-mass'/>

                                    <input type="submit" value="По массе"/>

                                    </form>
                                </li>

                            </ul>

                                <form method="post" action="#">

                                    <input type='hidden' name='entry'/>

                                    <input  type="submit"class="btn btn-primary" value="Вход"/>

                                </form>

                                <form method="post" action="#">

                                    <input type='hidden' name='exit'/>

                                    <input type="submit" class="btn btn-primary" value="Выход"/>

                                </form>


                        </div>
                    </div>
                </div>

            </div>

            <p class="mb-2 ms-4 fs-4 mt-3">Решение задания 3</p>

            <table class="table mt-5">
                <thead>
                    <th>Название</th>
                    <th>Радиус</th>
                    <th>Масса</th>
                    <th>Количество спутников</th>
                    <th>Расстояние</th>
                    <th></th>
                </thead>
                <tbody>
            <?php
            //подключили функции
            require_once("../tasks/task03.php");

            ?>
                </tbody>
            </table>

        </div>

    </div>
</main>

<div class="mt-5 p-3 bg-dark text-white-50 text-center footer">
    <p>Выполнила: Таций Анна ВПД011 Донецк 2022</p>
</div>

</body>
</html>

