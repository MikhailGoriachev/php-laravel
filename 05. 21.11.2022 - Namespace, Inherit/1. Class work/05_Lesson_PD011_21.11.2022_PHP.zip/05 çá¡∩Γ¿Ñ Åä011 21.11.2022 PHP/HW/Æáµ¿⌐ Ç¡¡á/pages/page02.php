<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_21.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../lib/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<header class="container-fluid bg-primary text-center text-white">
</header>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
    <div class="container-fluid">
        <div style="width: 70%; margin: auto;">
            <div class="navbar-collapse">
                <ul class="navbar-nav fs-4">
                    <li class="nav-item pt-1">
                        <a class="nav-link" href="../index.php">Страница с заданием</a>
                    </li>
                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link" href="page01.php">Задача 1</a>
                    </li>
                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link active" href="#">Задача 2</a>
                    </li>
                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link" href="page03.php">Задача 3</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<main class="container-fluid" >

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-3 bg-white m-3 border-warning-top border-warning-bottom">

            <p class="mb-2 ms-4 fs-4 mt-3">Решение задания 2</p>

            <form class="w-25 m-4" method="post" enctype="multipart/form-data">
                <label class="form-label" for="filename">Выберите файл:</label>
                <input class="form-control" type='file' name='filename' />

                <div class="mt-3 d-flex justify-content-end">
                    <input class="btn btn-primary" type='submit' value='Загрузить' />
                </div>

            </form>

            <?php
            //подключили функции
            require_once("../tasks/utils.php");
            require_once("../tasks/task02.php");

            ?>

        </div>

    </div>
</main>

<div class="mt-5 p-3 bg-dark text-white-50 text-center footer">
    <p>Выполнила: Таций Анна ВПД011 Донецк 2022</p>
</div>

</body>
</html>
