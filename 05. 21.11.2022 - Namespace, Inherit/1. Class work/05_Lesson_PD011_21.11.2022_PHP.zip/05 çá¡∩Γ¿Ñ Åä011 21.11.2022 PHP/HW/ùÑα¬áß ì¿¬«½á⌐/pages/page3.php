<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width" />
    <title>Задача 1</title>

    <link rel="stylesheet" href="../lib/css/bootstrap.min.css"/>
    <script src="../lib/js/bootstrap.bundle.min.js"></script>
    <link href="../css/style.css" rel="stylesheet"/>


</head>
<body>
<nav class="navbar fixed-top navbar-light bg-light">
    <div class="container-fluid">
        <ul class="nav" role="tablist">
            <li class="nav-item">
                <a class="nav-link" href="../index.php">Задание</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="page1.php">Задача 1</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="page2.php">Задача 2</a>
            </li>
        </ul>
    </div>
</nav>
<main class="col-sm p-3 mt-5">
    <div class="container-fluid ">
        <div class="row ">
            <div class="col-sm-3">

            </div>
            <div class="col p-1">

            </div>
        </div>
    </div>
</main>
<footer class="container-fluid bg-light p-3 mt-1">
    <p>Черкас Николай группа ВПД-011 г.Донецк 2022 г. группа ВПД-011</p>
</footer>
</body>
</html>
