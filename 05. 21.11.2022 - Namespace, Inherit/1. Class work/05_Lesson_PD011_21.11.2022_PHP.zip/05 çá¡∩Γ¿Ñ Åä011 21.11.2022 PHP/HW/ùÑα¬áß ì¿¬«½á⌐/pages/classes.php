<?php
class Box{
    public $side1;
    function __construct($side1)
    {
        $this->$side1 = $side1;
    }
    // выводит поля ввода
    static function showInput(){
        echo '<h6>сторона 1<br/><input class="form-control" type="number" name="side1"/></h6>';
    }
    // фото фигуры
    static function foto(){
        echo '<img src="../images/box.jpg"/>';
    }
    // площадь
    function square(){
        return $this->side1 ** 2;
    }
    // периметр
    function perimeter(){
        return $this->side1 * 4;
    }
}

class Rectangle extends Box{
    public $side2;
    function __construct($side1, $side2){
        $this->side1 = $side1;
        $this->side2 = $side2;
    }
    static function showInput()
    {
        parent::showInput();
        echo '<h6>сторона 2<br/><input class="form-control" type="number" name="side2"/></h6>';
    }
    static function foto(){
        echo '<img src="../images/rectangle.jpg"/>';
    }
    // площадь
    function square(){
        return $this->side1 ** $this->side2;
    }
    // периметр
    function perimeter(){
        return 2 * ($this->side1 + $this->side2);
    }
}
class Triangle extends Rectangle {
    public $side3;
    function __construct($side1, $side2, $side3){
        $this->side1 = $side1;
        $this->side2 = $side2;
        $this->side3 = $side3;
    }
    static function showInput()
    {
        parent::showInput();
        echo '<h6>сторона 3<br/><input class="form-control" type="number" name="side3"/></h6>';
    }
    static function foto(){
        echo '<img src="../images/triangle.png"/>';
    }
    // площадь
    function square(){
        $p = $this->perimeter() / 2;
        return sqrt($p * ($p-$this->side1) * ($p-$this->side2) * ($p-$this->side3));
    }
    // периметр
    function perimeter(){
        return $this->side1 + $this->side2 +  $this->side3;
    }
}
