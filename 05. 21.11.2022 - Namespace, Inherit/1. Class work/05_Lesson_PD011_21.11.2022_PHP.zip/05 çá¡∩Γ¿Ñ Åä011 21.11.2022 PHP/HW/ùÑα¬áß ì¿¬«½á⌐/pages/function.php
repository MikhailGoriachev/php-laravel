<?php
//$html = new DOMDocument();
require_once("classes.php");

// переходы при создании сессии
function pathTask(){
    if (session_status() != PHP_SESSION_NONE){
        echo '<li class="nav-item">
                <a class="nav-link" href="pages/page1.php">Задача 1</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="pages/page2.php">Задача 2</a>
            </li>';
    }
}

function workSession(){
    if (isset($_POST['no'])){
        session_unset();
        addCsv(readCsv(), "закрытие сессии");
    }
    elseif (isset($_POST['yes'])){
        session_start();
        $_SESSION["name"] = "Work";
        addCsv(readCsv(), "создание сессии");
    }
}
// чтение файла
function readCsv(){
    $list = [];
    if (($handle = fopen("file.csv", "r")) !== false){
        while (($data = fgetcsv($handle,0, ";")) !== false){
            $list[] = $data;
        }
        fclose($handle);
    }
    return $list;
}
// добавление записи
function addCsv($list, $str){
    array_push($list, array($str, date("d/m/Y H:i")));

    $fp = fopen('file.csv', 'w');
    foreach ($list as $fields) {
        fputcsv($fp, $fields, ';');
    }
    fclose($fp);
}

// запись текста в файл
function fileWriteText($str, $fname){
    $fd = fopen($fname,'a');
    fputs($fd, $str);
    fclose($fd);
}
// чтение текста из файла
function fileReadText($filename){
    $fd = fopen($filename, 'r') or die("не удалось открыть файл");
    while (!feof($fd)) {
        $str = htmlentities(fgets($fd));
        if (!isset($_POST['number']) and !isset($_POST['symbol']))
            echo "<p>$str</p>";
        if (isset($_POST['number'])){
            $p = '/\D\d{2}\D/';
            preg_match($p, $str,$out);
            if (count($out) > 0){
                echo "<p>$str</p>";
            }
        }
        if (isset($_POST['symbol'])){
            $p = "/[\?\!\:\,\.]/";
            preg_match($p, $str,$out);
            if (count($out) == 0){
                echo "<p>$str</p>";
            }
        }
    }
    fclose($fd);
    if (isset($_POST['number'])) unset($_POST['number']);
    if (isset($_POST['symbol'])) unset($_POST['symbol']);
}

// вывод полей ввода
function showInput(){
    if (isset($_SESSION['course'])){
        $course = $_SESSION['course'];
        echo '<form  class="border p-3 bg-light" method="post">';
        switch ($course){
            case "box":
                Box::showInput();
                break;
            case "rectangle":
                Rectangle::showInput();
                break;
            case "triangle":
                Triangle::showInput();
        }
        echo '<p><input class="mt-2 btn-secondary" type="submit" value="вычислить"/></p></form>';
    }
}
//  фигура
function factory(){
    if (isset($_SESSION['course'])){
        $side1 = 0;
        $side2 = 0;
        $side3 = 0;
        $figure = $_SESSION['course'];
        if (isset($_SESSION['side1'])) $side1 = $_SESSION['side1'];
        if (isset($_SESSION['side2'])) $side2 = $_SESSION['side2'];
        if (isset($_SESSION['side3'])) $side3 = $_SESSION['side3'];
        switch ($figure){
            case "rectangle":
                $_SESSION["figure"] = new Rectangle($side1, $side2);
                break;
            case "box":
                $_SESSION["figure"] = new Box($side1);
                break;
            case "triangle":
                $_SESSION["figure"] = new Triangle($side1, $side2, $side3);
                break;
        }
    }
}

function image(){
    if (isset($_SESSION["figure"])) {
        factory();
        $figure = $_SESSION["figure"];
        $figure->foto();
    }
}