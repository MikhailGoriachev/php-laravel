<?php
session_start();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width" />
    <title>Задача 1</title>
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css"/>
    <script src="../lib/js/bootstrap.bundle.min.js"></script>
    <link href="../css/style.css" rel="stylesheet"/>
</head>
<body>
<nav class="navbar fixed-top navbar-light bg-light">
    <div class="container-fluid">
        <ul class="nav" role="tablist">
            <li class="nav-item">
                <a class="nav-link" href="../index.php">Задание</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="page1.php">Задача 1</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="page2.php">Задача 2</a>
            </li>
        </ul>
    </div>
</nav>
<main class="col-sm p-3 mt-5">
    <div class="container-fluid ">
        <div class="row ">
            <div class="col-sm-3">

                <form  class="border p-3 bg-light" method="post">
                    <h6>фигуры</h6>
                    <p>
                        <input class="form-check-input" type="radio" name="course" id="rectangle" value="rectangle"/>
                        <label class="form-check-label" for="rectangle">прямоугольник</label>
                    </p>
                    <p>
                        <input class="form-check-input" type="radio" name="course" id="box" value="box"/>
                        <label  class="form-check-label" for="box">квадрат</label>
                    </p>
                    <p>
                        <input class="form-check-input" type="radio" name="course" id="triangle" value="triangle"/>
                        <label class="form-check-label" for="triangle">треугольник</label>
                    </p>
                    <h6>вычисляемые параметры</h6>
                    <p>
                        <input class="form-check-input" type="checkbox" name="chSquare" id="chSquare"/>
                        <label class="form-check-label" for="chSquare">площадь</label>
                    </p>
                    <p>
                        <input class="form-check-input" type="checkbox" name="chPerimeter" id="chPerimeter"/>
                        <label class="form-check-label" for="chPerimeter">периметр</label>
                    </p>

                    <p><input class="mt-2 btn-secondary" type="submit" value="выбрать"/></p>
                </form>
                <?php
                require_once("function.php");

                if (isset($_POST["chSquare"])) $_SESSION["chSquare"] = $_POST["chSquare"];
                if (isset($_POST["chPerimeter"])) $_SESSION["chPerimeter"] = $_POST["chPerimeter"];
                if (isset($_POST["course"])){
                    $_SESSION["course"] = $_POST["course"];
                    showInput();
                }
                ?>
            </div>
            <div class="col-7 p-1 m-2">
                <?php
                require_once("function.php");
                image();
                if (isset($_POST["side1"])) $_SESSION["side1"] = $_POST["side1"];
                if (isset($_POST["side2"])) $_SESSION["side2"] = $_POST["side2"];
                if (isset($_POST["side3"])) $_SESSION["side3"] = $_POST["side3"];
                if (isset($_SESSION["course"]) and isset($_SESSION["side1"])) {
                    factory();
                    if (isset($_SESSION["figure"]) and $_SESSION["side1"]) {
                        $str = '<p>'. date("d/m/Y H:i"). ' '. $_SESSION['course']. ' ';
                        $figure = $_SESSION["figure"];
                        if (isset($_SESSION["chSquare"])){

                            $s = $figure->square();
                            echo "<h6>площадь</h6><p>$s</p>";
                            $str = $str. 'площадь = '. $s. ' ';
                        }
                        if (isset($_SESSION["chPerimeter"])){
                            $p = $figure->perimeter();
                            $str = $str. ' периметр = '. $p;
                            echo "<h6>периметр</h6><p>$p</p>";
                        }
                        $str = $str. '</p>';
                        fileWriteText($str, "task1.txt");
                        unset($_SESSION["side1"]);
                        unset($_SESSION["chSquare"]);
                        unset($_SESSION["chPerimeter"]);
                    }
                }
                if (isset($_POST['journal'])){
                    $new_url = 'journal.php';
                    header('Location: '.$new_url);
                    unset($_POST['journal']);
                }
                // чистка журнала
                if (isset($_POST['journal2'])){
                    file_put_contents("task1.txt", "");
                }
                ?>
            </div>
            <div class="col p-1 m-2">
                <form class="p-3" method="post">
                    <input class="mt-2 btn-secondary" type="submit" name="journal" value="журнал"/>
                    <input class="mt-2 btn-secondary" type="submit" name="journal2" value="очистить"/>
                </form>
            </div>
        </div>
    </div>
</main>
<footer class="container-fluid bg-light p-3 mt-1">
    <p>Черкас Николай группа ВПД-011 г.Донецк 2022 г. группа ВПД-011</p>
</footer>
</body>
</html>