<?php
require_once "../src/utils.php";

// заглушка решения задачи 1
function task1() {
    alert("Предупреждение", "Задача 1 все еще в разработке...");
} // task3