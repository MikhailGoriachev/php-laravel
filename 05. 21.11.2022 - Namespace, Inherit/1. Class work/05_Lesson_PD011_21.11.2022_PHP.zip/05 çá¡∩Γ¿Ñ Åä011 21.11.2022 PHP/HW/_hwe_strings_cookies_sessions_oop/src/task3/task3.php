<?php
    require_once "../src/utils.php";

    // заглушка решения задачи 3
    function task3() {
        alert("Предупреждение", "Задача 3 все еще в разработке...");
    } // task3