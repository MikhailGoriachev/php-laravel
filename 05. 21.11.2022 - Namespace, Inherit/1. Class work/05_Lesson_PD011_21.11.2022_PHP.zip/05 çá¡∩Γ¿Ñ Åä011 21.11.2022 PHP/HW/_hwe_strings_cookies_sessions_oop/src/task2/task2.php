<?php
require_once "../src/utils.php";

// заглушка решения задачи 2
function task2() {
    alert("Предупреждение", "Задача 2 все еще в разработке...");
} // task3