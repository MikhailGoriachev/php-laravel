<?php
// вспомогательные функции

// генерация вещественного случайного числа в диапазоне значений [lo, hi]
function random_float ($lo, $hi) {
    return ($lo + lcg_value()*(abs($hi - $lo)));
} // random_float

// обмен двух переменных
function swap(&$a, &$b) {
    // языковая конструкция, начиная с версии языка PHP 7.1
    [$a, $b] = [$b, $a];
} // swap

// вывод предупреждения
function alert($title, $text){
    echo "
    <div class='alert alert-warning'>
        <strong>$title</strong><br>$text
    </div>";
} // alert


// вывод сообщения
function info($title, $text){
    echo "
    <div class='alert alert-success'>
        <strong>$title</strong><br>$text
    </div>";
} // alert

function isLogged($sessionName) {
    if (isset($_COOKIE[$sessionName])):
        // присоединяемся к существующей сессии
        session_name($sessionName);
        session_start();

        // есть сессия
        $loggedIn = true;
    else:
        // нет сессии
        $loggedIn = false;
    endif;

    return $loggedIn;
}

// Запись в файл журнал приложения
function writeToLog($sessionId, $sessionName, $message) {
    // установить правильный часовой пояс и получить текущее время
    // https://phpclub.ru/talk/threads/Корректировка-результата-функции-date-относительно-часового-пояса.51609/
    date_default_timezone_set('Europe/Moscow');
    $date = date("d-m-y");
    $time = date("H:i:s");

    // запись момента открытия сессии в журнал - файл в формате CSV
    // https://blog-about.ru/blog/chtenie-i-zapis-dannyx-v-csv-fajl-sredstvami-php/
    $path = "../app_data/app.log";
    $fh = fopen($path, 'a');
    if ($fh === false) {
        throw new Exception("Не могу открыть файл журнала $path для добавления записи");
    } // if

    fputcsv($fh, [$date, $time, $sessionName, $sessionId, $message], ';', '"');
    fclose($fh);
}
