<?php
    require_once "../src/utils.php";

    // начало сессии с назначенным именем
    // имя сессии будем записывать в журнал, поэтому сохраняем
    $sessionName = "HWE_PD011";
    session_name($sessionName);
    session_start();
    $sessionId = session_id();

    // TODO: записать данные в сессию
?>

<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>Задание на 21.11.2022</title>
    <!-- подключение файла-иконки -->
    <link rel="shortcut icon" href="../images/blimp.png" type="image/x-icon">

    <!-- подключение bootstrap -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- подключение собственных стилей -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php
// загрузка панели навигации

// активность страниц - ни одна не активна
$activateTask01Form = $activeTask01Log = $activeTask02 = $activateTask03 = "";

// собственно загрузка панели навигации
include_once "../pages/shared/_header.php";
?>

<!-- размещение контента страницы -->
<main class="container mt-5">
    <div class="row">
    <h5 class="my-3">Страница входа в приложение</h5>

    <div class="row">
        <?php
            try {
                // записать в журнал дату и время начала сессии:
                writeToLog($sessionId, $sessionName, "сессия открыта");
                info("К сведению", "Вход выполнен");
            } catch (Exception $ex) {
                alert("Ошибка", $ex->getMessage());
            }
        ?>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../pages/shared/_footer.php" ?>
</body>
</html>

