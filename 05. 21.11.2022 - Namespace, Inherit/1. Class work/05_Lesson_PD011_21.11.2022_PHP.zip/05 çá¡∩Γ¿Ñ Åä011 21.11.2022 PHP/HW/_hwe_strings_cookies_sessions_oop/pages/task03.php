<?php
require_once "../src/utils.php";

// проверим наличие сессии с назначенным именем
$sessionName = "HWE_PD011";
if (isset($_COOKIE[$sessionName])):
    session_name($sessionName);
    session_start();
    $sessionId = session_id();

    // есть сессия
    $loggedIn = true;
else:
    // нет сессии
    $loggedIn = false;
endif;
?>

<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>Задание на 21.11.2022</title>
    <!-- подключение файла-иконки -->
    <link rel="shortcut icon" href="../images/blimp.png" type="image/x-icon">

    <!-- подключение bootstrap -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- подключение собственных стилей -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php
    // загрузка панели навигации

    // активность страниц
    $activeTask03 = "active";
    $activateTask01Form = $activeTask01Log = $activeTask02 = "";

    // собственно загрузка панели навигации
    include_once "../pages/shared/_header.php";
?>

<!-- размещение контента страницы -->
<main class="container mt-5">
    <!-- показывать, если нет сессии -->
    <div class="row <?= !$loggedIn?"":"visually-hidden" ?>">
        <?php alert("Предупреждение", "Вход не выполнен"); ?>
    </div>

    <div class="row <?= $loggedIn?"":"visually-hidden" ?>">
        <details>
            <summary><b>Задача 3.</b> Обработка файла объектов в формате CSV.</summary>
            <p>Объект – класс Планета
                (Солнечной системы) с закрытыми свойствами название, радиус, масса, количество
                спутников, расстояние до Солнца в а.е., фотография. Разработайте геттеры и сеттеры
                с выбросом исключений при не валидных данных. По кликам на кнопки типа «submit»
                реализуйте обработки:
            </p>
            <ul class="ms-5">
                <li>
                    Демонстрация работы сеттеров (в том числе с не валидными данными)
                    и геттеров – используйте генерацию данных, формы не нужны
                </li>
                <li>Вывод данных из файла на страницу с упорядочиванием по расстоянию</li>
                <li>Вывод данных из файла на страницу с упорядочиванием по алфавиту</li>
                <li>Вывод данных из файла на страницу с упорядочиванием по массе</li>
            </ul>
        </details>

        <h5 class="my-3">Решение задачи 3 - Объекты, хранение коллекции объектов в текстовом файле CSV</h5>

        <?php
            require_once ("../src/task3/task3.php");
            task3();
        ?>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../pages/shared/_footer.php" ?>
</body>
</html>

