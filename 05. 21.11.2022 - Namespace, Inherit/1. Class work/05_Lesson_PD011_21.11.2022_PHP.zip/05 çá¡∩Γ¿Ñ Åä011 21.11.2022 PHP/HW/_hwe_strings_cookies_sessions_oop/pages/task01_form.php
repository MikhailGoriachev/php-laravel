<?php
    require_once "../src/utils.php";

    // проверим наличие сессии с назначенным именем
    $sessionName = "HWE_PD011";
    if (isset($_COOKIE[$sessionName])):
        session_name($sessionName);
        session_start();
        $sessionId = session_id();

        // есть сессия
        $loggedIn = true;
    else:
        // нет сессии
        $loggedIn = false;
    endif;
?>

<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>Задание на 21.11.2022</title>
    <!-- подключение файла-иконки -->
    <link rel="shortcut icon" href="../images/blimp.png" type="image/x-icon">

    <!-- подключение bootstrap -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <script src="../lib/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- подключение собственных стилей -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php
    // загрузка панели навигации

    // активность страниц
    $activeTask01Form = "active";
    $activeTask01Log = $activeTask02 = $activeTask03 = "";

    // собственно загрузка панели навигации
    include_once "../pages/shared/_header.php";
?>

<!-- размещение контента страницы -->
<main class="container mt-5">
    <!-- показывать, если нет сессии -->
    <div class="row <?= !$loggedIn?"":"visually-hidden" ?>">
        <?php alert("Предупреждение", "Вход не выполнен"); ?>
    </div>

    <!-- показывать, если есть сессия -->
    <div class="row <?= $loggedIn?"":"visually-hidden" ?>">
        <details>
                <summary><b>Задача 1.</b> Работа с формами и текстовым файлом</summary>
            <p>
                <b>Задача 1.</b> Требуется вычислять параметры плоских геометрических фигур. Параметры фигур вводить
                в форме. Тип фигуры выбирается пользователем, при помощи радиокнопок:
            </p>
            <ul class="ms-5">
                <li>Прямоугольник</li>
                <li>Квадрат</li>
                <li>Треугольник</li>
            </ul>
            <p>Параметры фигуры для вычисления задаются чек-боксами:</p>
            <ul class="ms-5">
                <li>площадь</li>
                <li>периметр</li>
            </ul>
            <p>
                Собственно вычисление выполнять при клике на кнопку "Вычислить" типа submit. Необходимые
                числовые параметры вводить при помощи строки ввода с типом number. Сохранять исходные данные
                в куки, если куки определены, выводить данные в поля формы из куки.
            </p>
            <p>
                Требуется также вести журнал операций – текстовый файл, в котором записывать дату и время
                выполнения расчета, исходные данные расчета, результаты расчета.
            </p>
            <p>Предусмотрите страницу для просмотра журнала, очистки журнала.</p>
        </details>

        <h5 class="my-3">Решение задачи 1 - работа с формами, текстовым файлом</h5>

        <?php
            require_once ("../src/task1/task1.php");
            task1();
        ?>
    </div>
    </div>
</main>

<!-- загрузка подвала страницы -->
<?php include "../pages/shared/_footer.php" ?>
</body>
</html>

