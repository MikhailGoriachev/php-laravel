<?php
include_once "../src/session.php";
include_once("../src/task1.php");

const HEADER = 'Задача 1';
const PAGE = 'task1';

Session::handleAuth();

if(!$_POST) {
    $formValues = Task1::loadCookies();
}else {
    $formValues = Task1::getValuesFromPost();
}

if(!strlen($formValues['figureType']))
    $formValues['figureType'] = "rectangle";

$results = ["figureName" => "", "area" => "", "perimeter" => ""];

$error = $_POST ? Task1::getError() : null;

if($_POST && !$error)
    $results = Task1::calc();

ob_start();
?>

<div class="row">
    <div class="col-5 bordered ps-4 pe-5 py-3">
        <div class="row">
            <div class="col-auto text-nowrap">
                <h4>Вычисление параметров геометрических фигур </h4>
            </div>
        </div>

        <form method="post">
            <p class="lead fs-5">Тип фигуры:</p>

            <div class="row mb-3">
                <div class="col-4">

                    <div class="btn-group" role="group">
                        <input type="radio" class="btn-check" name="figureType" id="btnRectangle" value="rectangle"
                               autocomplete="off" <?=$formValues['figureType'] == 'rectangle' ? "checked" : "" ?>>
                        <label class="btn btn-outline-primary" for="btnRectangle">Прямоугольник</label>

                        <input type="radio" class="btn-check" name="figureType" id="btnSquare" value="square"
                               autocomplete="off" <?=$formValues['figureType'] == 'square' ? "checked" : "" ?>>
                        <label class="btn btn-outline-primary" for="btnSquare">Квадрат</label>

                        <input type="radio" class="btn-check" name="figureType" id="btnTriangle" value="triangle"
                               autocomplete="off" <?=$formValues['figureType'] == 'triangle' ? "checked" : "" ?>>
                        <label class="btn btn-outline-primary" for="btnTriangle">Треугольник</label>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-3">
                    <div class="form-floating mb-3">
                        <input type="number" class="form-control" id="inpA" name="sideA" min="1e-10" value="<?=$formValues['sideA']?>" required>
                        <label for="inpA">Сторона a:</label>
                    </div>
                </div>
                <div class="col-3">
                    <div class="form-floating mb-3">
                        <input type="number" class="form-control" id="inpB" name="sideB" min="1e-10" value="<?=$formValues['sideB']?>">
                        <label for="inpB">Сторона b:</label>
                    </div>
                </div>
                <div class="col-3">
                    <div class="form-floating mb-3">
                        <input type="number" class="form-control" id="inpC" name="sideC" min="1e-10" value="<?=$formValues['sideC']?>">
                        <label for="inpC">Сторона c:</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-6">
                    <p class="lead fs-5">Параметры для вычисления:</p>

                    <div class="row mb-3">
                        <div class="col-auto">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="cbxArea" name="area"
                                       <?=$formValues['area'] ? "checked" : ""?>>
                                <label class="form-check-label" for="cbxArea">
                                    Площадь
                                </label>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="cbxPerimeter"
                                       name="perimeter" <?=$formValues['perimeter'] ? "checked" : ""?>>
                                <label class="form-check-label" for="cbxPerimeter">
                                    Периметр
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-auto">
                            <button class="btn btn-outline-secondary" type="submit">Вычислить</button>
                        </div>
                        <div class="col-auto">
                            <button class="btn btn-outline-secondary" type="reset">Очистить</button>
                        </div>
                    </div>
                </div>
                <div class="col-6 border rounded-4 d-flex flex-column justify-content-around px-3 py-2">
                    <?php if($error){  ?>
                        <div class="alert alert-danger"><?=$error?></div>
                    <?php }else{ ?>
                    <div class=""><b>Фигура: </b><?=$results['figureName']?></div>
                    <div class=""><b>Площадь: </b><?=$results['area'] ?? "не вычисляется"?></div>
                    <div class=""><b>Периметр: </b><?=$results['perimeter'] ?? "не вычисляется"?></div>
                    <?php } ?>
                </div>
            </div>

        </form>

        <a class="mt-3" href="task1_log.php">История операций</a>
    </div>

<?php
$content = ob_get_clean();
include_once("../pages/partial/layout.php");
?>

