
<?php $isLogin = Session::isLogin() ?>

<nav class="navbar navbar-expand-sm navbar-main bg-body sticky-top shadow mb-2">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#appNavbarMain">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="appNavbarMain">
            <ul class="navbar-nav ms-3">
                <li class="nav-item me-2">
                    <a href="../../index.php" class="nav-link <?= PAGE == 'index' ? 'active' : ''; ?>"
                       title="Перейти на страницу">
                        Главная </a>
                </li>
                <?php if($isLogin): ?>
                <li class="nav-item me-2">
                    <a href="/pages/task1_form.php" class="nav-link <?= PAGE == 'task1' ? 'active' : ''; ?>"
                       title="Перейти на страницу">
                        Задача 1 </a>
                </li>
                <li class="nav-item me-2">
                    <a href="/pages/task2_upload.php" class="nav-link <?= PAGE == 'task2' ? 'active' : ''; ?>"
                       title="Перейти на страницу">
                        Задача 2 </a>
                </li>
                <li class="nav-item me-2">
                    <a href="/pages/task3.php" class="nav-link <?= PAGE == 'task3' ? 'active' : ''; ?>"
                       title="Перейти на страницу">
                        Задача 3 </a>
                </li>
                <?php endif; ?>
            </ul>
                <form class="ms-auto me-4" method="post">
                    <button type="submit"
                            class="btn btn-outline-secondary"
                            name="login" value="<?=$isLogin?"out":"in"?>">
                        <?= $isLogin ? "Выход" : "Вход" ?>
                    </button>
                </form>
            </div>
        </div>
    </div>
</nav>
