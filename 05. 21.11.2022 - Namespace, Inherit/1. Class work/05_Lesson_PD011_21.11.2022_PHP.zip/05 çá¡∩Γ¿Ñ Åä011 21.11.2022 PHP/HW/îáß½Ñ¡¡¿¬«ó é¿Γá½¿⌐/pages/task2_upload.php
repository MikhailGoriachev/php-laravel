<?php
include_once "../src/session.php";

const HEADER = 'Задача 2';
const PAGE = 'task2';

Session::handleAuth();
ob_start();
?>

<form class="mt-5" action="task2_output.php" method="post" enctype='multipart/form-data'>
    <div class="row">
        <div class="col-3">
            <div class="input-group mb-3">
                <input type="file" class="form-control" name='upload_file' size='4' required>
            </div>
        </div>
        <div class="col-auto">
            <input class="btn btn-outline-secondary" type='submit' value='Загрузить'/>
        </div>
    </div>
</form>


<?php
$content = ob_get_clean();
include_once("../pages/partial/layout.php");
?>
