<?php
include_once "../src/session.php";
include_once("../src/task1.php");

const HEADER = 'Задание 1';
const PAGE = 'task1';

Session::handleAuth();
$history = "";

if (isset($_POST['clearHistory'])) {
    Task1::clearLog();
} else {
    if (file_exists(Task1::LOG_DIR . Task1::LOG_FILENAME))
        $history = Task1::readLog();
}

ob_start();

?>

<div class="row">
    <div class="col-auto">
        <a href="task1_form.php"><- назад</a>
    </div>
    <div class="col-auto ms-auto">
        <form method="post" class="ms-1">
            <button class="btn btn-outline-secondary" type="submit" name="clearHistory" id="test">Очистить журнал
            </button>
        </form>
    </div>
</div>
<p class="col-12 mt-4 text-center lead fs-4">История операций</p>

<div class="mt-4">
    <table class="table">
        <thead>
        <tr>
            <th>Дата и время</th>
            <th>Тип фигуры</th>
            <th>Сторона a</th>
            <th>Сторона b</th>
            <th>Сторона c</th>
            <th>Периметр</th>
            <th>Площадь</th>
        </tr></thead>
        <tbody class="color-2">
        <?php if(is_array($history)) {
            foreach ($history as $row) {
                echo '<tr>';
                foreach ($row as $value)
                    echo '<td>' . $value . '</td>';
                echo '</tr>';
            }
        }?>
        </tbody>
    </table>
</div>

<?php
$content = ob_get_clean();
include_once("../pages/partial/layout.php");
?>


