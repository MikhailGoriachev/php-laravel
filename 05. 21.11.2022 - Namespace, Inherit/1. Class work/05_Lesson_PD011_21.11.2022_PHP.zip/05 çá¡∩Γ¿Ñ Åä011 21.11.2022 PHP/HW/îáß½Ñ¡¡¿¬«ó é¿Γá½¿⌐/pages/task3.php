<?php
include_once "../src/session.php";
include_once "../src/models/planet.php";
include_once "../src/task3.php";

const HEADER = 'Задача 3';
const PAGE = 'task3';

Session::handleAuth();
ob_start();

$planets = Task3::loadPlanets();

if (isset($_POST['order']) && $_POST['order'] != 'source')
    Task3::orderPlanets($planets, $_POST['order']);

if (isset($_POST['setter'])) {
    $planets[0]->setMass(0);
}

?>
<div class="row">
    <div class="col-auto">
        <form method="post">
            <div class="row">
                <div class="col-auto">
                    <div class="form-floating">
                        <select class="form-select" id="selectMaterial" name="order">
                            <option value="source">Исходный порядок</option>
                            <option value="name">По алфавиту</option>
                            <option value="distance">По расстоянию</option>
                            <option value="mass">По массе</option>
                        </select>
                        <label for="selectMaterial">Упорядочить:</label>
                    </div>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-outline-secondary">Выбрать</button>
                </div>
            </div>
        </form>
    </div>
    <div class="col-auto">
        <form method="post">
            <input type="hidden" name="setter"/>
            <button type="submit" class="btn btn-outline-secondary">Исключение сеттера</button>
        </form>
    </div>
</div>
<table class="table mt-5">
    <thead>
    <tr>
        <th>Изображение</th>
        <th>Название</th>
        <th>Ср. расстояние до Солнца</th>
        <th>Радиус, км</th>
        <th>Масса, кг</th>
        <th>Кол-во спутников</th>
    </tr>
    </thead>
    <tbody class="color-2">
    <?php
    foreach ($planets as $p) { ?>
        <tr>
            <td><img class="w-200-px" src="../images/planets/<?= $p->getImage() ?>" alt="Фото планеты"></td>
            <td><?= $p->getName() ?></td>
            <td><?= $p->getAvgSunDistance() ?></td>
            <td><?= $p->getRadius() ?></td>
            <td><?= $p->getMass() ?></td>
            <td><?= $p->getMoons() ?></td>
        </tr>
    <?php } ?>

    </tbody>
</table>


<?php
$content = ob_get_clean();
include_once("../pages/partial/layout.php");
?>
