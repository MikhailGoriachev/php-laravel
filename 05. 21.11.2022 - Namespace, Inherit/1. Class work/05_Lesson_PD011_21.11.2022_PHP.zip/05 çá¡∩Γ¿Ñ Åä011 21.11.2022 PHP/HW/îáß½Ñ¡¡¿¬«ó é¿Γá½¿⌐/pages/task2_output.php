<?php
include_once "../src/session.php";
include_once("../src/task2.php");


const HEADER = 'Задание 2';
const PAGE = 'task2';
Session::handleAuth();

// сценарий дозаписи в файл
if (isset($_POST['saved_file']) && isset($_POST['text_append'])) {
    $savedFile = $_POST['saved_file'];

    Task2::writeToFile(Task2::UPLOAD_DIR . $savedFile, "\r\n" . $_POST['text_append']);
    $output = file(Task2::UPLOAD_DIR . $savedFile);
} // сценарий загрузки файла
else if (isset($_FILES['upload_file'])) {
    try {
        $savedFile = Task2::uploadFileHandle();
        $output = file(Task2::UPLOAD_DIR . $savedFile);
    } catch (RuntimeException $e) {
        $error = $e->getMessage();
    }
}

ob_start();
?>

<!--форма дозаписи текста в файл-->
<?php if (isset($savedFile)) { ?>
    <form method="post">
        <input type="hidden" name="saved_file" value=<?= $savedFile ?>>
        <div class="row">
            <div class="col-4">
                <div class="form-floating">
                    <textarea class="form-control h-180-px" id="txtArea" name="text_append" required></textarea>
                    <label for="txtArea">Введите текст:</label>
                </div>
            </div>
            <div class="col-auto mt-3">
                <input class="btn btn-outline-secondary" type='submit' value='Дозапись'/>
            </div>
        </div>
    </form>
<?php } ?>

<!--вывод содержимого файла-->
<div class="mt-4">
    <?php
    if (isset($error))
        echo '<div class="alert alert-danger">' . $error . '</div>';

    if (isset($output)) {
        echo '<h3 class="col-12 mt-4 text-center">Текст файла:</h3>';

        foreach ($output as $line)
            echo '<div>' . $line . '</div>';

        echo '<h3 class="col-12 mt-4 mb-2 text-center">Строки, содержащие двузначные числа:</h3>';
        $grep = preg_grep('/\D\d{2}\D/', $output);
        foreach ($grep as $line)
                echo '<div>' . $line . '</div>';

        echo '<h3 class="col-12 mt-4 text-center">Строки, не содержащие символов ".,!?:":</h3>';
        $grep = preg_grep('/([.,!?:])/', $output, PREG_GREP_INVERT);
        foreach ($grep as $line)
            echo '<div>' . $line . '</div>';

    }
    ?>
</div>


<?php
$content = ob_get_clean();
include_once("../pages/partial/layout.php");
?>

