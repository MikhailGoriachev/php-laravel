<?php

/*namespace models;*/

class Planet
{
    private string $name;
    private float $avgSunDistance;
    private float $radius;
    private float $mass;
    private int $moons;
    private string $image;

    public function __construct($name, $avgSunDistance, $radius, $mass, $image, $moons)
    {
        $this->name = $name;
        $this->avgSunDistance = intval($avgSunDistance);
        $this->radius = intval($radius);
        $this->mass = floatval($mass);
        $this->moons = intval($moons);
        $this->image = $image;
    }


    public function getName(): string   { return $this->name; }
    public function setName(string $name): Planet
    {
        if(!strlen($name)) throw new InvalidArgumentException("Не указано имя");
        $this->name = $name;
        return $this;
    }

    public function getAvgSunDistance(): float    { return $this->avgSunDistance; }
    public function setAvgSunDistance(float $avgSunDistance): Planet
    {
        if($avgSunDistance <= 0) throw new InvalidArgumentException("Допустимое значение - больше нуля");
        $this->avgSunDistance = $avgSunDistance;
        return $this;
    }

    public function getRadius(): float    { return $this->radius; }
    public function setRadius(float $radius): Planet
    {
        if($radius <= 0) throw new InvalidArgumentException("Допустимое значение - больше нуля");
        $this->radius = $radius;
        return $this;
    }

    public function getMass(): float    { return $this->mass; }
    public function setMass(float $mass): Planet
    {
        if($mass <= 0) throw new InvalidArgumentException("Допустимое значение - больше нуля");
        $this->mass = $mass;
        return $this;
    }

    public function getMoons(): int    { return $this->moons; }
    public function setMoons(int $moons): Planet
    {
        if($moons < 0) throw new InvalidArgumentException("Не может быть отрицательным");
        $this->moons = $moons;
        return $this;
    }

    public function getImage(): string { return $this->image; }
    public function setImage(string $image): Planet
    {
        $this->image = $image;
        return $this;
    }
}