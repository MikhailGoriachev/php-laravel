<?php

class Session
{
    const LOG_FILENAME = "sessions.csv";

    const SESSION_NAME = "HomeworkPHP";

    static function isLogin()
    {
        self::setSession();

        return isset($_SESSION['isLogged']);
    }

    static function login(): void
    {
        self::setSession();

        $_SESSION['isLogged'] = true;

        $id = session_id();
        $name = session_name();

        date_default_timezone_set('Europe/Moscow');

        self::writeLog($name, $id);
    }

    static function logout(): void
    {
        self::setSession();

        $id = session_id();
        $name = session_name();

        $_SESSION = [];
        if (session_id() != "" || isset($_COOKIE[session_name()]))
            setcookie(session_name(), '', time() - 10, '/');

        session_destroy();

        self::writeLog($name, $id, false);
    }

    static function setSession()
    {
        if (session_name() !== self::SESSION_NAME) {
            session_name(self::SESSION_NAME);
            session_start();
        }
    }

    static function writeLog($name, $id, $start = true)
    {
        $dir = PAGE == 'index' ? 'app_data/' : '../app_data/';
        $fd = fopen($dir . Session::LOG_FILENAME, 'a');
        fwrite($fd, '[.' . Date("d.m.y H:i:s") . '],' . $name . ',' . $id . "," . ($start ? "начата" : "завершена") . "\r\n");
        fclose($fd);
    }

    static function handleAuth()
    {
        if (isset($_POST['login'])) {
            $_POST['login'] === 'in' ? self::Login() : self::Logout();
        }
    }


}