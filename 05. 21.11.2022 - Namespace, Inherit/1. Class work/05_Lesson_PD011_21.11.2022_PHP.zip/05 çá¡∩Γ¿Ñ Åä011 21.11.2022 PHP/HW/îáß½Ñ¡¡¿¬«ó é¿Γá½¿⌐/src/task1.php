<?php

class Task1
{
    const LOG_DIR = "../app_data/";
    const LOG_FILENAME = "task1.csv";
    const FIGURES_DATA = [
        "square"    => ["areaFunc" => "squareArea",    "perimeterFunc" => "squarePerimeter",    "name" => "Квадрат"],
        "rectangle" => ["areaFunc" => "rectangleArea", "perimeterFunc" => "trianglePerimeter",  "name" => "Прямоугольник"],
        "triangle"  => ["areaFunc" => "triangleArea",  "perimeterFunc" => "rectanglePerimeter", "name" => "Треугольник"]
    ];

    static function getError(): ?string
    {
        if (!isset($_POST['figureType']))
            return "Не выбран тип фигуры";

        $figureType = $_POST['figureType'];

        if (!isset($_POST['sideA']) || !strlen($_POST['sideA']))
            return "Не введена сторона a";

        if ($figureType != 'square' && (!isset($_POST['sideB']) || !strlen($_POST['sideB'])))
            return "Не введена сторона b";

        if ($figureType == 'triangle' && (!isset($_POST['sideC']) || !strlen($_POST['sideC'])))
            return "Не введена сторона с";

        return null;
    }

    static function calc(): array
    {
        $figureType = $_POST['figureType'];


        $sideA = floatval($_POST['sideA']);
        $sideB = isset($_POST['sideB']) && strlen($_POST['sideB']) ? floatval($_POST['sideB']) : null;
        $sideC = isset($_POST['sideC']) && strlen($_POST['sideC']) ? floatval($_POST['sideC']) : null;

        $area = isset($_POST['area'])
            ? Task1::{Task1::FIGURES_DATA[$figureType]["areaFunc"]}($sideA, $sideB)
            : null;

        $perimeter = isset($_POST['perimeter'])
            ? Task1::{Task1::FIGURES_DATA[$figureType]["perimeterFunc"]}($sideA, $sideB, $sideC)
            : null;

        Task1::setCookie($figureType, isset($_POST['perimeter']), isset($_POST['area']), $sideA, $sideB, $sideC);
        Task1::writeLog(Task1::FIGURES_DATA[$figureType]["name"], $perimeter, $area, $sideA, $sideB, $sideC);

        return [
            "figureName" => Task1::FIGURES_DATA[$figureType]["name"],
            "area" => $area,
            "perimeter" => $perimeter,
        ];
    }

    static function setCookie($figureType, $perimeter, $area, $sideA, $sideB, $sideC): void
    {
        setcookie("php_hw_figureType", $figureType, time()+3600);
        setcookie("php_hw_perimeter", 1, $perimeter ? time()+3600 : -10);
        setcookie("php_hw_area", 1, $area ? time()+3600 : -10);
        setcookie("php_hw_sideA", $sideA ?? "", $sideA ? time()+3600 : -10);
        setcookie("php_hw_sideB", $sideB ?? "", $sideB ? time()+3600 : -10);
        setcookie("php_hw_sideC", $sideC ?? "", $sideC ? time()+3600 : -10);
    }

    static function loadCookies(): array
    {
        $values = [];
        $values['figureType'] = $_COOKIE['php_hw_figureType'] ?? "";
        $values['perimeter'] = isset($_COOKIE['php_hw_perimeter']);
        $values['area'] = isset($_COOKIE['php_hw_area']);
        $values['sideA'] = $_COOKIE['php_hw_sideA'] ?? "";
        $values['sideB'] = $_COOKIE['php_hw_sideB'] ?? "";
        $values['sideC'] = $_COOKIE['php_hw_sideC'] ?? "";

        return $values;
    }

    static function getValuesFromPost() {
        $values['figureType'] = $_POST['figureType'] ?? "";
        $values['area'] = isset($_POST['area']);
        $values['perimeter'] = isset($_POST['perimeter']);
        $values['sideA'] = $_POST['sideA'] ?? "";
        $values['sideB'] = $_POST['sideB'] ?? "";
        $values['sideC'] = $_POST['sideC'] ?? "";
        return $values;
    }
    static function writeLog($figureType, $perimeter, $area, $sideA, $sideB, $sideC): void
    {
        if(!is_dir(Task1::LOG_DIR))
            mkdir(Task1::LOG_DIR);

        date_default_timezone_set('Europe/Moscow');

        $record = Date("d.m.y H:i:s")
            . "," . $figureType
            . "," . $sideA
            . "," . ($sideB ?? "-")
            . "," . ($sideC ?? "-")
            . "," . ($perimeter ?? "не вычисляется")
            . "," . ($area ?? "не вычисляется")
            . "\r\n";

        $fd = fopen(Task1::LOG_DIR . Task1::LOG_FILENAME, 'a');
        fwrite($fd, $record);
        fclose($fd);
    }

    static function readLog(): array
    {
        return array_map('str_getcsv', file(Task1::LOG_DIR . Task1::LOG_FILENAME));
    }

    static function clearLog(): void
    {
        $f = @fopen(Task1::LOG_DIR . Task1::LOG_FILENAME, 'w');
        fclose($f);
    }

    static function squareArea($side): float|int { return $side ** 2; }

    static function squarePerimeter($side): float|int { return 4 * $side; }

    static function rectangleArea($sideA, $sideB): float|int { return $sideA * $sideB; }

    static function rectanglePerimeter($sideA, $sideB): float|int { return ($sideA + $sideB) * 2; }

    static function triangleArea($sideA, $sideB): float|int { return ($sideA * $sideB) / 2; }

    static function trianglePerimeter($sideA, $sideB, $sideC): float|int { return $sideA + $sideB + $sideC; }
}