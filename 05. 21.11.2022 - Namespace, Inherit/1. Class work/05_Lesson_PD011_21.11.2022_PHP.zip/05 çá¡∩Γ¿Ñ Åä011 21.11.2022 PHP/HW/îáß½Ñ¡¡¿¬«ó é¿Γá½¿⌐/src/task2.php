<?php

class Task2
{
    const UPLOAD_ERRORS_MSG = [
        UPLOAD_ERR_FORM_SIZE  => "Ошибка. Превышен допустимый размер файла",
        UPLOAD_ERR_INI_SIZE   => "Ошибка. Превышен допустимый размер файла",
        UPLOAD_ERR_CANT_WRITE => "Ошибка. Не удалось записать файл",
        UPLOAD_ERR_NO_FILE    => "Ошибка. Файл не был загружен",
        UPLOAD_ERR_NO_TMP_DIR => "Ошибка. Отсутствует временная директория",
        UPLOAD_ERR_EXTENSION  => "Ошибка. Загрузка была остановлена",
        UPLOAD_ERR_PARTIAL    => "Ошибка. Файл был загружен не полностью"
    ];
    const MAX_FILE_SIZE = 2097152;
    const VALID_MIME = "text/plain";
    const UPLOAD_DIR = "../uploaded/";

    static function uploadFileHandle(): string
    {
        $fileTmp = $_FILES['upload_file']['tmp_name'];

        if ($_FILES && $_FILES['upload_file']['error'] != UPLOAD_ERR_OK)
            throw new RuntimeException(Task2::UPLOAD_ERRORS_MSG[$_FILES['upload_file']['error']]);

        if (mime_content_type($fileTmp) != Task2::VALID_MIME)
            throw new RuntimeException("Допустимы только текстовые файлы");

        if ($_FILES['upload_file']['size'] > Task2::MAX_FILE_SIZE)
            throw new RuntimeException("Максимально допустимый размер файла для загрузки - " . Task2::MAX_FILE_SIZE / 1048576 . " Mb");

        if (!file_exists(Task2::UPLOAD_DIR))
            mkdir(Task2::UPLOAD_DIR);

        $ext = pathinfo($_FILES['upload_file']['name'], PATHINFO_EXTENSION);
        // имя для сохраняемого файла
        $savedFile = sha1_file($fileTmp) . "." . $ext;

        if (!move_uploaded_file($fileTmp, Task2::UPLOAD_DIR . $savedFile))
            throw new RuntimeException("Не удалось сохранить файл");

        return $savedFile;
    }

    static function writeToFile($file, $data): void {
        $fd = fopen($file, 'a');
        fwrite($fd, $data);
        fclose($fd);
    }
}