<?php

class Task3
{
    const DATA_DIR = "../app_data/";
    const DATA_FILENAME = "planets.csv";


    static function loadPlanets(): array
    {
        $planets = array_map('str_getcsv', file(self::DATA_DIR . self::DATA_FILENAME));
        return array_map(function ($values) {return new Planet(...$values);}, $planets);
    }

    static function orderPlanets(&$planets, $prop): void
    {
        $cmp = match ($prop) {
            'name' => function($a, $b) { return strcmp($a->getName(), $b->getName()); },
            'distance' => function($a, $b) { return $a->getAvgSunDistance() <=> $b->getAvgSunDistance(); },
            'mass' => function($a, $b) { return $a->getMass() <=> $b->getMass(); }
        };

        usort($planets, $cmp);
    }
}