<!-- настройка параметра -->
<?php $__env->startSection('title', 'Home/someValues'); ?>

<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <h1>Home/someValues</h1>
    <!-- Вывод параметра p1 -->
    <p>Случайное число, полученное из маршрута <?php echo e($id); ?></p>
    <p><a href="/">На главную</a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\12 Занятие ПД011 10.12.2022 PHP\CW\002_views_controllers\resources\views/home/get_param.blade.php ENDPATH**/ ?>