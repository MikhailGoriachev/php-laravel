<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home/someValues</title>
</head>
<body>
    <h1>Home/someValues</h1>
    <!-- Вывод скалярного параметра p1 -->
    <p>Случайное число <?php echo e($p1); ?></p>

    <!-- Вывод коллекции из параметра p2 -->
    <h3>Фрукты</h3>
    <ul>
        <?php $__currentLoopData = $p2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($p); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <p><a href="/">На главную</a></p>
</body>
</html>
<?php /**PATH D:\Students\ПД011\15 PHP\12 Занятие ПД011 10.12.2022 PHP\CW\002_views_controllers\resources\views/home/some_values.blade.php ENDPATH**/ ?>