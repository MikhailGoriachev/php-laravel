@extends('layouts.app')

<!-- настройка параметра -->
@section('title', 'Home/Index')

<!-- секция контент -->
@section('content')
    <h1>Страница home/index</h1>
    <ul>
        <li><a href="/">Переход на главную</a></li>
    </ul>
@endsection
