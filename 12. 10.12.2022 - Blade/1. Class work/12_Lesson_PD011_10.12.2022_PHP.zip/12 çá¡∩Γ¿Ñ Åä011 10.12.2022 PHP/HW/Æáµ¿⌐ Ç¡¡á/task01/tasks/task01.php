<?php

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,      // при ошибках выбрасывать исключение
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC  // запрос возвращает ассоциативный массив
];

// не подключается через use
class Applicant
{

    private int $id = 0;
    private string $surname = "";
    private string $name = "";
    private string $patronymic = "";
    private string $address = "";
    private int $year;
    private string $passport = "";

    function toTableRow(): string
    {

        return "<tr>
            
            <td>$this->id</td>
            <td>$this->surname</td>
            <td>$this->name</td>
            <td>$this->patronymic</td>
            <td>$this->address</td>
            <td>$this->year</td>
            <td>$this->passport</td>
        </tr>";

    }

}
class Exam
{

    private int $id;
    private $date;
    private string $title = "";
    private string $applicants_surname = "";
    private string $applicants_name = "";
    private string $applicants_patronymic = "";
    private string $passport = "";
    private string $examiners_surname = "";
    private string $examiners_name = "";
    private string $examiners_patronymic = "";
    private int $price = 0;
    private int $result = 0;

    function toTableRow(): string
    {

        return "<tr>
            
            <td>$this->id</td>
            <td>$this->date</td>
            <td>$this->title</td>
            <td>$this->applicants_surname $this->applicants_name $this->applicants_patronymic</td>
            <td>$this->passport</td>
            <td>$this->examiners_surname $this->examiners_name $this->examiners_patronymic</td>
            <td>$this->price</td>
            <td>$this->result</td>
        </tr>";

    }

    function toTableRow01(): string
    {

        return "<tr>
            
            <td>$this->id</td>
            <td>$this->date</td>
            <td>$this->title</td>
            <td>$this->applicants_surname $this->applicants_name $this->applicants_patronymic</td>
            <td>$this->passport</td>
            <td>$this->examiners_surname $this->examiners_name $this->examiners_patronymic</td>
            <td>$this->price</td>
            <td>$this->result</td>
            <td>
            <button class='btn btn-danger' id='$this->id'>Удалить</button>
            
            <script>
            
            $(function(){
            $('#$this->id').click(function(){
                $.get('../tasks/delete.php',   
                {'id':'$this->id'},
                function(data) {                
                    $('#result01').html(data);     
                });
            });
        });
</script>
            </td>
        </tr>";

    }
}

spl_autoload_register();

//если запросы с параметрами
if (isset($_POST['s1']) || isset($_POST['p']) || isset($_POST['p2']) || isset($_POST['s2'])) {

    if (isset($_POST['s1'])) {
        $value = $_POST['s1'];
    }

    if (isset($_POST['s2'])) {
        $query = "select * from exams_view where id_examiner = :id";
        $value = $_POST['s2'];
    }

    if (isset($_POST['p'])) {
        $value = $_POST['p'];
    }

    if (isset($_POST['p2'])) {
        $query = "select * from exams_view where id_applicant = :id";
        $value = $_POST['p2'];
    }

    if (isset($_POST['s1']) || isset($_POST['p'])) {

        $query = "select * from applicants_view where id = :id";
        $table = "<table class='table table-bordered'>
        <tr><th>Id</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Адрес</th><th>Год</th>
        <th>Паспорт</th></tr>";
        $class = 'Applicant';
    }

    if (isset($_POST['s2']) || isset($_POST['p2'])) {
        $table = "<table class='table table-bordered'>
        <tr><th>Id</th><th>Дата</th><th>Дисциплина</th><th>ФИО студента</th><th>Паспорт</th><th>ФИО экзаменатора</th>
        <th>Стоимость</th><th>Оценка</th></tr>";
        $class = 'Exam';
    }

    // подключение конфигурационного файла
    require_once '../db_config.php';

    // создание PDO объекта
    $pdo = new PDO($dsn, $user, $password, $options);

    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $value, PDO::PARAM_INT);
    $stmt->execute();
    view("", $stmt, $class, $table);
}

//если запросы без параметров
// ------------------------------------------------------------------------
//
// Хранимая процедура 5
// Выбирает информацию обо всех экзаменаторах
function doProc05($pdo): void
{
    $stmt = $pdo->prepare("call proc05()");
    $stmt->execute();

    // показать результаты
    $title = "<p class='fs-5 mt-5'>Выбирает информацию обо всех экзаменаторах: </p>";
    view($title, $stmt, 'Models\Examiner', "<table class='table table-bordered'><tr><th>Id</th><th>Фамилия
    </th><th>Имя</th><th>Отчество</th></tr>");
}

// ------------------------------------------------------------------------
//
// Хранимая процедура 6
// Вычисляет для каждого экзамена размер налога и зарплаты экзаменатора
function doProc06($pdo): void
{
    $stmt = $pdo->prepare("call proc06()");
    $stmt->execute();

    // показать результаты
    $title = "<p class='fs-5 mt-5'>Вычисляет для каждого экзамена размер налога и зарплаты экзаменатора: </p>";
    view($title, $stmt, 'Models\Proc06', "<table class='table table-bordered'><tr><th>Id</th><th>Налог</th><th>Зарплата</th></tr>");
}

// ------------------------------------------------------------------------
//
// Хранимая процедура 7
// Выполняет группировку по полю Год рождения. Для каждой группы определяет количество абитуриентов
function doProc07($pdo)
{
    $stmt = $pdo->prepare("call proc07()");
    $stmt->execute();

    // показать результаты
    $title = "<p class='fs-5 mt-5'>Выполняет группировку по полю Год рождения. Для каждой группы определяет количество абитуриентов: </p>";
    view($title, $stmt, 'Models\Proc07', "<table class='table table-bordered'><tr><th>Id</th><th>Год</th><th>Кол-во</th></tr>");
}

// ------------------------------------------------------------------------
//
// Хранимая процедура 8
// Выполняет группировку по полю Дата сдачи экзамена. Для каждой даты определяет среднее значения по полю Оценка
function doProc08($pdo)
{
    $stmt = $pdo->prepare("call proc08()");
    $stmt->execute();

    // показать результаты
    $title = "<p class='fs-5 mt-5'>Выполняет группировку по полю Дата сдачи экзамена. Для каждой даты определяет среднее значения по полю Оценка: </p>";
    view($title, $stmt, 'Models\Proc08', "<table class='table table-bordered'><tr><th>Дата</th><th>Оценка</th></tr>");
}

// ------------------------------------------------------------------------
//
// Таблица Экзамены
function viewExams($pdo):void{

    $table = "<table class='table table-bordered'>
        <tr><th>Id</th><th>Дата</th><th>Дисциплина</th><th>ФИО студента</th><th>Паспорт</th><th>ФИО экзаменатора</th>
        <th>Стоимость</th><th>Оценка</th></tr>";

    $stmt = $pdo->prepare("select * from exams_view ORDER BY id;");
    $stmt->execute();

    // показать результаты
    $title = "<p class='fs-5 mt-5'>Таблица Экзамены: </p>";

    // настроить режим вывода результата
    $stmt->setFetchMode(PDO::FETCH_CLASS, 'Exam');

    echo $title;
    echo $table;

    while ($row = $stmt->fetch()) {
        echo $row->toTableRow01();
    }
    echo "</table>";

    // необходимо для повторного использования запроса
    $stmt->closeCursor();
}

// ------------------------------------------------------------------------
//
// выводим выборку запроса
function view($title, $stmt, $class, $table): void
{
    // настроить режим вывода результата
    $stmt->setFetchMode(PDO::FETCH_CLASS, $class);

    echo $title;
    echo $table;

    while ($row = $stmt->fetch()) {
        echo $row->toTableRow();
    }
    echo "</table>";

    // необходимо для повторного использования запроса
    $stmt->closeCursor();
} // view

