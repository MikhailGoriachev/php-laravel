<?php

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,      // при ошибках выбрасывать исключение
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC  // запрос возвращает ассоциативный массив
];

$date = $_POST['date'];
$d = $_POST['d'];
$p = $_POST['p'];
$e = $_POST['e'];
$price = $_POST['price'];
$result = $_POST['result'];

$query = 'INSERT INTO `results_of_exams_tatsiy_anna`.`exams`
(
`date`,
`id_discipline`,
`id_applicant`,
`id_examiner`,
`price`,
`result`)
VALUES(

:date,
:id_discipline,
:id_applicant,
:id_examiner,
:price,
:result);';

// подключение конфигурационного файла
require_once '../db_config.php';

// создание PDO объекта
$pdo = new PDO($dsn, $user, $password, $options);

$stmt = $pdo->prepare($query);
$stmt->bindParam(':date', $date, PDO::PARAM_STR);
$stmt->bindParam(':id_discipline', $d, PDO::PARAM_INT);
$stmt->bindParam(':id_applicant', $p, PDO::PARAM_INT);
$stmt->bindParam(':id_examiner', $e, PDO::PARAM_INT);
$stmt->bindParam(':price', $price, PDO::PARAM_INT);
$stmt->bindParam(':result', $result, PDO::PARAM_INT);
$stmt->execute();

echo "<p class='fs-5 mt-5'>Запись добавлена</p>";