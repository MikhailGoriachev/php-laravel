<?php

$query =  $_GET['query'];

// подключение конфигурационного файла
require_once '../db_config.php';

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,      // при ошибках выбрасывать исключение
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC  // запрос возвращает ассоциативный массив
];

// создание PDO объекта
$pdo = new PDO($dsn, $user, $password, $options);

$stmt = $pdo->query($query);
$result = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

echo json_encode($result);