use results_of_exams_tatsiy_anna;

delimiter ::

-- удаляем функции если они существуют 
drop procedure if exists proc03::
drop procedure if exists proc04::
drop procedure if exists proc05::
drop procedure if exists proc06::
drop procedure if exists proc07::
drop procedure if exists proc08::

-- Хранимая функция 3  
-- Выбирает информацию об экзаменах, сданных абитуриентом с заданным номером/серией паспорта 
create procedure proc03(in p varchar(10)) 
begin
		select * from exams_view where passport like p;
end::

-- Хранимая функция 4
-- Выбирает информацию об абитуриенте с заданным номером/серией паспорта.  
create procedure proc04(in p varchar(10)) 
begin
		select *  from applicants_view where passport like p;
end::

-- Хранимая функция 5
-- Выбирает информацию обо всех экзаменаторах 
create procedure proc05() 
begin
		select * from examiners_view;
end::

-- Хранимая функция 6 
-- Вычисляет для каждого экзамена размер налога (Налог=Размер оплаты*13%) и зарплаты экзаменатора 
-- (Зарплата=Размер оплаты - Налог). Сортировка по полю Код экзаменатора 
create procedure proc06() 
begin
		select 
			id, 
			price*0.13 as tax, 
			price-price*0.13 as salary 
        from exams_view 
        order by id_examiner;
end::

-- Хранимая функция 7
-- Выполняет группировку по полю Год рождения в таблице АБИТУРИЕНТЫ. Для каждой группы определяет 
-- количество абитуриентов (итоги по полю Код абитуриента) 
create procedure proc07() 
begin
		select 
			`year`, 
			count(id) as count
        from applicants_view 
        group by `year`;
end::

-- Хранимая функция 8 
-- Выполняет группировку по полю Дата сдачи экзамена в таблице ЭКЗАМЕНЫ. Для каждой даты определяет
-- среднее значения по полю Оценка 
create procedure proc08() 
begin
		select 
			`date`, 
			avg(result) as avg_result
			from exams_view 
        group by `date`;
end::

delimiter ;



