
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_28.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../lib/js/bootstrap.bundle.min.js"></script>
    <script src='../lib/js/jquery-3.6.0.min.js'></script>

</head>
<body>

<?php
// активность страниц
$activePage01 = "active";
$activeIndex = $activePage02 = "";

// загрузка панели навигации
include_once "shared/_header.php";
?>

<main class="container-fluid">

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-4 bg-white m-3 border-warning-top border-warning-bottom">

            <div class="justify-content-end d-flex">

                <a class="btn btn-primary me-2 mt-2"  href="addForm.php" style="width: 200px">Добавить запись</a>

            </div>

            <?php

            // подключение конфигурационного файла
            require_once '../db_config.php';
            require_once '../tasks/task01.php';

            // создание PDO объекта
            $pdo = new PDO($dsn, $user, $password, $options);

            viewExams($pdo);

            ?>

            <div id="result01"></div>

        </div>

    </div>

</main>

<!-- загрузка подвала страницы -->
<?php include "shared/_footer.php" ?>

</body>
</html>
