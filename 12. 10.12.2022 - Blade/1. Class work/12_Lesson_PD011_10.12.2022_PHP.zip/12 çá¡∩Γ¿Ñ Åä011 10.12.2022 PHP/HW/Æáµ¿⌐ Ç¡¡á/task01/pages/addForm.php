
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_28.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../lib/js/bootstrap.bundle.min.js"></script>
    <script src='../lib/js/jquery-3.6.0.min.js'></script>

</head>
<body>

<?php
// активность страниц
$activePage01 = $activeIndex = $activePage02 = "";

// загрузка панели навигации
include_once "shared/_header.php";
?>

<main class="container-fluid">

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-4 bg-white m-3 border-warning-top border-warning-bottom">


            <p class='fs-5 mt-5'>Добавить экзамен: </p>

            <form id="form" name="form" method="post" class=" ms-4 m-2 w-50">

                <div class="mt-3">
                    <label class="form-label" for="date">Дата</label>
                    <input class="form-control" type="date" name="date" id="date" required>
                </div>

                <select id="d"  name="d" class="form-select mt-3" required>
                    <option selected>Выберите дисциплину</option>
                    <script>
                        $(function(){

                            // получение данных от сервера в формате JSON
                            $.get(
                                '../tasks/get.php',
                                {'query':'select id, title from disciplines'},
                                function(data) {
                                    $.each(data, function(key, val) {
                                        // отображаем val - название, но на сервере получаем key - ид
                                        $('#d').append(`<option value="${key}">${val}</option>`);
                                    });
                                },
                                'json'  // формат получаемых данных
                            );
                        });
                    </script>
                </select>

                <select id="p"  name="p" class="form-select mt-3" required>
                    <option selected>Выберите  номер/серию паспорта студента</option>
                    <script>
                        $(function(){

                            // получение данных от сервера в формате JSON
                            $.get(
                                '../tasks/get.php',
                                {'query':'select id, passport from applicants'},
                                function(data) {
                                    $.each(data, function(key, val) {
                                        // отображаем val - название, но на сервере получаем key - ид
                                        $('#p').append(`<option value="${key}">${val}</option>`);
                                    });
                                },
                                'json'  // формат получаемых данных
                            );
                        });
                    </script>
                </select>

                <select id="e"  name="e" class="form-select mt-3" required>
                    <option selected>Выберите экзаменатора</option>
                    <script>
                        $(function(){

                            // получение данных от сервера в формате JSON
                            $.get(
                                '../tasks/get.php',
                                {'query':'select id, surname as full_name from examiners_view'},
                                function(data) {
                                    $.each(data, function(key, val) {
                                        // отображаем val - название, но на сервере получаем key - ид
                                        $('#e').append(`<option value="${key}">${val}</option>`);
                                    });
                                },
                                'json'  // формат получаемых данных
                            );
                        });
                    </script>
                </select>

                <div class="mt-3">
                    <label for="price">Стоимость</label>
                    <input class="form-control" type="number" name="price" id="price" min="1000" required>
                </div>

                <div class="mt-3">
                    <label for="result">Оценка</label>
                    <input class="form-control" type="number" name="result" id="result" min="2" max="5" required>
                </div>

                <div class="d-flex justify-content-end">
                    <input class="btn btn-primary mt-3" type="submit" value="Добавить"/>
                </div>

            </form>

            <script>
                $("#form").submit(function(event) {
                    // Предотвращаем обычную отправку формы
                    event.preventDefault();

                    // отправка AJAX-запроса
                    $.post('../tasks/add.php',

                        // объект JavaScript с полями, соответствующими элементам
                        // формы
                        {'date':$('#date').val(),'d':$('#d').val(),'p':$('#p').val(),'e':$('#e').val(),'price':$('#price').val(),'result':$('#result').val()},

                        // функция обратного вызова сработает после получения
                        // данных от сервера
                        function(data) {
                            $('#result01').html(data);
                        }
                    );

                });
            </script>

            <div id="result01" class="m-4"></div>


        </div>

    </div>

</main>

<!-- загрузка подвала страницы -->
<?php include "shared/_footer.php" ?>

</body>
</html>

