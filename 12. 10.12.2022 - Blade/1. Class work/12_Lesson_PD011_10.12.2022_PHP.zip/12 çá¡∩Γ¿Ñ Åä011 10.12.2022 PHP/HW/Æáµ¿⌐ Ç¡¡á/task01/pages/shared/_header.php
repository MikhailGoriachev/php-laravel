<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top" xmlns="http://www.w3.org/1999/html"
     xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
    <div class="container-fluid">
        <div style="width: 70%; margin: auto;">
            <div class="navbar-collapse" id="appNavbar-1">
                <ul class="navbar-nav fs-4">
                    <li class="nav-item pt-1">
                        <a class="nav-link <?= $activeIndex ?>" href="/index.php">Запросы без параметров</a>
                    </li>


                    <li class="nav-item pt-1 ">
                            <a class="nav-link <?= $activePage02 ?>" href="/pages/page02.php">Запросы c параметрами</a>
                    </li>

                    <li class="nav-item pt-1 ps-3">
                        <a class="nav-link <?= $activePage01 ?>" href="/pages/page01.php">Экзамены</a>
                    </li>

                </ul>
            </div>
        </div>
    </div>
</nav>