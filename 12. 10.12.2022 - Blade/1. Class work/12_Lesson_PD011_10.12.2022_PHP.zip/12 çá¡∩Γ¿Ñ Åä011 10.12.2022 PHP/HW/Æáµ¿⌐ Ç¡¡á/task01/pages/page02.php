
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Step_28.11.22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href="../lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../lib/js/bootstrap.bundle.min.js"></script>
    <script src='../lib/js/jquery-3.6.0.min.js'></script>


</head>
<body>

<?php
// активность страниц
$activePage02 = "active";
$activeIndex = $activePage01 = "";

// загрузка панели навигации
include_once "shared/_header.php";

?>

<main class="container-fluid">

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-4 bg-white m-3 border-warning-top border-warning-bottom">

            <p class=" ms-4 fs-5">Выбирает информацию об абитуриентах с заданной фамилией:</p>

            <form id="form1" class="ms-4 m-2 w-25">

                <select id="s1"  name="s1" class="form-select">
                    <option selected>Выберите фамилию</option>
                    <script>
                        $(function(){

                            // получение данных от сервера в формате JSON
                            $.get(
                                '../tasks/get.php',
                                {'query':'select id, surname from applicants_view'},
                                function(data) {
                                    $.each(data, function(key, val) {
                                        // отображаем val - название, но на сервере получаем key - ид
                                        $('#s1').append(`<option value="${key}">${val}</option>`);
                                    });
                                },
                                'json'  // формат получаемых данных
                            );
                        });
                    </script>
                </select>

                <div class="d-flex justify-content-end">
                <input class="btn btn-primary mt-2" type="submit" value="Отправить"/>
                </div>
            </form>

            <div id="result1" class="m-4 mb-5"></div>

            <p class="ms-4 m-1 fs-5">Выбирает информацию об абитуриенте с заданным номером/серией паспорта:</p>

            <form id="form2" class="ms-4 m-2 w-25">

                <select id="p"  name="p" class="form-select">
                    <option selected>Выберите номер/серию паспорта</option>
                    <script>
                        $(function(){

                            // получение данных от сервера в формате JSON
                            $.get(
                                '../tasks/get.php',
                                {'query':'select id, passport from applicants_view'},
                                function(data) {
                                    $.each(data, function(key, val) {
                                        // отображаем val - название, но на сервере получаем key - ид
                                        $('#p').append(`<option value="${key}">${val}</option>`);
                                    });
                                },
                                'json'  // формат получаемых данных
                            );
                        });
                    </script>
                </select>

                <div class="d-flex justify-content-end">
                    <input class="btn btn-primary mt-2" type="submit" value="Отправить"/>
                </div>
            </form>

            <div id="result2" class="m-4"></div>

            <p class="ms-4 m-1  mt-5 fs-5">Выбирает информацию об экзаменах, которые были приняты экзаменатором с заданной фамилией:</p>

            <form id="form3" class="ms-4 m-2 w-25">

                <select id="s2"  name="s2" class="form-select">
                    <option selected>Выберите фамилию</option>
                    <script>
                        $(function(){

                            // получение данных от сервера в формате JSON
                            $.get(
                                '../tasks/get.php',
                                {'query':'select id_examiner, examiners_surname from exams_view'},
                                function(data) {
                                    $.each(data, function(key, val) {
                                        // отображаем val - название, но на сервере получаем key - ид
                                        $('#s2').append(`<option value="${key}">${val}</option>`);
                                    });
                                },
                                'json'  // формат получаемых данных
                            );
                        });
                    </script>
                </select>

                <div class="d-flex justify-content-end">
                    <input class="btn btn-primary mt-2" type="submit" value="Отправить"/>
                </div>
            </form>

            <div id="result3" class="m-4"></div>

            <p class="ms-4 m-1 mt-5 fs-5">Выбирает информацию об экзаменах, сданных абитуриентом с заданным номером/серией паспорта:</p>

            <form id="form4" class="ms-4 m-2 w-25">

                <select id="p2"  name="p2" class="form-select">
                    <option selected>Выберите номер/серию паспорта</option>
                    <script>
                        $(function(){

                            // получение данных от сервера в формате JSON
                            $.get(
                                '../tasks/get.php',
                                {'query':'select id_applicant, passport from exams_view'},
                                function(data) {
                                    $.each(data, function(key, val) {
                                        // отображаем val - название, но на сервере получаем key - ид
                                        $('#p2').append(`<option value="${key}">${val}</option>`);
                                    });
                                },
                                'json'  // формат получаемых данных
                            );
                        });
                    </script>
                </select>

                <div class="d-flex justify-content-end">
                    <input class="btn btn-primary mt-2" type="submit" value="Отправить"/>
                </div>
            </form>

            <div id="result4" class="m-4"></div>

            <script>
                $("#form1").submit(function(event) {
                    // Предотвращаем обычную отправку формы
                    event.preventDefault();

                    // отправка AJAX-запроса
                    $.post('../tasks/task01.php',

                        // объект JavaScript с полями, соответствующими элементам
                        // формы
                        {'s1':$('#s1').val()},

                        // функция обратного вызова сработает после получения
                        // данных от сервера
                        function(data) {
                            $('#result1').html(data);
                        }

                    );

                });

                $("#form2").submit(function(event) {
                    // Предотвращаем обычную отправку формы
                    event.preventDefault();

                    // отправка AJAX-запроса
                    $.post('../tasks/task01.php',

                        // объект JavaScript с полями, соответствующими элементам
                        // формы
                        {'p':$('#p').val()},

                        // функция обратного вызова сработает после получения
                        // данных от сервера
                        function(data) {
                            $('#result2').html(data);
                        }

                    );

                });

                $("#form3").submit(function(event) {
                    // Предотвращаем обычную отправку формы
                    event.preventDefault();

                    // отправка AJAX-запроса
                    $.post('../tasks/task01.php',

                        // объект JavaScript с полями, соответствующими элементам
                        // формы
                        {'s2':$('#s2').val()},

                        // функция обратного вызова сработает после получения
                        // данных от сервера
                        function(data) {
                            $('#result3').html(data);
                        }

                    );

                });

                $("#form4").submit(function(event) {
                    // Предотвращаем обычную отправку формы
                    event.preventDefault();

                    // отправка AJAX-запроса
                    $.post('../tasks/task01.php',

                        // объект JavaScript с полями, соответствующими элементам
                        // формы
                        {'p2':$('#p2').val()},

                        // функция обратного вызова сработает после получения
                        // данных от сервера
                        function(data) {
                            $('#result4').html(data);
                        }

                    );

                });
            </script>

        </div>

    </div>

</main>

<!-- загрузка подвала страницы -->
<?php include "shared/_footer.php" ?>

</body>
</html>
