<?php

namespace Models;

//Вычисляет для каждого экзамена размер налога (Налог=Размер оплаты*13%) и зарплаты экзаменатора
//(Зарплата=Размер оплаты - Налог). Сортировка по полю Код экзаменатора

class Proc06{

    private int $id;
    private float $tax;
    private float $salary;

    function toTableRow() :string {

        return "<tr>
            
            <td>$this->id</td>
            <td>$this->tax</td>
            <td>$this->salary</td>
        </tr>";

    }
}