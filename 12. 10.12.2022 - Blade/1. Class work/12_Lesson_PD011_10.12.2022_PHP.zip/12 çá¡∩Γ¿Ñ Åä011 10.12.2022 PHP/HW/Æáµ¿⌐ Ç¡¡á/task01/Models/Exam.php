<?php

namespace Models;

class Exam{

    private int $id;
    private $date;
    private string $title = "";
    private string $applicants_surname = "";
    private string $applicants_name = "";
    private string $applicants_patronymic = "";
    private string $passport = "";
    private string $examiners_surname = "";
    private string $examiners_name = "";
    private string $examiners_patronymic = "";
    private int $price = 0;
    private int $result = 0;

    function toTableRow() :string {

        return "<tr>
            
            <td>$this->id</td>
            <td>$this->date</td>
            <td>$this->title</td>
            <td>$this->applicants_surname $this->applicants_name $this->applicants_patronymic</td>
            <td>$this->passport</td>
            <td>$this->examiners_surname $this->examiners_name $this->examiners_patronymic</td>
            <td>$this->price</td>
            <td>$this->result</td>
        </tr>";

    }
}