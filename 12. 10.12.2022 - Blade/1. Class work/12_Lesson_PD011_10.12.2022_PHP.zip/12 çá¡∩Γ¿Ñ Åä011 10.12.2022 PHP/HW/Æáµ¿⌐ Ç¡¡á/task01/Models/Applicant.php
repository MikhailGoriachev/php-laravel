<?php

namespace Models;

class Applicant{

    private int $id = 0;
    private string $surname = "";
    private string $name = "";
    private  string $patronymic = "";
    private  string $address = "";
    private  int $year;
    private  string $passport = "";

    function toTableRow() :string {

        return "<tr>
            
            <td>$this->id</td>
            <td>$this->surname</td>
            <td>$this->name</td>
            <td>$this->patronymic</td>
            <td>$this->address</td>
            <td>$this->year</td>
            <td>$this->passport</td>
        </tr>";

    }

}