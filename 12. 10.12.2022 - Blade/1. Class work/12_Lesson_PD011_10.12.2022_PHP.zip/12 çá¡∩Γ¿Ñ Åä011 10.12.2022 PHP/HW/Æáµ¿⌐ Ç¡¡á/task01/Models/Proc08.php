<?php

namespace Models;

/*Выполняет группировку по полю Дата сдачи экзамена в
таблице ЭКЗАМЕНЫ. Для каждой даты определяет среднее значения по
полю Оценка */

class Proc08{

    private $date;
    private float $avg_result;

    function toTableRow() :string {

        return "<tr>
            
            <td>$this->date</td>
            <td>$this->avg_result</td>
        </tr>";

    }
}