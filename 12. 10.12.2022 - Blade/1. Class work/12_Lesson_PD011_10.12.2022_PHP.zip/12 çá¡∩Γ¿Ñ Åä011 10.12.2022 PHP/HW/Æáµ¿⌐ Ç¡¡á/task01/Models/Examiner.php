<?php

namespace Models;

class Examiner{

    private int $id = 0;
    private int $id_person = 0;
    private string $surname = "";
    private string $name = "";
    private  string $patronymic = "";

    function toTableRow() :string {

        return "<tr>
            
            <td>$this->id</td>
            <td>$this->surname</td>
            <td>$this->name</td>
            <td>$this->patronymic</td>
        </tr>";

    }

}