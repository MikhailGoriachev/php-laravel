<?php

namespace Models;

class Proc07{

    private int $year;
    private int $count;

    function toTableRow() :string {

        return "<tr>
            
            <td>$this->year</td>
            <td>$this->count</td>
        </tr>";

    }

}