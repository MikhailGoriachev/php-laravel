<?php

// база данных
$db = 'results_of_exams_tatsiy_anna';

// DSN - Data Source Name
$dsn = "mysql:host=localhost;port=3306;dbname=$db;charset=utf8";

// пользователь БД
$user = 'root';

// пароль пользователя
// $password = 'jkfdhsdkj355JHGH3';
$password = '___sP123456890...';

