﻿

<?php $__env->startSection('title', 'Выражения. Ввод данных'); ?>

<?php $__env->startSection('evaluateActive', 'active'); ?>

<?php $__env->startSection('content'); ?>

    <div class="min-vh-100">
        <section class="w-50 mx-auto my-4 bg-light shadow-sm border rounded-3 p-3">


            <form action="/evaluate" method="post">
                <?php echo csrf_field(); ?>

                <h4 class="text-center mb-4">Выражения. Ввод данных</h4>

                
                <h5 class="text-center">Выражение 1</h5>

                <div class="row mb-4">

                    
                    <div class="col">
                        <div class="form-floating">
                            <input name="a" class="form-control" type="number" step="any" placeholder=" "
                                   value="<?php echo e($a); ?>" required>
                            <label class="form-label">Число &alpha;</label>
                        </div>
                    </div>

                    
                    <div class="col">
                        <div class="form-floating">
                            <input name="b" class="form-control" type="number" step="any" placeholder=" "
                                   value="<?php echo e($b); ?>" required>
                            <label class="form-label">Число &beta;</label>
                        </div>
                    </div>

                </div>

                
                <h5 class="text-center">Выражение 2</h5>

                <div class="row mb-4">

                    
                    <div class="col">
                        <div class="form-floating">
                            <input name="m" class="form-control" type="number" step="any" placeholder=" "
                                   value="<?php echo e($m); ?>" required>
                            <label class="form-label">Число m</label>
                        </div>
                    </div>

                    
                    <div class="col">
                        <div class="form-floating">
                            <input name="n" class="form-control" type="number" step="any" placeholder=" "
                                   value="<?php echo e($n); ?>" required>
                            <label class="form-label">Число n</label>
                        </div>
                    </div>

                </div>

                <div class="mt-5">
                    <input class="btn btn-primary w-10rem me-2" type="submit" value="Вычислить">
                    <a class="btn btn-secondary w-10rem" href="/">На главную</a>
                </div>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\13. 12.12.2022 -\2. Home work\home-work\resources\views/calculate/evaluateForm.blade.php ENDPATH**/ ?>