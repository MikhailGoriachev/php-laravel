<?php

namespace App\Models;

// В классе Worker должны быть следующие поля:
class Worker
{
    // идентификатор работника
    private int $id;

    // фамилия и инициалы работника;
    private string $fullName;

    // название занимаемой должности;
    private string $position;

    // пол (мужской или женский, другие варианты не требуются);
    private bool $gender;

    // год поступления на работу;
    private int $year;

    // имя файла с фотографией работника;
    private string $photo;

    // величина оклада работника;
    private int $salary;

    // метод вычисления стажа работника для текущей даты.
    public function experience() {

    }  // experience
} // class Worker
