<?php

namespace App\Models;

// работник
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class Worker
{
    public int $id;
    public string $fullName;
    public string $position;
    public bool $gender;
    public int $admissionYear;
    public string $img;
    public float $salary;

    // ctor
    public function __construct(int $id = 0, string $fullName = '', string $position = '', bool $gender = true, int $admissionYear = 0, string $img = '', float $salary = 0)
    {
        $this->id = $id;
        $this->fullName = $fullName;
        $this->position = $position;
        $this->gender = $gender;
        $this->admissionYear = $admissionYear;
        $this->img = $img;
        $this->salary = $salary;
    }

    // метод вычисления стажа работника для текущей даты
    public function calculateExperience(): int
    {
        return date('Y') - $this->admissionYear;
    } // calculateExperience

    //  php artisan storage:link
    // https://github.com/russsiq/laravel-docs-ru/blob/9.x/docs/filesystem.md#the-public-disk
    // вывод в строку таблицы
    public function toTableRow(bool $isColored = false, bool $isEdit = false)
    {
        $str = "<tr class='" . ($isColored ? 'bg-info' : '') . "'>
                    <td class='text-center'>
                         <img src='" . asset("storage/photos/$this->img") . "' alt='$this->img'/>
                    </td>
                    <td>$this->fullName</td>
                    <td>$this->position</td>
                    <td>" . ($this->gender ? 'Мужской' : 'Женский') . "</td>
                    <td class='text-center'>$this->admissionYear</td>
                    <td class='text-center'>" . $this->calculateExperience() . "</td>
                    <td class='text-center'>" . number_format($this->salary, 2, '.', ' ') . "</td>";
        if ($isEdit) {
            $str .= "<td>
                        <div class='row justify-content-center'>

                            <div class='col-sm-6'>
                                <a class='btn btn-outline-primary col-sm-12'  href='/edit/$this->id' title='Редактировать сведения о сотруднике'>
                                <i class='bi bi-pencil-fill'></i></a>
                            </div>

                           <form action='/delete' method='post' class='form-inline col-sm-6'>
                                " . csrf_field() . "
                                <button type='submit' name='id' value='" . $this->id . "' class='btn btn-outline-danger col-sm-12' title='Удалить сведения о работнике'>
                                <i class='bi bi-x-lg'></i>
                                </button>
                           </form>
                        </div>
                    </td>";
        }
        $str .= "</tr>";
        return $str;
    } // toTableRow

    // строка текстового файла
    public function toTxtRow()
    {
        $row = "Id: $this->id ФИО: $this->fullName Должность: $this->position Пол: ";
        $row .= $this->gender ? 'Мужской' : 'Женский';
        $row .= " Год поступления на работу: $this->admissionYear";
        $row .= " Величина оклада: " . number_format($this->salary, 2, '.', ' ') . " руб.";
        $row .= "Стаж: ";
        $row .= $this->calculateExperience();
        return $row;
    }

    // строка таблицы файла
    public function toFileTableRow()
    {
        // https://laravel.com/docs/9.x/helpers#strings-method-list
        $row =
             sprintf("│ %4d", $this->id) .
            " │ " . Str::padRight($this->fullName, 33) .
            " │ " . Str::padRight($this->position, 22) .
            " │ " . Str::padRight($this->gender ? 'Мужской' : 'Женский', 11) .
            " │ " . sprintf("%25d", $this->admissionYear) .
            " │ " . Str::padLeft(number_format($this->salary, 2, '.', ' '), 15) .
            " │ " . sprintf("%6d │", $this->calculateExperience());


        /*
        $row = Utils::mb_sprintf(  "│ %4d │ %33s │ %-22s │ %-11s │ %25d │ %15.2f │ %6d │",
            $this->id, $this->fullName, $this->position, $this->gender ? 'Мужской' : 'Женский', $this->admissionYear,
            $this->salary, $this->calculateExperience());
        */
        return $row;
    }


} // class Worker
