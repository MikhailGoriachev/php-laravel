<?php

namespace App\Models;

use Illuminate\Support\Collection;

class Utils
{
    static function mb_str_pad($input, $pad_length, $pad_string=" ", $pad_style=STR_PAD_RIGHT, $encoding="UTF-8") {
        return str_pad($input, strlen($input)-mb_strlen($input,$encoding)+$pad_length, $pad_string, $pad_style);
    }

    // инициализация коллекции
    static function init(): Collection
    {
        return collect([
            new Worker(1, 'Иванов И.И.', 'Инженер', true, random_int(2017,2022), Utils::generateImgNameByGender(true), random_int(25, 35) * 1000),
            new Worker(2, 'Петрова С.А.', 'Оператор', false, random_int(2017,2022), Utils::generateImgNameByGender(false), random_int(25, 35) * 1000),
            new Worker(3, 'Гончаров А.В.', 'Программист', true, random_int(2017,2022), Utils::generateImgNameByGender(true), random_int(25, 35) * 1000),
            new Worker(4, 'Гоняева О.И.', 'Программист', false, random_int(2017,2022), Utils::generateImgNameByGender(false), random_int(25, 35) * 1000),
            new Worker(5, 'Колков В.И.', 'Инженер', true, random_int(2017,2022), Utils::generateImgNameByGender(true), random_int(25, 35) * 1000),
            new Worker(6, 'Овчарова Л.В.', 'Оператор', false, random_int(2017,2022), Utils::generateImgNameByGender(false), random_int(25, 35) * 1000),
            new Worker(7, 'Ковалев А.М.', 'Инженер', true, random_int(2017,2022), Utils::generateImgNameByGender(true), random_int(25, 35) * 1000),
            new Worker(8, 'Михайлова И.В.', 'Инженер', false, random_int(2017,2022), Utils::generateImgNameByGender(false), random_int(25, 35) * 1000),
            new Worker(9, 'Антипов А.Д.', 'Оператор', true, random_int(2017,2022), Utils::generateImgNameByGender(true), random_int(25, 35) * 1000),
            new Worker(10, 'Величко Д.Д.', 'Инженер', false, random_int(2017,2022), Utils::generateImgNameByGender(false), random_int(25, 35) * 1000),
        ]);
    } // init

    // генерация имени файла фотографии
    static function generateImgNameByGender(bool $gender): string
    {
        return ($gender ? 'man_' : 'woman_') . str_pad(strval(rand(1, 10)), 3, "0", STR_PAD_LEFT) . '.jpg';
    }

    // заголовок таблицы
    static function headerTable()
    {
        $header =  "┌──────┬───────────────────────────────────┬────────────────────────┬─────────────┬───────────────────────────┬─────────────────┬────────┐\n";
        $header .= "│  Id  │    Фамилия и инициалы работника   │       Должность        │     Пол     │ Год поступления на работу │      Оклад      │  Стаж  │\n";
        $header .= "├──────┼───────────────────────────────────┼────────────────────────┼─────────────┼───────────────────────────┼─────────────────┼────────┤";
        return $header;
    } // headerTable

    // подвал таблицы
    static function footerTable() {
        return "└──────┴───────────────────────────────────┴────────────────────────┴─────────────┴───────────────────────────┴─────────────────┴────────┘";
    } // footerTable

    // https://www.php.net/manual/en/function.sprintf.php#89020
    static function mb_sprintf($format) {
        $argv = func_get_args() ;
        array_shift($argv) ;
        return self::mb_vsprintf($format, $argv) ;
    }

    /**
     * Works with all encodings in format and arguments.
     * Supported: Sign, padding, alignment, width and precision.
     * Not supported: Argument swapping.
     */
    static function mb_vsprintf($format, $argv, $encoding=null) {
        if (is_null($encoding))
            $encoding = mb_internal_encoding();

        // Use UTF-8 in the format so we can use the u flag in preg_split
        $format = mb_convert_encoding($format, 'UTF-8', $encoding);

        $newformat = ""; // build a new format in UTF-8
        $newargv = array(); // unhandled args in unchanged encoding

        while ($format !== "") {

            // Split the format in two parts: $pre and $post by the first %-directive
            // We get also the matched groups
            list ($pre, $sign, $filler, $align, $size, $precision, $type, $post) =
                preg_split("!\%(\+?)('.|[0 ]|)(-?)([1-9][0-9]*|)(\.[1-9][0-9]*|)([%a-zA-Z])!u",
                    $format, 2, PREG_SPLIT_DELIM_CAPTURE) ;

            $newformat .= mb_convert_encoding($pre, $encoding, 'UTF-8');

            if ($type == '') {
                // didn't match. do nothing. this is the last iteration.
            }
            elseif ($type == '%') {
                // an escaped %
                $newformat .= '%%';
            }
            elseif ($type == 's') {
                $arg = array_shift($argv);
                $arg = mb_convert_encoding($arg, 'UTF-8', $encoding);
                $padding_pre = '';
                $padding_post = '';

                // truncate $arg
                if ($precision !== '') {
                    $precision = intval(substr($precision,1));
                    if ($precision > 0 && mb_strlen($arg,$encoding) > $precision)
                        $arg = mb_substr($precision,0,$precision,$encoding);
                }

                // define padding
                if ($size > 0) {
                    $arglen = mb_strlen($arg, $encoding);
                    if ($arglen < $size) {
                        if($filler==='')
                            $filler = ' ';
                        if ($align == '-')
                            $padding_post = str_repeat($filler, $size - $arglen);
                        else
                            $padding_pre = str_repeat($filler, $size - $arglen);
                    }
                }

                // escape % and pass it forward
                $newformat .= $padding_pre . str_replace('%', '%%', $arg) . $padding_post;
            }
            else {
                // another type, pass forward
                $newformat .= "%$sign$filler$align$size$precision$type";
                $newargv[] = array_shift($argv);
            }
            $format = strval($post);
        }
        // Convert new format back from UTF-8 to the original encoding
        $newformat = mb_convert_encoding($newformat, $encoding, 'UTF-8');
        return vsprintf($newformat, $newargv);
    }
}
