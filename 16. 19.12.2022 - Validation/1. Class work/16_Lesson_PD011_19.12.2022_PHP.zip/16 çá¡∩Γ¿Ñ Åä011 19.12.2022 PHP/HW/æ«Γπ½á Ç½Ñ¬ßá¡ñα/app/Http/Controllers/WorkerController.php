<?php

namespace App\Http\Controllers;

use App\Models\Utils;
use App\Models\Worker;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;

class WorkerController extends Controller
{

    private Collection $workers_;
    // название файла данных
    private string $fileName_;

    private $disk_;

    // ctor
    public function __construct(string $fileName = 'workers.json', $driver = 'local')
    {
        $this->fileName_ = $fileName;
        $this->disk_ = Storage::disk($driver);

        if ($this->disk_->missing($this->fileName_) || $this->disk_->size($this->fileName_) === 2) {
            $this->workers_ = Utils::init();
            $this->writeToFile();

        } else
            $this->readFromFile();
    }

    // запись в файл
    private function writeToFile()
    {
        $this->disk_->put($this->fileName_, json_encode($this->workers_));
    } // writeToFile

    // чтение из файла
    private function readFromFile()
    {
        $workers = json_decode($this->disk_->get($this->fileName_), true);

        $this->workers_ = new Collection();

        foreach ($workers as $worker)
            $this->workers_->add(new Worker(
                $worker['id'], $worker['fullName'], $worker['position'],
                $worker['gender'], $worker['admissionYear'], $worker['img'],
                $worker['salary']));

    } // readFromFile

    // вывод массива с упорядочиванием фамилий по алфавиту;
    public function showWorkers()
    {
        $this->readFromFile();

        return view('worker/showWorkers', ['workers' => $this->workers_->sortBy('fullName'),
            'header' => 'Список работников']);
    } // showWorkers

    // вывод массива с выделением работников с окладами, равными минимальному, упорядочивание по алфавиту;
    public function showWorkersWithMinSalary()
    {
        $this->readFromFile();
        return view('worker/showWorkersWithMinSalary', ['workers' => $this->workers_->sortBy('salary'),
            'minSalary' => $this->workers_->min('salary')]);
    } // showWorkersWithMinSalary

    // вывод массива с выделением работников с окладами, равными максимальному, упорядочивание по должностям;
    public function showWorkersWithMaxSalary()
    {
        $this->readFromFile();
        return view('worker/showWorkersWithMaxSalary', ['workers' => $this->workers_->sortBy('position'),
            'maxSalary' => $this->workers_->max('salary')]);
    } // showWorkersWithMinSalary

    // форма для ввода стажа
    public function getFormExperienceInput()
    {
        return view('worker/expInput');
    } // getFormExperienceInput

    // вывод массива с выделением работников с превышением заданного стажа работы, упорядочивать массив по окладу.
    public function showByExp(Request $request)
    {
        $this->readFromFile();
        return view('worker/showByExp', ['workers' => $this->workers_->sortBy('salary'),
            'exp' => $request->input('exp')]);
    } // showByExp

    // удаление работника по id
    public function deleteById(Request $request)
    {
        $this->readFromFile();

        $id = $request->input('id');
        $this->workers_ = $this->workers_->filter(fn($worker) => $worker->id != $id);

        $this->writeToFile();

        return view('worker/showWorkers', ['workers' => $this->workers_->sortBy('salary'),
            'header' => 'Работник успешно удален']);
    } // deleteById

    // форма для добавления работника
    public function getAddForm()
    {
        return view('worker/editForm', ['worker' => new Worker()]);
    } // getAddForm

    // форма для редактирования
    public function getEditForm($id)
    {
        return view('worker/editForm', ['worker' => $this->workers_->firstWhere('id', $id)]);
    } // getEditForm

    // обновление работника
    public function update(Request $request)
    {
        $header = 'Работник успешно ';

        $fields = $request->all();

        $file = $request->file('photo');
        $file->storeAs('public/photos', $file->getClientOriginalName());
        // ссылка на работника в коллекции
        $worker = $this->workers_->firstWhere('id', $fields['id']);

        // работник не найден
        if ($worker === null) {
            $header .= 'добавлен';

            $this->workers_->add(new Worker());
            $worker = $this->workers_->firstWhere('id', $fields['id']);

            // добавляем работника под следующим id
            $id = (int)$this->workers_->max('id');
            $worker->id = ++$id;
        } else {
            $header .= 'отредактирован';
        }

        // обновление полей
        $worker->fullName = $fields['fullName'];
        $worker->position = $fields['position'];
        $worker->gender = $fields['gender'] == 'true';
        $worker->img = $file->getClientOriginalName();
        $worker->admissionYear = $fields['admissionYear'];
        $worker->salary = $fields['salary'];

        // запись в файл
        $this->writeToFile();

        return view('worker/showWorkers', ['workers' => $this->workers_->sortBy('fullName'),
            'header' => $header]);
    } // update

    // загрузка выборки работников с окладами, равными максимальному в текстовом формате
    public function downloadWorkersByMaxSalaryTextFile(float $maxSalary)
    {
        $fileName = 'max_salary_workers.txt';

        if ($this->disk_->exists($fileName))
            $this->disk_->delete($fileName);

        $workers = $this->workers_->filter(fn($worker) => $worker->salary === $maxSalary);

        foreach ($workers as $worker)
            $this->disk_->append($fileName, $worker->toTxtRow());

        return Storage::download($fileName);
    } // downloadWorkersByMaxSalaryTextFile

    // загрузка выборки работников с окладами, равными максимальному в табличном формате
    public function downloadWorkersByMaxSalaryTableFile(float $maxSalary)
    {
        $fileName = 'max_salary_workers_table.txt';

        if ($this->disk_->exists($fileName))
            $this->disk_->delete($fileName);

        $workers = $this->workers_->filter(fn($worker) => $worker->salary === $maxSalary);

        $this->disk_->append($fileName, Utils::headerTable());

        foreach ($workers as $worker)
            $this->disk_->append($fileName, $worker->toFileTableRow());

        $this->disk_->append($fileName, Utils::footerTable());

        return Storage::download($fileName);
    } // downloadWorkersByMaxSalaryTextFile

    // загрузка выборки работников с превышением заданного стажа в текстовом формате
    public function downloadWorkersByExceedingExpTextFile(int $exp)
    {
        $fileName = 'exceeding_experience_workers.txt';

        if ($this->disk_->exists($fileName))
            $this->disk_->delete($fileName);

        $workers = $this->workers_->filter(fn($worker) => $worker->calculateExperience() > $exp);

        foreach ($workers as $worker)
            $this->disk_->append($fileName, $worker->toTxtRow());

        return Storage::download($fileName);
    } // downloadWorkersByMaxSalaryTextFile

    // загрузка выборки работников  с превышением заданного стажа в текстовом формате
    public function downloadWorkersByExceedingExpTableFile(int $exp)
    {
        $fileName = 'exceeding_experience_workers_table.txt';

        if ($this->disk_->exists($fileName))
            $this->disk_->delete($fileName);

        $workers = $this->workers_->filter(fn($worker) => $worker->calculateExperience() > $exp);

        $this->disk_->append($fileName, Utils::headerTable());

        foreach ($workers as $worker)
            $this->disk_->append($fileName, $worker->toFileTableRow());

        $this->disk_->append($fileName, Utils::footerTable());

        return Storage::download($fileName);
    } // downloadWorkersByExceedingExpTableFile

}
