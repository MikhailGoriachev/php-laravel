@extends('layouts.app')

@section('experience', 'active')
@section('title', "Выделены работники с стажем выше $exp")

@section('content')

    <div class="row mt-5 justify-content-end my-5">
        <a class='btn btn-outline-primary col-sm-3 me-2' href='/download-txt-exceeding-exp/{{$exp}}' >
            <i class="bi bi-file-earmark-arrow-down"></i> Скачать текстовый формат</a>

        <a class='btn btn-outline-primary col-sm-3' href='/download-table-exceeding-exp/{{$exp}}' >
            <i class="bi bi-table"></i> Скачать табличный формат</a>
    </div>

    <table class="table table-hover mt-5 mx-auto">
        <thead class="text-center">
        <th>Фото</th>
        <th>ФИО</th>
        <th>Должность</th>
        <th>Пол</th>
        <th>Год поступления на работу</th>
        <th>Стаж</th>
        <th>Оклад</th>
        </thead>
        <tbody>
        @foreach($workers as $worker)
            {!! html_entity_decode(($worker->toTableRow($worker->calculateExperience() > $exp))) !!}
        @endforeach
        </tbody>
    </table>
@endsection
