<?php $__env->startSection('experience', 'active'); ?>
<?php $__env->startSection('title', 'Введите стаж для выделения'); ?>

<?php $__env->startSection('content'); ?>
    <form action="/exp" method="post" class="mt-5">
        <?php echo csrf_field(); ?>
        <div class="row my-5">
            <div class="col-sm col-sm-4 mx-auto">
                <div class="form-floating">
                    <input type="number" class="form-control" name="exp" id="exp" required
                           placeholder="Минимальное значение стажа">
                    <label for="exp">Минимальное значение стажа</label>
                </div>
            </div>
        </div>

        <div class="row">
            <button type="submit" class="btn btn-outline-success mx-auto col-sm-3">Отметить</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Академия Шаг\ПД011\15 PHP\15 Занятие ПД011 17.12.2022 PHP\Сотула Александр\resources\views/worker/expInput.blade.php ENDPATH**/ ?>