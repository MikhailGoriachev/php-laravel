<?php $__env->startSection('array', 'active'); ?>
<?php $__env->startSection('title', 'Ошибка'); ?>

<?php $__env->startSection('content'); ?>
    <h5 class="h5 text-center text-danger mt-5"><?php echo e($errorMessage); ?></h5>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Академия Шаг\ПД011\15 PHP\13 Занятие ПД011 12.12.2022 PHP\Сотула Александр\resources\views/calculate/exception.blade.php ENDPATH**/ ?>