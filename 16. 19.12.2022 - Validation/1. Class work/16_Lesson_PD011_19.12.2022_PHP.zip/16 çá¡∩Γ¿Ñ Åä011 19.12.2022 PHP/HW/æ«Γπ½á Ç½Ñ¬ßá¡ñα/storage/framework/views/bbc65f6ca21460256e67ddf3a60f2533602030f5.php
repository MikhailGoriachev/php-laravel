<?php $__env->startSection('minSalary', 'active'); ?>
<?php $__env->startSection('title', "Выделены работники с минимальным окладом равным $minSalary руб."); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-hover mt-5 mx-auto">
        <thead class="text-center">
        <th>Фото</th>
        <th>ФИО</th>
        <th>Должность</th>
        <th>Пол</th>
        <th>Год поступления на работу</th>
        <th>Стаж</th>
        <th>Оклад</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo html_entity_decode(($worker->toTableRow($minSalary === $worker->salary))); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Академия Шаг\ПД011\15 PHP\15 Занятие ПД011 17.12.2022 PHP\Сотула Александр\resources\views/worker/showWorkersWithMinSalary.blade.php ENDPATH**/ ?>