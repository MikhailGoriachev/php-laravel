<?php $__env->startSection('workers', 'active'); ?>
<?php $__env->startSection('title', ($worker->id === 0 ? 'Добавить' : 'Редактировать') . ' данные'); ?>

<?php $__env->startSection('content'); ?>
    <form action="/update" method="post" class="w-50 mx-auto mt-5" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" id="id" name="id" value="<?php echo e($worker->id); ?>">

        <div class="form-floating ">
            <input type="text" class="form-control" name="fullName" id="fullName" required
                   placeholder="Имя работника" value="<?php echo e($worker->fullName); ?>">
            <label for="fullName">Имя работника</label>
        </div>

        <div class="form-floating mt-5">
            <select class="form-select" name="position" id="position">
                <option <?php echo e($worker->position == "Оператор" ? "selected=selected" : ""); ?> value="Оператор">Оператор</option>
                <option <?php echo e($worker->position == "Программист" ? "selected=selected" : ""); ?> value="Программист">Программист</option>
                <option <?php echo e($worker->position == "Инженер" ? "selected=selected" : ""); ?> value="Инженер">Инженер</option>
            </select>
            <label for="position">Должность</label>
        </div>

        <div class="form-floating mt-5">
            <select class="form-select" name="gender" id="gender">
                <option <?php echo e($worker->gender == 1 ? "selected=selected" : ""); ?> value="true">Мужской</option>
                <option <?php echo e($worker->gender == 0 ? "selected=selected" : ""); ?> value="false">Женский</option>
            </select>
            <label for="gender">Пол</label>
        </div>

        <div class="form-floating mt-5">
            <input type="number" class="form-control" name="admissionYear" id="admissionYear" required
                   placeholder="Год приема на работу" value="<?php echo e($worker->admissionYear); ?>">
            <label for="admissionYear">Год приема на работу</label>
        </div>

        <div class="form-floating mt-5">
            <input type="number" class="form-control" name="salary" id="salary" required
                   placeholder="Оклад" value="<?php echo e($worker->salary); ?>">
            <label for="salary">Оклад</label>
        </div>

        <div class="row mt-5">
            <label class="form-label col-sm-3" for="photo">Выберите фотографию</label>
            <div class="col-sm-9">
                <input class="form-control" type="file" name="photo" id="photo" required>
            </div>
        </div>

        <div class="row mt-5">
            <button type="submit" class="btn btn-outline-success mx-auto col-sm-3"><?php echo e($worker->id === 0 ? 'Добавить' : 'Редактировать'); ?></button>
        </div>
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Академия Шаг\ПД011\15 PHP\15 Занятие ПД011 17.12.2022 PHP\Сотула Александр\resources\views/worker/editForm.blade.php ENDPATH**/ ?>