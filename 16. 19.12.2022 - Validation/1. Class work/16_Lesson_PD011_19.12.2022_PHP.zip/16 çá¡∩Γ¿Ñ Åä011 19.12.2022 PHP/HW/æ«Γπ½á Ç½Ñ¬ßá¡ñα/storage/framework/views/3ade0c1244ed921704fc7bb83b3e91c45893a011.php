<?php $__env->startSection('maxSalary', 'active'); ?>
<?php $__env->startSection('title', "Выделены работники с максимальным окладом равным $maxSalary руб."); ?>

<?php $__env->startSection('content'); ?>

    <div class="row mt-5 justify-content-end my-5">
        <a class='btn btn-outline-primary col-sm-3 me-2' href='/download-txt-max-salary/<?php echo e($maxSalary); ?>' >
            <i class="bi bi-file-earmark-arrow-down"></i>Скачать текстовый файл</a>

        <a class='btn btn-outline-primary col-sm-3' href='/download-table-max-salary/<?php echo e($maxSalary); ?>' >
            <i class="bi bi-table"></i> Скачать табличный формат</a>
    </div>

    <table class="table table-hover mt-5 mx-auto">
        <thead class="text-center">
        <th>Фото</th>
        <th>ФИО</th>
        <th>Должность</th>
        <th>Пол</th>
        <th>Год поступления на работу</th>
        <th>Стаж</th>
        <th>Оклад</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo html_entity_decode(($worker->toTableRow($maxSalary === $worker->salary))); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Академия Шаг\ПД011\15 PHP\15 Занятие ПД011 17.12.2022 PHP\Сотула Александр\resources\views/worker/showWorkersWithMaxSalary.blade.php ENDPATH**/ ?>