<?php

// подключение собственных контроллеров
use App\Http\Controllers\HomeController;
use App\Http\Controllers\WorkerController;

use Illuminate\Support\Facades\Route;

// путь к действию index в контроллере HomeController
Route::get('/', [HomeController::class, 'index']);
Route::get('/index', [HomeController::class, 'index']);

// путь к действию about в контроллере HomeController
Route::get('/about', [HomeController::class, 'about']);

// отображение работников
Route::get('/workers', [WorkerController::class, 'showWorkers']);
Route::get('/minSalary', [WorkerController::class, 'showWorkersWithMinSalary']);
Route::get('/maxSalary', [WorkerController::class, 'showWorkersWithMaxSalary']);

// форма ввода стажа
Route::get('/exp-input', [WorkerController::class, 'getFormExperienceInput']);

// обработка post запроса формы ввода стажа
Route::post('/exp', [WorkerController::class, 'showByExp']);

// обработка удаления
Route::post('/delete', [WorkerController::class, 'deleteById']);

// форма редактирования
Route::get('/edit/{n}', [WorkerController::class, 'getEditForm']);

// форма добавления
Route::get('/add', [WorkerController::class, 'getAddForm']);

// обработка формы добавления/редактирования
Route::post('/update', [WorkerController::class, 'update']);

// скачивание выборки работников с окладами, равными максимальному в текстовом формате
Route::get('/download-txt-max-salary/{n}', [WorkerController::class, 'downloadWorkersByMaxSalaryTextFile']);

// скачивание выборки работников с окладами, равными максимальному в текстовом формате
Route::get('/download-table-max-salary/{n}', [WorkerController::class, 'downloadWorkersByMaxSalaryTableFile']);

// скачивание выборки работников с превышением заданного стажа в текстовом формате
Route::get('/download-txt-exceeding-exp/{n}', [WorkerController::class, 'downloadWorkersByExceedingExpTextFile']);

// скачивание выборки работников с превышением заданного стажа в табличном формате
Route::get('/download-table-exceeding-exp/{n}', [WorkerController::class, 'downloadWorkersByExceedingExpTableFile']);

