<?php $__env->startSection('active_person', 'active'); ?>

<!-- секция контента -->
<?php $__env->startSection('main_part'); ?>
    <div class="d-flex my-3">
        <h3>Демонстрация <u>записи</u>/<u>чтения</u> объекта в файл/из файла</h3>
        <a href="/add-person" class="ms-3 btn btn-success">Добавить данные</a>
    </div>
    <div class="row my-3">
        <h4>Из файла прочитано:</h4>
        <pre>
        <?php echo e($content); ?>

        </pre>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\15 Занятие ПД011 17.12.2022 PHP\CW\app-download-upload-validation\resources\views/person/demo.blade.php ENDPATH**/ ?>