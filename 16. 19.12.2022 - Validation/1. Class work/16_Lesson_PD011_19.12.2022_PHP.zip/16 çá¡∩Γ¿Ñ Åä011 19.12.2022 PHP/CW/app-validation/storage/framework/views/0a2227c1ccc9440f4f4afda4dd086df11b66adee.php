<?php $__env->startSection('active_upload', 'active'); ?>

<!-- секция контента -->
<?php $__env->startSection('main_part'); ?>
    <h4>Файл загружен</h4>
    <p>Имя файла от клиента: <strong><?php echo e($clientOriginalName); ?></strong></p>
    <p>Имя файла на сервере: <strong><?php echo e($path); ?></strong></p>
    <p>URL файла на сервере, для использования: <strong><?php echo e($pathUrl); ?></strong></p>

    <h5>Что загружено:</h5>
    <img src="<?php echo e($pathUrl); ?>" alt="картинка, загруженная на сервер"/>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\16 Занятие ПД011 19.12.2022 PHP\CW\app-validation\resources\views/file-operation/upload-result.blade.php ENDPATH**/ ?>