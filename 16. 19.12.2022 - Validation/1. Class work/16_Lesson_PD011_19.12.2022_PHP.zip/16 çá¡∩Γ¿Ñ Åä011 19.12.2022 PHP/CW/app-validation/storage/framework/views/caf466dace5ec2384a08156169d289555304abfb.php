<?php $__env->startSection('active_person', 'active'); ?>

<!-- секция контента -->
<?php $__env->startSection('main_part'); ?>
    <div class="w-50 mx-auto">
        <h4>Данные объекта класса Person, введенные в форму</h4>
        <h5>Строковое представление <u><?php echo e($person); ?></u></h5>
        <ul class="list-group w-50">
            <li class="list-group-item d-flex justify-content-between px-3">
                <span>Фамилия И.О:</span> <strong><?php echo e($person->fullName); ?></strong>
            </li>
            <li class="list-group-item d-flex justify-content-between px-3">
                <span>Возраст, лет:</span> <strong><?php echo e($person->age); ?></strong>
            </li>
            <li class="list-group-item d-flex justify-content-between px-3">
                <span>Оклад, руб:</span> <strong><?php echo e($person->salary); ?></strong>
            </li>
        </ul>

        




    </div>

    <div class="w-50 mx-auto">
        <h4>Данные объекта класса Person, прочтанные из файла CSV</h4>
        <h5>Строковое представление <u><?php echo e($p1); ?></u></h5>
        <ul class="list-group w-50">
            <li class="list-group-item d-flex justify-content-between px-3">
                <span>Фамилия И.О:</span> <strong><?php echo e($p1->fullName); ?></strong>
            </li>
            <li class="list-group-item d-flex justify-content-between px-3">
                <span>Возраст, лет:</span> <strong><?php echo e($p1->age); ?></strong>
            </li>
            <li class="list-group-item d-flex justify-content-between px-3">
                <span>Оклад, руб:</span> <strong><?php echo e($p1->salary); ?></strong>
            </li>
        </ul>






    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\16 Занятие ПД011 19.12.2022 PHP\CW\app-validation\resources\views/person/details-person.blade.php ENDPATH**/ ?>