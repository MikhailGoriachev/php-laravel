<!-- секция контент -->
<?php $__env->startSection('main_part'); ?>
    <h4 class="text-center my-5">Страница home/index</h4>

    <ul class="list-group w-50 mx-auto my-5">
        <li class="list-group-item">
            Операции с файлами
        </li>
        <li class="list-group-item">
            Скачивание файла с сервера
        </li>
        <li class="list-group-item">
            Загрузка файла на сервер
        </li>
        <li class="list-group-item">
            Использование загруженного на сервер файла
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\15 Занятие ПД011 17.12.2022 PHP\CW\app-download-upload\resources\views/home/index.blade.php ENDPATH**/ ?>