<?php $__env->startSection('active_person', 'active'); ?>

<!-- секция контента -->
<?php $__env->startSection('main_part'); ?>
    <div class="offset-2 col-5">
        <h4>Форма ввода данных для объекта класса <u>Person</u></h4>
        <form action="/handle-add-person" method="post" >
            
            <?php echo csrf_field(); ?>
            <div class="row my-3">
                <label class="form-label col-3" for="id_fullName">Фамилия И.О.:</label>
                <div class="col-9">
                    <input name="fullName" class="form-control <?php $__errorArgs = ['fullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           type="text"
                           id="id_fullName"
                           value="<?php echo e(old('fullName')); ?>">
                </div>
            </div>
            <div class="row my-3">
                <label class="form-label col-3" for="id_age">Возраст, лет:</label>
                <div class="col-9">
                    <input name="age" class="form-control <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           type="number" id="id_age"
                           value="<?php echo e(old('age')); ?>">
                </div>
            </div>
            <div class="row my-3">
                <label class="form-label col-3" for="id_salary">Оклад, руб.:</label>
                <div class="col-9">
                    <input name="salary"  class="form-control <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           type="number"
                           id="id_salary"
                           value="<?php echo e(old('salary')); ?>">
                </div>
            </div>

            <div class="my-3 row">
                <div class="offset-3 col-3 me-3">
                    <input class="btn btn-success" type="submit" value="Сохранить">
                </div>
                <div class="col-3">
                    <input class="btn btn-secondary" type="reset" value="Сбросить">
                </div>
            </div>
        </form>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\16 Занятие ПД011 19.12.2022 PHP\CW\app-validation\resources\views/person/add-form.blade.php ENDPATH**/ ?>