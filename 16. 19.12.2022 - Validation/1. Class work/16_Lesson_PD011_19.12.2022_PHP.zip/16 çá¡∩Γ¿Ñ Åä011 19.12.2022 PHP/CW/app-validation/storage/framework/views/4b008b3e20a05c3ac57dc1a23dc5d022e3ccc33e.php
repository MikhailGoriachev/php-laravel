<?php $__env->startSection('active_read', 'active'); ?>

<!-- секция контента -->
<?php $__env->startSection('main_part'); ?>
    <h3>Демонстрация <u>чтения</u> из файла</h3>
    <div>
        <h4>Из файла прочитано:</h4>
        <pre>
        <?php echo e($content); ?>

        </pre>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\15 Занятие ПД011 17.12.2022 PHP\CW\app-download-upload\resources\views/file-operation/read.blade.php ENDPATH**/ ?>