<?php

use App\Http\Controllers\CalculateController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// маршруты по заданию для HomeController

// путь к действию index контроллера home
Route::get('/', [ HomeController::class, 'index' ]);
Route::get('/home', [ HomeController::class, 'index' ]);
Route::get('/home/index', [ HomeController::class, 'index' ]);

// путь к действию about контроллера home
Route::get('/home/about', [ HomeController::class, 'about' ]);


// маршруты по заданию для CalculateController
Route::get('/calculate/variant13/{n?}', [ CalculateController::class, 'variant13' ]);
Route::get('/calculate/array17', [ CalculateController::class, 'array17' ]);
Route::get('/calculate/text7', [ CalculateController::class, 'text7' ]);
