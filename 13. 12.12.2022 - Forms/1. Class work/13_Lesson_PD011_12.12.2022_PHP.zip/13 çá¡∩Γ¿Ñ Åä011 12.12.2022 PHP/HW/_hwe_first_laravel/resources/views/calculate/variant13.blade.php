@extends('layouts.layout')

{{-- задать параметр шаблона - имя активной страницы--}}
@section('active_variant13', 'active')

<!-- секция контент -->
@section('main_part')
    <h4 class="text-center my-5">Вычисления выражений по заданию "Вариант 13"</h4>

    <div class="mb-5 text-center">
        <h5>Выражения для вычисления</h5>
        <img class="w-25" src="/images/variant13.png" >
    </div>

    <h4 class="text-center">Результаты вычислений</h4>
    <table class="table table-bordered table-striped w-75 mx-auto mb-5">
        <thead>
            <tr class="text-center">
                <th>Номер</th>
                <th>Параметр &alpha;</th>
                <th>Параметр &beta;</th>
                <th>Результат z<sub>1</sub></th>
                <th>Результат z<sub>2</sub></th>
                <th>Корректность</th>
            </tr>
        </thead>
        <tbody>
            @foreach($results as $result)
                <tr class="text-center">
                    <td>{{ $loop->iteration }} </td>
                    <td>{{ sprintf("%.5f", $result['a']) }} </td>
                    <td>{{ sprintf("%.5f", $result['b']) }} </td>
                    <td>{{ sprintf("%.5f", $result['z1']) }} </td>
                    <td>{{ sprintf("%.5f", $result['z2']) }} </td>
                    <td>{{ abs($result['z2'] - $result['z1']) < 1e-6?"":"не" }}корректно </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
