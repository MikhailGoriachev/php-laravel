<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// контроллео по заданию, реализаця простых обработок по заданию
class CalculateController extends Controller
{
    // GET calculate/variant13
    // выполните вычисления и вывод результатов для 5 случайных пар чисел,
    // не используйте модель
    public function variant13($n = 5) {
        // параметры выражения и результаты
        $results = [];

        // вычислеяем выражения и помещаем в массив
        for ($i = 0 ; $i < $n; ++$i) {
            $a = rand(-10, 10);
            $b = rand(-10, 10);

            $z1 = (sin($a) + cos(2 * $b - $a)) / (cos($a) - sin(2 * $b - $a));
            $z2 = (1 + sin(2 * $b)) / cos(2 * $b);

            // запись параметров и результатов в массив
            $results[$i]['a'] = $a;
            $results[$i]['b'] = $b;
            $results[$i]['z1'] = $z1;
            $results[$i]['z2'] = $z2;
        } // for $i

        // передача результатаов расчетов представлению
        return view("calculate.variant13", ['results'=>$results]);
    } // variant13

    // GET calculate/array17
    public function array17() {
        return view("calculate.array17");
    } // array17

    // GET calculate/text7
    public  function text7() {
        return view("calculate.text7");
    } // text7
}
