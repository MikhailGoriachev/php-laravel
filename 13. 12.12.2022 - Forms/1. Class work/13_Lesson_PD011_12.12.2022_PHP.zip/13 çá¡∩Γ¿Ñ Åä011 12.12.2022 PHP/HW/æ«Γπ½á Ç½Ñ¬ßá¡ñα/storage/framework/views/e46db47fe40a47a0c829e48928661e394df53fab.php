<?php $__env->startSection('array', 'active'); ?>
<?php $__env->startSection('title', 'Обработка массива'); ?>

<?php $__env->startSection('content'); ?>

    <div class="w-100 mt-4">
        <a href="#task" class="btn btn-outline-dark w-100 mb-4" data-bs-toggle="collapse">
            <strong>Задание</strong>
        </a>
        <div id="task" class="collapse">
            Выполните вычисления и вывода результата для массива случайных целых
            чисел, не используйте модель
            <ul>
                <li>вывести исходный массив</li>
                <li>определите количество положительных элементов массива;</li>
                <li>вычислите сумму элементов массива, расположенных после последнего элемента, равного нулю.</li>
                <li>преобразуйте массив таким образом, чтобы сначала располагались все элементы, равные нулю, а потом —
                    все остальные
                </li>
                <li>вывести преобразованный массив</li>
            </ul>
        </div>
    </div>

    <p class="mt-5"><b>Сгенерированный массив</b></p>
    <table class='w-50 table table-bordered mt-1'>
        <tr>
            <?php $__currentLoopData = $result['main']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($item); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>

    <p class="mt-5"><b>Количество положительных элементов: </b><?php echo e($result['count']); ?></p>

    <p class="mt-5"><b>Сумма элементов после последнего элемента равного нулю:</b> <?php echo e($result['sum']); ?></p>

    <p class="mt-5"><b>Преобразованный массив, по правилу сначала все элементы, равные нулю, а потом — все остальные</b>
    </p>
    <table class='w-50 table table-bordered mt-1'>
        <tr>
            <?php $__currentLoopData = $result['sorted']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($item); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Академия Шаг\ПД011\15 PHP\12 Занятие ПД011 10.12.2022 PHP\Сотула Александр\resources\views/calculate/array17.blade.php ENDPATH**/ ?>