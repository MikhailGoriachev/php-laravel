<?php $__env->startSection('equation', 'active'); ?>
<?php $__env->startSection('title', 'Уравнение'); ?>

<?php $__env->startSection('content'); ?>

    <div class="w-100 mt-4">
        <a href="#task" class="btn btn-outline-dark w-100 mb-4" data-bs-toggle="collapse">
            <strong>Задание</strong>
        </a>
        <div id="task" class="collapse">
            Выполните вычисления и вывод результатов для 5 случайных пар чисел (выводите также изображение расчетного
            выражения), не используйте модель
        </div>
    </div>

    <img class="rounded mx-auto d-block mt-5" src="../img/task1.jpg" alt="task1">

    <table class="table table-hover w-50 mx-auto mt-5">
        <thead class="text-center">
            <th>&alpha;</th>
            <th>&beta;</th>
            <th>z<sub>1</sub></th>
            <th>z<sub>2</sub></th>
        </thead>
        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($row['a']); ?></td>
                <td><?php echo e($row['b']); ?></td>
                <td><?php echo e($row['z1']); ?></td>
                <td><?php echo e($row['z2']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\13 Занятие ПД011 11.12.2022 PHP\HW\Сотула Александр\resources\views/calculate/variant13.blade.php ENDPATH**/ ?>