<?php $__env->startSection('text', 'active'); ?>
<?php $__env->startSection('title', 'Обработка текста'); ?>

<?php $__env->startSection('content'); ?>

    <div class="w-100 mt-4">
        <a href="#task" class="btn btn-outline-dark w-100 mb-4" data-bs-toggle="collapse">
            <strong>Задание</strong>
        </a>
        <div id="task" class="collapse">
            В строке, выбираемой из массива строк случайным образом (в массиве не менее 10 строк) определять, сколько в
            ней слов, состоящих не более чем из четырех букв
        </div>
    </div>

    <p class="mt-5"><b>Массив строк для обработки</b></p>
    <?php $__currentLoopData = $text; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="my-0"><?php echo e($s); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <p class="mt-5"><b>Строка для обработки:</b> "<?php echo e($str); ?>"</p>

    <p class="mt-5"><b>Количество слов состоящих не более чем из четырех букв:</b> <?php echo e($count); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Академия Шаг\ПД011\15 PHP\12 Занятие ПД011 10.12.2022 PHP\Сотула Александр\resources\views/calculate/text7.blade.php ENDPATH**/ ?>