<?php

// подключение собственных контроллеров
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CalculateController;

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// путь к действию index в контроллере HomeController
Route::get('/', [HomeController::class, 'index']);
Route::get('/home/index', [HomeController::class, 'index']);

// путь к действию about в контроллере HomeController
Route::get('/home/about', [HomeController::class, 'about']);

// путь к действию calcEquation в контроллере CalculateController
Route::get('/calculate/variant13', [CalculateController::class, 'calcEquation']);

// путь к действию processArray в контроллере CalculateController
Route::get('/calculate/array17', [CalculateController::class, 'processArray']);

// путь к действию processText в контроллере CalculateController
Route::get('/calculate/text7', [CalculateController::class, 'processText']);
