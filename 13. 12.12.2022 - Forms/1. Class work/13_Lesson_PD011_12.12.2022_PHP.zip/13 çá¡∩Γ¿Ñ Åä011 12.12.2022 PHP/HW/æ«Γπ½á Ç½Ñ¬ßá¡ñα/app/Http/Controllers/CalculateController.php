<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CalculateController extends Controller
{

    private const MIN_SIZE = 5;
    private const MAX_SIZE = 10;

    // диапазон значений для генерации
    private const MIN = -10;
    private const MAX = 10;

    // количество итераций вычисления уравнений
    private const COUNT = 5;

    // расчет выраженения
    public function calcEquation()
    {
        // массив для хранения данных
        $arr = [];

        // вычисление
        for ($i = 0; $i < self::COUNT; $i++) {
            // генерация значений для вычислений
            $a = rand(self::MIN, self::MAX);

            $b = rand(self::MIN, self::MAX);

            // формирование массива результатов
            $arr[] = [
                'a' => $a,
                'b' => $b,
                'z1' => $this->calcZ1($a, $b),
                'z2' => $this->calcZ2($b)
            ];
        }

        // возврат представление и передача в него данных
        return view('calculate/variant13', ['result' => $arr]);
    }

    // обработка массива
    public function processArray()
    {
        $result = [];

        $array = array_map(fn() => rand(self::MIN, self::MAX), array_pad([], rand(self::MIN_SIZE, self::MAX_SIZE), 0));
        $result['main'] = $array;

        // количество положительных элементов массива
        $countPositive = count(array_filter($array, fn($value) => $value >= 0));
        $result['count'] = $countPositive;

        // сумма элементов массива, расположенных после последнего элемента, равного нулю
        $pos = array_search(0, $array);
        $sum = $pos ? array_sum(array_slice($array, $pos + 1)) : "Нет нулевых элементов";
        $result['sum'] = $sum;

        // сначала все элементы, равные нулю, а потом — все остальные
        usort($array, fn($x, $y) => $x !== 0 && $y === 0);
        $result['sorted'] = $array;

        return view('calculate/array17', ['result' => $result]);
    } // processArray

    // обработка текста
    public function processText() {
        // массив строк
        $array = [
            "Я вообще не понимаю болезненного пристрастия",
            "всех отрицательных персонажей к чёрному цвету.",
            "Ведь с позиции трезвого расчёта, оденься ты в яркое,",
            "с весёленьким рисунком по ситцу,",
            "так жертва ничего не поймёт и расслабится,",
            "а тебе будет куда легче свершить над ней очередной злодейский умысел, разве нет?",
            "Но все мои знакомые мерзавцы один в один как заведенные",
            "гоняются по ярмаркам и разъездным лавчонкам магов-шарлатанов в",
            "едином порыве – купить себе чёрный плащ, чёрный меч, чёрные доспехи, чёрную обувь…",
            "Штамп на штампе! Интересно, а нижнее бельё у них тоже чёрное?! С резиночками и кружевами…",
        ];

        // строка для обработки
        $str = $array[rand(0, count($array) - 1)];

        // подсчет количества слов, длина которых в диапазоне от 1 до 4 символов
        $count = preg_match_all("/\b[\x{0400}-\x{04FF}]{1,4}\b/u", $str);

        return view('calculate/text7', ['text' => $array, 'str' => $str, 'count' => $count]);
    }

    // вычислить z1
    private function calcZ1(int $a, int $b)
    {
        return (sin($a) + cos(2 * $b - $a)) / (cos($a) - sin(2 * $b - $a));
    }

    // вычислить z2
    private function calcZ2(int $b)
    {
        return (1 + sin(2 * $b)) / cos(2 * $b);
    }
}
