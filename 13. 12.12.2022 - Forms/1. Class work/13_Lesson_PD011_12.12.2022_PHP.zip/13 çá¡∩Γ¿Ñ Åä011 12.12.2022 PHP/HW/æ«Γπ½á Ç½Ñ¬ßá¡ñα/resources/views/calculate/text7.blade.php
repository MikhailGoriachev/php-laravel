@extends('layouts.app')

@section('text', 'active')
@section('title', 'Обработка текста')

@section('content')

    <div class="w-100 mt-4">
        <a href="#task" class="btn btn-outline-dark w-100 mb-4" data-bs-toggle="collapse">
            <strong>Задание</strong>
        </a>
        <div id="task" class="collapse">
            В строке, выбираемой из массива строк случайным образом (в массиве не менее 10 строк) определять, сколько в
            ней слов, состоящих не более чем из четырех букв
        </div>
    </div>

    <p class="mt-5"><b>Массив строк для обработки</b></p>
    @foreach($text as $s)
        <p class="my-0">{{$s}}</p>
    @endforeach

    <p class="mt-5"><b>Строка для обработки:</b> "{{$str}}"</p>

    <p class="mt-5"><b>Количество слов состоящих не более чем из четырех букв:</b> {{$count}}</p>
@endsection
