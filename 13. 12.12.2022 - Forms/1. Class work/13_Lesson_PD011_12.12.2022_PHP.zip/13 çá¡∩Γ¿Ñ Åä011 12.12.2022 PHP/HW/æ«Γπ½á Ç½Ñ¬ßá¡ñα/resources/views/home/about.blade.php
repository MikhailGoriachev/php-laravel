@extends('layouts.app')

@section('about', 'active')
@section('title', 'О приложении')

@section('content')
    <div class="text-center my-5">
        <p><b>Фамилия:</b> {{$data['surname']}}</p>
        <p><b>Имя:</b> {{$data['name']}}</p>
        <p><b>Группа:</b> {{$data['group']}}</p>
        <img class="rounded mx-auto d-block mt-5" src="../img/{{$data['img']}}">
    </div>
@endsection
