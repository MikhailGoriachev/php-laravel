@extends('layouts.app')

@section('equation', 'active')
@section('title', 'Уравнение')

@section('content')

    <div class="w-100 mt-4">
        <a href="#task" class="btn btn-outline-dark w-100 mb-4" data-bs-toggle="collapse">
            <strong>Задание</strong>
        </a>
        <div id="task" class="collapse">
            Выполните вычисления и вывод результатов для 5 случайных пар чисел (выводите также изображение расчетного
            выражения), не используйте модель
        </div>
    </div>

    <img class="rounded mx-auto d-block mt-5" src="../img/task1.jpg" alt="task1">

    <table class="table table-hover w-50 mx-auto mt-5">
        <thead class="text-center">
            <th>&alpha;</th>
            <th>&beta;</th>
            <th>z<sub>1</sub></th>
            <th>z<sub>2</sub></th>
        </thead>
        @foreach($result as $row)
            <tr class="text-center">
                <td>{{$row['a']}}</td>
                <td>{{$row['b']}}</td>
                <td>{{$row['z1']}}</td>
                <td>{{$row['z2']}}</td>
            </tr>
        @endforeach
    </table>
@endsection
