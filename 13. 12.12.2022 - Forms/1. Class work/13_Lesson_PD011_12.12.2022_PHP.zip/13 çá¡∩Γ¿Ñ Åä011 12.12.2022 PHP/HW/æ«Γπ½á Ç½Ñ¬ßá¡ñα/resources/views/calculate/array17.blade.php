@extends('layouts.app')

@section('array', 'active')
@section('title', 'Обработка массива')

@section('content')

    <div class="w-100 mt-4">
        <a href="#task" class="btn btn-outline-dark w-100 mb-4" data-bs-toggle="collapse">
            <strong>Задание</strong>
        </a>
        <div id="task" class="collapse">
            Выполните вычисления и вывода результата для массива случайных целых
            чисел, не используйте модель
            <ul>
                <li>вывести исходный массив</li>
                <li>определите количество положительных элементов массива;</li>
                <li>вычислите сумму элементов массива, расположенных после последнего элемента, равного нулю.</li>
                <li>преобразуйте массив таким образом, чтобы сначала располагались все элементы, равные нулю, а потом —
                    все остальные
                </li>
                <li>вывести преобразованный массив</li>
            </ul>
        </div>
    </div>

    <p class="mt-5"><b>Сгенерированный массив</b></p>
    <table class='w-50 table table-bordered mt-1'>
        <tr>
            @foreach($result['main'] as $item)
                <td>{{$item}}</td>
            @endforeach
        </tr>
    </table>

    <p class="mt-5"><b>Количество положительных элементов: </b>{{$result['count']}}</p>

    <p class="mt-5"><b>Сумма элементов после последнего элемента равного нулю:</b> {{$result['sum']}}</p>

    <p class="mt-5"><b>Преобразованный массив, по правилу сначала все элементы, равные нулю, а потом — все остальные</b>
    </p>
    <table class='w-50 table table-bordered mt-1'>
        <tr>
            @foreach($result['sorted'] as $item)
                <td>{{$item}}</td>
            @endforeach
        </tr>
    </table>
@endsection
