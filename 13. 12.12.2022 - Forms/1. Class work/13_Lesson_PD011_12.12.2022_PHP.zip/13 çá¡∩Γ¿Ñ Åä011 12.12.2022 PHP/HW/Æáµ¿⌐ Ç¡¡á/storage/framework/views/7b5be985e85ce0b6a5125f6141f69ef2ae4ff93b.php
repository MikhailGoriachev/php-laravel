<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <p class="fs-5">Вывести исходный массив:</p>
    <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        &#160; <?php echo e($item); ?>	&#160;
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <p class="fs-5 mt-2">Количество положительных элементов массива: <?php echo e($amount); ?></p>
    <p class="fs-5 mt-2">Сумма элементов массива, расположенных после последнего элемента, равного нулю: <?php echo e($sum); ?></p>

    <p class="fs-5">Сначала располагались все элементы, равные нулю, а потом — все остальные:</p>
    <?php $__currentLoopData = $sorted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        &#160; <?php echo e($item); ?>	&#160;
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\13 Занятие ПД011 11.12.2022 PHP\HW\Таций Анна\resources\views/calculate/array17.blade.php ENDPATH**/ ?>