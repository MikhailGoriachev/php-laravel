<!-- секция контент -->
<?php $__env->startSection('content'); ?>
    <p class="fs-4 m-3" >Выполнила: Таций Анна ВПД011 Донецк 2022</p>

    <img class="mt-2" src=<?php echo e(asset('images/image.jpg')); ?> /> </li>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annat\source\repos\PHP\Step_12.12.22(Таций Анна)_PHP\task01\resources\views/home/about.blade.php ENDPATH**/ ?>