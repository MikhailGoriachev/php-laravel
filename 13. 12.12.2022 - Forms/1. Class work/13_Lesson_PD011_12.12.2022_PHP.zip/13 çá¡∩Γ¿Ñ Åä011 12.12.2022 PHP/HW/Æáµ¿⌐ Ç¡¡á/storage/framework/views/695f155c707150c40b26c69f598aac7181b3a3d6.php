<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <img class="mt-2" src=<?php echo e(asset('images/image.png')); ?> /> </li>


    <table class="table">
        <thead>
            <tr>
                <th>α</th>
                <th>β</th>
                <th>z1</th>
                <th>z2</th>
            </tr>
        </thead>
        <tbody>
        <?php for($i = 0; $i < 20; $i+=4): ?>
            <tr>
                <td><?php echo e($arr[$i]); ?></td>
                <td><?php echo e($arr[$i+1]); ?></td>
                <td><?php echo e($arr[$i+2]); ?></td>
                <td><?php echo e($arr[$i+3]); ?></td>
            </tr>
        <?php endfor; ?>

        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annat\source\repos\PHP\Step_12.12.22(Таций Анна)_PHP\task01\resources\views/calculate/variant13.blade.php ENDPATH**/ ?>