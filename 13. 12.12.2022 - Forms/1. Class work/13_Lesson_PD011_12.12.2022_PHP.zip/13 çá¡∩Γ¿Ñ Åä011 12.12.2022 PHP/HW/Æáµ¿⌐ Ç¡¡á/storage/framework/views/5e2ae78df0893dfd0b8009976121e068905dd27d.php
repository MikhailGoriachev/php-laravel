<html lang="ru">
<head>
    <title>Step_12_12_22</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- подключение bootstrap локально -->
    <link rel="stylesheet" href=<?php echo e(asset('lib/css/bootstrap.min.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(asset('css/style.css')); ?>>

    <script src="<?php echo e(asset('lib/js/bootstrap.min.js')); ?>"></script>
</head>
<body  class="antialiased">

<?php $__env->startSection('header'); ?>

    <nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
        <div class="container-fluid">
            <div style="width: 70%; margin: auto;">
                <div class="navbar-collapse" id="appNavbar-1">
                    <ul class="navbar-nav fs-4">
                        <li class="nav-item pt-1">
                            <a class="nav-link active" href="/">Страница с заданием</a>
                        </li>

                        <li class="nav-item pt-1">
                            <a class="nav-link" href="/home/about">О разработчике</a>
                        </li>

                        <li class="nav-item pt-1">
                            <a class="nav-link" href="/calculate/variant13">Variant13</a>
                        </li>

                        <li class="nav-item pt-1">
                            <a class="nav-link" href="/calculate/array17">Array17</a>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </nav>

<?php echo $__env->yieldSection(); ?>

<main class="container-fluid">

    <div class="row-sm mt-5 p-3 container-fluid-style">

        <div class="p-4 bg-white m-3 border-warning-top border-warning-bottom">

<!-- контент страницы -->
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
        </div>

    </div>

</main>

<?php $__env->startSection('footer'); ?>
    <div class="mt-5 p-3 bg-dark text-white-50 text-center footer">
        <p>Выполнила: Таций Анна ВПД011 Донецк 2022</p>
    </div>
<?php echo $__env->yieldSection(); ?>

</body>
</html>

<?php /**PATH C:\Users\annat\source\repos\PHP\Step_12.12.22(Таций Анна)_PHP\task01\resources\views/layouts/app.blade.php ENDPATH**/ ?>