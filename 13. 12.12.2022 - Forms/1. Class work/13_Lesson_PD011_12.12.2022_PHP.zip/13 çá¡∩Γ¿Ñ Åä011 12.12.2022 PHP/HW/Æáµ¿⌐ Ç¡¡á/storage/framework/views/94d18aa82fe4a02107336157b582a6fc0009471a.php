<?php
 ?><?php /**PATH C:\Users\annat\source\repos\PHP\Step_12.12.22(Таций Анна)_PHP\task01\resources\views/index.blade.php ENDPATH**/ ?>