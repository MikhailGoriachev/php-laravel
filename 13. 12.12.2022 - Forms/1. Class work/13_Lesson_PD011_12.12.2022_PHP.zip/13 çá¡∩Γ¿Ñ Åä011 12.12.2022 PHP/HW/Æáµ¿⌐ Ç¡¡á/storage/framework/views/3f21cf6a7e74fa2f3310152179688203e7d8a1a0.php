<!-- секция контент -->
<?php $__env->startSection('content'); ?>

    <img class="mt-2" src=<?php echo e(asset('images/image.png')); ?> /> </li>


    <table class="table">
        <thead>
            <tr>
                <th>α</th>
                <th>β</th>
                <th>z1</th>
                <th>z2</th>
            </tr>
        </thead>
        <tbody>








        <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($datum[0]); ?></td>
                <td><?php echo e($datum[1]); ?></td>
                <td><?php echo e($datum[2]); ?></td>
                <td><?php echo e($datum[3]); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\13 Занятие ПД011 11.12.2022 PHP\HW\Таций Анна\resources\views/calculate/variant13.blade.php ENDPATH**/ ?>