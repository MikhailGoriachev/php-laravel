@extends('layouts.app')

<!-- секция контент -->
@section('content')

    <img class="mt-2" src={{ asset('images/image.png') }} /> </li>


    <table class="table">
        <thead>
            <tr>
                <th>α</th>
                <th>β</th>
                <th>z1</th>
                <th>z2</th>
            </tr>
        </thead>
        <tbody>
{{--        @for($i = 0; $i < count($arr)/4; $i++)--}}
{{--            <tr>--}}
{{--                <td>{{$arr[$i++]}}</td>--}}
{{--                <td>{{$arr[$i++]}}</td>--}}
{{--                <td>{{$arr[$i++]}}</td>--}}
{{--                <td>{{$arr[$i]}}</td>--}}
{{--            </tr>--}}
{{--        @endfor        --}}
        @foreach($arr as $datum)
            <tr>
                <td>{{$datum[0]}}</td>
                <td>{{$datum[1]}}</td>
                <td>{{$datum[2]}}</td>
                <td>{{$datum[3]}}</td>
            </tr>
        @endforeach

        </tbody>
    </table>

@endsection
