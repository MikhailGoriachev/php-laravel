@extends('layouts.app')

<!-- секция контент -->
@section('content')

    <p class="fs-5">Вывести исходный массив:</p>
    @foreach($arr as $item)
        &#160; {{$item}}	&#160;
    @endforeach

    <p class="fs-5 mt-2">Количество положительных элементов массива: {{$amount}}</p>
    <p class="fs-5 mt-2">Сумма элементов массива, расположенных после последнего элемента, равного нулю: {{$sum}}</p>

    <p class="fs-5">Сначала располагались все элементы, равные нулю, а потом — все остальные:</p>
    @foreach($sorted as $item)
        &#160; {{$item}}	&#160;
    @endforeach

@endsection
