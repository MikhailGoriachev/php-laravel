@extends('layouts.app')

<!-- секция контент -->
@section('content')
    <p class="fs-4 m-3" >Выполнила: Таций Анна ВПД011 Донецк 2022</p>

    <img class="mt-2" src={{ asset('images/image.jpg') }} />

@endsection
