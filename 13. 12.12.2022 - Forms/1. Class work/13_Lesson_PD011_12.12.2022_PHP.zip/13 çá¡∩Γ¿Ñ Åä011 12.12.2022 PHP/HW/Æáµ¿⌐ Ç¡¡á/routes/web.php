<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\CalculateController;
use Illuminate\Support\Facades\Route;

Route::get('/calculate/variant13', [ CalculateController::class, 'variant13' ]);
Route::get('/calculate/array17', [ CalculateController::class, 'array17' ]);

// путь к действию about  контроллера home
Route::get('/home/about', [ HomeController::class, 'about' ]);

// путь к действию index контроллера home
Route::get('/', [ HomeController::class, 'index' ]);
