<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CalculateController extends Controller
{
    public function variant13() {

        $arr = [];

        for($i = 0; $i < 5; $i++){

            $a = rand(-10, 10);
            $b = rand(-10, 10);

            $z1 = (sin($a)+cos(2*$b-$a))/(cos($a) - sin(2*$b - $a));
            $z2 = (1+sin(2*$b))/(cos(2*$b));

            // array_push($arr, $a, $b, $z1, $z2);
            array_push($arr, [$a, $b, $z1, $z2]);
        }

        return view('calculate/variant13',['arr'=>$arr]);
    } // index

    public function array17(){

        $arr = [];

        for($i = 0; $i < rand(6, 12); $i++){
            $arr[] = rand(-2, 2);
        }

        //количество положительных элементов массива
        $count = array_filter($arr,fn($a) => $a >= 0);

        //вычислите сумму элементов массива, расположенных после последнего элемента, равного нулю.
        $arr01 = array_reverse($arr);
        $index = array_search(0,$arr01);
        array_splice($arr01,$index);
        $sum = array_sum($arr01);

        $sorted = $arr;

        usort($sorted,fn($a) => $a == 0 ? -1: 1);

        return view('calculate/array17',['arr'=>$arr,'amount' => sizeof($count),'sum' => $sum, 'sorted'=> $sorted]);
    }
}
