﻿

<?php $__env->startSection('title', 'Массивы'); ?>

<?php $__env->startSection('content'); ?>
    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">
        <h4 class="text-center">Массивы</h4>

        <?php echo e($showArrayFn($sourceArray, 'Исходный массив')); ?>


        <?php echo e($showArrayFn($sourceArray, "Количество положительных элеменетов $countPositiveItems",
            fn($n) => $n > 0 ? 'bg-primary text-white' : '')); ?>


        <?php echo e($showArrayFn($sourceArray, "Количество положительных элеменетов $countPositiveItems",
            fn($n) => $n === 0 ? 'bg-success text-white' : '')); ?>


        <?php echo e($showArrayFn($sortArray, "Сортировка по правилу: нули в начале",
            fn($n) => $n === 0 ? 'bg-success text-white' : '')); ?>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\12. 10.12.2022 -\2. Home work\home-work\resources\views/calculate/array17.blade.php ENDPATH**/ ?>