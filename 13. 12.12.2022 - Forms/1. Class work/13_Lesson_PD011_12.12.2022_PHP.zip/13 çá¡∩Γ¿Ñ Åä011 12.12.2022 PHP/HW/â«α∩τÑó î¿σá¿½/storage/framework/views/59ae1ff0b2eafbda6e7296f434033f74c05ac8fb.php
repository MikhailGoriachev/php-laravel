﻿

<?php $__env->startSection('title', 'Текст'); ?>

<?php $__env->startSection('content'); ?>
    <section class="mx-5 my-4 bg-light shadow-sm border rounded-3 min-vh-100 p-3">
        <h4>Текст. Количество слов из 4 букв: <?php echo e($amountWordsFourLetters); ?></h4>

        <div class="border shadow-sm">
            <p><?php echo e($str); ?></p>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\01. Programming\16. PHP\12. 10.12.2022 -\2. Home work\home-work\resources\views/calculate/text7.blade.php ENDPATH**/ ?>