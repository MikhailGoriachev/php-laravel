<?php $__env->startSection('active_form2', 'active'); ?>

<!-- секция контент -->
<?php $__env->startSection('main_part'); ?>

    <h4>Получен идентфиикатор <?php echo e($id); ?></h4>

    <h4>Данные из формы ввода, полученные по POST-запросу от form2</h4>
    <ul>
        <li>Полное имя: <?php echo e($fullName); ?></li>
        <li>Возраст: <?php echo e($age); ?></li>
        <li>Подготвка: <?php echo e($skill); ?></li>
        <li>Сертифицирован: <?php echo e($certified?"да":"нет"); ?></li>
    </ul>

    <h4>Данные из массива ввода</h4>
    <ul>
        <li>Полное имя: <?php echo e($data['fullName']); ?></li>
        <li>Возраст: <?php echo e($data['age']); ?></li>
        <li>Подготвка: <?php echo e($data['skill']); ?></li>
        <li>Сертифицирован: <?php echo e($data['certified']?"да":"нет"); ?></li>
    </ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Students\ПД011\15 PHP\13 Занятие ПД011 11.12.2022 PHP\CW\app-blade-forms\resources\views/post/handle2.blade.php ENDPATH**/ ?>